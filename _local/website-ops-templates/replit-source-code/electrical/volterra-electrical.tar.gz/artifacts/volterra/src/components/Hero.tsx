import { motion } from "framer-motion";
import { ArrowRight, ShieldCheck, Clock, Award, CheckCircle } from "lucide-react";
import { useEffect, useState } from "react";

const Counter = ({ end, duration = 2 }: { end: number, duration?: number }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let startTime: number | null = null;
    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / (duration * 1000), 1);
      
      // Easing out
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      setCount(Math.floor(easeOutQuart * end));
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    requestAnimationFrame(animate);
  }, [end, duration]);

  return <span>{count}</span>;
};

export function Hero() {
  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-background to-background"></div>
        
        {/* Animated Lines/Circuit Board Effect */}
        <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(59, 130, 246, 0.2)" strokeWidth="1"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
          <motion.path 
            d="M 0 120 Q 200 120 400 200 T 800 160 T 1200 240" 
            fill="none" 
            stroke="rgba(59, 130, 246, 0.5)" 
            strokeWidth="2"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{ duration: 3, ease: "easeInOut", repeat: Infinity, repeatType: "reverse" }}
          />
          <motion.path 
            d="M -100 300 Q 300 400 500 250 T 1000 350" 
            fill="none" 
            stroke="rgba(59, 130, 246, 0.3)" 
            strokeWidth="1.5"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{ duration: 4, ease: "easeInOut", repeat: Infinity, repeatType: "reverse", delay: 1 }}
          />
        </svg>

        {/* Particles */}
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-primary rounded-full"
              initial={{
                x: Math.random() * window.innerWidth,
                y: Math.random() * window.innerHeight,
                opacity: Math.random() * 0.5 + 0.2,
                scale: Math.random() * 0.5 + 0.5,
              }}
              animate={{
                y: [null, Math.random() * window.innerHeight],
                opacity: [null, Math.random() * 0.8 + 0.2, 0],
              }}
              transition={{
                duration: Math.random() * 10 + 10,
                repeat: Infinity,
                ease: "linear",
              }}
            />
          ))}
        </div>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex items-center gap-2 mb-6"
          >
            <span className="w-12 h-0.5 bg-primary"></span>
            <span className="text-primary font-semibold tracking-wider uppercase text-sm">PREMIUM ELECTRICAL SERVICES</span>
          </motion.div>
          
          <motion.h1 
            className="text-5xl md:text-7xl lg:text-8xl font-display font-bold leading-tight mb-8 text-white text-glow"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            Powering Homes.<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-cyan-400">Energizing Futures.</span>
          </motion.h1>
          
          <motion.p 
            className="text-xl md:text-2xl text-white/70 mb-10 max-w-2xl font-light"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            Certified electricians delivering safe, reliable, and innovative electrical solutions. Showroom-quality results for those who demand the best.
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 mb-20"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            <button 
              onClick={() => scrollTo("contact")}
              className="bg-primary hover:bg-primary/90 text-white px-8 py-4 rounded-lg font-bold text-lg flex items-center justify-center gap-2 transition-all glow-hover"
            >
              Request Service <ArrowRight className="w-5 h-5" />
            </button>
            <a 
              href="tel:+15552478830"
              className="bg-white/5 hover:bg-white/10 border border-white/10 text-white px-8 py-4 rounded-lg font-bold text-lg flex items-center justify-center transition-all"
            >
              Call Now
            </a>
          </motion.div>

          <motion.div 
            className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-10 border-t border-white/10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
          >
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2 text-primary">
                <CheckCircle className="w-5 h-5" />
                <span className="text-2xl font-bold font-display"><Counter end={500} />+</span>
              </div>
              <span className="text-sm text-white/60 uppercase tracking-wider font-semibold">Projects Completed</span>
            </div>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2 text-primary">
                <Award className="w-5 h-5" />
                <span className="text-2xl font-bold font-display"><Counter end={15} />+</span>
              </div>
              <span className="text-sm text-white/60 uppercase tracking-wider font-semibold">Years Experience</span>
            </div>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2 text-primary">
                <Clock className="w-5 h-5" />
                <span className="text-2xl font-bold font-display">24/7</span>
              </div>
              <span className="text-sm text-white/60 uppercase tracking-wider font-semibold">Emergency Service</span>
            </div>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2 text-primary">
                <ShieldCheck className="w-5 h-5" />
                <span className="text-2xl font-bold font-display">100%</span>
              </div>
              <span className="text-sm text-white/60 uppercase tracking-wider font-semibold">Licensed & Insured</span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
