import { motion } from "framer-motion";
import { ArrowUpRight, Zap, Home, Building2 } from "lucide-react";

const projects = [
  {
    title: "Modern Service Upgrade",
    description: "Complete 200A panel replacement with whole-home surge protection.",
    category: "Residential",
    gradient: "from-blue-950 via-blue-900 to-slate-900",
    accent: "from-blue-500/30 to-cyan-500/10",
    Icon: Home,
    stats: "200A Panel · Surge Protection · Code Compliant"
  },
  {
    title: "Luxury Smart Home",
    description: "Integrated Lutron lighting and automated climate control system.",
    category: "Smart Systems",
    gradient: "from-slate-900 via-indigo-950 to-slate-900",
    accent: "from-indigo-500/30 to-blue-500/10",
    Icon: Zap,
    stats: "Lutron · Voice Control · 42 Zones"
  },
  {
    title: "Commercial Warehouse",
    description: "High-bay LED lighting and exposed conduit installation across 18,000 sq ft.",
    category: "Commercial",
    gradient: "from-slate-900 via-cyan-950 to-slate-900",
    accent: "from-cyan-500/20 to-blue-500/10",
    Icon: Building2,
    stats: "18,000 sq ft · LED Retrofit · NEC 2023"
  }
];

export function Projects() {
  return (
    <section id="projects" className="py-24 bg-card/30 border-y border-white/5">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <motion.div
            className="max-w-2xl"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-primary font-semibold tracking-wider uppercase text-sm mb-3">Featured Work</h2>
            <h3 className="text-3xl md:text-5xl font-display font-bold text-white">Precision in Practice</h3>
          </motion.div>
          <motion.p
            className="text-white/50 max-w-xs text-sm"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            A selection of recent work across residential, smart home, and commercial sectors.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {projects.map((project, index) => {
            const Icon = project.Icon;
            return (
              <motion.div
                key={index}
                data-testid={`card-project-${index}`}
                className="group relative rounded-2xl overflow-hidden aspect-[4/5] cursor-pointer border border-white/5 hover:border-primary/40 transition-colors duration-500"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.15 }}
                whileHover={{ y: -6 }}
              >
                {/* Background */}
                <div className={`absolute inset-0 bg-gradient-to-br ${project.gradient}`} />

                {/* Glow accent */}
                <div className={`absolute inset-0 bg-gradient-to-br ${project.accent} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />

                {/* Circuit grid overlay */}
                <div className="absolute inset-0 circuit-grid opacity-30" />

                {/* Animated electric line */}
                <svg className="absolute inset-0 w-full h-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 400 500">
                  <motion.path
                    d="M 0 300 Q 120 200 240 300 T 400 200"
                    fill="none"
                    stroke="rgba(59, 130, 246, 0.4)"
                    strokeWidth="1"
                    initial={{ pathLength: 0 }}
                    whileInView={{ pathLength: 1 }}
                    transition={{ duration: 1.5, ease: "easeInOut" }}
                  />
                </svg>

                {/* Category badge */}
                <div className="absolute top-6 left-6">
                  <span className="px-3 py-1 bg-primary/20 border border-primary/30 rounded-full text-xs font-bold text-primary tracking-wider uppercase">
                    {project.category}
                  </span>
                </div>

                {/* Center icon */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <motion.div
                    className="w-24 h-24 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center group-hover:bg-primary/20 group-hover:border-primary/50 transition-all duration-500"
                    whileHover={{ scale: 1.1 }}
                  >
                    <Icon className="w-12 h-12 text-primary/70 group-hover:text-primary transition-colors duration-300" />
                  </motion.div>
                </div>

                {/* Bottom content */}
                <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-background via-background/80 to-transparent">
                  <p className="text-xs text-primary/70 font-semibold mb-1 tracking-wider">
                    {project.stats}
                  </p>
                  <h4 className="text-2xl font-display font-bold text-white mb-2">{project.title}</h4>
                  <p className="text-white/60 text-sm mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100">
                    {project.description}
                  </p>
                  <div className="flex items-center gap-2 text-primary font-bold text-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-150">
                    <span className="text-glow">View Project</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </div>

                {/* Electric border glow on hover */}
                <div className="absolute inset-0 rounded-2xl shadow-[inset_0_0_0_1px_rgba(59,130,246,0)] group-hover:shadow-[inset_0_0_0_1px_rgba(59,130,246,0.4)] transition-shadow duration-500 pointer-events-none" />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
