import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { MapPin, Phone, Mail, Clock, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters."),
  email: z.string().email("Please enter a valid email address."),
  phone: z.string().min(10, "Please enter a valid phone number."),
  serviceType: z.string({ required_error: "Please select a service type." }),
  message: z.string().min(10, "Please provide more details about your project.")
});

export function Contact() {
  const { toast } = useToast();
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: ""
    }
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    console.log(values);
    toast({
      title: "Request Received",
      description: "We'll get back to you shortly to confirm your service appointment.",
    });
    form.reset();
  }

  return (
    <section id="contact" className="py-24 bg-card/80 border-y border-white/5">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16">
          
          {/* Left Column: Info */}
          <motion.div 
            className="lg:w-5/12 flex flex-col"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-primary font-semibold tracking-wider uppercase text-sm mb-3">Get in Touch</h2>
            <h3 className="text-3xl md:text-5xl font-display font-bold text-white mb-8">Ready to Power Up?</h3>
            <p className="text-white/60 mb-10 text-lg">
              Contact us today for a consultation or emergency service. Our licensed experts are standing by.
            </p>
            
            <div className="space-y-6 mb-12 flex-grow">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center shrink-0 border border-primary/20">
                  <MapPin className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="text-white font-semibold text-lg">Headquarters</h4>
                  <p className="text-white/60 mt-1">1400 Energy Drive, Suite 200<br/>San Francisco, CA 94103</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center shrink-0 border border-primary/20">
                  <Phone className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="text-white font-semibold text-lg">Direct Line</h4>
                  <p className="text-white/60 mt-1">(555) 247-8830<br/>24/7 Emergency Dispatch Available</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center shrink-0 border border-primary/20">
                  <Mail className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="text-white font-semibold text-lg">Email</h4>
                  <p className="text-white/60 mt-1">service@volterraelectrical.com</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center shrink-0 border border-primary/20">
                  <Clock className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="text-white font-semibold text-lg">Operating Hours</h4>
                  <p className="text-white/60 mt-1">Monday - Friday: 7am - 6pm<br/>Weekends & Emergencies: 24/7</p>
                </div>
              </div>
            </div>

            {/* Stylized Map Placeholder */}
            <div className="w-full h-48 rounded-xl bg-background border border-white/10 circuit-grid relative overflow-hidden flex items-center justify-center mt-auto">
              <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent z-0"></div>
              <div className="absolute inset-0 bg-primary/5"></div>
              <div className="relative z-10 flex items-center gap-2 px-4 py-2 bg-card border border-primary/20 rounded-full">
                 <MapPin className="w-4 h-4 text-primary" />
                 <span className="text-sm font-semibold text-white">View on Map</span>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Form */}
          <motion.div 
            className="lg:w-7/12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="bg-background border border-white/10 rounded-2xl p-8 md:p-10 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-[80px] pointer-events-none"></div>
              
              <h3 className="text-2xl font-display font-bold text-white mb-6 relative z-10">Request a Service Quote</h3>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 relative z-10">
                  <div className="grid md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white/80">Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" className="bg-card/50 border-white/10 focus-visible:ring-primary text-white" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white/80">Phone Number</FormLabel>
                          <FormControl>
                            <Input placeholder="(555) 000-0000" className="bg-card/50 border-white/10 focus-visible:ring-primary text-white" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white/80">Email Address</FormLabel>
                        <FormControl>
                          <Input placeholder="john@example.com" className="bg-card/50 border-white/10 focus-visible:ring-primary text-white" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="serviceType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white/80">Service Required</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-card/50 border-white/10 focus:ring-primary text-white">
                              <SelectValue placeholder="Select a service type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-card border-white/10 text-white">
                            <SelectItem value="residential">Residential Service / Upgrade</SelectItem>
                            <SelectItem value="commercial">Commercial Wiring</SelectItem>
                            <SelectItem value="smart_home">Smart Home Integration</SelectItem>
                            <SelectItem value="emergency">Emergency Repair</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white/80">Project Details</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Please describe your issue or project requirements..." 
                            className="min-h-[120px] bg-card/50 border-white/10 focus-visible:ring-primary text-white resize-none" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-white py-6 text-lg font-bold glow-hover">
                    Submit Request <Send className="w-5 h-5 ml-2" />
                  </Button>
                </form>
              </Form>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
