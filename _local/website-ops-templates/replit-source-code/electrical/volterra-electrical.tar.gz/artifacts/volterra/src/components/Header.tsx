import { useState, useEffect } from "react";
import { motion, useScroll, useMotionValueEvent } from "framer-motion";
import { Zap } from "lucide-react";

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (latest) => {
    setIsScrolled(latest > 50);
  });

  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <motion.header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-background/80 backdrop-blur-md border-b border-white/5 py-4"
          : "bg-transparent py-6"
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container mx-auto px-6 flex items-center justify-between">
        <div 
          className="flex items-center gap-2 cursor-pointer"
          onClick={() => scrollTo("hero")}
        >
          <div className="bg-primary/20 p-2 rounded-lg">
            <Zap className="w-6 h-6 text-primary" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight text-white">
            VOLTERRA
          </span>
        </div>

        <nav className="hidden md:flex items-center gap-8">
          {["Services", "Projects", "Testimonials", "Contact"].map((item) => (
            <button
              key={item}
              onClick={() => scrollTo(item.toLowerCase())}
              className="text-sm font-medium text-white/70 hover:text-primary transition-colors"
            >
              {item}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <a
            href="tel:+15552478830"
            className="hidden sm:flex items-center gap-2 text-sm font-bold text-white hover:text-primary transition-colors"
          >
            (555) 247-8830
          </a>
          <button 
            onClick={() => scrollTo("contact")}
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-5 py-2.5 rounded-md font-semibold text-sm transition-all glow-hover"
          >
            Request Service
          </button>
        </div>
      </div>
    </motion.header>
  );
}
