import { motion } from "framer-motion";
import { Star } from "lucide-react";

const testimonials = [
  {
    name: "David Chen",
    role: "Homeowner",
    quote: "Volterra upgraded our 1950s panel to a modern 200A system. The technicians were incredibly clean, respectful of our space, and the final wiring job looks like a work of art. Absolute professionals."
  },
  {
    name: "Sarah Jenkins",
    role: "Business Owner",
    quote: "When our restaurant's main breaker failed during a weekend dinner rush, they were here in 45 minutes. They accurately diagnosed the fault and had us running before we lost our inventory. Lifesavers."
  },
  {
    name: "Marcus Rodriguez",
    role: "Real Estate Developer",
    quote: "I've worked with dozens of electrical contractors, but Volterra is in a league of their own. Their smart home integration work on our recent luxury build was flawless. They are my permanent go-to."
  },
  {
    name: "Emily Thorne",
    role: "Homeowner",
    quote: "They installed our EV charger and ran new lines for a hot tub. Transparent pricing, no hidden fees, and the inspector specifically complimented the quality of the electrical work."
  }
];

export function Testimonials() {
  return (
    <section id="testimonials" className="py-24 bg-background relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute left-0 top-1/2 -translate-y-1/2 w-64 h-64 bg-primary/5 rounded-full blur-[100px] pointer-events-none"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div 
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-primary font-semibold tracking-wider uppercase text-sm mb-3">Client Trust</h2>
          <h3 className="text-3xl md:text-5xl font-display font-bold text-white">Reputation Built on Results</h3>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
          {testimonials.map((t, index) => (
            <motion.div
              key={index}
              className="bg-card/50 border border-white/5 p-8 rounded-2xl relative"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="flex gap-1 text-primary mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-primary" />
                ))}
              </div>
              <p className="text-lg text-white/80 mb-8 font-light italic leading-relaxed">
                "{t.quote}"
              </p>
              <div className="flex items-center gap-4 mt-auto">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center border border-primary/20 text-primary font-bold font-display">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <h5 className="text-white font-bold">{t.name}</h5>
                  <span className="text-sm text-white/50">{t.role}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
