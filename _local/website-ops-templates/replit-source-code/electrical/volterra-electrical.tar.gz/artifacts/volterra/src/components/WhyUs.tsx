import { motion } from "framer-motion";
import { ShieldCheck, Zap, History, BadgeDollarSign } from "lucide-react";

export function WhyUs() {
  const benefits = [
    {
      icon: ShieldCheck,
      title: "Licensed & Insured",
      description: "Full liability coverage and state certifications. We protect your property as if it were our own, guaranteeing peace of mind on every job."
    },
    {
      icon: Zap,
      title: "Fast Response",
      description: "Same-day service availability for critical issues. Our fully-stocked fleet is dispatched rapidly to minimize your downtime."
    },
    {
      icon: History,
      title: "15+ Years Experience",
      description: "Decades of master-level craftsmanship. We've seen it all, solved it all, and continually adapt to the latest electrical code and technologies."
    },
    {
      icon: BadgeDollarSign,
      title: "Transparent Pricing",
      description: "No hidden fees, no surprise invoices. We provide detailed, upfront estimates before any work begins, so you're always in control."
    }
  ];

  return (
    <section className="py-24 bg-background relative">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          
          <motion.div 
            className="lg:w-1/2"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-primary font-semibold tracking-wider uppercase text-sm mb-3">Why Choose Volterra</h2>
            <h3 className="text-3xl md:text-5xl font-display font-bold text-white mb-6 leading-tight">
              The Standard in <br/>Electrical Excellence
            </h3>
            <p className="text-lg text-white/60 mb-8 leading-relaxed">
              We aren't just contractors; we are dedicated professionals committed to elevating the safety and functionality of your space. Our clean vans, uniformed technicians, and meticulous attention to detail set us apart from the rest.
            </p>
            
            <div className="flex items-center gap-4 p-6 bg-card border border-white/5 rounded-2xl">
              <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-8 h-8 text-primary" />
              </div>
              <div>
                <h5 className="text-white font-bold text-lg mb-1">Our Safety Guarantee</h5>
                <p className="text-sm text-white/60">Every project undergoes a rigorous multi-point safety inspection before we consider it complete.</p>
              </div>
            </div>
          </motion.div>

          <div className="lg:w-1/2 w-full">
            <div className="grid sm:grid-cols-2 gap-6">
              {benefits.map((benefit, index) => (
                <motion.div 
                  key={index}
                  className="bg-card border border-white/5 p-6 rounded-2xl relative overflow-hidden group"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-[40px] group-hover:bg-primary/10 transition-colors"></div>
                  <benefit.icon className="w-10 h-10 text-primary mb-4 relative z-10" />
                  <h4 className="text-white font-bold text-lg mb-2 relative z-10">{benefit.title}</h4>
                  <p className="text-sm text-white/50 relative z-10">{benefit.description}</p>
                </motion.div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
