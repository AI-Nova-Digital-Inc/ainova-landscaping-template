import { motion } from "framer-motion";
import { Home, Zap, Cpu, Wrench } from "lucide-react";

const services = [
  {
    icon: Home,
    title: "Residential Wiring",
    description: "Comprehensive home wiring services from new construction to renovations. We ensure your home's electrical backbone is safe, modern, and code-compliant."
  },
  {
    icon: Zap,
    title: "Panel Upgrades",
    description: "Modernize your power capacity with 200A+ panel upgrades. Essential for safely integrating EV chargers, hot tubs, and high-draw modern appliances."
  },
  {
    icon: Cpu,
    title: "Smart Home Systems",
    description: "Transform your living space with intelligent automation, custom lighting scenes, and integrated voice control systems designed for luxury living."
  },
  {
    icon: Wrench,
    title: "Emergency Repairs",
    description: "When the unexpected happens, our 24/7 rapid response team is ready. Fast, accurate fault finding to restore your power safely and efficiently."
  }
];

export function Services() {
  return (
    <section id="services" className="py-24 bg-card/50 border-y border-white/5 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-primary/5 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="container mx-auto px-6 relative z-10">
        <motion.div 
          className="text-center max-w-3xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-primary font-semibold tracking-wider uppercase text-sm mb-3">Our Expertise</h2>
          <h3 className="text-3xl md:text-5xl font-display font-bold text-white mb-6">Uncompromising Quality in Every Connection</h3>
          <p className="text-lg text-white/60">
            From essential safety upgrades to cutting-edge smart home integrations, our certified team delivers precision and reliability.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={index}
                className="bg-background border border-white/10 rounded-2xl p-8 hover:bg-card transition-all duration-300 group hover:-translate-y-2 hover:shadow-[0_0_30px_rgba(59,130,246,0.15)] hover:border-primary/30 cursor-default"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="w-14 h-14 bg-card border border-white/5 rounded-xl flex items-center justify-center mb-6 group-hover:bg-primary/20 group-hover:text-primary group-hover:border-primary/50 transition-all duration-300">
                  <Icon className="w-7 h-7 text-white/80 group-hover:text-primary transition-colors" />
                </div>
                <h4 className="text-xl font-bold text-white mb-3 font-display">{service.title}</h4>
                <p className="text-white/60 leading-relaxed text-sm">
                  {service.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
