import { Zap } from "lucide-react";
import { FaFacebook, FaInstagram, FaLinkedin } from "react-icons/fa";

export function Footer() {
  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-background pt-20 pb-10 border-t border-white/5">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          <div className="col-span-1 md:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2 mb-6">
              <div className="bg-primary/20 p-2 rounded-lg">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <span className="font-display font-bold text-xl tracking-tight text-white">
                VOLTERRA
              </span>
            </div>
            <p className="text-white/50 text-sm leading-relaxed mb-6 max-w-xs">
              Premium residential and commercial electrical services. We deliver safety, reliability, and innovation to every project, large or small.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-card border border-white/10 flex items-center justify-center text-white/70 hover:bg-primary hover:text-white hover:border-primary transition-all">
                <FaFacebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-card border border-white/10 flex items-center justify-center text-white/70 hover:bg-primary hover:text-white hover:border-primary transition-all">
                <FaInstagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-card border border-white/10 flex items-center justify-center text-white/70 hover:bg-primary hover:text-white hover:border-primary transition-all">
                <FaLinkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 font-display">Quick Links</h4>
            <ul className="space-y-3">
              {["Hero", "Services", "Projects", "Testimonials", "Contact"].map((item) => (
                <li key={item}>
                  <button 
                    onClick={() => scrollTo(item.toLowerCase())}
                    className="text-white/60 hover:text-primary transition-colors text-sm"
                  >
                    {item === "Hero" ? "Home" : item}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 font-display">Services</h4>
            <ul className="space-y-3">
              <li className="text-white/60 text-sm">Residential Wiring</li>
              <li className="text-white/60 text-sm">Commercial Systems</li>
              <li className="text-white/60 text-sm">Panel Upgrades</li>
              <li className="text-white/60 text-sm">Smart Home Automation</li>
              <li className="text-white/60 text-sm">EV Charger Installation</li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 font-display">Certifications</h4>
            <div className="space-y-4">
              <div className="bg-card/50 border border-white/5 px-4 py-3 rounded-lg flex items-center gap-3">
                <ShieldIcon className="w-6 h-6 text-primary" />
                <div>
                  <div className="text-white text-xs font-bold">State Licensed</div>
                  <div className="text-white/40 text-[10px]">#ELEC-849302</div>
                </div>
              </div>
              <div className="bg-card/50 border border-white/5 px-4 py-3 rounded-lg flex items-center gap-3">
                <ShieldIcon className="w-6 h-6 text-primary" />
                <div>
                  <div className="text-white text-xs font-bold">Fully Insured</div>
                  <div className="text-white/40 text-[10px]">Liability & Worker's Comp</div>
                </div>
              </div>
            </div>
          </div>

        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-white/40 text-sm">
            © {new Date().getFullYear()} Volterra Electrical. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm text-white/40">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

function ShieldIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2-1 4-2 7-2 2.89 0 5.09 1 7.21 2a1 1 0 0 1 .79 1z" />
    </svg>
  );
}
