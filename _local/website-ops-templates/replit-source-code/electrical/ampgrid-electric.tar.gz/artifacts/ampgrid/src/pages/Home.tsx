import { motion } from "framer-motion";
import { Link } from "wouter";
import { Phone, Zap, AlertTriangle, ShieldCheck, Clock, CheckCircle2, ChevronRight, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary selection:text-primary-foreground">
      {/* Floating CTA */}
      <motion.div 
        className="fixed bottom-6 right-6 z-50"
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <a href="tel:5552473600">
          <Button size="lg" className="rounded-full shadow-lg shadow-primary/20 h-14 px-6 text-lg font-bold">
            <Phone className="mr-2 h-5 w-5" />
            Call Now
          </Button>
        </a>
      </motion.div>

      {/* Sticky Header */}
      <header className="fixed top-0 left-0 right-0 z-40 bg-background/80 backdrop-blur-lg border-b border-border">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Zap className="h-8 w-8 text-primary fill-primary" />
            <span className="font-display text-2xl font-bold uppercase tracking-wider">AmpGrid Electric</span>
          </Link>
          
          <nav className="hidden md:flex items-center gap-8 font-medium">
            <a href="#services" className="hover:text-primary transition-colors">Services</a>
            <a href="#about" className="hover:text-primary transition-colors">About</a>
            <a href="#areas" className="hover:text-primary transition-colors">Areas</a>
            <a href="#contact" className="hover:text-primary transition-colors">Contact</a>
          </nav>

          <div className="flex items-center gap-4">
            <a href="tel:5552473600">
              <Button variant="default" className="font-bold hidden sm:flex">
                <Phone className="mr-2 h-4 w-4" />
                (555) 247-3600
              </Button>
            </a>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative min-h-[100dvh] flex items-center pt-20 overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-background to-background"></div>
          <svg className="absolute w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg" style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }}>
            <defs>
              <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#ffd000" stopOpacity="0" />
                <stop offset="50%" stopColor="#ffd000" stopOpacity="1" />
                <stop offset="100%" stopColor="#ffd000" stopOpacity="0" />
              </linearGradient>
            </defs>
            <path className="arc-anim arc-1" d="M-200,200 Q200,50 600,300 T1400,100" stroke="url(#grad1)" strokeWidth="1.5" fill="none" />
            <path className="arc-anim arc-2" d="M-100,500 Q300,200 700,450 T1500,250" stroke="url(#grad1)" strokeWidth="1" fill="none" />
            <path className="arc-anim arc-3" d="M0,700 Q400,400 800,600 T1600,350" stroke="url(#grad1)" strokeWidth="0.8" fill="none" />
          </svg>
        </div>

        <div className="container relative z-10 mx-auto px-4 py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl"
          >
            <div className="inline-flex items-center gap-2 bg-secondary/50 border border-primary/20 rounded-full px-4 py-1.5 mb-8">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
              </span>
              <span className="text-sm font-semibold tracking-wide text-primary">Available Now • Same-Day Service</span>
            </div>

            <h1 className="font-display text-6xl md:text-8xl font-black uppercase leading-[0.9] mb-6">
              <span className="text-primary block mb-2">24/7</span>
              Electrical Repairs<br />
              Fast, Safe, Reliable
            </h1>

            <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mb-10 font-medium">
              From power failures to upgrades — we fix it right, the first time.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <a href="tel:5552473600">
                <Button size="lg" className="w-full sm:w-auto h-14 px-8 text-lg font-bold">
                  Call Now
                </Button>
              </a>
              <a href="#contact">
                <Button size="lg" variant="outline" className="w-full sm:w-auto h-14 px-8 text-lg font-bold border-primary text-primary hover:bg-primary/10">
                  Get Free Quote
                </Button>
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Emergency Highlight Strip */}
      <section className="bg-primary text-primary-foreground py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 divide-y md:divide-y-0 md:divide-x divide-primary-foreground/20">
            {[
              { icon: Zap, text: "Power Outage?" },
              { icon: AlertTriangle, text: "Burning Smell?" },
              { icon: ShieldCheck, text: "Breaker Keeps Tripping?" }
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between md:justify-center gap-4 pt-4 md:pt-0 first:pt-0">
                <div className="flex items-center gap-3 font-bold text-xl uppercase font-display tracking-wider">
                  <item.icon className="h-8 w-8" />
                  {item.text}
                </div>
                <a href="tel:5552473600" className="text-sm font-bold flex items-center hover:underline">
                  Call Now <ChevronRight className="h-4 w-4" />
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-5xl font-bold uppercase tracking-wider mb-4">Our Services</h2>
            <div className="h-1 w-20 bg-primary mx-auto"></div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { title: "Residential Wiring", desc: "Complete home rewiring, updates, and custom electrical installations." },
              { title: "Panel Upgrades", desc: "Modernize your electrical panel to handle today's high power demands safely." },
              { title: "Emergency Repair", desc: "Rapid response to critical electrical failures, available 24/7." },
              { title: "EV Charger Install", desc: "Professional installation of Level 2 charging stations for all vehicle brands." },
              { title: "Smart Home Systems", desc: "Integration of smart lighting, security, and automated power management." },
              { title: "Safety Inspections", desc: "Comprehensive home electrical audits to ensure code compliance and safety." }
            ].map((service, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -5, scale: 1.02 }}
                className="bg-card border border-border p-8 hover:border-primary/50 hover:shadow-[0_0_30px_rgba(255,208,0,0.1)] transition-all duration-300 cursor-pointer"
              >
                <Zap className="h-10 w-10 text-primary mb-6" />
                <h3 className="font-display text-2xl font-bold uppercase mb-3">{service.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{service.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Strip */}
      <section className="py-16 bg-secondary border-y border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { number: "15+", label: "Years Experience" },
              { number: "2,400+", label: "Jobs Completed" },
              { number: "24/7", label: "Availability" },
              { number: "100%", label: "Licensed & Insured" }
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ scale: 0.9, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <div className="font-display text-5xl md:text-6xl font-black text-primary mb-2">{stat.number}</div>
                <div className="font-bold uppercase tracking-wider text-sm md:text-base">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Before / After Section */}
      <section className="py-24 overflow-hidden bg-background">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-5xl font-bold uppercase tracking-wider mb-4">See The Difference</h2>
            <p className="text-muted-foreground text-lg">Real results from our certified electricians</p>
            <div className="h-1 w-20 bg-primary mx-auto mt-4"></div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {/* BEFORE Panel */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative overflow-hidden group rounded-sm border border-red-900/60 bg-zinc-950"
              style={{ minHeight: 420 }}
            >
              {/* Burn mark bg */}
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_20%,rgba(180,20,0,0.18),transparent_60%)]" />
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_80%_80%,rgba(120,10,0,0.12),transparent_50%)]" />

              {/* Panel box */}
              <div className="relative z-10 p-6 h-full flex flex-col gap-4">
                {/* Header bar */}
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-mono text-zinc-500 uppercase tracking-widest">Main Panel · 100A</span>
                  <span className="text-xs text-red-500 font-bold flex items-center gap-1">
                    <span className="inline-block h-2 w-2 rounded-full bg-red-500 animate-pulse" />
                    FAULT DETECTED
                  </span>
                </div>

                {/* Tangled wire mess at top */}
                <div className="relative h-20 w-full bg-zinc-900 border border-zinc-800 rounded-sm overflow-hidden">
                  <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 80" preserveAspectRatio="none">
                    <path d="M0,40 C30,10 60,70 90,30 S140,60 170,25 S230,65 260,30 S320,55 360,20 L400,35" stroke="#ef4444" strokeWidth="2.5" fill="none" opacity="0.7"/>
                    <path d="M0,55 C40,20 80,70 120,40 S180,65 220,30 S280,60 320,35 L400,50" stroke="#f97316" strokeWidth="2" fill="none" opacity="0.6"/>
                    <path d="M0,20 C50,55 100,10 150,50 S220,15 270,55 S340,25 400,40" stroke="#a3a3a3" strokeWidth="1.5" fill="none" opacity="0.5"/>
                    <path d="M0,65 C30,40 70,75 110,45 S170,70 210,40 S270,65 310,40 L400,60" stroke="#fbbf24" strokeWidth="1.5" fill="none" opacity="0.4"/>
                    <path d="M10,10 C50,60 90,5 130,55 S190,10 230,55 S290,15 340,50 L400,25" stroke="#6b7280" strokeWidth="1" fill="none" opacity="0.4"/>
                  </svg>
                  <div className="absolute bottom-1 right-2 text-[10px] text-zinc-600 font-mono">UNMANAGED WIRING</div>
                </div>

                {/* Breaker rows — damaged state */}
                <div className="grid grid-cols-2 gap-2 flex-1">
                  {[
                    { label: "Kitchen 20A", status: "tripped", color: "bg-red-600" },
                    { label: "HVAC 30A", status: "on", color: "bg-zinc-600" },
                    { label: "Master BR 15A", status: "tripped", color: "bg-red-600" },
                    { label: "Garage 20A", status: "on", color: "bg-zinc-600" },
                    { label: "Outdoor 15A", status: "off", color: "bg-zinc-800" },
                    { label: "Unknown ??A", status: "fault", color: "bg-orange-700" },
                    { label: "Laundry 20A", status: "tripped", color: "bg-red-600" },
                    { label: "Attic 15A", status: "off", color: "bg-zinc-800" },
                  ].map((breaker, i) => (
                    <div key={i} className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 px-3 py-2 rounded-sm">
                      <div className={`h-3 w-3 rounded-full shrink-0 ${breaker.color} ${breaker.status === 'tripped' ? 'animate-pulse' : ''}`} />
                      <span className="text-xs font-mono text-zinc-400 truncate">{breaker.label}</span>
                      <span className={`ml-auto text-[10px] font-bold shrink-0 ${breaker.status === 'tripped' ? 'text-red-400' : breaker.status === 'fault' ? 'text-orange-400' : 'text-zinc-600'}`}>
                        {breaker.status === 'tripped' ? 'TRIP' : breaker.status === 'fault' ? 'ERR' : breaker.status === 'on' ? 'ON' : 'OFF'}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Burn warning */}
                <div className="flex items-center gap-2 bg-red-950/60 border border-red-800/50 px-3 py-2 rounded-sm">
                  <AlertTriangle className="h-4 w-4 text-red-500 shrink-0" />
                  <span className="text-xs text-red-400 font-medium">Burn marks detected — fire hazard risk</span>
                </div>
              </div>

              {/* Label */}
              <div className="absolute top-0 left-0 bg-red-600 px-5 py-2 font-display font-black tracking-widest text-sm text-white uppercase">
                BEFORE
              </div>
            </motion.div>

            {/* AFTER Panel */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative overflow-hidden group rounded-sm border border-primary/40 bg-zinc-950"
              style={{ minHeight: 420 }}
            >
              {/* Glow bg */}
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_0%,rgba(255,208,0,0.08),transparent_60%)]" />

              <div className="relative z-10 p-6 h-full flex flex-col gap-4">
                {/* Header bar */}
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-mono text-zinc-400 uppercase tracking-widest">Main Panel · 200A Upgrade</span>
                  <span className="text-xs text-green-400 font-bold flex items-center gap-1">
                    <span className="inline-block h-2 w-2 rounded-full bg-green-400" />
                    ALL SYSTEMS NORMAL
                  </span>
                </div>

                {/* Clean cable management bar */}
                <div className="relative h-20 w-full bg-zinc-900 border border-zinc-700 rounded-sm overflow-hidden flex items-center px-4 gap-3">
                  {["red","orange","yellow","green","blue","gray"].map((c,i) => (
                    <div key={i} className="flex-1 h-3 rounded-full" style={{ backgroundColor: c === 'red' ? '#ef4444' : c === 'orange' ? '#f97316' : c === 'yellow' ? '#ffd000' : c === 'green' ? '#22c55e' : c === 'blue' ? '#3b82f6' : '#71717a', opacity: 0.8 }} />
                  ))}
                  <div className="absolute bottom-1 right-2 text-[10px] text-zinc-500 font-mono">LABELED & MANAGED</div>
                </div>

                {/* Breaker rows — clean state */}
                <div className="grid grid-cols-2 gap-2 flex-1">
                  {[
                    { label: "Kitchen 20A", status: "on" },
                    { label: "HVAC 30A", status: "on" },
                    { label: "Master BR 15A", status: "on" },
                    { label: "Garage 20A", status: "on" },
                    { label: "Outdoor GFCI 20A", status: "on" },
                    { label: "EV Charger 50A", status: "on" },
                    { label: "Laundry 20A", status: "on" },
                    { label: "Attic / Utility 15A", status: "on" },
                  ].map((breaker, i) => (
                    <div key={i} className="flex items-center gap-2 bg-zinc-900 border border-zinc-700 px-3 py-2 rounded-sm hover:border-primary/30 transition-colors">
                      <div className="h-3 w-3 rounded-full shrink-0 bg-green-500" />
                      <span className="text-xs font-mono text-zinc-300 truncate">{breaker.label}</span>
                      <span className="ml-auto text-[10px] font-bold text-green-400 shrink-0">ON</span>
                    </div>
                  ))}
                </div>

                {/* Success badge */}
                <div className="flex items-center gap-2 bg-primary/10 border border-primary/30 px-3 py-2 rounded-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                  <span className="text-xs text-primary font-medium">Code-compliant · 200A panel · 10-year warranty</span>
                </div>
              </div>

              {/* Label */}
              <div className="absolute top-0 left-0 bg-primary px-5 py-2 font-display font-black tracking-widest text-sm text-primary-foreground uppercase">
                AFTER
              </div>
            </motion.div>
          </div>

          {/* CTA below */}
          <div className="text-center mt-12">
            <a href="#contact">
              <Button size="lg" className="h-14 px-10 text-lg font-bold">
                Get Your Panel Upgraded
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section id="about" className="py-24 bg-secondary/50 border-t border-border">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h2 className="font-display text-5xl font-bold uppercase tracking-wider mb-6">Why Choose<br/><span className="text-primary">AmpGrid</span></h2>
              <p className="text-lg text-muted-foreground mb-8">When the power goes out or danger strikes, you need a team that doesn't guess. We arrive fast, diagnose accurately, and execute with precision.</p>
              <a href="#contact">
                <Button size="lg" className="h-14 px-8 text-lg font-bold">Request Service</Button>
              </a>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {[
                { icon: ShieldCheck, title: "Licensed & Insured", desc: "Full protection for your property and absolute peace of mind." },
                { icon: Clock, title: "Fast Response Time", desc: "Emergency dispatches within hours, not days." },
                { icon: CheckCircle2, title: "Certified Technicians", desc: "Rigorous training and up-to-date code compliance." },
                { icon: Zap, title: "Upfront Pricing", desc: "No hidden fees. You know the cost before we start." }
              ].map((benefit, i) => (
                <div key={i} className="bg-background p-6 border border-border hover:border-primary/30 transition-colors">
                  <benefit.icon className="h-8 w-8 text-primary mb-4" />
                  <h4 className="font-bold uppercase mb-2">{benefit.title}</h4>
                  <p className="text-sm text-muted-foreground">{benefit.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-display text-5xl font-bold uppercase tracking-wider mb-4">What Our Clients Say</h2>
            <div className="h-1 w-20 bg-primary mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { name: "Michael T.", quote: "Lost power to half my house on a Sunday night. AmpGrid was here in 45 minutes and fixed a burnt breaker. Unbelievable service." },
              { name: "Sarah J.", quote: "The only electricians I'll ever call. Upgraded our entire 1950s panel seamlessly. Clean, professional, and exactly on budget." },
              { name: "David R.", quote: "Had a scary sparking outlet in the kitchen. They showed up fast, made it safe immediately, and rewired the circuit perfectly." }
            ].map((testimonial, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-card p-8 border border-border"
              >
                <div className="flex gap-1 mb-4 text-primary">
                  {[1,2,3,4,5].map(star => <Star key={star} className="h-5 w-5 fill-primary" />)}
                </div>
                <p className="text-lg italic mb-6 leading-relaxed">"{testimonial.quote}"</p>
                <div className="font-bold font-display tracking-wide uppercase">{testimonial.name}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Areas */}
      <section id="areas" className="py-24 bg-secondary">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-display text-5xl font-bold uppercase tracking-wider mb-4">Areas We Serve</h2>
          <div className="h-1 w-20 bg-primary mx-auto mb-12"></div>
          
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
              {["Metro Center", "North Hills", "West End", "South Park", "River District", "Highland Park", "Pine Valley", "Oak Creek", "Silver Lake", "Cedar Grove", "Maplewood", "Willow Creek"].map(city => (
                <div key={city} className="bg-background border border-border py-3 px-4 font-medium flex items-center justify-center gap-2 hover:border-primary/50 transition-colors">
                  <Zap className="h-3 w-3 text-primary" />
                  {city}
                </div>
              ))}
            </div>
            
            <div className="relative h-64 bg-background border border-border overflow-hidden opacity-50 flex items-center justify-center group">
              <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(hsl(var(--muted-foreground)/0.2) 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-24 w-24 rounded-full bg-primary/10 animate-pulse"></div>
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-4 w-4 rounded-full bg-primary shadow-[0_0_15px_hsl(var(--primary))]"></div>
              <span className="relative z-10 font-display text-2xl uppercase font-bold tracking-widest text-muted-foreground mt-8">Service Region Map</span>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-background to-secondary/20 -z-10"></div>
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div>
              <h2 className="font-display text-5xl font-bold uppercase tracking-wider mb-6">Need Immediate Assistance?</h2>
              <p className="text-xl text-muted-foreground mb-12">Don't wait when it comes to electrical safety. Our team is standing by 24/7 for emergencies.</p>
              
              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <Phone className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <div className="font-bold text-sm text-muted-foreground uppercase mb-1">24/7 Emergency Hotline</div>
                    <a href="tel:5552473600" className="font-display text-4xl font-bold text-primary hover:underline">(555) 247-3600</a>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center shrink-0">
                    <Clock className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <div>
                    <div className="font-bold text-sm text-muted-foreground uppercase mb-1">Service Hours</div>
                    <div className="font-bold text-xl">24 Hours / 7 Days</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-card border border-border p-8 shadow-2xl shadow-black/50">
              <h3 className="font-display text-3xl font-bold uppercase mb-6">Request A Quote</h3>
              <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-bold uppercase">Name</label>
                    <Input placeholder="John Doe" className="bg-background" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold uppercase">Phone</label>
                    <Input placeholder="(555) 000-0000" className="bg-background" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold uppercase">Service Needed</label>
                  <select className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm">
                    <option value="">Select a service...</option>
                    <option value="emergency">Emergency Repair</option>
                    <option value="panel">Panel Upgrade</option>
                    <option value="wiring">Residential Wiring</option>
                    <option value="ev">EV Charger Install</option>
                    <option value="other">Other / Not Sure</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold uppercase">Message</label>
                  <Textarea placeholder="Describe your issue..." className="min-h-[120px] bg-background" />
                </div>
                <Button type="submit" size="lg" className="w-full h-14 text-lg font-bold mt-4">
                  Get Immediate Assistance
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black py-12 border-t border-border">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2 opacity-50">
            <Zap className="h-6 w-6 text-primary fill-primary" />
            <span className="font-display text-xl font-bold uppercase tracking-wider">AmpGrid</span>
          </div>
          
          <nav className="flex gap-6 text-sm font-bold uppercase text-muted-foreground">
            <a href="#services" className="hover:text-primary transition-colors">Services</a>
            <a href="#about" className="hover:text-primary transition-colors">About</a>
            <a href="#contact" className="hover:text-primary transition-colors">Contact</a>
          </nav>
          
          <div className="text-sm text-muted-foreground">
            © 2025 AmpGrid Electric. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
