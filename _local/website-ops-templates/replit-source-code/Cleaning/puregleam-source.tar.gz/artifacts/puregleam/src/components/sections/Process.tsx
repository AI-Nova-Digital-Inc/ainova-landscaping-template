import { motion } from "framer-motion";
import { Calendar, DoorOpen, Sparkles, CheckCircle2, Smile } from "lucide-react";

const steps = [
  { id: 1, title: "Book", description: "Schedule conveniently online.", icon: Calendar },
  { id: 2, title: "We Arrive", description: "Punctual, professional entry.", icon: DoorOpen },
  { id: 3, title: "Deep Clean", description: "Meticulous attention to detail.", icon: Sparkles },
  { id: 4, title: "Inspect", description: "Rigorous quality assurance.", icon: CheckCircle2 },
  { id: 5, title: "Enjoy", description: "Relax in your pristine space.", icon: Smile },
];

export function Process() {
  return (
    <section id="process" className="py-24 bg-white overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-20">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">Effortless Process</h2>
          <p className="text-muted-foreground text-lg">
            From booking to brilliance in five simple steps.
          </p>
        </div>

        <div className="relative max-w-5xl mx-auto">
          {/* Connecting Line */}
          <div className="hidden md:block absolute top-1/2 left-0 w-full h-[2px] bg-border -translate-y-1/2 z-0" />
          
          <div className="grid grid-cols-1 md:grid-cols-5 gap-10 md:gap-4 relative z-10">
            {steps.map((step, index) => (
              <motion.div 
                key={step.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
                className="flex flex-col items-center text-center group"
              >
                <div className="w-20 h-20 rounded-full bg-background border-2 border-border flex items-center justify-center mb-6 group-hover:border-primary group-hover:shadow-lg group-hover:shadow-primary/20 transition-all duration-300 relative">
                  <div className="absolute inset-2 rounded-full bg-primary/5 group-hover:bg-primary/10 transition-colors" />
                  <step.icon className="w-8 h-8 text-foreground group-hover:text-primary transition-colors relative z-10" />
                </div>
                <h3 className="font-serif font-bold text-xl mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground max-w-[150px]">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
