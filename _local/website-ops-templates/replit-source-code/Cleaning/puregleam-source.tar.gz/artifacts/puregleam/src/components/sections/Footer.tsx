import { Facebook, Twitter, Instagram, Linkedin } from "lucide-react";
import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-foreground text-background py-16">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12 border-b border-border/10 pb-12">
          <div className="md:col-span-1">
            <Link href="/" className="text-2xl font-serif font-bold text-white mb-4 block">
              PureGleam
            </Link>
            <p className="text-background/60 text-sm leading-relaxed mb-6 pr-4">
              The premier choice for luxury home and commercial cleaning. We deliver perfection, every time.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-background/60 hover:text-white transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-background/60 hover:text-white transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-background/60 hover:text-white transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-background/60 hover:text-white transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold text-white mb-6">Services</h4>
            <ul className="space-y-3 text-sm text-background/60">
              <li><a href="#" className="hover:text-white transition-colors">Home Deep Clean</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Commercial Cleaning</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Move In / Out</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Recurring Maintenance</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-white mb-6">Company</h4>
            <ul className="space-y-3 text-sm text-background/60">
              <li><a href="#about" className="hover:text-white transition-colors">About Us</a></li>
              <li><a href="#process" className="hover:text-white transition-colors">Our Process</a></li>
              <li><a href="#contact" className="hover:text-white transition-colors">Careers</a></li>
              <li><a href="#contact" className="hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-white mb-6">Legal</h4>
            <ul className="space-y-3 text-sm text-background/60">
              <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Insurance Details</a></li>
            </ul>
          </div>
        </div>
        
        <div className="text-center text-sm text-background/40">
          <p>&copy; {new Date().getFullYear()} PureGleam Cleaning Services. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
