import { motion } from "framer-motion";
import { Sparkles, Building2, KeyRound, CalendarSync } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const services = [
  {
    title: "Home Deep Clean",
    description: "A meticulous, top-to-bottom revitalization of your space. We address every corner, baseboard, and hidden surface.",
    icon: Sparkles,
  },
  {
    title: "Office & Commercial",
    description: "Professional cleaning tailored for high-end workspaces. Impress clients and inspire your team with an immaculate environment.",
    icon: Building2,
  },
  {
    title: "Move In / Move Out",
    description: "Ensure a flawless transition. We prepare properties to perfection, whether you're welcoming new owners or settling in.",
    icon: KeyRound,
  },
  {
    title: "Recurring Maintenance",
    description: "Seamless, scheduled upkeep designed around your lifestyle. Enjoy continuous perfection without a second thought.",
    icon: CalendarSync,
  }
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
};

export function Services() {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">Our Premium Services</h2>
          <p className="text-muted-foreground text-lg">
            Tailored cleaning solutions executed with precision and care. We treat every space as a masterpiece.
          </p>
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {services.map((service, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="h-full border-border/50 bg-card hover:shadow-xl hover:shadow-primary/5 transition-all duration-300 group overflow-hidden relative">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <CardHeader>
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                    <service.icon className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="font-serif text-xl">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base text-muted-foreground/80 leading-relaxed">
                    {service.description}
                  </CardDescription>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
