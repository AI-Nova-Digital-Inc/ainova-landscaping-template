import { motion } from "framer-motion";
import { Star, ShieldCheck, Leaf } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ParticleCanvas } from "@/components/ui/ParticleCanvas";

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background">
      {/* Background Image / Gradient */}
      <div 
        className="absolute inset-0 z-0 bg-[url('https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&q=80')] bg-cover bg-center"
        style={{ transform: "translateZ(-1px) scale(1)" }}
      >
        <div className="absolute inset-0 bg-background/80 backdrop-blur-[2px]" />
      </div>

      <ParticleCanvas />

      <div className="container relative z-10 mx-auto px-6 pt-24 text-center flex flex-col items-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-3xl mx-auto"
        >
          <h1 className="text-5xl md:text-7xl font-serif font-bold text-foreground leading-tight tracking-tight mb-6">
            Immaculate Spaces.<br/>
            <span className="text-primary italic">Effortless Living.</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
            Premium cleaning services designed for modern lifestyles. Experience the luxury of returning to a perfectly pristine home.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <Button size="lg" className="rounded-full w-full sm:w-auto text-md px-8 py-6 h-auto" onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: 'smooth' })}>
              Book a Cleaning
            </Button>
            <Button size="lg" variant="outline" className="rounded-full w-full sm:w-auto text-md px-8 py-6 h-auto bg-white/50 backdrop-blur-sm" onClick={() => document.getElementById("services")?.scrollIntoView({ behavior: 'smooth' })}>
              View Services
            </Button>
          </div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="flex flex-wrap items-center justify-center gap-6 md:gap-12"
          >
            <div className="flex items-center gap-2">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                ))}
              </div>
              <span className="text-sm font-medium text-foreground">5-Star Rated</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium text-foreground">Insured & Verified</span>
            </div>
            <div className="flex items-center gap-2">
              <Leaf className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium text-foreground">Eco-Friendly</span>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
