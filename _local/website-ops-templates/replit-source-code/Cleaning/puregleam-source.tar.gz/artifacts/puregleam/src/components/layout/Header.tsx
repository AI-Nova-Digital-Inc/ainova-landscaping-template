import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export function Header() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/70 backdrop-blur-md border-b border-border shadow-sm py-4"
          : "bg-transparent py-6"
      }`}
    >
      <div className="container mx-auto px-6 flex items-center justify-between">
        <Link href="/" className="text-2xl font-serif font-bold text-foreground">
          PureGleam
        </Link>

        <nav className="hidden md:flex items-center gap-8">
          <a href="#services" className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors">Services</a>
          <a href="#process" className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors">Process</a>
          <a href="#about" className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors">About</a>
          <a href="#contact" className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors">Contact</a>
        </nav>

        <Button onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: 'smooth' })} className="hidden md:inline-flex rounded-full">
          Book a Cleaning
        </Button>
      </div>
    </header>
  );
}
