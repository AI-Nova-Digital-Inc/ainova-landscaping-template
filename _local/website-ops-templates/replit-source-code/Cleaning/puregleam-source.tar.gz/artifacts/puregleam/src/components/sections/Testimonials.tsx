import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";

const testimonials = [
  {
    name: "Eleanor Vance",
    location: "Upper East Side",
    quote: "PureGleam transformed my apartment. The attention to detail is staggering. It genuinely feels like walking into a luxury hotel every time they visit.",
    rating: 5
  },
  {
    name: "Marcus Sterling",
    location: "Tribeca",
    quote: "Professional, discreet, and incredibly thorough. They handle my fragile antiques with the utmost care. I wouldn't trust my home with anyone else.",
    rating: 5
  },
  {
    name: "Sophia Chen",
    location: "West Village",
    quote: "The eco-friendly products they use leave a subtle, fresh scent that isn't overpowering. The team is always punctual and polite. Highly recommended.",
    rating: 5
  }
];

export function Testimonials() {
  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">Client Experiences</h2>
          <p className="text-muted-foreground text-lg">
            Don't just take our word for it. Hear from those who expect the best.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.15 }}
            >
              <Card className="h-full bg-background border-border/50 hover:shadow-lg transition-shadow duration-300 flex flex-col">
                <CardContent className="pt-8 flex-grow">
                  <div className="flex mb-4">
                    {[...Array(t.rating)].map((_, j) => (
                      <Star key={j} className="w-4 h-4 fill-primary text-primary mr-1" />
                    ))}
                  </div>
                  <p className="text-foreground/80 italic leading-relaxed">"{t.quote}"</p>
                </CardContent>
                <CardFooter className="flex flex-col items-start pb-8">
                  <span className="font-serif font-bold text-foreground">{t.name}</span>
                  <span className="text-sm text-muted-foreground">{t.location}</span>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
