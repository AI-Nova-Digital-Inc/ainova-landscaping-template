import { motion } from "framer-motion";
import { Leaf, Shield, Clock, Star } from "lucide-react";

const benefits = [
  {
    title: "Eco-Friendly Products",
    description: "Hospital-grade efficacy meets environmental responsibility. Safe for your family, pets, and the planet.",
    icon: Leaf
  },
  {
    title: "Trained Professionals",
    description: "Our staff undergo rigorous background checks and comprehensive training in luxury estate care.",
    icon: Shield
  },
  {
    title: "Reliable Scheduling",
    description: "Your time is invaluable. We arrive precisely when scheduled and operate with quiet efficiency.",
    icon: Clock
  },
  {
    title: "Satisfaction Guarantee",
    description: "Perfection is our baseline. If any detail falls short of impeccable, we return and resolve it.",
    icon: Star
  }
];

export function WhyChooseUs() {
  return (
    <section id="about" className="py-24 bg-background border-t border-border/50">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-6">Uncompromising Quality. Unquestionable Trust.</h2>
            <p className="text-lg text-muted-foreground mb-10">
              We understand that inviting someone into your personal space requires absolute trust. That's why we've built a service predicated on transparency, premium products, and obsessive attention to detail.
            </p>
            <div className="relative rounded-2xl overflow-hidden aspect-[4/3] shadow-lg">
              <img 
                src="https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?auto=format&fit=crop&w=800&q=80" 
                alt="Detail of pristine cleaning" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
            </div>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
            {benefits.map((benefit, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="flex flex-col"
              >
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <benefit.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-serif font-bold text-lg mb-2">{benefit.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
