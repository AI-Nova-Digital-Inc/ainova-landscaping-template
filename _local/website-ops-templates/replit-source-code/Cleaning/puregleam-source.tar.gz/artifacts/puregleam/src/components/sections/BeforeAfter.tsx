import { motion } from "framer-motion";

export function BeforeAfter() {
  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">The PureGleam Standard</h2>
          <p className="text-muted-foreground text-lg">
            Experience the dramatic difference. We elevate spaces from chaotic to calming.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 md:gap-4 max-w-5xl mx-auto overflow-hidden rounded-2xl shadow-xl">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative group aspect-[4/3] overflow-hidden"
          >
            <img 
              src="https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=800&q=80" 
              alt="Messy room before cleaning" 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 filter grayscale-[30%]"
            />
            <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md text-white px-4 py-1 rounded-full text-sm font-medium tracking-wide">
              Before
            </div>
            <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors duration-500" />
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative group aspect-[4/3] overflow-hidden"
          >
            <img 
              src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80" 
              alt="Pristine room after cleaning" 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute top-4 left-4 bg-primary/90 backdrop-blur-md text-white px-4 py-1 rounded-full text-sm font-medium tracking-wide shadow-lg">
              After
            </div>
            <div className="absolute inset-0 bg-white/5 group-hover:bg-transparent transition-colors duration-500" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
