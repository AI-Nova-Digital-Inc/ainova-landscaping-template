import { motion } from "framer-motion";
import { Home, Briefcase, Sparkles, Building } from "lucide-react";
import homeImg from "@/assets/service-home.png";
import officeImg from "@/assets/service-office.png";
import deepImg from "@/assets/service-deep.png";
import moveImg from "@/assets/service-move.png";

const SERVICES = [
  {
    id: "home",
    title: "Home Cleaning",
    description: "Standard weekly, bi-weekly, or monthly cleaning to keep your home fresh and tidy.",
    icon: Home,
    image: homeImg,
  },
  {
    id: "deep",
    title: "Deep Cleaning",
    description: "A thorough top-to-bottom clean for spring cleaning or special occasions.",
    icon: Sparkles,
    image: deepImg,
  },
  {
    id: "office",
    title: "Office Cleaning",
    description: "Professional cleaning to maintain a productive and healthy workspace.",
    icon: Briefcase,
    image: officeImg,
  },
  {
    id: "move",
    title: "Move-In/Out",
    description: "Detailed cleaning to ensure you leave on good terms or move into a spotless new place.",
    icon: Building,
    image: moveImg,
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

export default function Services() {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-4"
          >
            Cleaning services for every need
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-lg text-muted-foreground"
          >
            From routine maintenance to deep scrubs, our professional team is equipped to handle it all.
          </motion.p>
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-50px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {SERVICES.map((service) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.id}
                variants={itemVariants}
                whileHover={{ y: -10, scale: 1.02 }}
                className="group relative bg-card rounded-2xl overflow-hidden border border-border shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col h-full"
              >
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.title} 
                    className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-80" />
                  <div className="absolute bottom-4 left-4 bg-white/20 backdrop-blur-md p-2 rounded-lg text-white">
                    <Icon className="w-6 h-6" />
                  </div>
                </div>
                
                <div className="p-6 flex-1 flex flex-col">
                  <h3 className="text-xl font-bold text-foreground mb-2">{service.title}</h3>
                  <p className="text-muted-foreground text-sm flex-1 leading-relaxed">{service.description}</p>
                  
                  <div className="mt-6 pt-4 border-t border-border/50">
                    <button className="text-primary font-bold text-sm flex items-center gap-1 group-hover:gap-2 transition-all">
                      Learn more
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M5 12h14"></path>
                        <path d="m12 5 7 7-7 7"></path>
                      </svg>
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}