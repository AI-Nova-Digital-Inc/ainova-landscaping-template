import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import BookingEstimator from "@/components/BookingEstimator";
import Services from "@/components/Services";
import BeforeAfter from "@/components/BeforeAfter";
import TrustBadges from "@/components/TrustBadges";
import Testimonials from "@/components/Testimonials";
import Pricing from "@/components/Pricing";
import BookingForm from "@/components/BookingForm";
import Footer from "@/components/Footer";

export default function Home() {
  const [showFloatingCTA, setShowFloatingCTA] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowFloatingCTA(window.scrollY > 600);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToBooking = () => {
    document.getElementById("booking-form")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-[100dvh] flex flex-col relative w-full overflow-x-hidden">
      <Navigation onBookClick={scrollToBooking} />

      <main className="flex-1 w-full">
        <Hero onBookClick={scrollToBooking} />

        <section className="bg-white py-20">
          <div className="container mx-auto px-4 md:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-12">
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-3">
                Get an instant estimate
              </h2>
              <p className="text-lg text-muted-foreground">
                Select your service, frequency, and date — see pricing in real time.
              </p>
            </div>
            <BookingEstimator onBookClick={scrollToBooking} />
          </div>
        </section>

        <Services />
        <BeforeAfter />
        <TrustBadges />
        <Testimonials />
        <Pricing onBookClick={scrollToBooking} />

        <section id="booking-form" className="bg-muted/40 py-24">
          <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-4xl">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-4">
                Book Your Cleaning Now
              </h2>
              <p className="text-muted-foreground text-lg">
                Complete this form to schedule your professional cleaning service.
              </p>
            </div>
            <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-border">
              <BookingForm />
            </div>
          </div>
        </section>
      </main>

      <Footer />

      <AnimatePresence>
        {showFloatingCTA && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="fixed bottom-6 right-6 z-50"
          >
            <button
              onClick={scrollToBooking}
              className="bg-primary text-primary-foreground px-6 py-4 rounded-full shadow-2xl font-bold hover:scale-105 transition-transform duration-200 active:scale-95 flex items-center gap-2"
            >
              Book Now
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
