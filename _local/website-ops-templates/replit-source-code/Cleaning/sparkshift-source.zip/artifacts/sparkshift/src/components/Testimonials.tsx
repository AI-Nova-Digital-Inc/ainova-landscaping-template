import { motion } from "framer-motion";
import { Star } from "lucide-react";

const TESTIMONIALS = [
  {
    name: "Sarah Jenkins",
    role: "Busy Mom of 3",
    content: "With three kids and a full-time job, keeping the house clean was impossible. SparkShift gave me my weekends back. The attention to detail is incredible—they even organized my kids' toys!",
    rating: 5,
    initials: "SJ",
    color: "bg-blue-100 text-blue-700"
  },
  {
    name: "Michael Chen",
    role: "Software Engineer",
    content: "I've tried five different cleaning services in the city. SparkShift is the only one that consistently shows up on time and leaves my apartment spotless. The online booking is seamless.",
    rating: 5,
    initials: "MC",
    color: "bg-green-100 text-green-700"
  },
  {
    name: "Elena Rodriguez",
    role: "Homeowner",
    content: "We hired them for a move-in clean before settling into our new house. They made the place shine from the baseboards to the ceiling fans. Worth every penny for the peace of mind.",
    rating: 5,
    initials: "ER",
    color: "bg-purple-100 text-purple-700"
  }
];

export default function Testimonials() {
  return (
    <section id="reviews" className="py-24 bg-white overflow-hidden">
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="flex justify-center items-center gap-1 mb-6"
          >
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
            ))}
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-4"
          >
            Loved by our neighbors
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-lg text-muted-foreground"
          >
            Don't just take our word for it. Read what real homeowners have to say.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((t, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: idx * 0.2, duration: 0.6 }}
              className="bg-card rounded-2xl p-8 border border-border shadow-sm flex flex-col h-full"
            >
              <div className="flex gap-1 mb-6">
                {[...Array(t.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              
              <p className="text-foreground text-lg leading-relaxed flex-1 italic">
                "{t.content}"
              </p>
              
              <div className="flex items-center gap-4 mt-8 pt-6 border-t border-border/50">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg ${t.color}`}>
                  {t.initials}
                </div>
                <div>
                  <h4 className="font-bold text-foreground">{t.name}</h4>
                  <p className="text-sm text-muted-foreground">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}