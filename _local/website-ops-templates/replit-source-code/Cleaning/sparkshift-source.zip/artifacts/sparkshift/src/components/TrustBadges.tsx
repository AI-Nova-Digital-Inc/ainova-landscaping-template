import { motion } from "framer-motion";
import { ShieldCheck, Star, CalendarDays, ThumbsUp, Leaf, BadgeCheck } from "lucide-react";

const BADGES = [
  {
    icon: ShieldCheck,
    title: "Verified & Vetted",
    description: "Every cleaner passes strict background checks and interviews."
  },
  {
    icon: Star,
    title: "5-Star Rated",
    description: "Over 2,400+ happy customers and counting."
  },
  {
    icon: CalendarDays,
    title: "Flexible Scheduling",
    description: "Book for tomorrow or next month. Reschedule easily."
  },
  {
    icon: ThumbsUp,
    title: "100% Guaranteed",
    description: "Not happy? We'll re-clean for free."
  },
  {
    icon: Leaf,
    title: "Eco-Friendly",
    description: "Safe, non-toxic products safe for pets and kids."
  },
  {
    icon: BadgeCheck,
    title: "Insured & Bonded",
    description: "Full coverage for your peace of mind."
  }
];

const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, scale: 0.9 },
  show: { opacity: 1, scale: 1, transition: { type: "spring", bounce: 0.4 } },
};

export default function TrustBadges() {
  return (
    <section className="py-24 bg-primary/5 border-y border-primary/10">
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-4"
          >
            Why Choose SparkShift?
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-lg text-muted-foreground"
          >
            We don't just clean homes, we build trust.
          </motion.p>
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-50px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {BADGES.map((badge, idx) => {
            const Icon = badge.icon;
            return (
              <motion.div
                key={idx}
                variants={itemVariants}
                className="bg-white rounded-2xl p-6 shadow-sm border border-primary/10 flex items-start gap-4 hover:shadow-md transition-shadow"
              >
                <div className="bg-primary/10 p-3 rounded-xl shrink-0">
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-foreground text-lg mb-1">{badge.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{badge.description}</p>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}