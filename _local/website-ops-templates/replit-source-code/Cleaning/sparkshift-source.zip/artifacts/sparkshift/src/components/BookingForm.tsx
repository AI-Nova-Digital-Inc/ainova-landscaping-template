import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, ChevronRight, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function BookingForm() {
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "home",
    frequency: "once",
    date: ""
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const nextStep = () => {
    if (step === 1 && (!formData.name || !formData.email || !formData.phone)) {
      toast({ title: "Please fill out all fields", variant: "destructive" });
      return;
    }
    if (step === 2 && (!formData.date)) {
      toast({ title: "Please select a date", variant: "destructive" });
      return;
    }
    setStep((prev) => Math.min(prev + 1, 3));
  };

  const prevStep = () => {
    setStep((prev) => Math.max(prev - 1, 1));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1500);
  };

  if (isSuccess) {
    return (
      <div className="p-10 md:p-16 text-center bg-white flex flex-col items-center justify-center min-h-[400px]">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", bounce: 0.5 }}
        >
          <CheckCircle2 className="w-24 h-24 text-primary mx-auto mb-6" />
        </motion.div>
        <h3 className="text-3xl font-bold text-foreground mb-4">Booking Confirmed!</h3>
        <p className="text-muted-foreground text-lg mb-8 max-w-md mx-auto">
          Thanks {formData.name.split(' ')[0]}! We've sent a confirmation email to {formData.email}. Our team will see you on {formData.date}.
        </p>
        <button
          onClick={() => {
            setIsSuccess(false);
            setStep(1);
            setFormData({ name: "", email: "", phone: "", service: "home", frequency: "once", date: "" });
          }}
          className="text-primary font-bold hover:underline"
        >
          Book another cleaning
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white flex flex-col md:flex-row min-h-[500px]">
      {/* Sidebar Progress */}
      <div className="bg-primary/5 border-r border-primary/10 p-8 md:w-1/3 flex flex-col">
        <h3 className="text-xl font-bold text-foreground mb-8">Secure Booking</h3>
        
        <div className="space-y-8 flex-1">
          {[
            { num: 1, title: "Your Details", desc: "Contact information" },
            { num: 2, title: "Cleaning Details", desc: "Service & schedule" },
            { num: 3, title: "Confirmation", desc: "Review & book" }
          ].map((s) => (
            <div key={s.num} className="flex gap-4">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm shrink-0 transition-colors ${
                step >= s.num 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-muted text-muted-foreground"
              }`}>
                {step > s.num ? <CheckCircle2 className="w-5 h-5" /> : s.num}
              </div>
              <div>
                <h4 className={`font-bold ${step >= s.num ? "text-foreground" : "text-muted-foreground"}`}>
                  {s.title}
                </h4>
                <p className="text-xs text-muted-foreground mt-1">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Form Area */}
      <div className="p-8 md:p-12 md:w-2/3 flex flex-col justify-between">
        <form onSubmit={handleSubmit} className="flex-1">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <h3 className="text-2xl font-bold text-foreground">Tell us about yourself</h3>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-bold text-foreground mb-2">Full Name</label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="Jane Doe"
                      className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-foreground mb-2">Email Address</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="jane@example.com"
                      className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-foreground mb-2">Phone Number</label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="(555) 123-4567"
                      className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <h3 className="text-2xl font-bold text-foreground">Customize your clean</h3>
                
                <div className="space-y-5">
                  <div>
                    <label className="block text-sm font-bold text-foreground mb-2">Service Type</label>
                    <select
                      name="service"
                      value={formData.service}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all appearance-none"
                    >
                      <option value="home">Home Cleaning</option>
                      <option value="deep">Deep Clean</option>
                      <option value="office">Office Cleaning</option>
                      <option value="move">Move-In/Out</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-bold text-foreground mb-2">Frequency</label>
                    <select
                      name="frequency"
                      value={formData.frequency}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all appearance-none"
                    >
                      <option value="once">One-Time</option>
                      <option value="weekly">Weekly (15% Off)</option>
                      <option value="monthly">Monthly (10% Off)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-foreground mb-2">Preferred Date</label>
                    <input
                      type="date"
                      name="date"
                      value={formData.date}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <h3 className="text-2xl font-bold text-foreground">Review & Confirm</h3>
                
                <div className="bg-muted rounded-2xl p-6 space-y-4">
                  <div className="flex justify-between border-b border-border/50 pb-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Contact</p>
                      <p className="font-bold text-foreground">{formData.name}</p>
                      <p className="text-sm text-foreground">{formData.email}</p>
                    </div>
                    <button type="button" onClick={() => setStep(1)} className="text-primary text-sm font-bold">Edit</button>
                  </div>
                  
                  <div className="flex justify-between pt-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Service Details</p>
                      <p className="font-bold text-foreground capitalize">{formData.service.replace('-', ' ')} Cleaning</p>
                      <p className="text-sm text-foreground capitalize">{formData.frequency} • {formData.date}</p>
                    </div>
                    <button type="button" onClick={() => setStep(2)} className="text-primary text-sm font-bold">Edit</button>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 bg-blue-50 text-blue-800 p-4 rounded-xl border border-blue-100">
                  <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
                  <p className="text-sm leading-relaxed">No payment required now. You'll only be charged after the cleaning is complete and you are 100% satisfied.</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Form Navigation */}
          <div className="flex justify-between mt-10 pt-6 border-t border-border">
            {step > 1 ? (
              <button
                type="button"
                onClick={prevStep}
                className="px-6 py-3 rounded-xl font-bold text-muted-foreground hover:bg-muted transition-colors flex items-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
            ) : <div></div>}
            
            {step < 3 ? (
              <button
                type="button"
                onClick={nextStep}
                className="bg-primary text-primary-foreground px-8 py-3 rounded-xl font-bold shadow-md hover:shadow-lg hover:bg-primary/90 transition-all flex items-center gap-2 active:scale-95"
              >
                Continue <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="submit"
                disabled={isSubmitting}
                className="bg-primary text-primary-foreground px-8 py-3 rounded-xl font-bold shadow-xl shadow-primary/20 hover:shadow-2xl hover:bg-primary/90 transition-all flex items-center gap-2 active:scale-95 disabled:opacity-70"
              >
                {isSubmitting ? (
                  <>Processing...</>
                ) : (
                  <>Book Your Cleaning Now <CheckCircle2 className="w-5 h-5" /></>
                )}
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}