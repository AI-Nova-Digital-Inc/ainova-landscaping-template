import { useState, useEffect } from "react";
import { Sparkles, Menu, X } from "lucide-react";
import { Link } from "wouter";

interface NavigationProps {
  onBookClick: () => void;
}

export default function Navigation({ onBookClick }: NavigationProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <div className="bg-secondary text-secondary-foreground text-center py-2 text-sm font-medium">
        ✨ Next-day slots available! Book now for 10% off your first cleaning.
      </div>
      <header
        className={`sticky top-0 z-50 w-full transition-all duration-300 ${
          isScrolled
            ? "bg-white/95 backdrop-blur-md shadow-sm border-b border-border py-3"
            : "bg-white py-5"
        }`}
      >
        <div className="container mx-auto px-4 md:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-primary/10 p-2 rounded-lg">
              <Sparkles className="text-primary w-6 h-6" />
            </div>
            <span className="font-bold text-xl tracking-tight text-foreground">SparkShift</span>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            <a href="#services" className="text-muted-foreground hover:text-primary font-medium transition-colors">Services</a>
            <a href="#how-it-works" className="text-muted-foreground hover:text-primary font-medium transition-colors">How it Works</a>
            <a href="#pricing" className="text-muted-foreground hover:text-primary font-medium transition-colors">Pricing</a>
            <a href="#reviews" className="text-muted-foreground hover:text-primary font-medium transition-colors">Reviews</a>
          </nav>

          <div className="hidden md:flex items-center gap-4">
            <span className="text-muted-foreground font-medium text-sm">Questions? (555) 123-4567</span>
            <button
              onClick={onBookClick}
              className="bg-primary text-primary-foreground px-6 py-2.5 rounded-full font-bold shadow-md hover:shadow-lg hover:scale-105 transition-all duration-200 active:scale-95"
            >
              Book Now
            </button>
          </div>

          <button
            className="md:hidden p-2 text-foreground"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden absolute top-full left-0 w-full bg-white border-b border-border shadow-lg py-4 px-4 flex flex-col gap-4">
            <a href="#services" onClick={() => setIsMobileMenuOpen(false)} className="text-foreground font-medium py-2">Services</a>
            <a href="#how-it-works" onClick={() => setIsMobileMenuOpen(false)} className="text-foreground font-medium py-2">How it Works</a>
            <a href="#pricing" onClick={() => setIsMobileMenuOpen(false)} className="text-foreground font-medium py-2">Pricing</a>
            <a href="#reviews" onClick={() => setIsMobileMenuOpen(false)} className="text-foreground font-medium py-2">Reviews</a>
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onBookClick();
              }}
              className="bg-primary text-primary-foreground px-6 py-3 rounded-full font-bold w-full mt-2"
            >
              Book Now
            </button>
          </div>
        )}
      </header>
    </>
  );
}