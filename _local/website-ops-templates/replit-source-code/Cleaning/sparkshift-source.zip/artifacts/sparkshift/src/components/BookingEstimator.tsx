import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Check, Calendar } from "lucide-react";

interface BookingEstimatorProps {
  onBookClick: () => void;
}

const SERVICES = [
  { id: "home", label: "Home Cleaning", basePrice: 89 },
  { id: "office", label: "Office Cleaning", basePrice: 120 },
  { id: "deep", label: "Deep Clean", basePrice: 149 },
  { id: "move", label: "Move-In/Out", basePrice: 179 },
];

const FREQUENCIES = [
  { id: "once", label: "One-Time", multiplier: 1, discount: "0%" },
  { id: "monthly", label: "Monthly", multiplier: 0.9, discount: "10% off" },
  { id: "weekly", label: "Weekly", multiplier: 0.85, discount: "15% off" },
];

export default function BookingEstimator({ onBookClick }: BookingEstimatorProps) {
  const [service, setService] = useState(SERVICES[0]);
  const [frequency, setFrequency] = useState(FREQUENCIES[0]);
  const [date, setDate] = useState("");

  const estimatedPrice = useMemo(() => {
    return Math.round(service.basePrice * frequency.multiplier);
  }, [service, frequency]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.6 }}
      className="bg-card rounded-2xl shadow-xl shadow-black/5 p-6 md:p-8 border border-border w-full"
    >
      <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
        <div className="flex-1 space-y-6">
          <div>
            <h3 className="text-xl font-bold text-foreground mb-4">1. Select Service</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {SERVICES.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setService(s)}
                  className={`py-3 px-4 rounded-xl text-sm font-semibold transition-all border-2 ${
                    service.id === s.id
                      ? "border-primary bg-primary/5 text-primary shadow-sm"
                      : "border-border bg-white text-muted-foreground hover:border-primary/30 hover:bg-muted"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold text-foreground mb-4">2. Choose Frequency</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {FREQUENCIES.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setFrequency(f)}
                  className={`py-3 px-4 rounded-xl flex flex-col items-center justify-center gap-1 transition-all border-2 relative overflow-hidden ${
                    frequency.id === f.id
                      ? "border-primary bg-primary/5 text-primary shadow-sm"
                      : "border-border bg-white text-muted-foreground hover:border-primary/30 hover:bg-muted"
                  }`}
                >
                  <span className="font-bold text-sm z-10">{f.label}</span>
                  {f.id !== "once" && (
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full z-10 ${
                      frequency.id === f.id ? "bg-primary text-white" : "bg-green-100 text-green-800"
                    }`}>
                      {f.discount}
                    </span>
                  )}
                  {frequency.id === f.id && (
                    <div className="absolute top-2 right-2 z-10">
                      <Check className="w-4 h-4" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold text-foreground mb-4">3. Pick a Date</h3>
            <div className="relative">
              <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5 pointer-events-none" />
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-border bg-white text-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all font-medium"
              />
            </div>
          </div>
        </div>

        <div className="lg:w-80 bg-muted/50 rounded-2xl p-6 md:p-8 flex flex-col justify-center border border-border/50">
          <div className="text-center">
            <p className="text-muted-foreground font-medium mb-2 uppercase tracking-wider text-sm">Estimated Total</p>
            <div className="text-5xl font-extrabold text-foreground mb-4 flex items-start justify-center">
              <span className="text-2xl mt-1 mr-1 text-muted-foreground">$</span>
              {estimatedPrice}
            </div>
            
            <ul className="text-left space-y-3 mb-8">
              <li className="flex items-center text-sm text-muted-foreground">
                <Check className="w-4 h-4 text-primary mr-2 flex-shrink-0" />
                {service.label} service
              </li>
              <li className="flex items-center text-sm text-muted-foreground">
                <Check className="w-4 h-4 text-primary mr-2 flex-shrink-0" />
                {frequency.label} schedule ({frequency.discount})
              </li>
              <li className="flex items-center text-sm text-muted-foreground">
                <Check className="w-4 h-4 text-primary mr-2 flex-shrink-0" />
                Background-checked cleaner
              </li>
            </ul>

            <button
              onClick={onBookClick}
              className="w-full bg-primary text-primary-foreground py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl hover:scale-[1.02] transition-all duration-200 active:scale-[0.98]"
            >
              Book This Cleaning
            </button>
            <p className="text-xs text-muted-foreground text-center mt-4">
              No credit card required to book.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}