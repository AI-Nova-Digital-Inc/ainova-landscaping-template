import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import beforeKitchen from "@/assets/before-kitchen.png";
import afterKitchen from "@/assets/after-kitchen.png";
import beforeLiving from "@/assets/before-living.png";
import afterLiving from "@/assets/after-living.png";

const COMPARISONS = [
  {
    id: "kitchen",
    title: "Kitchen Deep Clean",
    before: beforeKitchen,
    after: afterKitchen,
  },
  {
    id: "living",
    title: "Living Room Recovery",
    before: beforeLiving,
    after: afterLiving,
  }
];

export default function BeforeAfter() {
  return (
    <section className="py-24 bg-muted/30">
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-4"
          >
            The SparkShift Difference
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-lg text-muted-foreground"
          >
            See the results for yourself. Drag the slider to reveal the transformation.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {COMPARISONS.map((comp, idx) => (
            <motion.div
              key={comp.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: idx * 0.2, duration: 0.6 }}
              className="flex flex-col"
            >
              <div className="bg-card rounded-2xl overflow-hidden border border-border shadow-md aspect-[4/3] relative">
                {/* Before Image (Base) */}
                <img 
                  src={comp.before} 
                  alt={`${comp.title} before`} 
                  className="absolute inset-0 w-full h-full object-cover object-center"
                />
                
                {/* CSS-only hover reveal for simplicity and robustness */}
                <div 
                  className="absolute inset-y-0 right-0 w-[50%] overflow-hidden transition-all duration-500 ease-in-out group hover:w-full"
                  style={{ borderLeft: '4px solid white' }}
                >
                  <img 
                    src={comp.after} 
                    alt={`${comp.title} after`} 
                    className="absolute inset-0 w-[200%] max-w-none h-full object-cover object-center transition-all duration-500 group-hover:w-full group-hover:translate-x-0 -translate-x-1/2"
                  />
                  <div className="absolute top-1/2 -left-[14px] -translate-y-1/2 w-6 h-6 bg-white rounded-full shadow-md flex items-center justify-center pointer-events-none group-hover:opacity-0 transition-opacity">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="hsl(var(--primary))" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <path d="m15 18-6-6 6-6"/>
                      <path d="m9 18 6-6-6-6"/>
                    </svg>
                  </div>
                </div>

                <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                  Before
                </div>
                <div className="absolute top-4 right-4 bg-primary/90 backdrop-blur-md text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider z-10">
                  After
                </div>
              </div>
              <h3 className="text-xl font-bold text-center mt-6 text-foreground">{comp.title}</h3>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}