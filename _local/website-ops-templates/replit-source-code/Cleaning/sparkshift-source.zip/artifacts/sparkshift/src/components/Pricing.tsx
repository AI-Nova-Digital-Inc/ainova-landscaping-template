import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";

interface PricingProps {
  onBookClick: () => void;
}

const PACKAGES = [
  {
    name: "Basic",
    price: "89",
    description: "Perfect for regular maintenance",
    popular: false,
    features: [
      "Dusting all surfaces",
      "Vacuuming & mopping floors",
      "Wiping counters & exteriors",
      "Emptying trash bins",
      "1 Bathroom, 1 Bedroom, Kitchen, Living"
    ]
  },
  {
    name: "Standard",
    price: "129",
    description: "Our most popular deep clean",
    popular: true,
    features: [
      "Everything in Basic",
      "Scrubbing showers & tubs",
      "Cleaning inside microwave",
      "Dusting baseboards & blinds",
      "Making beds (linens provided)",
      "Up to 2 Bathrooms, 3 Bedrooms"
    ]
  },
  {
    name: "Premium",
    price: "189",
    description: "The ultimate spotless treatment",
    popular: false,
    features: [
      "Everything in Standard",
      "Cleaning inside fridge & oven",
      "Wiping interior windows",
      "Spot cleaning walls/doors",
      "Deep scrub of tile grout",
      "Unlimited rooms (within reason)"
    ]
  }
];

export default function Pricing({ onBookClick }: PricingProps) {
  return (
    <section id="pricing" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-4"
          >
            Simple, transparent pricing
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-lg text-muted-foreground"
          >
            No hidden fees, no surprises. Choose the level of clean you need.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {PACKAGES.map((pkg, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: idx * 0.2, duration: 0.6 }}
              className={`bg-card rounded-3xl p-8 border-2 relative flex flex-col h-full ${
                pkg.popular 
                  ? "border-primary shadow-xl shadow-primary/10 md:-translate-y-4 md:hover:-translate-y-6" 
                  : "border-border shadow-sm hover:shadow-md hover:-translate-y-2"
              } transition-all duration-300`}
            >
              {pkg.popular && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-bold uppercase tracking-wider">
                  Most Popular
                </div>
              )}
              
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-foreground mb-2">{pkg.name}</h3>
                <p className="text-muted-foreground text-sm mb-6">{pkg.description}</p>
                <div className="flex items-start justify-center text-foreground">
                  <span className="text-2xl font-bold mt-2 mr-1">$</span>
                  <span className="text-6xl font-extrabold tracking-tight">{pkg.price}</span>
                </div>
                <p className="text-sm text-muted-foreground mt-2">Starting at / one-time</p>
              </div>
              
              <ul className="space-y-4 mb-8 flex-1">
                {pkg.features.map((feature, fIdx) => (
                  <li key={fIdx} className="flex items-start">
                    <CheckCircle2 className={`w-5 h-5 mr-3 shrink-0 ${pkg.popular ? "text-primary" : "text-muted-foreground"}`} />
                    <span className="text-foreground text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <button
                onClick={onBookClick}
                className={`w-full py-4 rounded-xl font-bold text-lg transition-all duration-200 ${
                  pkg.popular
                    ? "bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg hover:shadow-xl active:scale-95"
                    : "bg-white text-foreground border-2 border-border hover:border-primary hover:bg-muted active:scale-95"
                }`}
              >
                Choose {pkg.name}
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}