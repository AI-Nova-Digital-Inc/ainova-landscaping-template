import React from "react";
import { motion } from "framer-motion";
import { Phone, Flame, Snowflake, AlertTriangle, ShieldCheck, Clock, PenTool, CheckCircle, Wrench, ArrowRight, Star } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { toast } from "sonner";
import techImage from "@/assets/images/technician.png";
import brokenImage from "@/assets/images/broken-unit.png";
import newImage from "@/assets/images/new-unit.png";

// Validation schema for booking
const formSchema = z.object({
  name: z.string().min(2, "Name is required"),
  phone: z.string().min(10, "Valid phone is required"),
  issueType: z.string().min(1, "Please select an issue type"),
  preferredTime: z.string().min(1, "Please select a time"),
});

export default function Home() {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      phone: "",
      issueType: "",
      preferredTime: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    toast.success("Request Received!", {
      description: "Our emergency dispatcher will call you in exactly 2 minutes.",
    });
    form.reset();
  }

  const fadeIn = {
    initial: { opacity: 0, y: 20 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true },
    transition: { duration: 0.5 }
  };

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden font-sans">
      {/* Sticky Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex -space-x-1">
              <Snowflake className="w-8 h-8 text-primary" />
              <Flame className="w-8 h-8 text-accent" />
            </div>
            <span className="text-2xl font-black tracking-tight">FrostFlow</span>
          </div>
          
          <nav className="hidden md:flex items-center gap-8 font-medium">
            <a href="#services" className="hover:text-primary transition-colors">Services</a>
            <a href="#results" className="hover:text-primary transition-colors">Results</a>
            <a href="#reviews" className="hover:text-primary transition-colors">Reviews</a>
          </nav>

          <Button size="lg" className="bg-accent hover:bg-accent/90 text-white font-bold gap-2 animate-pulse shadow-[0_0_15px_rgba(249,115,22,0.5)]">
            <Phone className="w-5 h-5" />
            <span className="hidden sm:inline">Call Now </span>800-555-0199
          </Button>
        </div>
      </header>

      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button size="icon" className="w-16 h-16 rounded-full bg-accent hover:bg-accent/90 text-white shadow-[0_0_20px_rgba(249,115,22,0.6)] animate-pulse border-2 border-white/20">
          <Phone className="w-8 h-8" />
        </Button>
      </div>

      <main>
        {/* Hero Section */}
        <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden">
          <div className="absolute inset-0 flex w-full h-full z-0 opacity-20">
            <div className="w-1/2 bg-gradient-to-r from-primary to-transparent" />
            <div className="w-1/2 bg-gradient-to-l from-accent to-transparent" />
          </div>
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0IiBoZWlnaHQ9IjQiPgo8cmVjdCB3aWR0aD0iNCIgaGVpZ2h0PSI0IiBmaWxsPSIjZmZmIiBmaWxsLW9wYWNpdHk9IjAuMDUiLz4KPC9zdmc+')] opacity-20 mix-blend-overlay pointer-events-none" />

          <div className="container mx-auto px-4 relative z-10 py-12 md:py-24">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="max-w-4xl mx-auto text-center"
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20 text-accent font-bold mb-8">
                <AlertTriangle className="w-5 h-5" />
                SAME-DAY SERVICE AVAILABLE
              </div>
              
              <h1 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter leading-[1.1] mb-6">
                Heating or Cooling. <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-white to-accent">We Fix It Fast.</span>
              </h1>
              
              <p className="text-xl md:text-2xl text-muted-foreground mb-10 max-w-2xl mx-auto">
                24/7 emergency HVAC services for immediate comfort. When your system fails, FrostFlow responds.
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button size="lg" className="w-full sm:w-auto h-16 px-8 text-lg font-bold bg-accent hover:bg-accent/90 text-white shadow-xl shadow-accent/20">
                  <Phone className="w-6 h-6 mr-2" />
                  Call 800-555-0199
                </Button>
                <Button size="lg" variant="outline" className="w-full sm:w-auto h-16 px-8 text-lg font-bold border-2 hover:bg-white/5">
                  Get Free Estimate
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Emergency Strip */}
        <section className="bg-card border-y border-border py-6 relative z-20">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 divide-x divide-border/50">
              {[
                { icon: Snowflake, text: "AC not cooling?" },
                { icon: Flame, text: "Heater not working?" },
                { icon: AlertTriangle, text: "Strange noise?" },
                { icon: PenTool, text: "No airflow?" },
              ].map((item, i) => (
                <div key={i} className="flex flex-col items-center text-center px-4 group cursor-pointer">
                  <item.icon className="w-8 h-8 text-muted-foreground group-hover:text-primary transition-colors mb-2" />
                  <span className="font-bold">{item.text}</span>
                  <span className="text-sm text-accent font-medium mt-1 opacity-0 group-hover:opacity-100 transition-opacity flex items-center">
                    Fix It Now <ArrowRight className="w-4 h-4 ml-1" />
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Services Grid */}
        <section id="services" className="py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-4xl md:text-5xl font-black mb-4">Complete HVAC Solutions</h2>
              <p className="text-xl text-muted-foreground">Expert repairs, flawless installations, and proactive maintenance to keep your home comfortable year-round.</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { title: "AC Repair", desc: "Fast diagnostics and fixes for any air conditioning issue.", icon: Snowflake, color: "text-primary" },
                { title: "Heating Repair", desc: "Emergency furnace and heat pump repairs when you need them.", icon: Flame, color: "text-accent" },
                { title: "Installation", desc: "Energy-efficient system replacements with expert sizing.", icon: Wrench, color: "text-white" },
                { title: "Maintenance", desc: "Preventative tune-ups to avoid costly future breakdowns.", icon: ShieldCheck, color: "text-muted-foreground" },
              ].map((service, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="group relative p-8 bg-card rounded-2xl border border-border hover:border-accent/50 transition-all hover:-translate-y-2 hover:shadow-[0_10px_30px_-10px_rgba(249,115,22,0.15)]"
                >
                  <service.icon className={`w-12 h-12 ${service.color} mb-6`} />
                  <h3 className="text-2xl font-bold mb-3">{service.title}</h3>
                  <p className="text-muted-foreground mb-6">{service.desc}</p>
                  <Button variant="link" className="p-0 h-auto text-white group-hover:text-accent">
                    Learn More <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Before / After */}
        <section id="results" className="py-24 bg-card border-y border-border">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div {...fadeIn}>
                <h2 className="text-4xl md:text-5xl font-black mb-6">From Frozen Solid to Firing Perfectly.</h2>
                <p className="text-xl text-muted-foreground mb-8">
                  We don't just patch problems; we restore complete system integrity. See the difference professional emergency service makes.
                </p>
                <div className="space-y-4 mb-8">
                  {["Frozen coils thawed and repaired", "Burnt contactors replaced", "Refrigerant leaks sealed", "System efficiency restored"].map((item, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <CheckCircle className="w-6 h-6 text-primary flex-shrink-0" />
                      <span className="text-lg font-medium">{item}</span>
                    </div>
                  ))}
                </div>
                <Button size="lg" className="h-14 px-8 text-lg">Book An Inspection</Button>
              </motion.div>
              
              <div className="grid grid-cols-2 gap-4">
                <motion.div 
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  className="space-y-4"
                >
                  <div className="relative aspect-[3/4] rounded-2xl overflow-hidden group">
                    <img src={brokenImage} alt="Broken HVAC" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                    <div className="absolute top-4 left-4 bg-destructive text-white text-sm font-bold px-3 py-1 rounded-full">BEFORE</div>
                  </div>
                </motion.div>
                <motion.div 
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2 }}
                  className="space-y-4 mt-8"
                >
                  <div className="relative aspect-[3/4] rounded-2xl overflow-hidden group">
                    <img src={newImage} alt="Fixed HVAC" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                    <div className="absolute top-4 left-4 bg-primary text-white text-sm font-bold px-3 py-1 rounded-full">AFTER</div>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-24 bg-background">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl md:text-5xl font-black mb-16">Why Trust FrostFlow?</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              {[
                { icon: ShieldCheck, text: "Licensed & Insured" },
                { icon: Clock, text: "24/7 Emergency" },
                { icon: AlertTriangle, text: "Same-Day Service" },
                { icon: Star, text: "Affordable Pricing" },
                { icon: Wrench, text: "15+ Years Exp." },
                { icon: CheckCircle, text: "5,000+ Homes" }
              ].map((badge, i) => (
                <div key={i} className="flex flex-col items-center gap-4 group">
                  <div className="w-20 h-20 rounded-2xl bg-card border border-border flex items-center justify-center group-hover:bg-primary/10 group-hover:border-primary/50 transition-all group-hover:scale-110">
                    <badge.icon className="w-10 h-10 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                  <span className="font-bold text-lg">{badge.text}</span>
                </div>
              ))}
            </div>
            <Button size="lg" className="mt-16 h-14 px-8 text-lg font-bold bg-accent hover:bg-accent/90 text-white">
              <Phone className="w-5 h-5 mr-2" />
              Call Now
            </Button>
          </div>
        </section>

        {/* Testimonials */}
        <section id="reviews" className="py-24 bg-card border-y border-border">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-black mb-4">Don't Just Take Our Word For It</h2>
              <p className="text-xl text-muted-foreground">Real reviews from relieved homeowners.</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {[
                { name: "Sarah M.", date: "2 days ago", text: "AC died during the 100° heatwave. Called FrostFlow at 11 PM, tech was here by midnight. Pure lifesavers." },
                { name: "James T.", date: "1 week ago", text: "Honest pricing, no upselling. They fixed what another company said needed a full replacement. Highly recommend." },
                { name: "David L.", date: "3 weeks ago", text: "The name says it all. Super fast response when my furnace went out in January. Within 2 hours, my house was warm again." }
              ].map((review, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-8 rounded-2xl bg-background border border-border relative"
                >
                  <div className="flex gap-1 text-accent mb-4">
                    {[...Array(5)].map((_, j) => <Star key={j} className="w-5 h-5 fill-current" />)}
                  </div>
                  <p className="text-lg mb-6 italic">"{review.text}"</p>
                  <div className="flex items-center justify-between mt-auto">
                    <span className="font-bold">{review.name}</span>
                    <span className="text-sm text-muted-foreground">{review.date}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Booking Form */}
        <section className="py-24 relative overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img src={techImage} alt="Technician background" className="w-full h-full object-cover opacity-20 mix-blend-luminosity grayscale" />
            <div className="absolute inset-0 bg-background/90 backdrop-blur-sm" />
          </div>

          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-xl mx-auto bg-card border border-border rounded-3xl p-8 md:p-12 shadow-2xl">
              <div className="text-center mb-10">
                <h2 className="text-3xl md:text-4xl font-black mb-4">Need Service Now?</h2>
                <p className="text-muted-foreground">Fill out the form below and we'll dispatch a technician immediately.</p>
              </div>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <Label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Name</Label>
                          <FormControl>
                            <Input placeholder="John Doe" className="h-14 bg-background border-border text-lg" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <Label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Phone Number</Label>
                          <FormControl>
                            <Input placeholder="(555) 000-0000" className="h-14 bg-background border-border text-lg" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="issueType"
                    render={({ field }) => (
                      <FormItem>
                        <Label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Type of Service</Label>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="h-14 bg-background border-border text-lg">
                              <SelectValue placeholder="Select an issue..." />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="ac_repair">AC Repair</SelectItem>
                            <SelectItem value="heat_repair">Heating Repair</SelectItem>
                            <SelectItem value="install">New Installation</SelectItem>
                            <SelectItem value="maint">Maintenance</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="preferredTime"
                    render={({ field }) => (
                      <FormItem>
                        <Label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Preferred Time</Label>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="h-14 bg-background border-border text-lg">
                              <SelectValue placeholder="When do you need us?" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="asap">EMERGENCY: As Soon As Possible</SelectItem>
                            <SelectItem value="today">Sometime Today</SelectItem>
                            <SelectItem value="tomorrow">Tomorrow</SelectItem>
                            <SelectItem value="flexible">Flexible</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" size="lg" className="w-full h-16 text-xl font-black bg-accent hover:bg-accent/90 text-white mt-4">
                    Schedule Service Now
                  </Button>
                </form>
              </Form>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border pt-16 pb-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Snowflake className="w-6 h-6 text-primary" />
                <Flame className="w-6 h-6 text-accent" />
                <span className="text-xl font-black">FrostFlow</span>
              </div>
              <p className="text-muted-foreground">
                Premium emergency HVAC repair services. Fast, reliable, and always ready when you need us most.
              </p>
            </div>
            
            <div>
              <h4 className="font-bold text-lg mb-4">Services</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-white transition-colors">AC Repair</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Furnace Repair</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Heat Pumps</a></li>
                <li><a href="#" className="hover:text-white transition-colors">System Installation</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-lg mb-4">Company</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Service Areas</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Reviews</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-lg mb-4">Emergency Contact</h4>
              <div className="space-y-4">
                <div className="p-4 bg-background rounded-lg border border-border">
                  <p className="text-sm text-muted-foreground mb-1">24/7 Dispatch Line</p>
                  <p className="text-2xl font-black text-accent">800-555-0199</p>
                </div>
                <p className="text-sm text-muted-foreground">Lic. #HVAC-89234 • Fully Insured</p>
              </div>
            </div>
          </div>
          
          <div className="pt-8 border-t border-border text-center text-sm text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} FrostFlow HVAC Services. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
