import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";

const projects = [
  {
    title: "Apex Tower — Commercial Retrofit",
    description: "18-floor office tower. Complete HVAC system redesign with zoned climate control and IoT monitoring.",
    category: "Commercial",
    result: "38% energy reduction",
    bg: "from-blue-900/60 to-slate-900/80",
  },
  {
    title: "Summit Hospitality Portfolio",
    description: "Four-hotel installation covering 600+ rooms with silent split systems and centralized building management.",
    category: "Hospitality",
    result: "Zero guest complaints",
    bg: "from-cyan-900/60 to-slate-900/80",
  },
  {
    title: "Harborview Residences",
    description: "48-unit luxury condominium with individual smart thermostat control per unit and shared central plant.",
    category: "Multi-family Residential",
    result: "LEED Gold certified",
    bg: "from-indigo-900/60 to-slate-900/80",
  },
  {
    title: "Meridian Medical Campus",
    description: "Hospital-grade filtration and precision climate control across surgical suites, labs, and patient wings.",
    category: "Healthcare",
    result: "ISO Class 7 compliant",
    bg: "from-teal-900/60 to-slate-900/80",
  },
  {
    title: "Riverton Distribution Center",
    description: "500,000 sq ft warehouse with industrial rooftop units, destratification fans, and smart zoning.",
    category: "Industrial",
    result: "41% operational savings",
    bg: "from-blue-800/60 to-slate-900/80",
  },
  {
    title: "The Langley Penthouse",
    description: "Bespoke residential installation — fully concealed ducted system with voice-integrated climate control.",
    category: "Luxury Residential",
    result: "White-glove installation",
    bg: "from-slate-800/60 to-slate-900/80",
  },
];

export function Projects() {
  return (
    <section id="projects" className="py-24 bg-background relative overflow-hidden">
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[300px] bg-primary/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-primary text-sm font-semibold uppercase tracking-widest mb-3"
          >
            Portfolio
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Systems We've <span className="text-primary">Built to Last</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-muted-foreground text-lg"
          >
            From single-family retrofits to full commercial campuses — every project backed by our performance guarantee.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.08 }}
              className="group relative bg-card border border-border rounded-2xl overflow-hidden hover:border-primary/40 hover:shadow-[0_8px_40px_rgba(0,255,255,0.1)] transition-all duration-300 cursor-pointer"
            >
              {/* Visual block */}
              <div className={`h-48 bg-gradient-to-br ${project.bg} relative overflow-hidden`}>
                {/* Grid overlay */}
                <div
                  className="absolute inset-0 opacity-20"
                  style={{
                    backgroundImage: `linear-gradient(rgba(0,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,255,0.1) 1px, transparent 1px)`,
                    backgroundSize: "32px 32px",
                  }}
                />
                {/* Animated glow spot */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-primary/20 rounded-full blur-2xl group-hover:bg-primary/30 transition-all duration-500" />
                {/* Category badge */}
                <div className="absolute top-4 left-4">
                  <span className="text-xs font-semibold uppercase tracking-widest text-primary bg-primary/10 border border-primary/20 px-3 py-1 rounded-full backdrop-blur-sm">
                    {project.category}
                  </span>
                </div>
                {/* Arrow icon on hover */}
                <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <ArrowUpRight className="h-4 w-4 text-primary" />
                </div>
              </div>

              <div className="p-6">
                <h3 className="font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-4">{project.description}</p>
                <div className="flex items-center justify-between pt-3 border-t border-border">
                  <span className="text-xs text-muted-foreground">Key Outcome</span>
                  <span className="text-sm font-semibold text-primary">{project.result}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
