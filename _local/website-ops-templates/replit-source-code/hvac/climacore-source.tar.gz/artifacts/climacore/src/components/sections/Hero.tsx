import React, { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Award, Zap, ShieldCheck } from "lucide-react";

function AirflowCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", handleResize);

    const lines: {
      x: number;
      y: number;
      speed: number;
      length: number;
      opacity: number;
      waveOffset: number;
      thickness: number;
    }[] = [];

    for (let i = 0; i < 60; i++) {
      lines.push({
        x: Math.random() * width,
        y: Math.random() * height,
        speed: 1 + Math.random() * 2,
        length: 50 + Math.random() * 150,
        opacity: Math.random() * 0.5 + 0.1,
        waveOffset: Math.random() * Math.PI * 2,
        thickness: Math.random() * 2 + 1,
      });
    }

    let animationFrameId: number;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Subtle gradient background (optional if we let CSS handle it)
      // We rely on CSS background, canvas is just the lines.

      lines.forEach((line) => {
        ctx.beginPath();
        ctx.moveTo(line.x, line.y);
        
        // create a flowing curve
        ctx.bezierCurveTo(
          line.x + line.length * 0.4, line.y + Math.sin(line.waveOffset) * 20,
          line.x + line.length * 0.6, line.y + Math.cos(line.waveOffset) * 20,
          line.x + line.length, line.y
        );

        ctx.strokeStyle = `rgba(0, 255, 255, ${line.opacity})`;
        ctx.lineWidth = line.thickness;
        ctx.lineCap = "round";
        ctx.stroke();

        line.x += line.speed;
        line.waveOffset += 0.02;

        if (line.x > width) {
          line.x = -line.length;
          line.y = Math.random() * height;
        }
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none opacity-60" />;
}

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-background">
      {/* Background glow effects */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[150px] pointer-events-none" />
      
      <AirflowCanvas />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="inline-flex items-center rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-sm text-primary mb-6 backdrop-blur-sm shadow-[0_0_15px_rgba(0,255,255,0.15)]">
              <span className="flex h-2 w-2 rounded-full bg-primary mr-2 animate-pulse" />
              Next-Gen Climate Systems
            </div>
            <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-foreground mb-6 leading-tight">
              Intelligent <br />
              Climate Control <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-400 drop-shadow-sm">
                for Modern Living
              </span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-10 leading-relaxed max-w-2xl">
              Precision engineering meets sustainable technology. Experience perfect temperatures, superior air quality, and uncompromising efficiency.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 h-14 px-8 text-base font-semibold shadow-[0_0_20px_rgba(0,255,255,0.3)] hover:shadow-[0_0_30px_rgba(0,255,255,0.5)] transition-all" asChild>
                <a href="#contact">Schedule Service</a>
              </Button>
              <Button size="lg" variant="outline" className="h-14 px-8 text-base font-semibold border-border bg-card/50 backdrop-blur-sm hover:bg-card hover:border-primary/50 transition-all" asChild>
                <a href="#technology">Explore Solutions</a>
              </Button>
            </div>

            <div className="flex flex-wrap items-center gap-6 text-sm font-medium text-muted-foreground">
              <div className="flex items-center gap-2">
                <Award className="h-5 w-5 text-primary" />
                <span>Certified Technicians</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-primary" />
                <span>Energy Star Rated</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-primary" />
                <span>10+ Years Experience</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
