import { motion } from "framer-motion";
import { Search, Stethoscope, Wrench, BarChart3 } from "lucide-react";

const steps = [
  {
    number: "01",
    title: "Inspection",
    description: "Our certified engineers conduct a comprehensive site survey, analyzing your space's thermal dynamics, insulation, and existing infrastructure.",
    icon: Search,
  },
  {
    number: "02",
    title: "Diagnosis",
    description: "Using advanced diagnostic tools and AI-driven analysis, we identify inefficiencies and design the optimal climate architecture for your needs.",
    icon: Stethoscope,
  },
  {
    number: "03",
    title: "Installation",
    description: "Precision installation by factory-trained technicians with minimal disruption. Every component is tested to exacting performance standards.",
    icon: Wrench,
  },
  {
    number: "04",
    title: "Optimization",
    description: "Post-install commissioning, smart system programming, and ongoing remote monitoring to ensure peak efficiency year-round.",
    icon: BarChart3,
  },
];

export function Process() {
  return (
    <section id="process" className="py-24 bg-card/30 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-primary text-sm font-semibold uppercase tracking-widest mb-3"
          >
            How We Work
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            From First Contact to <span className="text-primary">Perfect Climate</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-muted-foreground text-lg"
          >
            A rigorous four-phase process that leaves nothing to chance.
          </motion.p>
        </div>

        <div className="relative">
          {/* Connecting line (desktop) */}
          <div className="hidden lg:block absolute top-16 left-0 right-0 h-px">
            <motion.div
              className="h-full bg-gradient-to-r from-transparent via-primary/40 to-transparent"
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1.2, ease: "easeInOut", delay: 0.3 }}
              style={{ transformOrigin: "left" }}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-6">
            {steps.map((step, index) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.15 }}
                className="relative flex flex-col items-center text-center lg:items-center"
              >
                {/* Step number circle */}
                <div className="relative mb-6 z-10">
                  <div className="w-14 h-14 rounded-full bg-background border-2 border-primary/50 flex items-center justify-center shadow-[0_0_20px_rgba(0,255,255,0.2)] group-hover:shadow-[0_0_30px_rgba(0,255,255,0.4)] transition-all">
                    <step.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div className="absolute -top-3 -right-3 w-7 h-7 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center">
                    <span className="text-primary text-xs font-bold">{step.number}</span>
                  </div>
                </div>

                <div className="bg-card border border-border rounded-xl p-6 hover:border-primary/40 transition-all duration-300 hover:shadow-[0_8px_30px_rgba(0,255,255,0.08)] hover:-translate-y-1 w-full">
                  <h3 className="text-lg font-semibold text-foreground mb-3">{step.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
