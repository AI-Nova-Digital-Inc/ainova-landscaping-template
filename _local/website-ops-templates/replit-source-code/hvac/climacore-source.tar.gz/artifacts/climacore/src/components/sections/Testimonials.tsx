import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    name: "Marcus J.",
    role: "Facilities Director",
    company: "Apex Tower Group",
    rating: 5,
    quote:
      "ClimaCore redesigned the HVAC infrastructure across our 18-floor commercial building. Energy costs dropped 38% in the first year. The smart monitoring dashboard alone saved us thousands in avoided service calls.",
  },
  {
    name: "Priya S.",
    role: "Homeowner",
    company: "Residential",
    rating: 5,
    quote:
      "We had three other companies quote the job. ClimaCore was the only one that actually walked through our home's airflow before writing a proposal. The system they installed is whisper-quiet and our bills are noticeably lower.",
  },
  {
    name: "Daniel W.",
    role: "Operations Manager",
    company: "Summit Hospitality",
    rating: 5,
    quote:
      "Four hotels converted to ClimaCore systems in 18 months. Guest comfort complaints dropped to near zero. Their technicians treated our properties like their own — professional in every sense of the word.",
  },
  {
    name: "Karen L.",
    role: "Property Manager",
    company: "Vantage Realty",
    rating: 5,
    quote:
      "The flat-rate pricing was a relief. What they quoted is what we paid — not a dollar more. When we had an issue six months post-install, they were on-site in under three hours. Rare accountability in this industry.",
  },
];

function StarRating({ count }: { count: number }) {
  return (
    <div className="flex gap-1">
      {Array.from({ length: count }).map((_, i) => (
        <Star key={i} className="h-4 w-4 fill-primary text-primary" />
      ))}
    </div>
  );
}

export function Testimonials() {
  return (
    <section id="testimonials" className="py-24 bg-card/30 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-primary text-sm font-semibold uppercase tracking-widest mb-3"
          >
            Client Stories
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Trusted by the People <span className="text-primary">Who Demand More</span>
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {testimonials.map((t, index) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-card border border-border rounded-2xl p-8 hover:border-primary/30 hover:shadow-[0_8px_30px_rgba(0,255,255,0.06)] transition-all duration-300 relative"
            >
              <Quote className="absolute top-6 right-6 h-8 w-8 text-primary/15" />

              <div className="mb-4">
                <StarRating count={t.rating} />
              </div>

              <p className="text-foreground leading-relaxed mb-6 text-base">
                "{t.quote}"
              </p>

              <div className="flex items-center gap-3 pt-4 border-t border-border">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                  <span className="text-primary font-bold text-sm">{t.name[0]}</span>
                </div>
                <div>
                  <div className="font-semibold text-foreground text-sm">{t.name}</div>
                  <div className="text-muted-foreground text-xs">{t.role} — {t.company}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
