import React from "react";
import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";

export function Technology() {
  return (
    <section id="technology" className="py-24 bg-background relative overflow-hidden">
      {/* Decorative lines */}
      <div className="absolute top-0 right-0 w-1/2 h-full opacity-10 pointer-events-none">
        <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
          <path d="M0,100 L100,0" stroke="currentColor" strokeWidth="0.5" className="text-primary" />
          <path d="M0,80 L100,-20" stroke="currentColor" strokeWidth="0.5" className="text-primary" />
          <path d="M0,120 L100,20" stroke="currentColor" strokeWidth="0.5" className="text-primary" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              The Brain Behind the <span className="text-primary">Breeze</span>
            </h2>
            <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
              Our proprietary smart thermostats and centralized control units don't just react to temperature—they anticipate it. Using predictive algorithms and real-time weather data, ClimaCore systems optimize energy usage while maintaining perfect comfort.
            </p>
            
            <ul className="space-y-4 mb-8">
              {[
                "Machine learning temperature prediction",
                "Multi-zone micro-climate management",
                "Real-time energy consumption analytics",
                "Seamless integration with major smart home ecosystems"
              ].map((item, i) => (
                <li key={i} className="flex items-start">
                  <CheckCircle2 className="h-6 w-6 text-primary shrink-0 mr-3" />
                  <span className="text-foreground">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            {/* Mockup UI Block */}
            <div className="bg-card border border-border rounded-2xl shadow-2xl overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent pointer-events-none" />
              
              <div className="p-4 border-b border-border flex items-center justify-between bg-card/80 backdrop-blur">
                <div className="flex space-x-2">
                  <div className="w-3 h-3 rounded-full bg-red-500/20" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/20" />
                  <div className="w-3 h-3 rounded-full bg-green-500/20" />
                </div>
                <div className="text-xs font-mono text-muted-foreground">CLIMA_CORE_OS_v2.4</div>
              </div>
              
              <div className="p-8">
                <div className="flex justify-between items-end mb-8">
                  <div>
                    <div className="text-sm text-muted-foreground uppercase tracking-wider mb-1">Current Temp</div>
                    <div className="text-5xl font-light text-foreground">72.4°<span className="text-primary">F</span></div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-muted-foreground uppercase tracking-wider mb-1">Target</div>
                    <div className="text-2xl text-foreground">72.0°F</div>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-muted-foreground">System Load</span>
                      <span className="text-primary font-mono">42%</span>
                    </div>
                    <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                      <motion.div 
                        className="h-full bg-primary" 
                        initial={{ width: 0 }}
                        whileInView={{ width: "42%" }}
                        viewport={{ once: true }}
                        transition={{ duration: 1.5, ease: "easeOut", delay: 0.5 }}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-muted-foreground">Air Quality Index</span>
                      <span className="text-green-400 font-mono">98/100 (Optimal)</span>
                    </div>
                    <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                      <motion.div 
                        className="h-full bg-green-400" 
                        initial={{ width: 0 }}
                        whileInView={{ width: "98%" }}
                        viewport={{ once: true }}
                        transition={{ duration: 1.5, ease: "easeOut", delay: 0.7 }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Glow behind the mockup */}
            <div className="absolute -inset-4 bg-primary/20 blur-3xl -z-10 rounded-full opacity-50" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
