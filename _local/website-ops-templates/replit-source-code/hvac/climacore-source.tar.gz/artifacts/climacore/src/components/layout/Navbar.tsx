import React from "react";
import { Link } from "wouter";
import { Wind, Menu, X, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Navbar() {
  const [isOpen, setIsOpen] = React.useState(false);

  const navLinks = [
    { name: "Services", href: "#services" },
    { name: "Technology", href: "#technology" },
    { name: "Process", href: "#process" },
    { name: "Projects", href: "#projects" },
    { name: "About", href: "#why-us" },
  ];

  return (
    <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center">
            <Link href="/" className="flex items-center gap-2 group">
              <Wind className="h-8 w-8 text-primary group-hover:drop-shadow-[0_0_8px_rgba(0,255,255,0.8)] transition-all duration-300" />
              <span className="font-bold text-xl tracking-tight">ClimaCore</span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
              >
                {link.name}
              </a>
            ))}
          </div>

          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-center text-sm font-medium text-muted-foreground">
              <Phone className="h-4 w-4 mr-2 text-primary" />
              <span>1-800-CLIMA</span>
            </div>
            <Button variant="default" className="bg-primary text-primary-foreground hover:bg-primary/90 hover:drop-shadow-[0_0_12px_rgba(0,255,255,0.5)] transition-all" asChild>
              <a href="#contact">Get Quote</a>
            </Button>
          </div>

          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-muted-foreground hover:text-foreground focus:outline-none"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-background border-b border-border/50">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="block px-3 py-2 rounded-md text-base font-medium text-muted-foreground hover:text-primary hover:bg-muted/50"
                onClick={() => setIsOpen(false)}
              >
                {link.name}
              </a>
            ))}
            <div className="pt-4 flex flex-col gap-3 px-3">
              <div className="flex items-center text-sm font-medium text-muted-foreground">
                <Phone className="h-4 w-4 mr-2 text-primary" />
                <span>1-800-CLIMA</span>
              </div>
              <Button className="w-full bg-primary text-primary-foreground" onClick={() => setIsOpen(false)} asChild>
                <a href="#contact">Get Quote</a>
              </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
