import React from "react";
import { motion } from "framer-motion";
import { ThermometerSun, Snowflake, Wind, Cpu } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const services = [
  {
    title: "Precision Cooling",
    description: "High-efficiency AC systems designed for quiet operation and rapid temperature stabilization.",
    icon: Snowflake,
  },
  {
    title: "Advanced Heating",
    description: "Smart heat pumps and furnaces that maximize energy utilization without sacrificing comfort.",
    icon: ThermometerSun,
  },
  {
    title: "Air Purification",
    description: "Hospital-grade HEPA filtration and ventilation systems ensuring pristine indoor air quality.",
    icon: Wind,
  },
  {
    title: "Smart Integration",
    description: "IoT-enabled thermostats and zone controls accessible via mobile, optimizing usage automatically.",
    icon: Cpu,
  },
];

export function Services() {
  return (
    <section id="services" className="py-24 bg-card/30 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Engineered for <span className="text-primary">Performance</span>
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-muted-foreground text-lg"
          >
            We don't just install boxes. We architect complete climate ecosystems tailored to your space's unique thermal dynamics.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="bg-card border-border hover:border-primary/50 transition-all duration-300 group hover:shadow-[0_8px_30px_rgba(0,255,255,0.1)] hover:-translate-y-1 h-full overflow-hidden relative">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                <CardContent className="p-8">
                  <div className="w-14 h-14 rounded-lg bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                    <service.icon className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3 text-foreground group-hover:text-primary transition-colors">{service.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
