import { motion } from "framer-motion";
import { Leaf, BadgeCheck, Timer, DollarSign } from "lucide-react";

const benefits = [
  {
    icon: Leaf,
    title: "Energy Efficient",
    description: "All ClimaCore systems are Energy Star certified, reducing your carbon footprint and lowering energy bills by up to 40% versus standard equipment.",
    stat: "Up to 40%",
    statLabel: "Energy Savings",
  },
  {
    icon: BadgeCheck,
    title: "Certified Technicians",
    description: "Every member of our field team holds NATE certification. We train in-house on each system we install — no generalists, only specialists.",
    stat: "NATE",
    statLabel: "Certified Staff",
  },
  {
    icon: Timer,
    title: "Fast Response",
    description: "Emergency service within 4 hours, guaranteed. Our dispatch network covers the entire metro area with fully-stocked service vehicles.",
    stat: "< 4 hrs",
    statLabel: "Emergency Response",
  },
  {
    icon: DollarSign,
    title: "Transparent Pricing",
    description: "Flat-rate service calls, itemized quotes, and no hidden fees — ever. You approve every dollar before any work begins.",
    stat: "Zero",
    statLabel: "Hidden Fees",
  },
];

export function WhyUs() {
  return (
    <section id="why-us" className="py-24 bg-background relative overflow-hidden">
      <div className="absolute top-0 left-0 w-1/3 h-full pointer-events-none opacity-30">
        <div className="w-full h-full bg-gradient-to-r from-primary/5 to-transparent" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-primary text-sm font-semibold uppercase tracking-widest mb-3"
          >
            Why ClimaCore
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            The Standard Other Companies <span className="text-primary">Measure Against</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-muted-foreground text-lg"
          >
            We built ClimaCore on four commitments that never get compromised.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {benefits.map((benefit, index) => (
            <motion.div
              key={benefit.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group bg-card border border-border rounded-2xl p-8 hover:border-primary/40 hover:shadow-[0_8px_40px_rgba(0,255,255,0.08)] transition-all duration-300 hover:-translate-y-1 flex gap-6 items-start"
            >
              <div className="shrink-0 w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                <benefit.icon className="h-8 w-8 text-primary" />
              </div>

              <div className="flex-1">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors">{benefit.title}</h3>
                  <div className="text-right ml-4">
                    <div className="text-2xl font-bold text-primary font-mono leading-none">{benefit.stat}</div>
                    <div className="text-xs text-muted-foreground mt-1">{benefit.statLabel}</div>
                  </div>
                </div>
                <p className="text-muted-foreground leading-relaxed">{benefit.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
