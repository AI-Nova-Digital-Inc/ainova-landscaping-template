import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import { Heart, MapPin, Trash2, Clock, Star, ArrowRight, BookOpen } from "lucide-react";
import { useSavedTrips } from "@/hooks/use-saved";
import { destinations } from "@/data/destinations";
import { useState, useEffect } from "react";

interface SavedItinerary {
  destId: string;
  destName: string;
  savedAt: number;
}

export default function Saved() {
  const { savedIds, toggle } = useSavedTrips();
  const [itineraries, setItineraries] = useState<SavedItinerary[]>([]);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("savedItineraries") || "[]");
    setItineraries(saved);
  }, []);

  const savedDestinations = destinations.filter((d) => savedIds.includes(d.id));

  const removeItinerary = (destId: string) => {
    const updated = itineraries.filter((it) => it.destId !== destId);
    setItineraries(updated);
    localStorage.setItem("savedItineraries", JSON.stringify(updated));
  };

  const isEmpty = savedDestinations.length === 0 && itineraries.length === 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="px-4 pt-8 pb-4 max-w-2xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-900">Saved Trips</h1>
        <p className="text-gray-500 text-sm mt-1">Your wishlist and saved itineraries</p>
      </div>

      <div className="px-4 pb-8 max-w-2xl mx-auto">
        {isEmpty ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-24"
          >
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="text-6xl mb-6"
            >
              🗺️
            </motion.div>
            <h2 className="text-xl font-bold text-gray-900 mb-3">No saved trips yet</h2>
            <p className="text-gray-500 text-sm leading-relaxed mb-8 max-w-xs mx-auto">
              Tap the heart icon on any destination to save it here for later. You can also save full itineraries.
            </p>
            <Link href="/destinations">
              <motion.button
                className="inline-flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-orange-500 to-amber-500 text-white font-semibold rounded-xl shadow-md shadow-orange-200"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Explore Destinations
                <ArrowRight className="w-4 h-4" />
              </motion.button>
            </Link>
          </motion.div>
        ) : (
          <div className="space-y-6">
            {/* Saved destinations */}
            {savedDestinations.length > 0 && (
              <div>
                <h2 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                  <Heart className="w-4 h-4 text-red-500 fill-red-500" />
                  Wishlist ({savedDestinations.length})
                </h2>
                <div className="space-y-3">
                  <AnimatePresence>
                    {savedDestinations.map((dest, i) => (
                      <motion.div
                        key={dest.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ delay: i * 0.05 }}
                        className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden"
                      >
                        <div className={`h-20 bg-gradient-to-br ${dest.gradient} relative`}>
                          <div className="absolute inset-0 flex items-center px-4 justify-between">
                            <div>
                              <h3 className="font-bold text-white text-sm">{dest.name}</h3>
                              <p className="text-white/80 text-xs">{dest.region}</p>
                            </div>
                            <button
                              onClick={() => toggle(dest.id)}
                              className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center"
                            >
                              <Heart className="w-4 h-4 fill-white text-white" />
                            </button>
                          </div>
                        </div>

                        <div className="p-4">
                          <div className="grid grid-cols-3 gap-3 text-center">
                            <div>
                              <div className="text-xs text-gray-400">Toddler score</div>
                              <div className="font-bold text-orange-500">{dest.toddlerScore}/10</div>
                            </div>
                            <div>
                              <div className="text-xs text-gray-400">Food score</div>
                              <div className="font-bold text-blue-500">{dest.foodScore}/10</div>
                            </div>
                            <div>
                              <div className="text-xs text-gray-400">From Cambridge</div>
                              <div className="font-bold text-gray-700 text-xs">{dest.drivingDistance.Cambridge}</div>
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-1 mt-3">
                            {dest.bestSeasons.map((s) => (
                              <span key={s} className="text-[10px] bg-orange-50 text-orange-600 px-2 py-0.5 rounded-full font-medium border border-orange-100">
                                {s}
                              </span>
                            ))}
                            {dest.hasIndianFood && <span className="text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">Indian food</span>}
                          </div>

                          <Link href={`/destinations/${dest.id}`}>
                            <button className="mt-3 w-full flex items-center justify-center gap-2 py-2 bg-orange-50 hover:bg-orange-100 text-orange-600 rounded-xl text-sm font-medium transition-all">
                              View details
                              <ArrowRight className="w-4 h-4" />
                            </button>
                          </Link>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </div>
            )}

            {/* Saved itineraries */}
            {itineraries.length > 0 && (
              <div>
                <h2 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-purple-500" />
                  Saved Itineraries ({itineraries.length})
                </h2>
                <div className="space-y-3">
                  <AnimatePresence>
                    {itineraries.map((it, i) => {
                      const dest = destinations.find((d) => d.id === it.destId);
                      return (
                        <motion.div
                          key={it.destId}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, x: -20 }}
                          transition={{ delay: i * 0.05 }}
                          className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4"
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${dest?.gradient || "from-orange-400 to-amber-400"} flex items-center justify-center text-lg`}>
                                📋
                              </div>
                              <div>
                                <h3 className="font-bold text-gray-900 text-sm">{it.destName}</h3>
                                <p className="text-xs text-gray-400 flex items-center gap-1 mt-0.5">
                                  <Clock className="w-3 h-3" />
                                  Saved {new Date(it.savedAt).toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                            <button
                              onClick={() => removeItinerary(it.destId)}
                              className="w-8 h-8 rounded-full bg-red-50 flex items-center justify-center text-red-400 hover:bg-red-100 transition-all"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="mt-3 p-3 bg-purple-50 rounded-xl">
                            <div className="text-xs text-purple-700 font-medium mb-2">Day trip schedule:</div>
                            <div className="space-y-1">
                              {["9:00 AM — Leave home", "11:00 AM — Main attraction", "12:30 PM — Lunch", "1:30 PM — Nap break", "3:00 PM — Easy activity", "5:00 PM — Dinner", "6:30 PM — Return"].map((item, j) => (
                                <div key={j} className="text-xs text-purple-600 flex items-center gap-1.5">
                                  <span className="w-1.5 h-1.5 rounded-full bg-purple-400 shrink-0" />
                                  {item}
                                </div>
                              ))}
                            </div>
                          </div>

                          <Link href={`/destinations/${it.destId}`}>
                            <button className="mt-3 w-full flex items-center justify-center gap-2 py-2 bg-purple-50 hover:bg-purple-100 text-purple-600 rounded-xl text-sm font-medium transition-all">
                              <MapPin className="w-4 h-4" />
                              View full destination
                            </button>
                          </Link>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
