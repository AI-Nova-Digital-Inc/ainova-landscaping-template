import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckSquare, RotateCcw, Package, Share2 } from "lucide-react";

interface ChecklistItem {
  id: string;
  label: string;
  emoji: string;
  category: string;
  note: string;
}

const checklistItems: ChecklistItem[] = [
  // Mobility
  { id: "stroller", label: "Stroller", emoji: "🛒", category: "Mobility", note: "Lightweight or all-terrain based on destination" },
  { id: "carrier", label: "Baby carrier / wrap", emoji: "🤱", category: "Mobility", note: "For crowded areas or uneven paths" },

  // Essentials
  { id: "diapers", label: "Diapers & wipes", emoji: "🧻", category: "Essentials", note: "Pack 2x more than you think you need" },
  { id: "extra-clothes", label: "Extra clothes (3 sets)", emoji: "👕", category: "Essentials", note: "Toddlers will get messy — guaranteed" },
  { id: "snacks", label: "Toddler snacks", emoji: "🍎", category: "Essentials", note: "Pouches, crackers, cut fruit" },
  { id: "water-bottle", label: "Spill-proof water bottle", emoji: "💧", category: "Essentials", note: "Keep toddler hydrated especially in summer" },
  { id: "favorite-toy", label: "Favorite toy / comfort item", emoji: "🧸", category: "Essentials", note: "For long drives and wind-down time" },
  { id: "nap-blanket", label: "Nap blanket", emoji: "🛏️", category: "Essentials", note: "Familiar blanket helps with naps on the go" },

  // Health & Safety
  { id: "sunscreen", label: "Sunscreen SPF 50+", emoji: "☀️", category: "Health & Safety", note: "Apply 30 min before sun exposure, reapply every 2h" },
  { id: "first-aid", label: "First aid kit", emoji: "🩹", category: "Health & Safety", note: "Band-aids, antiseptic, toddler pain reliever" },
  { id: "bug-spray", label: "Bug spray (toddler-safe)", emoji: "🦟", category: "Health & Safety", note: "DEET-free formulas for toddlers" },
  { id: "medicine", label: "Toddler medicine bag", emoji: "💊", category: "Health & Safety", note: "Tylenol, allergy meds, thermometer" },

  // Weather-specific
  { id: "winter-layers", label: "Winter layers", emoji: "🧥", category: "Weather", note: "Snowsuit, mittens, warm boots, hat — dress in layers" },
  { id: "rain-poncho", label: "Rain poncho", emoji: "🌧️", category: "Weather", note: "Compact poncho for sudden showers or falls mist" },
  { id: "sun-hat", label: "Sun hat with strap", emoji: "👒", category: "Weather", note: "Chin strap keeps it on active toddlers" },

  // Food & Feeding
  { id: "bibs", label: "Bibs & feeding spoons", emoji: "🍼", category: "Food", note: "Mess-proof bibs for restaurant meals" },
  { id: "portable-mat", label: "Portable high chair / clip-on seat", emoji: "🪑", category: "Food", note: "Not all restaurants have high chairs" },

  // Documents
  { id: "passports", label: "Passports (if crossing border)", emoji: "📘", category: "Documents", note: "Toddlers need their own passport for USA trips" },
  { id: "health-card", label: "Provincial health card", emoji: "🏥", category: "Documents", note: "Keep all family health cards in one wallet" },
  { id: "car-seat", label: "Car seat properly installed", emoji: "🚗", category: "Documents", note: "Check seat before every road trip" },
];

const categories = [...new Set(checklistItems.map((item) => item.category))];

const categoryColors: Record<string, string> = {
  Mobility: "bg-blue-50 border-blue-100",
  Essentials: "bg-orange-50 border-orange-100",
  "Health & Safety": "bg-red-50 border-red-100",
  Weather: "bg-sky-50 border-sky-100",
  Food: "bg-green-50 border-green-100",
  Documents: "bg-purple-50 border-purple-100",
};

const categoryHeaderColors: Record<string, string> = {
  Mobility: "text-blue-700",
  Essentials: "text-orange-700",
  "Health & Safety": "text-red-700",
  Weather: "text-sky-700",
  Food: "text-green-700",
  Documents: "text-purple-700",
};

export default function Checklist() {
  const [checked, setChecked] = useState<Set<string>>(new Set());

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("checklist") || "[]");
    setChecked(new Set(saved));
  }, []);

  const toggle = (id: string) => {
    const next = new Set(checked);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setChecked(next);
    localStorage.setItem("checklist", JSON.stringify([...next]));
  };

  const reset = () => {
    setChecked(new Set());
    localStorage.setItem("checklist", "[]");
  };

  const completedCount = checked.size;
  const totalCount = checklistItems.length;
  const progress = (completedCount / totalCount) * 100;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-20 shadow-sm px-4 py-4">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                <Package className="w-5 h-5 text-orange-500" />
                Packing Checklist
              </h1>
              <p className="text-xs text-gray-500 mt-0.5">For toddler travel — never forget the essentials</p>
            </div>
            <button
              onClick={reset}
              className="flex items-center gap-1.5 px-3 py-2 bg-gray-100 text-gray-600 rounded-xl text-xs font-medium hover:bg-gray-200 transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset
            </button>
          </div>

          {/* Progress */}
          <div className="mt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-500 font-medium">
                {completedCount} of {totalCount} packed
              </span>
              <span className="text-xs font-bold text-orange-600">{Math.round(progress)}%</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-orange-500 to-amber-500 rounded-full"
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.4, ease: "easeOut" }}
              />
            </div>
            {progress === 100 && (
              <motion.div
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-2 text-center text-sm font-bold text-green-600"
              >
                All packed — ready to go!
              </motion.div>
            )}
          </div>
        </div>
      </div>

      <div className="px-4 py-6 max-w-2xl mx-auto space-y-6">
        {categories.map((category) => {
          const items = checklistItems.filter((item) => item.category === category);
          const catChecked = items.filter((item) => checked.has(item.id)).length;

          return (
            <div key={category}>
              <div className="flex items-center justify-between mb-3">
                <h2 className={`font-bold text-sm flex items-center gap-2 ${categoryHeaderColors[category]}`}>
                  <CheckSquare className="w-4 h-4" />
                  {category}
                </h2>
                <span className="text-xs text-gray-400">{catChecked}/{items.length}</span>
              </div>

              <div className={`rounded-2xl border overflow-hidden ${categoryColors[category]}`}>
                {items.map((item, i) => {
                  const isChecked = checked.has(item.id);
                  return (
                    <motion.button
                      key={item.id}
                      onClick={() => toggle(item.id)}
                      className={`w-full flex items-center gap-4 p-4 text-left transition-all ${
                        i < items.length - 1 ? "border-b border-white/60" : ""
                      } ${isChecked ? "opacity-60" : ""}`}
                      whileTap={{ scale: 0.99 }}
                    >
                      {/* Checkbox */}
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${
                        isChecked ? "bg-green-500 border-green-500" : "border-gray-300 bg-white"
                      }`}>
                        <AnimatePresence>
                          {isChecked && (
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              exit={{ scale: 0 }}
                            >
                              <svg className="w-3.5 h-3.5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={3}>
                                <polyline points="20 6 9 17 4 12" />
                              </svg>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>

                      {/* Emoji */}
                      <span className="text-xl shrink-0">{item.emoji}</span>

                      {/* Content */}
                      <div className="flex-1">
                        <div className={`font-semibold text-sm ${isChecked ? "line-through text-gray-400" : "text-gray-900"}`}>
                          {item.label}
                        </div>
                        <div className="text-xs text-gray-500 mt-0.5">{item.note}</div>
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </div>
          );
        })}

        {/* Tips */}
        <div className="bg-amber-50 border border-amber-100 rounded-2xl p-4">
          <h3 className="font-bold text-amber-900 text-sm mb-2">Pro tip for Indian families</h3>
          <p className="text-xs text-amber-700 leading-relaxed">
            Pack a small insulated bag with familiar snacks from home — Indian snack foods like puffs, rusk, and munchies are toddler favorites and hard to find at tourist spots. A small thermos with dal or khichdi can save a mealtime meltdown!
          </p>
        </div>

        {/* Reset button */}
        <motion.button
          onClick={reset}
          className="w-full flex items-center justify-center gap-2 py-3 bg-white border-2 border-dashed border-gray-200 text-gray-500 rounded-2xl text-sm font-medium hover:border-orange-300 hover:text-orange-500 transition-all"
          whileTap={{ scale: 0.98 }}
        >
          <RotateCcw className="w-4 h-4" />
          Reset all checkboxes
        </motion.button>
      </div>
    </div>
  );
}
