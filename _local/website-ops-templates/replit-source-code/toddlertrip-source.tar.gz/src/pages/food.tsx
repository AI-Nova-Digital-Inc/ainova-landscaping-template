import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { useSearch } from "wouter";
import { Utensils, Star, MapPin, Car, Search, Filter, Baby } from "lucide-react";
import { restaurants, type Cuisine } from "@/data/restaurants";
import { destinations } from "@/data/destinations";

const cuisineColors: Record<string, string> = {
  Indian: "bg-orange-100 text-orange-700 border-orange-200",
  "Middle Eastern": "bg-amber-100 text-amber-700 border-amber-200",
  Chinese: "bg-red-100 text-red-700 border-red-200",
  Mandi: "bg-yellow-100 text-yellow-700 border-yellow-200",
  Vegetarian: "bg-green-100 text-green-700 border-green-200",
  "Family-friendly": "bg-blue-100 text-blue-700 border-blue-200",
};

const cuisineEmoji: Record<string, string> = {
  Indian: "🍛",
  "Middle Eastern": "🧆",
  Chinese: "🥟",
  Mandi: "🍖",
  Vegetarian: "🥗",
  "Family-friendly": "👨‍👩‍👧",
};

const priceColors: Record<string, string> = {
  "$": "text-green-600",
  "$$": "text-amber-600",
  "$$$": "text-red-600",
};

function StarRating({ score }: { score: number }) {
  return (
    <div className="flex items-center gap-1">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className={`w-3 h-3 ${i < Math.round(score / 2) ? "fill-amber-400 text-amber-400" : "text-gray-200"}`}
        />
      ))}
      <span className="text-xs text-gray-500 ml-1">{score}/10</span>
    </div>
  );
}

export default function Food() {
  const search = useSearch();
  const params = new URLSearchParams(search);
  const initDest = params.get("dest") || "";

  const [selectedCuisines, setSelectedCuisines] = useState<Cuisine[]>([]);
  const [selectedDest, setSelectedDest] = useState(initDest);
  const [searchQ, setSearchQ] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const allCuisines: Cuisine[] = ["Indian", "Middle Eastern", "Chinese", "Mandi", "Vegetarian", "Family-friendly"];

  const filtered = useMemo(() =>
    restaurants.filter((r) => {
      if (selectedCuisines.length && !selectedCuisines.includes(r.cuisine)) return false;
      if (selectedDest && !r.destinationIds.includes(selectedDest)) return false;
      if (searchQ && !r.name.toLowerCase().includes(searchQ.toLowerCase()) && !r.city.toLowerCase().includes(searchQ.toLowerCase())) return false;
      return true;
    }),
    [selectedCuisines, selectedDest, searchQ]
  );

  const toggleCuisine = (c: Cuisine) =>
    setSelectedCuisines((prev) => (prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c]));

  const destName = destinations.find((d) => d.id === selectedDest)?.name;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-20 shadow-sm">
        <div className="px-4 pt-4 pb-3 max-w-2xl mx-auto">
          <h1 className="text-xl font-bold text-gray-900">Food Finder</h1>
          <p className="text-xs text-gray-500 mt-0.5">
            Indian, Middle Eastern, Chinese & Mandi restaurants near your destination
          </p>

          <div className="flex gap-2 mt-3">
            <div className="flex-1 flex items-center gap-2 bg-gray-100 rounded-xl px-3 py-2">
              <Search className="w-4 h-4 text-gray-400 shrink-0" />
              <input
                value={searchQ}
                onChange={(e) => setSearchQ(e.target.value)}
                placeholder="Search restaurants..."
                className="bg-transparent flex-1 text-sm text-gray-700 outline-none placeholder:text-gray-400"
              />
            </div>
            <motion.button
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border text-sm font-medium ${showFilters ? "bg-orange-500 text-white border-orange-500" : "bg-white text-gray-700 border-gray-200"}`}
              whileTap={{ scale: 0.97 }}
            >
              <Filter className="w-4 h-4" />
            </motion.button>
          </div>

          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="mt-3 space-y-3"
            >
              <div>
                <div className="text-xs font-semibold text-gray-500 mb-2 uppercase tracking-wide">Cuisine type</div>
                <div className="flex flex-wrap gap-2">
                  {allCuisines.map((c) => (
                    <button
                      key={c}
                      onClick={() => toggleCuisine(c)}
                      className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                        selectedCuisines.includes(c) ? "bg-orange-500 text-white border-orange-500" : "bg-white text-gray-600 border-gray-200"
                      }`}
                    >
                      <span>{cuisineEmoji[c]}</span>
                      {c}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-xs font-semibold text-gray-500 mb-2 uppercase tracking-wide">Near destination</div>
                <select
                  value={selectedDest}
                  onChange={(e) => setSelectedDest(e.target.value)}
                  className="w-full text-sm border border-gray-200 rounded-xl px-3 py-2 bg-white text-gray-700 outline-none"
                >
                  <option value="">All destinations</option>
                  {destinations.map((d) => (
                    <option key={d.id} value={d.id}>{d.name}</option>
                  ))}
                </select>
              </div>
            </motion.div>
          )}
        </div>

        {/* Cuisine quick filters */}
        {!showFilters && (
          <div className="flex gap-2 px-4 pb-3 overflow-x-auto scrollbar-none max-w-2xl mx-auto">
            {allCuisines.map((c) => (
              <motion.button
                key={c}
                onClick={() => toggleCuisine(c)}
                className={`shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                  selectedCuisines.includes(c) ? "bg-orange-500 text-white border-orange-500" : "bg-white text-gray-600 border-gray-200"
                }`}
                whileTap={{ scale: 0.95 }}
              >
                <span>{cuisineEmoji[c]}</span>
                {c}
              </motion.button>
            ))}
          </div>
        )}
      </div>

      <div className="px-4 py-6 max-w-2xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-gray-500">
            <span className="font-bold text-gray-900">{filtered.length}</span> restaurants
            {destName && <span> near <span className="font-semibold text-orange-600">{destName}</span></span>}
          </p>
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-5xl mb-4">🍽️</div>
            <h3 className="font-bold text-gray-900">No restaurants found</h3>
            <p className="text-gray-500 text-sm mt-2">Try changing the cuisine filter or destination</p>
            <button
              onClick={() => { setSelectedCuisines([]); setSelectedDest(""); setSearchQ(""); }}
              className="mt-4 px-6 py-2 bg-orange-500 text-white rounded-xl text-sm font-medium"
            >
              Clear filters
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {filtered.map((r, i) => (
              <motion.div
                key={r.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06 }}
                className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden"
              >
                {/* Color stripe */}
                <div className={`h-1.5 ${cuisineColors[r.cuisine]?.split(" ")[0]?.replace("text-", "bg-")?.replace("100", "400") || "bg-orange-400"}`} />

                <div className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{cuisineEmoji[r.cuisine]}</span>
                        <h3 className="font-bold text-gray-900">{r.name}</h3>
                      </div>
                      <p className="text-xs text-gray-500 mt-0.5">{r.city}</p>
                    </div>
                    <div className="text-right">
                      <StarRating score={r.familyFriendlyScore} />
                      <span className={`text-sm font-bold ${priceColors[r.priceRange]}`}>{r.priceRange}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mt-3">
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${cuisineColors[r.cuisine]}`}>
                      {r.cuisine}
                    </span>
                    <span className="text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full font-medium flex items-center gap-1">
                      <MapPin className="w-2.5 h-2.5" />
                      {r.distanceFromAttraction}
                    </span>
                    <span className="text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full font-medium flex items-center gap-1">
                      <Car className="w-2.5 h-2.5" />
                      {r.parking}
                    </span>
                  </div>

                  <div className="mt-3 p-3 bg-orange-50 rounded-xl">
                    <div className="text-xs font-semibold text-orange-700 mb-1">What to order</div>
                    <div className="flex flex-wrap gap-1">
                      {r.whatToOrder.map((item, j) => (
                        <span key={j} className="text-xs bg-white border border-orange-100 text-orange-600 px-2 py-0.5 rounded-full">
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="mt-3 flex items-start gap-2 p-3 bg-blue-50 rounded-xl">
                    <Baby className="w-3.5 h-3.5 text-blue-500 shrink-0 mt-0.5" />
                    <p className="text-xs text-blue-700">{r.toddlerNotes}</p>
                  </div>

                  <a
                    href={r.mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-3 flex items-center justify-center gap-2 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-medium transition-all"
                  >
                    <Utensils className="w-4 h-4" />
                    View on Google Maps
                  </a>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
