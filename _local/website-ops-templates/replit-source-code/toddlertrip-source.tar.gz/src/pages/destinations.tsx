import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Link, useSearch } from "wouter";
import { MapPin, Star, Heart, Filter, X, Baby, Car, Utensils, Search } from "lucide-react";
import { destinations, filterDestinations, type Season, type StartCity } from "@/data/destinations";
import { useSavedTrips } from "@/hooks/use-saved";

const seasonColors: Record<string, string> = {
  Summer: "bg-amber-100 text-amber-700",
  Winter: "bg-blue-100 text-blue-700",
  Spring: "bg-green-100 text-green-700",
  Fall: "bg-orange-100 text-orange-700",
};

function ScoreBar({ score, color = "orange" }: { score: number; color?: string }) {
  const colors: Record<string, string> = {
    orange: "bg-orange-500",
    blue: "bg-blue-500",
    green: "bg-green-500",
  };
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
        <motion.div
          className={`h-full rounded-full ${colors[color]}`}
          initial={{ width: 0 }}
          animate={{ width: `${score * 10}%` }}
          transition={{ duration: 0.7, delay: 0.2 }}
        />
      </div>
      <span className="text-xs font-bold text-gray-700 w-6">{score}</span>
    </div>
  );
}

export default function Destinations() {
  const search = useSearch();
  const params = new URLSearchParams(search);

  const initSeason = params.get("season") as Season | null;
  const initCity = (params.get("city") as StartCity) || "Cambridge";
  const initMaxHours = params.get("maxHours") ? Number(params.get("maxHours")) : undefined;

  const [selectedSeasons, setSelectedSeasons] = useState<Season[]>(initSeason ? [initSeason] : []);
  const [startCity, setStartCity] = useState<StartCity>(initCity);
  const [maxHours, setMaxHours] = useState<number | undefined>(initMaxHours);
  const [strollerOnly, setStrollerOnly] = useState(false);
  const [lowWalkingOnly, setLowWalkingOnly] = useState(false);
  const [indianFoodOnly, setIndianFoodOnly] = useState(false);
  const [meFoodOnly, setMeFoodOnly] = useState(false);
  const [searchQ, setSearchQ] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const { savedIds, toggle } = useSavedTrips();

  const filtered = useMemo(() =>
    filterDestinations(destinations, {
      seasons: selectedSeasons,
      startCity,
      maxHours,
      strollerFriendly: strollerOnly || undefined,
      lowWalking: lowWalkingOnly || undefined,
      hasIndianFood: indianFoodOnly || undefined,
      hasMiddleEasternFood: meFoodOnly || undefined,
      search: searchQ || undefined,
    }),
    [selectedSeasons, startCity, maxHours, strollerOnly, lowWalkingOnly, indianFoodOnly, meFoodOnly, searchQ]
  );

  const activeFilters = [
    ...selectedSeasons,
    maxHours ? `<${maxHours}h` : null,
    strollerOnly ? "Stroller-friendly" : null,
    lowWalkingOnly ? "Low walking" : null,
    indianFoodOnly ? "Indian food" : null,
    meFoodOnly ? "Middle Eastern food" : null,
  ].filter(Boolean) as string[];

  const seasons: Season[] = ["Summer", "Winter", "Spring", "Fall"];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-white border-b border-gray-100 px-4 py-4 shadow-sm">
        <div className="flex items-center gap-3 max-w-4xl mx-auto">
          <div className="flex-1 flex items-center gap-2 bg-gray-100 rounded-xl px-3 py-2">
            <Search className="w-4 h-4 text-gray-400 shrink-0" />
            <input
              value={searchQ}
              onChange={(e) => setSearchQ(e.target.value)}
              placeholder="Search destinations..."
              className="bg-transparent flex-1 text-sm text-gray-700 outline-none placeholder:text-gray-400"
            />
          </div>
          <motion.button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl border text-sm font-medium transition-all ${showFilters ? "bg-orange-500 text-white border-orange-500" : "bg-white text-gray-700 border-gray-200"}`}
            whileTap={{ scale: 0.97 }}
          >
            <Filter className="w-4 h-4" />
            Filters
            {activeFilters.length > 0 && (
              <span className={`ml-0.5 w-5 h-5 rounded-full text-xs flex items-center justify-center font-bold ${showFilters ? "bg-white text-orange-500" : "bg-orange-500 text-white"}`}>
                {activeFilters.length}
              </span>
            )}
          </motion.button>
        </div>

        {/* Filter panel */}
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="max-w-4xl mx-auto mt-3 space-y-4"
          >
            <div>
              <div className="text-xs font-semibold text-gray-500 mb-2 uppercase tracking-wide">Starting city</div>
              <div className="flex flex-wrap gap-2">
                {(["Cambridge", "Waterloo", "Mississauga", "Toronto"] as StartCity[]).map((c) => (
                  <button
                    key={c}
                    onClick={() => setStartCity(c)}
                    className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${startCity === c ? "bg-orange-500 text-white border-orange-500" : "bg-white text-gray-600 border-gray-200"}`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div className="text-xs font-semibold text-gray-500 mb-2 uppercase tracking-wide">Season</div>
              <div className="flex flex-wrap gap-2">
                {seasons.map((s) => (
                  <button
                    key={s}
                    onClick={() =>
                      setSelectedSeasons((prev) =>
                        prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]
                      )
                    }
                    className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${selectedSeasons.includes(s) ? "bg-orange-500 text-white border-orange-500" : "bg-white text-gray-600 border-gray-200"}`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div className="text-xs font-semibold text-gray-500 mb-2 uppercase tracking-wide">Max drive</div>
              <div className="flex flex-wrap gap-2">
                {[1, 3, 6, 99].map((h) => (
                  <button
                    key={h}
                    onClick={() => setMaxHours(maxHours === h ? undefined : h)}
                    className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${maxHours === h ? "bg-orange-500 text-white border-orange-500" : "bg-white text-gray-600 border-gray-200"}`}
                  >
                    {h === 1 ? "< 1hr" : h === 99 ? "Any" : `< ${h}hr`}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div className="text-xs font-semibold text-gray-500 mb-2 uppercase tracking-wide">Special filters</div>
              <div className="flex flex-wrap gap-2">
                {[
                  { label: "Stroller-friendly", val: strollerOnly, set: setStrollerOnly },
                  { label: "Low walking", val: lowWalkingOnly, set: setLowWalkingOnly },
                  { label: "Indian food", val: indianFoodOnly, set: setIndianFoodOnly },
                  { label: "Middle Eastern food", val: meFoodOnly, set: setMeFoodOnly },
                ].map(({ label, val, set }) => (
                  <button
                    key={label}
                    onClick={() => set(!val)}
                    className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${val ? "bg-orange-500 text-white border-orange-500" : "bg-white text-gray-600 border-gray-200"}`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Active filter chips */}
        {activeFilters.length > 0 && !showFilters && (
          <div className="flex gap-2 overflow-x-auto mt-3 max-w-4xl mx-auto pb-1 scrollbar-none">
            {activeFilters.map((f) => (
              <span key={f} className="shrink-0 flex items-center gap-1 px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-xs font-medium">
                {f}
                <X className="w-3 h-3 cursor-pointer" onClick={() => {
                  if (seasons.includes(f as Season)) setSelectedSeasons((p) => p.filter((s) => s !== f));
                  if (f.startsWith("<")) setMaxHours(undefined);
                  if (f === "Stroller-friendly") setStrollerOnly(false);
                  if (f === "Low walking") setLowWalkingOnly(false);
                  if (f === "Indian food") setIndianFoodOnly(false);
                  if (f === "Middle Eastern food") setMeFoodOnly(false);
                }} />
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Results */}
      <div className="px-4 py-6 max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-gray-500">
            <span className="font-bold text-gray-900">{filtered.length}</span> destinations found
          </p>
          <p className="text-xs text-gray-400">Distances from {startCity}</p>
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-5xl mb-4">🗺️</div>
            <h3 className="font-bold text-gray-900 text-lg">No destinations match</h3>
            <p className="text-gray-500 text-sm mt-2">Try removing some filters to see more options</p>
            <button
              onClick={() => {
                setSelectedSeasons([]);
                setMaxHours(undefined);
                setStrollerOnly(false);
                setLowWalkingOnly(false);
                setIndianFoodOnly(false);
                setMeFoodOnly(false);
                setSearchQ("");
              }}
              className="mt-4 px-6 py-2 bg-orange-500 text-white rounded-xl text-sm font-medium"
            >
              Clear all filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filtered.map((dest, i) => {
              const isSaved = savedIds.includes(dest.id);
              return (
                <motion.div
                  key={dest.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <div className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 hover:shadow-md transition-all group">
                    {/* Card image area */}
                    <div className={`h-36 bg-gradient-to-br ${dest.gradient} relative`}>
                      <div className="absolute inset-0 flex items-center justify-center opacity-10 text-7xl select-none">
                        {dest.country === "Canada" ? "🍁" : "🦅"}
                      </div>

                      {/* Save button */}
                      <motion.button
                        onClick={(e) => { e.preventDefault(); toggle(dest.id); }}
                        className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-sm"
                        whileTap={{ scale: 0.85 }}
                      >
                        <Heart className={`w-4 h-4 ${isSaved ? "fill-red-500 text-red-500" : "text-gray-400"}`} />
                      </motion.button>

                      {/* Season badge */}
                      <div className="absolute top-3 left-3 flex gap-1 flex-wrap">
                        {dest.bestSeasons.slice(0, 2).map((s) => (
                          <span key={s} className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${seasonColors[s]} bg-white/90`}>
                            {s}
                          </span>
                        ))}
                      </div>

                      {/* Country */}
                      <div className="absolute bottom-3 left-3">
                        <span className="bg-white/90 text-xs font-medium px-2 py-1 rounded-full text-gray-700">{dest.country}</span>
                      </div>
                    </div>

                    <Link href={`/destinations/${dest.id}`}>
                      <div className="p-4 cursor-pointer">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-bold text-gray-900">{dest.name}</h3>
                            <p className="text-xs text-gray-500 mt-0.5">{dest.region}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 mt-2">
                          <Car className="w-3 h-3 text-gray-400" />
                          <span className="text-xs text-gray-600">{dest.drivingDistance[startCity]}</span>
                          {dest.strollerFriendly && (
                            <span className="ml-auto text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">Stroller OK</span>
                          )}
                        </div>

                        <div className="mt-3 space-y-1.5">
                          <div className="flex items-center gap-2">
                            <Baby className="w-3 h-3 text-orange-400 shrink-0" />
                            <span className="text-[10px] text-gray-500 w-12">Toddler</span>
                            <ScoreBar score={dest.toddlerScore} color="orange" />
                          </div>
                          <div className="flex items-center gap-2">
                            <Utensils className="w-3 h-3 text-blue-400 shrink-0" />
                            <span className="text-[10px] text-gray-500 w-12">Food</span>
                            <ScoreBar score={dest.foodScore} color="blue" />
                          </div>
                        </div>

                        {(dest.hasIndianFood || dest.hasMiddleEasternFood) && (
                          <div className="flex gap-1 mt-3">
                            {dest.hasIndianFood && (
                              <span className="text-[10px] bg-orange-50 text-orange-600 border border-orange-100 px-2 py-0.5 rounded-full font-medium">Indian food</span>
                            )}
                            {dest.hasMiddleEasternFood && (
                              <span className="text-[10px] bg-amber-50 text-amber-600 border border-amber-100 px-2 py-0.5 rounded-full font-medium">Middle Eastern</span>
                            )}
                          </div>
                        )}
                      </div>
                    </Link>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
