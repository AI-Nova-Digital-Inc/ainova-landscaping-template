import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import { MapPin, Sun, Snowflake, Leaf, Flower2, Car, ChevronRight, ChevronLeft } from "lucide-react";

const steps = ["Where", "When", "Style", "Distance"];

type FormData = {
  startCity: string;
  season: string;
  tripType: string;
  travelStyle: string;
  maxDistance: string;
  weatherPref: string;
};

const initialData: FormData = {
  startCity: "",
  season: "",
  tripType: "",
  travelStyle: "",
  maxDistance: "",
  weatherPref: "",
};

const cities = ["Cambridge", "Waterloo", "Mississauga", "Toronto", "Custom"];
const seasons = [
  { label: "Summer", icon: Sun, color: "amber", description: "Beaches, parks, outdoor fun" },
  { label: "Winter", icon: Snowflake, color: "blue", description: "Indoor parks, snow, Christmas" },
  { label: "Spring", icon: Flower2, color: "green", description: "Mild weather, blooms" },
  { label: "Fall", icon: Leaf, color: "orange", description: "Fall colors, cozy vibes" },
];
const tripTypes = ["Day trip", "Weekend trip", "3–5 days", "Long vacation"];
const travelStyles = [
  { label: "Nature", icon: "🌲" },
  { label: "City", icon: "🏙️" },
  { label: "Beach", icon: "🏖️" },
  { label: "Mountains", icon: "🏔️" },
  { label: "Snow activities", icon: "⛷️" },
  { label: "Indoor toddler-friendly", icon: "🎪" },
];
const maxDistances = [
  { label: "Under 1 hour", hours: 1 },
  { label: "1–3 hours", hours: 3 },
  { label: "3–6 hours", hours: 6 },
  { label: "6+ hours", hours: 99 },
];
const weatherPrefs = ["Warm", "Mild", "Snowy", "Indoor-safe", "Avoid extreme weather"];

function OptionButton({
  selected,
  onClick,
  children,
}: {
  selected: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <motion.button
      onClick={onClick}
      className={`w-full text-left p-4 rounded-2xl border-2 transition-all font-medium text-sm ${
        selected
          ? "border-orange-500 bg-orange-50 text-orange-700"
          : "border-gray-200 bg-white text-gray-700 hover:border-orange-300"
      }`}
      whileTap={{ scale: 0.98 }}
    >
      {children}
    </motion.button>
  );
}

export default function Planner() {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<FormData>(initialData);
  const [, navigate] = useLocation();

  const update = (key: keyof FormData, val: string) => setForm((f) => ({ ...f, [key]: val }));

  const canProceed = [
    form.startCity,
    form.season,
    form.tripType || form.travelStyle,
    form.maxDistance,
  ][step];

  const handleFinish = () => {
    const params = new URLSearchParams();
    if (form.season) params.set("season", form.season);
    if (form.startCity) params.set("city", form.startCity);
    if (form.maxDistance) {
      const d = maxDistances.find((x) => x.label === form.maxDistance);
      if (d) params.set("maxHours", String(d.hours));
    }
    if (form.travelStyle) params.set("style", form.travelStyle);
    navigate(`/destinations?${params.toString()}`);
  };

  const seasonColorMap: Record<string, string> = {
    Summer: "amber",
    Winter: "blue",
    Spring: "green",
    Fall: "orange",
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 flex flex-col">
      <div className="px-6 pt-8 pb-4">
        <h1 className="text-2xl font-bold text-gray-900">Plan Your Trip</h1>
        <p className="text-gray-500 text-sm mt-1">4 quick questions to find your perfect destination</p>

        {/* Progress */}
        <div className="flex gap-2 mt-6">
          {steps.map((s, i) => (
            <div key={s} className="flex-1 flex flex-col items-center gap-1">
              <div
                className={`h-1.5 w-full rounded-full transition-all ${
                  i <= step ? "bg-orange-500" : "bg-gray-200"
                }`}
              />
              <span className={`text-[10px] font-medium ${i <= step ? "text-orange-600" : "text-gray-400"}`}>
                {s}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 px-6 pb-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            transition={{ duration: 0.25 }}
          >
            {step === 0 && (
              <div className="space-y-3 mt-4">
                <h2 className="text-lg font-bold text-gray-900 mb-4">Where are you starting from?</h2>
                {cities.map((city) => (
                  <OptionButton
                    key={city}
                    selected={form.startCity === city}
                    onClick={() => update("startCity", city)}
                  >
                    <div className="flex items-center gap-3">
                      <MapPin className="w-4 h-4 text-orange-400" />
                      {city}
                    </div>
                  </OptionButton>
                ))}
              </div>
            )}

            {step === 1 && (
              <div className="space-y-3 mt-4">
                <h2 className="text-lg font-bold text-gray-900 mb-4">What season are you planning for?</h2>
                {seasons.map((s) => (
                  <OptionButton
                    key={s.label}
                    selected={form.season === s.label}
                    onClick={() => update("season", s.label)}
                  >
                    <div className="flex items-center gap-3">
                      <s.icon className="w-4 h-4 text-orange-400" />
                      <div>
                        <div className="font-semibold">{s.label}</div>
                        <div className="text-xs text-gray-500 mt-0.5">{s.description}</div>
                      </div>
                    </div>
                  </OptionButton>
                ))}

                <div className="mt-6">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3">Trip length</h3>
                  <div className="grid grid-cols-2 gap-2">
                    {tripTypes.map((t) => (
                      <OptionButton
                        key={t}
                        selected={form.tripType === t}
                        onClick={() => update("tripType", t)}
                      >
                        <span className="text-sm">{t}</span>
                      </OptionButton>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="mt-4">
                <h2 className="text-lg font-bold text-gray-900 mb-4">What's your travel style?</h2>
                <div className="grid grid-cols-2 gap-3">
                  {travelStyles.map((ts) => (
                    <motion.button
                      key={ts.label}
                      onClick={() => update("travelStyle", ts.label)}
                      className={`p-4 rounded-2xl border-2 text-center transition-all ${
                        form.travelStyle === ts.label
                          ? "border-orange-500 bg-orange-50 text-orange-700"
                          : "border-gray-200 bg-white text-gray-700"
                      }`}
                      whileTap={{ scale: 0.97 }}
                    >
                      <div className="text-2xl mb-2">{ts.icon}</div>
                      <div className="text-xs font-semibold">{ts.label}</div>
                    </motion.button>
                  ))}
                </div>

                <div className="mt-6">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3">Weather preference</h3>
                  <div className="flex flex-wrap gap-2">
                    {weatherPrefs.map((wp) => (
                      <button
                        key={wp}
                        onClick={() => update("weatherPref", wp)}
                        className={`px-3 py-2 rounded-full border text-xs font-medium transition-all ${
                          form.weatherPref === wp
                            ? "border-orange-500 bg-orange-500 text-white"
                            : "border-gray-200 bg-white text-gray-600 hover:border-orange-300"
                        }`}
                      >
                        {wp}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-3 mt-4">
                <h2 className="text-lg font-bold text-gray-900 mb-4">How far are you willing to drive?</h2>
                {maxDistances.map((d) => (
                  <OptionButton
                    key={d.label}
                    selected={form.maxDistance === d.label}
                    onClick={() => update("maxDistance", d.label)}
                  >
                    <div className="flex items-center gap-3">
                      <Car className="w-4 h-4 text-orange-400" />
                      {d.label}
                    </div>
                  </OptionButton>
                ))}

                {/* Summary */}
                {form.startCity && (
                  <div className="mt-8 p-5 bg-white rounded-2xl border border-orange-100 shadow-sm">
                    <h3 className="text-sm font-bold text-gray-900 mb-3">Your trip summary</h3>
                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex justify-between"><span className="text-gray-400">From</span><span className="font-medium">{form.startCity}</span></div>
                      <div className="flex justify-between"><span className="text-gray-400">Season</span><span className="font-medium">{form.season || "—"}</span></div>
                      <div className="flex justify-between"><span className="text-gray-400">Trip type</span><span className="font-medium">{form.tripType || "—"}</span></div>
                      <div className="flex justify-between"><span className="text-gray-400">Style</span><span className="font-medium">{form.travelStyle || "—"}</span></div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex gap-3 mt-8">
          {step > 0 && (
            <button
              onClick={() => setStep((s) => s - 1)}
              className="flex items-center gap-2 px-6 py-3 bg-white border border-gray-200 rounded-xl text-gray-700 font-medium text-sm hover:border-gray-300 transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
              Back
            </button>
          )}
          {step < steps.length - 1 ? (
            <motion.button
              onClick={() => canProceed && setStep((s) => s + 1)}
              disabled={!canProceed}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-sm transition-all ${
                canProceed
                  ? "bg-gradient-to-r from-orange-500 to-amber-500 text-white shadow-md shadow-orange-200"
                  : "bg-gray-100 text-gray-400 cursor-not-allowed"
              }`}
              whileTap={canProceed ? { scale: 0.98 } : {}}
            >
              Next
              <ChevronRight className="w-4 h-4" />
            </motion.button>
          ) : (
            <motion.button
              onClick={handleFinish}
              disabled={!form.maxDistance}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-sm transition-all ${
                form.maxDistance
                  ? "bg-gradient-to-r from-orange-500 to-amber-500 text-white shadow-md shadow-orange-200"
                  : "bg-gray-100 text-gray-400 cursor-not-allowed"
              }`}
              whileTap={form.maxDistance ? { scale: 0.98 } : {}}
            >
              Find Destinations
              <ChevronRight className="w-4 h-4" />
            </motion.button>
          )}
        </div>
      </div>
    </div>
  );
}
