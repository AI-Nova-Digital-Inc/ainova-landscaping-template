import { motion } from "framer-motion";
import { Link } from "wouter";
import { MapPin, Utensils, Star, ArrowRight, Sun, Snowflake, Leaf, Flower2 } from "lucide-react";
import { destinations } from "@/data/destinations";

const floatingIcons = [
  { emoji: "🚗", x: "10%", y: "20%", delay: 0, size: 40 },
  { emoji: "🏔️", x: "80%", y: "15%", delay: 0.5, size: 36 },
  { emoji: "❄️", x: "15%", y: "70%", delay: 1, size: 32 },
  { emoji: "🏖️", x: "75%", y: "65%", delay: 0.3, size: 38 },
  { emoji: "🍽️", x: "50%", y: "10%", delay: 0.8, size: 34 },
  { emoji: "🛒", x: "88%", y: "45%", delay: 0.2, size: 30 },
];

const seasons = [
  { label: "Summer", icon: Sun, color: "bg-amber-100 text-amber-700 border-amber-200" },
  { label: "Winter", icon: Snowflake, color: "bg-blue-100 text-blue-700 border-blue-200" },
  { label: "Fall", icon: Leaf, color: "bg-orange-100 text-orange-700 border-orange-200" },
  { label: "Spring", icon: Flower2, color: "bg-green-100 text-green-700 border-green-200" },
];

const featured = destinations.slice(0, 6);

export default function Home() {
  return (
    <div className="min-h-screen overflow-x-hidden">
      {/* Hero Section */}
      <div className="relative min-h-[90vh] flex flex-col items-center justify-center overflow-hidden bg-gradient-to-br from-orange-50 via-amber-50 to-sky-50 px-6 py-16">
        {/* Animated background blobs */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div
            className="absolute w-96 h-96 rounded-full bg-orange-200/30 blur-3xl"
            style={{ top: "-10%", left: "-10%" }}
            animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
            transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.div
            className="absolute w-80 h-80 rounded-full bg-sky-200/30 blur-3xl"
            style={{ bottom: "0%", right: "-5%" }}
            animate={{ scale: [1.2, 1, 1.2], opacity: [0.4, 0.2, 0.4] }}
            transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.div
            className="absolute w-64 h-64 rounded-full bg-amber-200/20 blur-2xl"
            style={{ top: "50%", left: "30%" }}
            animate={{ scale: [1, 1.3, 1], opacity: [0.2, 0.4, 0.2] }}
            transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
          />
        </div>

        {/* Floating icons */}
        {floatingIcons.map((icon, i) => (
          <motion.div
            key={i}
            className="absolute select-none pointer-events-none"
            style={{ left: icon.x, top: icon.y, fontSize: icon.size }}
            animate={{ y: [0, -15, 0], rotate: [-5, 5, -5] }}
            transition={{ duration: 4 + i * 0.5, repeat: Infinity, ease: "easeInOut", delay: icon.delay }}
          >
            {icon.emoji}
          </motion.div>
        ))}

        {/* Hero content */}
        <div className="relative z-10 text-center max-w-2xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm border border-orange-200 rounded-full text-sm font-medium text-orange-700 mb-6 shadow-sm"
          >
            <span className="w-2 h-2 bg-orange-500 rounded-full animate-pulse" />
            AI-Powered Family Travel Planner
          </motion.div>

          <motion.h1
            className="text-4xl md:text-6xl font-bold text-gray-900 leading-tight mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
          >
            Plan Toddler-Friendly Trips{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-amber-500">
              Without Guessing
            </span>
          </motion.h1>

          <motion.p
            className="text-lg md:text-xl text-gray-600 mb-10 leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            Find Canada and USA vacation ideas based on weather, season, driving distance, toddler comfort, and your food preferences.
          </motion.p>

          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
          >
            <Link href="/planner">
              <motion.button
                className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-orange-500 to-amber-500 text-white font-semibold rounded-2xl shadow-lg shadow-orange-200 hover:shadow-xl hover:shadow-orange-300 transition-all"
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <MapPin className="w-5 h-5" />
                Plan a Trip
                <ArrowRight className="w-4 h-4" />
              </motion.button>
            </Link>
            <Link href="/food">
              <motion.button
                className="inline-flex items-center gap-2 px-8 py-4 bg-white text-gray-700 font-semibold rounded-2xl border-2 border-gray-200 shadow-sm hover:border-orange-300 hover:shadow-md transition-all"
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <Utensils className="w-5 h-5 text-orange-500" />
                Explore Food Spots
              </motion.button>
            </Link>
          </motion.div>
        </div>

        {/* Season filters */}
        <motion.div
          className="relative z-10 flex flex-wrap gap-3 justify-center mt-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.5 }}
        >
          {seasons.map((s) => (
            <Link key={s.label} href={`/destinations?season=${s.label}`}>
              <div className={`flex items-center gap-2 px-4 py-2 rounded-full border text-sm font-medium cursor-pointer hover:shadow-md transition-all ${s.color}`}>
                <s.icon className="w-4 h-4" />
                {s.label} trips
              </div>
            </Link>
          ))}
        </motion.div>
      </div>

      {/* Stats bar */}
      <div className="bg-white border-y border-gray-100 py-6 px-6">
        <div className="max-w-4xl mx-auto grid grid-cols-3 gap-4 text-center">
          {[
            { value: "20+", label: "Destinations" },
            { value: "20+", label: "Restaurants" },
            { value: "2 yr", label: "Toddler Focus" },
          ].map((stat) => (
            <div key={stat.label}>
              <div className="text-2xl font-bold text-orange-500">{stat.value}</div>
              <div className="text-xs text-gray-500 font-medium mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Featured Destinations */}
      <div className="px-6 py-12 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Top Picks for Families</h2>
              <p className="text-gray-500 text-sm mt-1">Curated for Ontario families with toddlers</p>
            </div>
            <Link href="/destinations">
              <span className="text-orange-500 font-medium text-sm flex items-center gap-1 hover:gap-2 transition-all">
                View all <ArrowRight className="w-4 h-4" />
              </span>
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {featured.map((dest, i) => (
              <motion.div
                key={dest.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Link href={`/destinations/${dest.id}`}>
                  <motion.div
                    className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 cursor-pointer"
                    whileHover={{ y: -4, shadow: "0 20px 40px rgba(0,0,0,0.1)" }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className={`h-28 bg-gradient-to-br ${dest.gradient} relative flex items-center justify-center`}>
                      <div className="text-4xl opacity-20">
                        {dest.country === "Canada" ? "🍁" : "🦅"}
                      </div>
                      <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm rounded-full px-2 py-1 flex items-center gap-1">
                        <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                        <span className="text-xs font-bold">{dest.toddlerScore}/10</span>
                      </div>
                      <div className="absolute bottom-3 left-3">
                        <span className="bg-white/90 backdrop-blur-sm text-xs font-medium px-2 py-1 rounded-full text-gray-700">
                          {dest.country}
                        </span>
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="font-bold text-gray-900 text-sm">{dest.name}</h3>
                      <p className="text-xs text-gray-500 mt-0.5">{dest.region}</p>
                      <div className="flex items-center gap-2 mt-3">
                        <MapPin className="w-3 h-3 text-orange-400" />
                        <span className="text-xs text-gray-600">{dest.drivingDistance.Cambridge} from Cambridge</span>
                      </div>
                    </div>
                  </motion.div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Features section */}
      <div className="px-6 py-12 bg-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-10">Everything a toddler parent needs</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {[
              { icon: "🗺️", title: "Smart Trip Planner", desc: "Filter by season, distance, and travel style to find your perfect trip." },
              { icon: "🍽️", title: "Indian & Middle Eastern Food", desc: "Find halal and South Asian restaurants near every destination." },
              { icon: "📋", title: "Day-by-Day Itinerary", desc: "Auto-generated schedules with toddler nap times built in." },
              { icon: "✅", title: "Safety Checklist", desc: "Never forget stroller, diapers, or sunscreen again." },
            ].map((f, i) => (
              <motion.div
                key={i}
                className="flex gap-4 p-5 bg-orange-50/50 rounded-2xl border border-orange-100"
                initial={{ opacity: 0, x: -10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <div className="text-3xl">{f.icon}</div>
                <div>
                  <h3 className="font-semibold text-gray-900 text-sm">{f.title}</h3>
                  <p className="text-xs text-gray-500 mt-1 leading-relaxed">{f.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Banner */}
      <div className="mx-6 mb-12 bg-gradient-to-r from-orange-500 to-amber-500 rounded-3xl p-8 text-center shadow-xl shadow-orange-200">
        <h2 className="text-2xl font-bold text-white mb-3">Ready to plan your next family adventure?</h2>
        <p className="text-orange-100 mb-6 text-sm">Tell us your starting city and we'll handle the rest.</p>
        <Link href="/planner">
          <motion.button
            className="inline-flex items-center gap-2 px-8 py-3 bg-white text-orange-600 font-semibold rounded-xl shadow-md hover:shadow-lg transition-all"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
          >
            Get Started
            <ArrowRight className="w-4 h-4" />
          </motion.button>
        </Link>
      </div>
    </div>
  );
}
