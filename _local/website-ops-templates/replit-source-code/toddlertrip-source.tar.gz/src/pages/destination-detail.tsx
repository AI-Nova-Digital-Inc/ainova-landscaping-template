import { useState } from "react";
import { motion } from "framer-motion";
import { useParams, Link } from "wouter";
import {
  ArrowLeft, Heart, MapPin, Car, Baby, Utensils, CloudRain, Shield,
  Package, Clock, AlertTriangle, CheckSquare, Star, ChevronDown, ChevronUp,
  Sun, Snowflake, Leaf, Flower2
} from "lucide-react";
import { destinations } from "@/data/destinations";
import { restaurants } from "@/data/restaurants";
import { useSavedTrips } from "@/hooks/use-saved";

const seasonIcons: Record<string, React.ReactNode> = {
  Summer: <Sun className="w-4 h-4" />,
  Winter: <Snowflake className="w-4 h-4" />,
  Spring: <Flower2 className="w-4 h-4" />,
  Fall: <Leaf className="w-4 h-4" />,
};

const seasonColors: Record<string, string> = {
  Summer: "bg-amber-100 text-amber-700 border-amber-200",
  Winter: "bg-blue-100 text-blue-700 border-blue-200",
  Spring: "bg-green-100 text-green-700 border-green-200",
  Fall: "bg-orange-100 text-orange-700 border-orange-200",
};

function ScoreBar({ score, label, color = "orange" }: { score: number; label: string; color?: string }) {
  const colors: Record<string, string> = {
    orange: "bg-orange-500",
    blue: "bg-blue-500",
    green: "bg-green-500",
  };
  return (
    <div className="flex items-center gap-3">
      <span className="text-xs text-gray-500 w-20 shrink-0">{label}</span>
      <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
        <motion.div
          className={`h-full rounded-full ${colors[color]}`}
          initial={{ width: 0 }}
          animate={{ width: `${score * 10}%` }}
          transition={{ duration: 0.8, delay: 0.3 }}
        />
      </div>
      <span className="text-xs font-bold text-gray-700 w-8 text-right">{score}/10</span>
    </div>
  );
}

const itinerary = [
  { time: "9:00 AM", activity: "Leave home", icon: "🚗" },
  { time: "Arrival", activity: "Check in / parking", icon: "📍" },
  { time: "Late morning", activity: "Main attraction", icon: "⭐" },
  { time: "12:30 PM", activity: "Lunch at nearby restaurant", icon: "🍽️" },
  { time: "1:30 PM", activity: "Toddler nap / rest break", icon: "😴" },
  { time: "3:00 PM", activity: "Easy afternoon activity", icon: "🎡" },
  { time: "5:00 PM", activity: "Dinner", icon: "🌅" },
  { time: "6:30 PM", activity: "Head home", icon: "🏡" },
];

export default function DestinationDetail() {
  const params = useParams<{ id: string }>();
  const dest = destinations.find((d) => d.id === params.id);
  const { savedIds, toggle } = useSavedTrips();
  const [selectedSeason, setSelectedSeason] = useState<string | null>(dest?.bestSeasons[0] || null);
  const [showAllThings, setShowAllThings] = useState(false);
  const [saved, setSaved] = useState(false);

  if (!dest) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-4">🗺️</div>
          <h2 className="font-bold text-gray-900">Destination not found</h2>
          <Link href="/destinations">
            <button className="mt-4 px-6 py-2 bg-orange-500 text-white rounded-xl text-sm">Back to destinations</button>
          </Link>
        </div>
      </div>
    );
  }

  const isSaved = savedIds.includes(dest.id);
  const nearbyRestaurants = restaurants.filter((r) => r.destinationIds.includes(dest.id));

  const handleSaveItinerary = () => {
    const itineraries = JSON.parse(localStorage.getItem("savedItineraries") || "[]");
    const existing = itineraries.find((it: { destId: string }) => it.destId === dest.id);
    if (!existing) {
      itineraries.push({ destId: dest.id, destName: dest.name, savedAt: Date.now() });
      localStorage.setItem("savedItineraries", JSON.stringify(itineraries));
    }
    setSaved(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero */}
      <div className={`relative h-56 md:h-72 bg-gradient-to-br ${dest.gradient}`}>
        <div className="absolute inset-0 flex items-center justify-center opacity-10 text-9xl select-none">
          {dest.country === "Canada" ? "🍁" : "🦅"}
        </div>

        <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
          <Link href="/destinations">
            <motion.button
              className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-sm"
              whileTap={{ scale: 0.9 }}
            >
              <ArrowLeft className="w-5 h-5 text-gray-700" />
            </motion.button>
          </Link>
          <motion.button
            onClick={() => toggle(dest.id)}
            className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-sm"
            whileTap={{ scale: 0.85 }}
          >
            <Heart className={`w-5 h-5 ${isSaved ? "fill-red-500 text-red-500" : "text-gray-600"}`} />
          </motion.button>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/40 to-transparent">
          <div className="flex gap-2 mb-2 flex-wrap">
            {dest.bestSeasons.map((s) => (
              <span key={s} className="text-xs font-semibold px-3 py-1 rounded-full bg-white/20 text-white backdrop-blur-sm">
                {s}
              </span>
            ))}
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-white">{dest.name}</h1>
          <p className="text-white/80 text-sm mt-0.5">{dest.region}</p>
        </div>
      </div>

      <div className="px-4 py-6 max-w-2xl mx-auto space-y-6">
        {/* Quick stats */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-3 mb-4">
            <Car className="w-4 h-4 text-gray-400" />
            <span className="text-sm text-gray-600">from Cambridge: <strong className="text-gray-900">{dest.drivingDistance.Cambridge}</strong></span>
            <span className="ml-auto text-xs text-gray-400">{dest.estimatedLength}</span>
          </div>
          <div className="space-y-3">
            <ScoreBar score={dest.toddlerScore} label="Toddler" color="orange" />
            <ScoreBar score={dest.weatherScore} label="Weather" color="blue" />
            <ScoreBar score={dest.foodScore} label="Food" color="green" />
          </div>

          <div className="flex flex-wrap gap-2 mt-4">
            {dest.strollerFriendly && (
              <span className="text-xs bg-green-50 text-green-700 border border-green-100 px-3 py-1 rounded-full font-medium">Stroller-friendly</span>
            )}
            {dest.lowWalking && (
              <span className="text-xs bg-blue-50 text-blue-700 border border-blue-100 px-3 py-1 rounded-full font-medium">Low walking</span>
            )}
            {dest.hasIndianFood && (
              <span className="text-xs bg-orange-50 text-orange-700 border border-orange-100 px-3 py-1 rounded-full font-medium">Indian food</span>
            )}
            {dest.hasMiddleEasternFood && (
              <span className="text-xs bg-amber-50 text-amber-700 border border-amber-100 px-3 py-1 rounded-full font-medium">Middle Eastern</span>
            )}
          </div>
        </div>

        {/* Description */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <p className="text-gray-600 text-sm leading-relaxed">{dest.description}</p>
        </div>

        {/* Weather suitability */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <h2 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
            <CloudRain className="w-4 h-4 text-blue-500" />
            Weather Suitability
          </h2>
          <div className="flex flex-wrap gap-2 mb-4">
            {dest.bestSeasons.map((s) => (
              <button
                key={s}
                onClick={() => setSelectedSeason(s)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium transition-all ${
                  selectedSeason === s ? seasonColors[s] : "bg-gray-50 text-gray-600 border-gray-200"
                }`}
              >
                {seasonIcons[s]}
                {s}
              </button>
            ))}
          </div>
          {selectedSeason && dest.weatherLogic[selectedSeason] && (
            <motion.div
              key={selectedSeason}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-3 rounded-xl text-sm ${seasonColors[selectedSeason]} border`}
            >
              {dest.weatherLogic[selectedSeason]}
            </motion.div>
          )}
          <div className="mt-3 p-3 bg-amber-50 border border-amber-100 rounded-xl flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700">{dest.safetyNotes}</p>
          </div>
          <div className="mt-2 p-3 bg-teal-50 border border-teal-100 rounded-xl">
            <p className="text-xs font-semibold text-teal-700">Indoor backup: <span className="font-normal">{dest.indoorBackup}</span></p>
          </div>
        </div>

        {/* Things to do */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <h2 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Star className="w-4 h-4 text-amber-500" />
            Things to Do
          </h2>
          <div className="space-y-2">
            {(showAllThings ? dest.thingsToDo : dest.thingsToDo.slice(0, 3)).map((thing, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl"
              >
                <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center shrink-0">
                  <span className="text-xs font-bold text-orange-600">{i + 1}</span>
                </div>
                <span className="text-sm text-gray-700">{thing}</span>
              </motion.div>
            ))}
          </div>
          {dest.thingsToDo.length > 3 && (
            <button
              onClick={() => setShowAllThings(!showAllThings)}
              className="mt-3 flex items-center gap-1 text-orange-500 text-sm font-medium"
            >
              {showAllThings ? <><ChevronUp className="w-4 h-4" />Show less</> : <><ChevronDown className="w-4 h-4" />Show {dest.thingsToDo.length - 3} more</>}
            </button>
          )}
        </div>

        {/* Day Itinerary */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-gray-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-purple-500" />
              Day Trip Itinerary
            </h2>
            <button
              onClick={handleSaveItinerary}
              className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-all ${saved ? "bg-green-100 text-green-700" : "bg-orange-500 text-white"}`}
            >
              {saved ? "Saved!" : "Save itinerary"}
            </button>
          </div>

          <div className="relative">
            <div className="absolute left-5 top-0 bottom-0 w-0.5 bg-gray-100" />
            <div className="space-y-4">
              {itinerary.map((item, i) => (
                <div key={i} className="flex items-start gap-3 relative">
                  <div className="w-10 h-10 rounded-full bg-orange-50 border-2 border-orange-100 flex items-center justify-center shrink-0 z-10">
                    <span className="text-lg">{item.icon}</span>
                  </div>
                  <div className="pt-1.5">
                    <div className="text-xs text-orange-500 font-semibold">{item.time}</div>
                    <div className="text-sm text-gray-700 font-medium">
                      {i === 2 ? dest.thingsToDo[0] : item.activity}
                    </div>
                    {i === 3 && nearbyRestaurants[0] && (
                      <div className="text-xs text-gray-400 mt-0.5">{nearbyRestaurants[0].name} — {nearbyRestaurants[0].cuisine}</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Packing tips */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <h2 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Package className="w-4 h-4 text-indigo-500" />
            Packing Tips for Toddlers
          </h2>
          <div className="grid grid-cols-2 gap-2">
            {dest.packingTips.map((tip, i) => (
              <div key={i} className="flex items-center gap-2 p-2 bg-indigo-50 rounded-xl">
                <CheckSquare className="w-3 h-3 text-indigo-400 shrink-0" />
                <span className="text-xs text-indigo-700 font-medium">{tip}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Nearby restaurants */}
        {nearbyRestaurants.length > 0 && (
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-gray-900 flex items-center gap-2">
                <Utensils className="w-4 h-4 text-red-500" />
                Food Nearby
              </h2>
              <Link href={`/food?dest=${dest.id}`}>
                <span className="text-xs text-orange-500 font-medium">View all</span>
              </Link>
            </div>
            <div className="space-y-3">
              {nearbyRestaurants.slice(0, 2).map((r) => (
                <div key={r.id} className="p-3 bg-gray-50 rounded-xl">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-semibold text-sm text-gray-900">{r.name}</h4>
                      <p className="text-xs text-gray-500 mt-0.5">{r.cuisine} · {r.city}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                      <span className="text-xs font-bold">{r.familyFriendlyScore}/10</span>
                    </div>
                  </div>
                  <p className="text-xs text-orange-600 mt-2">Try: {r.whatToOrder.slice(0, 2).join(", ")}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Distances from all cities */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <h2 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
            <MapPin className="w-4 h-4 text-orange-500" />
            Drive Times
          </h2>
          <div className="space-y-2">
            {(["Cambridge", "Waterloo", "Mississauga", "Toronto"] as const).map((city) => (
              <div key={city} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                <span className="text-sm text-gray-600">{city}</span>
                <span className="text-sm font-semibold text-gray-900">{dest.drivingDistance[city]}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Safety */}
        <div className="p-4 bg-amber-50 border border-amber-100 rounded-2xl flex items-start gap-3">
          <Shield className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <div>
            <h3 className="font-semibold text-amber-900 text-sm">Safety for 2-year-olds</h3>
            <p className="text-xs text-amber-700 mt-1 leading-relaxed">{dest.safetyNotes}</p>
          </div>
        </div>

        {/* Explore food CTA */}
        <Link href={`/food?dest=${dest.id}`}>
          <motion.div
            className="bg-gradient-to-r from-orange-500 to-amber-500 rounded-2xl p-5 text-white text-center cursor-pointer shadow-lg shadow-orange-200"
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
          >
            <Utensils className="w-6 h-6 mx-auto mb-2" />
            <h3 className="font-bold">Find Indian & Middle Eastern Food</h3>
            <p className="text-orange-100 text-xs mt-1">Near {dest.name}</p>
          </motion.div>
        </Link>
      </div>
    </div>
  );
}
