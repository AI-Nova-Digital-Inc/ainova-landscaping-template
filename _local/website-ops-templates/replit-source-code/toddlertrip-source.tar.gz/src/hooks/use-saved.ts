import { useState, useEffect } from "react";

export function useSavedTrips() {
  const [savedIds, setSavedIds] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("savedTrips") || "[]");
    } catch {
      return [];
    }
  });

  const toggle = (id: string) => {
    setSavedIds((prev) => {
      const next = prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id];
      localStorage.setItem("savedTrips", JSON.stringify(next));
      return next;
    });
  };

  return { savedIds, toggle };
}
