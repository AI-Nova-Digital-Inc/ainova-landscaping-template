import { MapPin, Utensils, Heart, CheckSquare, Navigation } from "lucide-react";
import { Link, useLocation } from "wouter";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { href: "/destinations", icon: MapPin, label: "Explore" },
    { href: "/planner", icon: Navigation, label: "Planner" },
    { href: "/food", icon: Utensils, label: "Food" },
    { href: "/saved", icon: Heart, label: "Saved" },
    { href: "/checklist", icon: CheckSquare, label: "Checklist" },
  ];

  return (
    <div className="min-h-screen flex flex-col max-w-md mx-auto bg-background shadow-2xl relative overflow-hidden md:max-w-4xl md:flex-row">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-64 flex-col bg-card border-r p-6 shrink-0">
        <Link href="/" className="flex items-center gap-2 mb-12">
          <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center text-white font-bold font-display">T</div>
          <span className="font-display font-bold text-xl text-foreground">ToddlerTrip AI</span>
        </Link>

        <nav className="flex-1 flex flex-col gap-2">
          {navItems.map((item) => {
            const active = location === item.href || location.startsWith(`${item.href}/`);
            return (
              <Link key={item.href} href={item.href}>
                <div className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer font-medium ${
                  active 
                    ? "bg-primary/10 text-primary" 
                    : "text-muted-foreground hover:bg-muted/50 hover:text-foreground"
                }`}>
                  <item.icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </div>
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-h-[100dvh] pb-20 md:pb-0 relative overflow-y-auto">
        <div className="md:hidden flex items-center justify-between p-4 bg-background/80 backdrop-blur-md sticky top-0 z-50 border-b border-border/50">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center text-white font-bold font-display">T</div>
            <span className="font-display font-bold text-lg text-foreground">ToddlerTrip</span>
          </Link>
        </div>
        <div className="flex-1 w-full max-w-full">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-card border-t border-border/50 px-6 py-4 flex justify-between items-center z-50 pb-[env(safe-area-inset-bottom)]">
        {navItems.map((item) => {
          const active = location === item.href || location.startsWith(`${item.href}/`);
          return (
            <Link key={item.href} href={item.href}>
              <div className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
                active ? "text-primary" : "text-muted-foreground"
              }`}>
                <div className={`p-2 rounded-full transition-all ${active ? "bg-primary/10" : ""}`}>
                  <item.icon className="w-6 h-6" />
                </div>
                <span className="text-[10px] font-medium">{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}