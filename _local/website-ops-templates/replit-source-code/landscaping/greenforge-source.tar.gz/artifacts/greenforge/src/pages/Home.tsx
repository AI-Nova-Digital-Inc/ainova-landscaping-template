import React, { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { 
  Leaf, 
  Menu, 
  X, 
  Phone, 
  ArrowRight, 
  Star, 
  CheckCircle2, 
  Shield, 
  Sprout, 
  Clock, 
  ThumbsUp, 
  ChevronRight,
  Droplets,
  Flower2,
  Trees,
  MountainSnow,
  MapPin,
  Instagram,
  Facebook,
  Mail
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion";
import { Link } from "wouter";

gsap.registerPlugin(ScrollTrigger);

const formSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(10, "Valid phone number required"),
  service: z.string().min(1, "Please select a service"),
  size: z.string().min(1, "Please select property size"),
  message: z.string().optional(),
});

export default function Home() {
  const { toast } = useToast();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const sliderRef = useRef<HTMLDivElement>(null);
  const sliderHandleRef = useRef<HTMLDivElement>(null);
  const beforeImageRef = useRef<HTMLDivElement>(null);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      service: "",
      size: "",
      message: "",
    },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    toast({
      title: "Estimate Request Received",
      description: "We'll be in touch within 24 hours to discuss your project.",
    });
    form.reset();
  };

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // GSAP Slider logic
  useEffect(() => {
    if (!sliderRef.current || !sliderHandleRef.current || !beforeImageRef.current) return;
    
    let isDragging = false;
    
    const handleDragStart = (e: MouseEvent | TouchEvent) => {
      isDragging = true;
    };
    
    const handleDragEnd = () => {
      isDragging = false;
    };
    
    const handleDrag = (e: MouseEvent | TouchEvent) => {
      if (!isDragging) return;
      
      const slider = sliderRef.current;
      if (!slider) return;
      
      const rect = slider.getBoundingClientRect();
      const x = ('touches' in e) ? e.touches[0].clientX : (e as MouseEvent).clientX;
      
      let percentage = ((x - rect.left) / rect.width) * 100;
      percentage = Math.max(0, Math.min(100, percentage));
      
      gsap.to(beforeImageRef.current, { width: `${percentage}%`, duration: 0.1 });
      gsap.to(sliderHandleRef.current, { left: `${percentage}%`, duration: 0.1 });
    };
    
    const handleRef = sliderHandleRef.current;
    handleRef.addEventListener('mousedown', handleDragStart);
    handleRef.addEventListener('touchstart', handleDragStart);
    
    window.addEventListener('mousemove', handleDrag);
    window.addEventListener('touchmove', handleDrag);
    window.addEventListener('mouseup', handleDragEnd);
    window.addEventListener('touchend', handleDragEnd);
    
    return () => {
      handleRef.removeEventListener('mousedown', handleDragStart);
      handleRef.removeEventListener('touchstart', handleDragStart);
      window.removeEventListener('mousemove', handleDrag);
      window.removeEventListener('touchmove', handleDrag);
      window.removeEventListener('mouseup', handleDragEnd);
      window.removeEventListener('touchend', handleDragEnd);
    };
  }, []);

  return (
    <div className="min-h-screen bg-background font-sans text-foreground overflow-x-hidden">
      {/* Navigation */}
      <header 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? "bg-white/95 backdrop-blur-md shadow-sm py-4" : "bg-transparent py-6"
        }`}
      >
        <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 group z-50 relative">
            <div className="bg-primary text-white p-2 rounded-lg group-hover:scale-105 transition-transform">
              <Leaf className="w-5 h-5" />
            </div>
            <span className={`text-2xl font-serif font-bold ${isScrolled ? 'text-primary' : 'text-primary lg:text-white'}`}>
              GreenForge
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-8">
            <a href="#services" className={`text-sm font-medium hover:text-secondary transition-colors ${isScrolled ? 'text-foreground' : 'text-white/90'}`}>Services</a>
            <a href="#projects" className={`text-sm font-medium hover:text-secondary transition-colors ${isScrolled ? 'text-foreground' : 'text-white/90'}`}>Projects</a>
            <a href="#about" className={`text-sm font-medium hover:text-secondary transition-colors ${isScrolled ? 'text-foreground' : 'text-white/90'}`}>About</a>
            <a href="#contact" className={`text-sm font-medium hover:text-secondary transition-colors ${isScrolled ? 'text-foreground' : 'text-white/90'}`}>Contact</a>
          </nav>

          <div className="hidden lg:flex items-center gap-6">
            <div className={`flex items-center gap-2 ${isScrolled ? 'text-foreground' : 'text-white'}`}>
              <Phone className="w-4 h-4 text-secondary" />
              <span className="font-semibold">(555) 847-2200</span>
            </div>
            <Button className="bg-primary hover:bg-primary/90 text-white shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 hover:shadow-primary/30" data-testid="button-nav-estimate" onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}>
              Get Free Estimate
            </Button>
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            className={`lg:hidden z-50 relative p-2 ${isScrolled || mobileMenuOpen ? 'text-foreground' : 'text-white'}`}
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="button-mobile-menu"
          >
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-0 left-0 right-0 bg-white shadow-lg pt-24 pb-8 px-6 flex flex-col gap-6 lg:hidden"
            >
              <a href="#services" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium">Services</a>
              <a href="#projects" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium">Projects</a>
              <a href="#about" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium">About</a>
              <a href="#contact" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium">Contact</a>
              <div className="flex flex-col gap-4 mt-4 pt-4 border-t border-gray-100">
                <div className="flex items-center gap-2">
                  <Phone className="w-5 h-5 text-primary" />
                  <span className="font-bold text-lg">(555) 847-2200</span>
                </div>
                <Button className="w-full bg-primary" onClick={() => {
                  setMobileMenuOpen(false);
                  document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                }}>
                  Get Free Estimate
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden bg-green-900">
        <div className="absolute inset-0 z-0">
          <img 
            src="/images/hero-bg.jpg" 
            alt="Beautiful professionally landscaped garden" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/50 to-black/20" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        </div>
        
        {/* Animated elements */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          {[...Array(15)].map((_, i) => (
            <div 
              key={i}
              className="absolute w-2 h-2 rounded-full bg-secondary/60 blur-[1px] animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${6 + Math.random() * 4}s`
              }}
            />
          ))}
        </div>

        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-sm border border-white/30 text-white text-sm font-medium mb-6">
                <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                <span>#1 Rated Landscaping in Metro Area</span>
              </div>
              <h1 className="text-5xl md:text-7xl font-serif font-bold text-white leading-tight mb-6 drop-shadow-lg">
                Transform Your Yard Into a{" "}
                <span className="text-green-400">Living Masterpiece</span>
              </h1>
              <p className="text-lg md:text-xl text-white/95 mb-10 max-w-2xl leading-relaxed drop-shadow">
                Professional landscaping designed to elevate your home and outdoor living. We blend expert craftsmanship with natural beauty.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-green-500 hover:bg-green-400 text-white text-lg h-14 px-8 shadow-xl shadow-green-900/40 hover:-translate-y-1 transition-all duration-300 font-semibold" data-testid="button-hero-estimate" onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}>
                  Get Free Estimate
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button size="lg" variant="outline" className="bg-white/10 hover:bg-white/20 text-white border-white/50 text-lg h-14 px-8 backdrop-blur-sm transition-all duration-300 font-semibold" data-testid="button-hero-projects" onClick={() => document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })}>
                  View Our Projects
                </Button>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Grass animation overlay at bottom */}
        <div className="absolute bottom-0 w-full h-32 z-10 pointer-events-none opacity-80" style={{ background: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 100 100\' preserveAspectRatio=\'none\'%3E%3Cpath d=\'M0,100 Q10,80 20,100 Q30,70 40,100 Q50,60 60,100 Q70,80 80,100 Q90,70 100,100 L100,100 L0,100 Z\' fill=\'%23ffffff\' /%3E%3C/svg%3E") bottom center / 100px 30px repeat-x' }}></div>
      </section>

      {/* Stats Bar */}
      <section className="py-12 bg-white relative z-20 shadow-sm border-b border-border">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 divide-x divide-border">
            {[
              { num: "500+", label: "Projects Completed" },
              { num: "12", label: "Years Experience" },
              { num: "100%", label: "Satisfaction Guarantee" },
              { num: "5.0", label: "Star Rated" }
            ].map((stat, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center px-4"
              >
                <div className="text-3xl md:text-4xl font-bold font-serif text-primary mb-2">{stat.num}</div>
                <div className="text-sm md:text-base text-muted-foreground font-medium">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-muted">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-secondary font-bold tracking-wider uppercase text-sm mb-4 block">Our Services</span>
            <h2 className="text-4xl font-serif font-bold text-foreground mb-4">Expert Care for Every Landscape</h2>
            <p className="text-muted-foreground text-lg">Comprehensive landscaping solutions tailored to your property's unique needs.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: Droplets,
                title: "Lawn Care & Maintenance",
                desc: "Precision mowing, fertilization, and weed control for a pristine, healthy lawn year-round.",
                img: "/images/lawn-care.jpg"
              },
              {
                icon: Flower2,
                title: "Garden Design & Planting",
                desc: "Custom garden layouts featuring native plants, vibrant blooms, and balanced ecosystems.",
                img: "/images/garden-design.jpg"
              },
              {
                icon: MountainSnow,
                title: "Hardscaping & Patios",
                desc: "Elegant stone pathways, retaining walls, and custom patios that expand your living space.",
                img: "/images/hardscape-card.jpg"
              },
              {
                icon: Trees,
                title: "Seasonal Cleanup",
                desc: "Spring prep and fall leaf removal to keep your property looking flawless in every season.",
                img: "/images/seasonal.jpg"
              }
            ].map((service, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="h-full border-transparent hover:border-secondary/30 transition-all duration-300 hover:shadow-xl hover:shadow-secondary/5 group overflow-hidden bg-white">
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={service.img}
                      alt={service.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                    <div className="absolute bottom-4 left-4 w-12 h-12 rounded-xl bg-white flex items-center justify-center shadow-lg group-hover:bg-secondary group-hover:scale-110 transition-all duration-500">
                      <service.icon className="w-6 h-6 text-primary group-hover:text-white transition-colors" />
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-bold font-serif mb-2 text-foreground">{service.title}</h3>
                    <p className="text-muted-foreground mb-4 text-sm line-clamp-3">{service.desc}</p>
                    <a href="#contact" className="inline-flex items-center text-primary font-semibold hover:text-secondary transition-colors group/link text-sm">
                      Learn More
                      <ArrowRight className="w-4 h-4 ml-1 group-hover/link:translate-x-1 transition-transform" />
                    </a>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Before/After Slider Section */}
      <section id="projects" className="py-24 bg-primary overflow-hidden">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
            <div className="max-w-2xl">
              <span className="text-green-400 font-bold tracking-wider uppercase text-sm mb-4 block">Transformations</span>
              <h2 className="text-4xl font-serif font-bold text-white mb-4">Every Yard Has a Story</h2>
              <p className="text-white/70 text-lg">Real results from real homeowners. Move the handle to reveal the before and after.</p>
            </div>
            <Button variant="outline" className="hidden md:flex border-white/30 text-white hover:bg-white/10 hover:text-white">View Portfolio</Button>
          </div>

          {/* Main Interactive Slider */}
          <div
            className="relative w-full max-w-5xl mx-auto rounded-2xl overflow-hidden shadow-2xl cursor-ew-resize select-none mb-8"
            style={{ aspectRatio: '16/9' }}
            ref={sliderRef}
            data-testid="before-after-slider"
          >
            {/* After Image — full width background */}
            <img
              src="/images/garden-after.jpg"
              alt="Professionally landscaped garden after transformation"
              className="absolute inset-0 w-full h-full object-cover"
              draggable={false}
            />
            <div className="absolute top-4 right-4 bg-green-600 text-white px-4 py-1.5 rounded-full font-bold text-sm z-10 shadow-lg">
              After
            </div>

            {/* Before Image — clipped to left portion, expands on drag */}
            <div
              ref={beforeImageRef}
              className="absolute top-0 left-0 bottom-0 overflow-hidden z-20"
              style={{ width: '50%' }}
            >
              <img
                src="/images/garden-before.jpg"
                alt="Yard before landscaping transformation"
                className="absolute top-0 left-0 h-full object-cover object-left"
                draggable={false}
                style={{ width: sliderRef.current?.offsetWidth ? `${sliderRef.current.offsetWidth}px` : '800px' }}
              />
              <div className="absolute top-4 left-4 bg-black/70 text-white px-4 py-1.5 rounded-full font-bold text-sm z-10 shadow-lg">
                Before
              </div>
            </div>

            {/* Divider line + Handle */}
            <div
              ref={sliderHandleRef}
              className="absolute top-0 bottom-0 z-30 flex items-center justify-center"
              style={{ left: '50%', transform: 'translateX(-50%)', width: '4px', background: 'white', cursor: 'ew-resize' }}
            >
              <div className="w-12 h-12 bg-white rounded-full shadow-2xl flex items-center justify-center ring-2 ring-black/10 flex-shrink-0">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <path d="M7 5L3 10L7 15M13 5L17 10L13 15" stroke="#2d6a4f" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
            </div>
          </div>

          {/* 3 Transformation Examples Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {[
              {
                label: "Backyard Lawn Renovation",
                img: "/images/lawn.jpg",
                tag: "Lawn Care"
              },
              {
                label: "Garden & Flower Bed Design",
                img: "/images/garden-design.jpg",
                tag: "Garden Design"
              },
              {
                label: "Stone Patio & Pathway",
                img: "/images/hardscape.jpg",
                tag: "Hardscaping"
              }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="relative rounded-xl overflow-hidden shadow-md group aspect-[4/3]"
              >
                <img src={item.img} alt={item.label} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <span className="text-xs font-bold text-green-400 uppercase tracking-wider">{item.tag}</span>
                  <p className="text-white font-semibold mt-1">{item.label}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-primary text-primary-foreground relative overflow-hidden">
        {/* Subtle background pattern */}
        <div className="absolute inset-0 opacity-5" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }} />
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-6">Why Homeowners Trust GreenForge</h2>
            <div className="w-24 h-1 bg-secondary mx-auto rounded-full" />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-6 md:gap-8 max-w-4xl mx-auto">
            {[
              { icon: Shield, text: "Licensed & Insured" },
              { icon: Star, text: "5-Star Google Reviews" },
              { icon: Sprout, text: "Eco-Friendly Methods" },
              { icon: ThumbsUp, text: "Satisfaction Guaranteed" },
              { icon: Clock, text: "Same-Week Service" },
              { icon: CheckCircle2, text: "Free Estimates" }
            ].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="flex flex-col items-center text-center p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors"
              >
                <feature.icon className="w-8 h-8 text-secondary mb-4" />
                <span className="font-semibold text-lg">{feature.text}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-muted">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <span className="text-secondary font-bold tracking-wider uppercase text-sm mb-4 block">Testimonials</span>
            <h2 className="text-4xl font-serif font-bold text-foreground">Stories From the Neighborhood</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                quote: "They completely transformed our overgrown backyard into a beautiful patio space. The crew was professional, clean, and fast.",
                name: "Sarah Jenkins",
                area: "Oakwood Heights",
                initials: "SJ"
              },
              {
                quote: "Best landscaping service I've ever hired. The weekly lawn maintenance is flawless, and our spring garden design gets compliments daily.",
                name: "Michael Chen",
                area: "Riverdale",
                initials: "MC"
              },
              {
                quote: "GreenForge replaced our retaining wall and laid new sod. Honest pricing, incredible craftsmanship. Highly recommend.",
                name: "David & Emma Smith",
                area: "West End",
                initials: "DS"
              }
            ].map((testimonial, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="h-full border-none shadow-md hover:shadow-lg transition-shadow bg-white">
                  <CardContent className="p-8">
                    <div className="flex gap-1 mb-6">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                      ))}
                    </div>
                    <p className="text-foreground/80 italic mb-8 min-h-[80px]">"{testimonial.quote}"</p>
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-primary/10 text-primary font-bold flex items-center justify-center text-lg">
                        {testimonial.initials}
                      </div>
                      <div>
                        <div className="font-bold text-foreground">{testimonial.name}</div>
                        <div className="text-sm text-muted-foreground">{testimonial.area}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-16 bg-white border-y border-border">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-12">
            <div className="flex items-center gap-3">
              <MapPin className="w-6 h-6 text-secondary" />
              <h3 className="text-xl font-bold font-serif">Proudly Serving:</h3>
            </div>
            <div className="flex flex-wrap justify-center gap-4 md:gap-8 text-muted-foreground font-medium">
              <span>Downtown</span>
              <span className="hidden md:inline">•</span>
              <span>West End</span>
              <span className="hidden md:inline">•</span>
              <span>Oakwood Heights</span>
              <span className="hidden md:inline">•</span>
              <span>Riverdale</span>
              <span className="hidden md:inline">•</span>
              <span>Pine Valley</span>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <section id="contact" className="py-24 bg-white relative">
        <div className="absolute top-0 left-0 w-1/3 h-full bg-muted/50 hidden lg:block rounded-r-[100px]" />
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center max-w-6xl mx-auto">
            <div className="space-y-8">
              <div>
                <h2 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-6">Get Your Free Estimate Today</h2>
                <p className="text-xl text-muted-foreground">Ready to elevate your outdoor space? Fill out the form and our team will get back to you within 24 hours.</p>
              </div>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <Phone className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg">Call Us Directly</h4>
                    <p className="text-muted-foreground">Available Mon-Sat, 8am-6pm</p>
                    <a href="tel:5558472200" className="text-secondary font-bold text-xl hover:underline">(555) 847-2200</a>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <Mail className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg">Email Us</h4>
                    <p className="text-muted-foreground">For general inquiries</p>
                    <a href="mailto:hello@greenforge.com" className="text-secondary font-bold text-lg hover:underline">hello@greenforge.com</a>
                  </div>
                </div>
              </div>
            </div>

            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-white rounded-3xl shadow-xl border border-border p-8 md:p-10 relative"
            >
              <div className="absolute -top-6 -right-6 w-24 h-24 bg-secondary rounded-full blur-3xl opacity-20" />
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 relative z-10" data-testid="form-contact">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" className="bg-muted/50" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input placeholder="john@example.com" type="email" className="bg-muted/50" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input placeholder="(555) 000-0000" className="bg-muted/50" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="service"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Service Needed</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-muted/50">
                                <SelectValue placeholder="Select a service" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="lawn">Lawn Maintenance</SelectItem>
                              <SelectItem value="design">Garden Design</SelectItem>
                              <SelectItem value="hardscape">Hardscaping/Patios</SelectItem>
                              <SelectItem value="cleanup">Seasonal Cleanup</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="size"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Property Size (Approximate)</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-muted/50">
                              <SelectValue placeholder="Select size" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="small">Small (&lt; 1/4 acre)</SelectItem>
                            <SelectItem value="medium">Medium (1/4 - 1/2 acre)</SelectItem>
                            <SelectItem value="large">Large (&gt; 1/2 acre)</SelectItem>
                            <SelectItem value="commercial">Commercial</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Project Details</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Tell us a bit about what you're looking for..." 
                            className="resize-none bg-muted/50 h-32"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-white h-12 text-lg shadow-lg hover:shadow-primary/30 transition-all duration-300" data-testid="button-submit-quote">
                    Submit Request
                  </Button>
                </form>
              </Form>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-white/80 py-16 border-t-4 border-secondary">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-6">
                <Leaf className="w-6 h-6 text-secondary" />
                <span className="text-2xl font-serif font-bold text-white">GreenForge</span>
              </div>
              <p className="mb-6 max-w-xs">Premium residential landscaping crafted with precision and care. Elevating outdoor living spaces.</p>
              <div className="flex items-center gap-4">
                <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-secondary hover:text-white transition-colors">
                  <Instagram className="w-5 h-5" />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-secondary hover:text-white transition-colors">
                  <Facebook className="w-5 h-5" />
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-white font-bold mb-6 text-lg">Services</h4>
              <ul className="space-y-4">
                <li><a href="#" className="hover:text-secondary transition-colors">Lawn Care & Maintenance</a></li>
                <li><a href="#" className="hover:text-secondary transition-colors">Garden Design & Planting</a></li>
                <li><a href="#" className="hover:text-secondary transition-colors">Hardscaping & Patios</a></li>
                <li><a href="#" className="hover:text-secondary transition-colors">Seasonal Cleanup</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold mb-6 text-lg">Company</h4>
              <ul className="space-y-4">
                <li><a href="#about" className="hover:text-secondary transition-colors">About Us</a></li>
                <li><a href="#projects" className="hover:text-secondary transition-colors">Our Projects</a></li>
                <li><a href="#" className="hover:text-secondary transition-colors">Testimonials</a></li>
                <li><a href="#contact" className="hover:text-secondary transition-colors">Contact</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold mb-6 text-lg">Contact Info</h4>
              <ul className="space-y-4">
                <li className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-secondary" />
                  <span>(555) 847-2200</span>
                </li>
                <li className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-secondary" />
                  <span>hello@greenforge.com</span>
                </li>
                <li className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-secondary shrink-0 mt-1" />
                  <span>123 Nature Way<br/>Metro Area, ST 12345</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4 text-sm">
            <p>&copy; {new Date().getFullYear()} GreenForge Landscaping. All rights reserved.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-secondary transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-secondary transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating CTA */}
      <AnimatePresence>
        {isScrolled && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="fixed bottom-6 right-6 z-50 hidden md:block"
          >
            <Button 
              size="lg" 
              className="bg-primary hover:bg-primary/90 text-white rounded-full h-14 px-6 shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-300 animate-pulse-glow"
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              data-testid="button-floating-cta"
            >
              <Leaf className="w-5 h-5 mr-2" />
              Get Quote
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
