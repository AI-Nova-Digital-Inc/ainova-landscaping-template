import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";

const navLinks = [
  { label: "Services", href: "#services" },
  { label: "Portfolio", href: "#portfolio" },
  { label: "Process", href: "#process" },
  { label: "About", href: "#materials" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <motion.header
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
      style={{
        background: scrolled
          ? "rgba(13, 13, 11, 0.92)"
          : "transparent",
        backdropFilter: scrolled ? "blur(16px)" : "none",
        borderBottom: scrolled ? "1px solid rgba(255,255,255,0.06)" : "none",
      }}
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: "easeOut", delay: 0.3 }}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12 h-20 flex items-center justify-between">
        {/* Logo */}
        <a
          href="#"
          onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: "smooth" }); }}
          className="flex items-center gap-3 group"
          data-testid="link-logo"
        >
          <div className="w-8 h-8 relative">
            <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M16 2C16 2 6 10 6 18C6 23.5228 10.4772 28 16 28C21.5228 28 26 23.5228 26 18C26 10 16 2 16 2Z" fill="hsl(145, 35%, 22%)" />
              <path d="M16 8C16 8 10 14 10 19C10 22.3137 12.6863 25 16 25C19.3137 25 22 22.3137 22 19C22 14 16 8 16 8Z" fill="hsl(145, 30%, 32%)" />
              <line x1="16" y1="25" x2="16" y2="30" stroke="hsl(38, 55%, 62%)" strokeWidth="1.5" />
            </svg>
          </div>
          <div>
            <span className="font-serif text-xl font-light tracking-widest text-beige uppercase" style={{ letterSpacing: "0.15em" }}>
              VerdantScape
            </span>
            <span className="block text-[10px] tracking-[0.3em] uppercase" style={{ color: "hsl(38, 55%, 62%)", lineHeight: 1.2 }}>
              Design
            </span>
          </div>
        </a>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-10" data-testid="nav-desktop">
          {navLinks.map((link) => (
            <button
              key={link.label}
              onClick={() => handleNavClick(link.href)}
              className="text-xs uppercase tracking-[0.2em] transition-colors duration-300 cursor-pointer"
              style={{ color: "hsl(35, 12%, 55%)" }}
              onMouseEnter={(e) => (e.currentTarget.style.color = "hsl(35, 25%, 88%)")}
              onMouseLeave={(e) => (e.currentTarget.style.color = "hsl(35, 12%, 55%)")}
              data-testid={`nav-${link.label.toLowerCase()}`}
            >
              {link.label}
            </button>
          ))}
          <button
            onClick={() => handleNavClick("#contact")}
            className="px-6 py-2.5 text-xs uppercase tracking-[0.2em] border transition-all duration-300 cursor-pointer"
            style={{
              borderColor: "hsl(38, 55%, 62%)",
              color: "hsl(38, 55%, 62%)",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = "hsl(38, 55%, 62%)";
              e.currentTarget.style.color = "hsl(20, 10%, 5%)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = "transparent";
              e.currentTarget.style.color = "hsl(38, 55%, 62%)";
            }}
            data-testid="button-consultation-nav"
          >
            Consultation
          </button>
        </nav>

        {/* Mobile menu toggle */}
        <button
          className="md:hidden text-beige"
          onClick={() => setMenuOpen(!menuOpen)}
          data-testid="button-menu-toggle"
          style={{ color: "hsl(35, 25%, 88%)" }}
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            className="md:hidden"
            style={{ background: "rgba(13, 13, 11, 0.97)", backdropFilter: "blur(16px)" }}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            data-testid="nav-mobile"
          >
            <div className="px-6 py-8 flex flex-col gap-6">
              {navLinks.map((link) => (
                <button
                  key={link.label}
                  onClick={() => handleNavClick(link.href)}
                  className="text-left text-sm uppercase tracking-[0.2em] cursor-pointer"
                  style={{ color: "hsl(35, 25%, 88%)" }}
                  data-testid={`mobile-nav-${link.label.toLowerCase()}`}
                >
                  {link.label}
                </button>
              ))}
              <button
                onClick={() => handleNavClick("#contact")}
                className="w-full py-3 text-xs uppercase tracking-[0.2em] border text-center cursor-pointer"
                style={{ borderColor: "hsl(38, 55%, 62%)", color: "hsl(38, 55%, 62%)" }}
                data-testid="button-consultation-mobile"
              >
                Request Consultation
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
