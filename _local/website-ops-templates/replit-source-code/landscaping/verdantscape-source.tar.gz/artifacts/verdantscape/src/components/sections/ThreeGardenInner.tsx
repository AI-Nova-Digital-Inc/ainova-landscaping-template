import { useRef, useMemo, Suspense } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Stars } from "@react-three/drei";
import * as THREE from "three";

function Tree({ position, seed }: { position: [number, number, number]; seed: number }) {
  const scale = 0.65 + (seed % 7) * 0.08;
  const hue = 135 + (seed % 5) * 4;
  return (
    <group position={position} scale={[scale, scale, scale]}>
      <mesh position={[0, 0.9, 0]}>
        <cylinderGeometry args={[0.07, 0.13, 1.8, 7]} />
        <meshStandardMaterial color="#291608" roughness={0.95} />
      </mesh>
      <mesh position={[0, 2.3, 0]}>
        <coneGeometry args={[0.7, 1.7, 7]} />
        <meshStandardMaterial color={`hsl(${hue}, 50%, 14%)`} roughness={0.85} />
      </mesh>
      <mesh position={[0, 3.2, 0]}>
        <coneGeometry args={[0.5, 1.4, 7]} />
        <meshStandardMaterial color={`hsl(${hue + 4}, 50%, 18%)`} roughness={0.85} />
      </mesh>
      <mesh position={[0, 4.0, 0]}>
        <coneGeometry args={[0.32, 1.1, 7]} />
        <meshStandardMaterial color={`hsl(${hue + 8}, 50%, 22%)`} roughness={0.85} />
      </mesh>
    </group>
  );
}

function StonePath() {
  const stones = useMemo(() => {
    const list = [];
    for (let i = 0; i < 20; i++) {
      const t = i / 19;
      list.push({
        x: Math.sin(t * Math.PI * 0.7) * 1.3,
        z: -15 + t * 30,
        w: 0.5 + (i % 3) * 0.12,
        d: 0.38 + (i % 4) * 0.08,
        rot: (i % 5) * 0.1 - 0.2,
      });
    }
    return list;
  }, []);

  return (
    <group>
      {stones.map((s, i) => (
        <mesh key={i} position={[s.x, -0.05, s.z]} rotation={[0, s.rot, 0]}>
          <boxGeometry args={[s.w, 0.05, s.d]} />
          <meshStandardMaterial color="#3d3830" roughness={0.98} metalness={0.05} />
        </mesh>
      ))}
    </group>
  );
}

function Fireflies() {
  const count = 180;
  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 26;
      arr[i * 3 + 1] = 0.5 + Math.random() * 5.5;
      arr[i * 3 + 2] = (Math.random() - 0.5) * 26;
    }
    return arr;
  }, []);

  const ref = useRef<THREE.Points>(null);
  useFrame(({ clock }) => {
    if (ref.current) {
      ref.current.rotation.y = clock.getElapsedTime() * 0.008;
      ref.current.position.y = Math.sin(clock.getElapsedTime() * 0.15) * 0.12;
    }
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.045}
        color="#c9a96e"
        transparent
        opacity={0.55}
        sizeAttenuation
      />
    </points>
  );
}

function SlowOrbit({ children }: { children: React.ReactNode }) {
  const ref = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    const t = clock.getElapsedTime();
    if (ref.current) {
      ref.current.rotation.y = Math.sin(t * 0.055) * 0.11;
      ref.current.position.y = Math.sin(t * 0.09) * 0.18;
    }
  });
  return <group ref={ref}>{children}</group>;
}

const treeData: Array<{ pos: [number, number, number]; seed: number }> = [
  { pos: [-4.5, 0, -8], seed: 1 }, { pos: [-2.8, 0, -5], seed: 2 },
  { pos: [-5.5, 0, -2], seed: 3 }, { pos: [-4.0, 0, 1], seed: 4 },
  { pos: [-5.2, 0, 5], seed: 5 }, { pos: [-3.5, 0, 9], seed: 6 },
  { pos: [-5.8, 0, 13], seed: 7 }, { pos: [-4.3, 0, -12], seed: 8 },
  { pos: [4.5, 0, -8], seed: 9 }, { pos: [2.9, 0, -5], seed: 10 },
  { pos: [5.5, 0, -2], seed: 11 }, { pos: [4.1, 0, 1], seed: 12 },
  { pos: [5.3, 0, 5], seed: 13 }, { pos: [3.6, 0, 9], seed: 14 },
  { pos: [6.0, 0, 13], seed: 15 }, { pos: [4.4, 0, -12], seed: 16 },
  { pos: [-7.2, 0, -4], seed: 17 }, { pos: [7.4, 0, 3], seed: 18 },
  { pos: [-8.2, 0, 7], seed: 19 }, { pos: [8.5, 0, -2], seed: 20 },
  { pos: [-6.8, 0, 15], seed: 21 }, { pos: [7.0, 0, 15], seed: 22 },
];

function Scene() {
  return (
    <>
      <color attach="background" args={["#050906"]} />
      <fog attach="fog" args={["#050906", 12, 36]} />

      <ambientLight intensity={0.14} color="#192e1a" />
      <directionalLight position={[6, 14, 4]} intensity={0.85} color="#c9a96e" />
      <pointLight position={[0, 2.5, 0]} intensity={1.6} color="#c9a96e" distance={14} decay={2} />
      <pointLight position={[-3.5, 1.8, 4]} intensity={0.7} color="#52d98a" distance={9} decay={2.5} />
      <pointLight position={[4, 1.8, -4]} intensity={0.5} color="#7ef0a0" distance={9} decay={2.5} />

      <Suspense fallback={null}>
        <Stars radius={75} depth={45} count={500} factor={2} saturation={0} fade speed={0.4} />
      </Suspense>

      {/* Ground */}
      <mesh position={[0, -0.12, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[60, 60]} />
        <meshStandardMaterial color="#0c180c" roughness={1} />
      </mesh>

      <SlowOrbit>
        <StonePath />
        {treeData.map(({ pos, seed }) => (
          <Tree key={seed} position={pos} seed={seed} />
        ))}
        <Fireflies />
      </SlowOrbit>
    </>
  );
}

export default function ThreeGardenInner() {
  return (
    <Canvas
      camera={{ position: [0, 3.8, 9.5], fov: 58 }}
      shadows={false}
      gl={{ antialias: true, alpha: true }}
      style={{ background: "transparent" }}
    >
      <Scene />
    </Canvas>
  );
}
