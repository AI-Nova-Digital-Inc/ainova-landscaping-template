import { useState } from "react";
import { motion } from "framer-motion";

const projects = [
  {
    title: "Hillside Sanctuary",
    location: "Marin County, CA",
    type: "Residential Estate",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=900&q=80",
    size: "large",
  },
  {
    title: "Coastal Retreat",
    location: "Carmel-by-the-Sea, CA",
    type: "Waterfront Garden",
    image: "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=900&q=80",
    size: "small",
  },
  {
    title: "The Glass Pavilion",
    location: "Atherton, CA",
    type: "Modern Estate",
    image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=900&q=80",
    size: "small",
  },
  {
    title: "Zenith Gardens",
    location: "Pacific Heights, SF",
    type: "Urban Terrace",
    image: "https://images.unsplash.com/photo-1600607688969-a5bfcd646154?w=900&q=80",
    size: "large",
  },
  {
    title: "Stone & Water",
    location: "Woodside, CA",
    type: "Estate Grounds",
    image: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=900&q=80",
    size: "small",
  },
  {
    title: "The Emerald Court",
    location: "Tiburon, CA",
    type: "Courtyard Garden",
    image: "https://images.unsplash.com/photo-1590490359683-658d3d23f972?w=900&q=80",
    size: "small",
  },
];

function ProjectCard({ project, index }: { project: typeof projects[0]; index: number }) {
  const [hovered, setHovered] = useState(false);

  return (
    <motion.div
      className="relative overflow-hidden cursor-pointer"
      style={{
        gridColumn: project.size === "large" ? "span 1" : "span 1",
      }}
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.8, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      data-testid={`card-project-${index}`}
    >
      {/* Image */}
      <div className="relative overflow-hidden" style={{ paddingBottom: project.size === "large" ? "130%" : "80%" }}>
        <motion.img
          src={project.image}
          alt={project.title}
          className="absolute inset-0 w-full h-full object-cover"
          animate={{ scale: hovered ? 1.07 : 1 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          loading="lazy"
        />

        {/* Overlay */}
        <motion.div
          className="absolute inset-0 flex flex-col justify-end p-8"
          style={{ background: "linear-gradient(to top, rgba(5,9,6,0.95) 0%, rgba(5,9,6,0.3) 50%, transparent 100%)" }}
          animate={{ opacity: hovered ? 1 : 0.7 }}
          transition={{ duration: 0.4 }}
        >
          <motion.div
            animate={{ y: hovered ? 0 : 12, opacity: hovered ? 1 : 0 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          >
            <span className="text-xs uppercase tracking-[0.3em] mb-3 block" style={{ color: "hsl(38, 55%, 62%)" }}>
              {project.type}
            </span>
          </motion.div>

          <h3
            className="font-serif font-light text-2xl mb-1"
            style={{ color: "hsl(35, 25%, 92%)" }}
          >
            {project.title}
          </h3>
          <p className="text-xs tracking-wider" style={{ color: "hsl(35, 12%, 58%)" }}>
            {project.location}
          </p>

          <motion.div
            className="mt-4 pt-4 border-t"
            style={{ borderColor: "rgba(255,255,255,0.12)" }}
            animate={{ opacity: hovered ? 1 : 0, y: hovered ? 0 : 8 }}
            transition={{ duration: 0.4, delay: 0.05 }}
          >
            <span className="text-xs uppercase tracking-[0.25em]" style={{ color: "hsl(38, 55%, 62%)" }}>
              View Project →
            </span>
          </motion.div>
        </motion.div>
      </div>
    </motion.div>
  );
}

export default function PortfolioSection() {
  return (
    <section
      id="portfolio"
      className="section-padding px-6 lg:px-12"
      style={{ backgroundColor: "hsl(20, 10%, 7%)" }}
      data-testid="section-portfolio"
    >
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          className="mb-20 flex flex-col md:flex-row md:items-end md:justify-between gap-8"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8 }}
        >
          <div className="max-w-lg">
            <div className="gold-line" />
            <span className="text-xs uppercase tracking-[0.3em] mb-4 block" style={{ color: "hsl(38, 55%, 62%)" }}>
              Selected Works
            </span>
            <h2
              className="font-serif font-light leading-tight"
              style={{ fontSize: "clamp(2.2rem, 5vw, 4rem)", color: "hsl(35, 25%, 88%)" }}
              data-testid="heading-portfolio"
            >
              Projects That<br />Define Excellence
            </h2>
          </div>
          <p className="text-sm leading-relaxed max-w-xs" style={{ color: "hsl(35, 12%, 52%)" }}>
            Each project is a singular collaboration — a dialogue between what you envision and what the land allows.
          </p>
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.map((project, i) => (
            <ProjectCard key={i} project={project} index={i} />
          ))}
        </div>

        {/* CTA */}
        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          <motion.button
            className="px-12 py-4 text-xs uppercase tracking-[0.25em] border cursor-pointer"
            style={{ borderColor: "rgba(255,255,255,0.2)", color: "hsl(35, 25%, 88%)" }}
            whileHover={{ borderColor: "hsl(38, 55%, 62%)", color: "hsl(38, 55%, 62%)" }}
            transition={{ duration: 0.3 }}
            data-testid="button-view-all-projects"
          >
            View All Projects
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}
