import { motion } from "framer-motion";
import { Instagram, Linkedin, Facebook } from "lucide-react";

const navLinks = [
  { label: "Services", href: "#services" },
  { label: "Portfolio", href: "#portfolio" },
  { label: "Process", href: "#process" },
  { label: "About", href: "#materials" },
  { label: "Contact", href: "#contact" },
];

const handleNavClick = (href: string) => {
  const el = document.querySelector(href);
  if (el) el.scrollIntoView({ behavior: "smooth" });
};

export default function Footer() {
  return (
    <footer
      style={{ borderTop: "1px solid rgba(255,255,255,0.06)", backgroundColor: "hsl(20, 10%, 4%)" }}
      className="px-6 lg:px-12 py-20"
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16 mb-16">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8">
                <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M16 2C16 2 6 10 6 18C6 23.5228 10.4772 28 16 28C21.5228 28 26 23.5228 26 18C26 10 16 2 16 2Z" fill="hsl(145, 35%, 22%)" />
                  <path d="M16 8C16 8 10 14 10 19C10 22.3137 12.6863 25 16 25C19.3137 25 22 22.3137 22 19C22 14 16 8 16 8Z" fill="hsl(145, 30%, 32%)" />
                  <line x1="16" y1="25" x2="16" y2="30" stroke="hsl(38, 55%, 62%)" strokeWidth="1.5" />
                </svg>
              </div>
              <div>
                <span className="font-serif text-lg font-light tracking-widest uppercase" style={{ color: "hsl(35, 25%, 88%)", letterSpacing: "0.15em" }}>
                  VerdantScape
                </span>
                <span className="block text-[10px] tracking-[0.3em] uppercase" style={{ color: "hsl(38, 55%, 62%)" }}>
                  Design
                </span>
              </div>
            </div>
            <p className="text-sm leading-relaxed" style={{ color: "hsl(35, 12%, 50%)" }}>
              Luxury landscaping and outdoor living environments crafted for those who demand the extraordinary.
            </p>
            <div className="flex gap-4 mt-8">
              {[Instagram, Linkedin, Facebook].map((Icon, i) => (
                <motion.a
                  key={i}
                  href="#"
                  whileHover={{ scale: 1.1 }}
                  className="w-9 h-9 rounded-full flex items-center justify-center border transition-colors duration-300"
                  style={{ borderColor: "rgba(255,255,255,0.1)", color: "hsl(35, 12%, 50%)" }}
                  onMouseEnter={(e) => (e.currentTarget.style.borderColor = "hsl(38, 55%, 62%)")}
                  onMouseLeave={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
                  data-testid={`link-social-${i}`}
                >
                  <Icon size={15} />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="text-xs uppercase tracking-[0.3em] mb-6" style={{ color: "hsl(38, 55%, 62%)" }}>
              Navigation
            </h4>
            <ul className="space-y-4">
              {navLinks.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => handleNavClick(link.href)}
                    className="text-sm cursor-pointer transition-colors duration-300"
                    style={{ color: "hsl(35, 12%, 50%)" }}
                    onMouseEnter={(e) => (e.currentTarget.style.color = "hsl(35, 25%, 88%)")}
                    onMouseLeave={(e) => (e.currentTarget.style.color = "hsl(35, 12%, 50%)")}
                    data-testid={`footer-nav-${link.label.toLowerCase()}`}
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-xs uppercase tracking-[0.3em] mb-6" style={{ color: "hsl(38, 55%, 62%)" }}>
              Studio
            </h4>
            <div className="space-y-3 text-sm" style={{ color: "hsl(35, 12%, 50%)" }}>
              <p>1248 Jackson Street, Suite 400</p>
              <p>San Francisco, CA 94109</p>
              <p className="mt-6">
                <a
                  href="tel:+14155550180"
                  className="transition-colors duration-300"
                  onMouseEnter={(e) => (e.currentTarget.style.color = "hsl(35, 25%, 88%)")}
                  onMouseLeave={(e) => (e.currentTarget.style.color = "hsl(35, 12%, 50%)")}
                  data-testid="link-phone"
                >
                  +1 (415) 555-0180
                </a>
              </p>
              <p>
                <a
                  href="mailto:studio@verdantscape.com"
                  className="transition-colors duration-300"
                  onMouseEnter={(e) => (e.currentTarget.style.color = "hsl(35, 25%, 88%)")}
                  onMouseLeave={(e) => (e.currentTarget.style.color = "hsl(35, 12%, 50%)")}
                  data-testid="link-email"
                >
                  studio@verdantscape.com
                </a>
              </p>
            </div>
          </div>
        </div>

        <div
          className="pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs"
          style={{ borderTop: "1px solid rgba(255,255,255,0.06)", color: "hsl(35, 10%, 38%)" }}
        >
          <p>2024 VerdantScape Design. All rights reserved.</p>
          <p className="tracking-widest uppercase" style={{ letterSpacing: "0.2em" }}>
            Crafting Outdoor Excellence
          </p>
        </div>
      </div>
    </footer>
  );
}
