import { motion } from "framer-motion";

const materials = [
  {
    title: "Natural Stone",
    detail: "Limestone, Travertine, Basalt",
    description: "Sourced from quarries in Italy, France, and the American Southwest. Each slab tells a geological story spanning millions of years.",
    image: "https://images.unsplash.com/photo-1581621403668-aca8dc1f3e7b?w=800&q=80",
  },
  {
    title: "Hardwood Timber",
    detail: "Teak, Ipe, Cumaru",
    description: "FSC-certified hardwoods selected for their extraordinary durability, grain, and ability to weather into something even more beautiful.",
    image: "https://images.unsplash.com/photo-1541123437800-1bb1317badc2?w=800&q=80",
  },
  {
    title: "Living Moss & Turf",
    detail: "Curated botanical selections",
    description: "Regionally appropriate plantings chosen not just for beauty but for ecological resilience — living systems that thrive with minimal intervention.",
    image: "https://images.unsplash.com/photo-1501004318641-b39e6451bec6?w=800&q=80",
  },
  {
    title: "Water & Reflection",
    detail: "Natural & engineered aquatics",
    description: "Basalt fountains, infinity edges, naturalistic streams. Water that moves, reflects, and fills silence with something essential.",
    image: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&q=80",
  },
];

export default function MaterialsSection() {
  return (
    <section
      id="materials"
      className="section-padding px-6 lg:px-12"
      style={{ backgroundColor: "hsl(20, 10%, 7%)" }}
      data-testid="section-materials"
    >
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          className="mb-20 max-w-xl"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8 }}
        >
          <div className="gold-line" />
          <span className="text-xs uppercase tracking-[0.3em] mb-4 block" style={{ color: "hsl(38, 55%, 62%)" }}>
            Materials & Craft
          </span>
          <h2
            className="font-serif font-light leading-tight mb-6"
            style={{ fontSize: "clamp(2.2rem, 5vw, 4rem)", color: "hsl(35, 25%, 88%)" }}
            data-testid="heading-materials"
          >
            Only What the Land<br />Deserves
          </h2>
          <p className="text-base leading-relaxed" style={{ color: "hsl(35, 12%, 55%)" }}>
            We work with a curated palette of materials — chosen for their beauty, provenance, and ability to age with dignity. Nothing synthetic. Nothing disposable.
          </p>
        </motion.div>

        {/* Material grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-px" style={{ backgroundColor: "rgba(255,255,255,0.05)" }}>
          {materials.map((mat, i) => (
            <motion.div
              key={i}
              className="group relative overflow-hidden flex"
              style={{ backgroundColor: "hsl(20, 10%, 7%)" }}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.7, delay: i * 0.1 }}
              data-testid={`card-material-${i}`}
            >
              {/* Image */}
              <div className="w-40 flex-shrink-0 relative overflow-hidden">
                <motion.img
                  src={mat.image}
                  alt={mat.title}
                  className="absolute inset-0 w-full h-full object-cover"
                  whileHover={{ scale: 1.08 }}
                  transition={{ duration: 0.6 }}
                  loading="lazy"
                />
                <div className="absolute inset-0" style={{ background: "linear-gradient(to right, transparent, hsl(20, 10%, 7%))" }} />
              </div>

              {/* Text */}
              <div className="p-8 flex flex-col justify-center">
                <span className="text-xs uppercase tracking-[0.25em] mb-2 block" style={{ color: "hsl(38, 55%, 62%)" }}>
                  {mat.detail}
                </span>
                <h3
                  className="font-serif font-light text-2xl mb-4"
                  style={{ color: "hsl(35, 25%, 88%)" }}
                >
                  {mat.title}
                </h3>
                <p className="text-sm leading-relaxed" style={{ color: "hsl(35, 12%, 52%)" }}>
                  {mat.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Stats bar */}
        <motion.div
          className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-px"
          style={{ backgroundColor: "rgba(255,255,255,0.06)" }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          {[
            { value: "22+", label: "Years of Mastery" },
            { value: "340+", label: "Projects Completed" },
            { value: "18", label: "Design Awards" },
            { value: "100%", label: "Client Satisfaction" },
          ].map((stat, i) => (
            <div
              key={i}
              className="p-10 text-center"
              style={{ backgroundColor: "hsl(20, 10%, 7%)" }}
              data-testid={`stat-${i}`}
            >
              <div
                className="font-serif font-light mb-2"
                style={{ fontSize: "3rem", color: "hsl(38, 55%, 62%)", lineHeight: 1 }}
              >
                {stat.value}
              </div>
              <div className="text-xs uppercase tracking-[0.2em]" style={{ color: "hsl(35, 12%, 50%)" }}>
                {stat.label}
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
