import { motion } from "framer-motion";

const testimonials = [
  {
    quote:
      "Working with VerdantScape was unlike any design experience we've had. They didn't just transform our garden — they gave us a place that has become the center of our family's life. We entertain outdoors now more than inside.",
    name: "Catherine & James Whitmore",
    project: "Hillside Estate, Marin County",
    initials: "CW",
  },
  {
    quote:
      "The level of craftsmanship is extraordinary. Every material was chosen with intention. Eighteen months in, our garden only grows more beautiful. I find myself out there at dawn before the world wakes up, just sitting in the quiet.",
    name: "Robert Andersen",
    project: "Coastal Retreat, Carmel",
    initials: "RA",
  },
  {
    quote:
      "I've worked with landscape architects on three properties. VerdantScape operates in a different category entirely. They see the potential in a site that no one else sees. Our courtyard is a true work of art.",
    name: "Sophia Nkemelu",
    project: "Urban Terrace, Pacific Heights",
    initials: "SN",
  },
];

export default function TestimonialsSection() {
  return (
    <section
      id="testimonials"
      className="section-padding px-6 lg:px-12 relative overflow-hidden"
      style={{ backgroundColor: "hsl(145, 35%, 8%)" }}
      data-testid="section-testimonials"
    >
      {/* Background radial glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse at 50% 100%, hsl(145, 35%, 12%) 0%, transparent 60%)",
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          className="mb-20 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8 }}
        >
          <div className="gold-line mx-auto" style={{ width: "3rem", marginLeft: "auto", marginRight: "auto" }} />
          <span className="text-xs uppercase tracking-[0.3em] mb-4 block" style={{ color: "hsl(38, 55%, 62%)" }}>
            Client Stories
          </span>
          <h2
            className="font-serif font-light leading-tight"
            style={{ fontSize: "clamp(2.2rem, 5vw, 4rem)", color: "hsl(35, 25%, 88%)" }}
            data-testid="heading-testimonials"
          >
            Spaces That Change<br />How You Live
          </h2>
        </motion.div>

        {/* Testimonial cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              className="relative p-10 flex flex-col gap-8"
              style={{
                backgroundColor: "hsl(20, 10%, 6%)",
                border: "1px solid rgba(255,255,255,0.06)",
              }}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.7, delay: i * 0.15, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ borderColor: "rgba(201, 169, 110, 0.3)" }}
              data-testid={`card-testimonial-${i}`}
            >
              {/* Quote mark */}
              <span
                className="font-serif absolute top-6 right-8"
                style={{ fontSize: "5rem", lineHeight: 1, color: "rgba(201, 169, 110, 0.08)", userSelect: "none" }}
              >
                "
              </span>

              {/* Gold accent */}
              <div className="w-8 h-px" style={{ backgroundColor: "hsl(38, 55%, 62%)" }} />

              {/* Quote */}
              <p
                className="font-serif font-light text-lg leading-relaxed flex-1"
                style={{ color: "hsl(35, 20%, 75%)", fontStyle: "italic" }}
                data-testid={`text-quote-${i}`}
              >
                "{t.quote}"
              </p>

              {/* Attribution */}
              <div className="flex items-center gap-4 pt-6" style={{ borderTop: "1px solid rgba(255,255,255,0.07)" }}>
                <div
                  className="w-11 h-11 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: "hsl(145, 35%, 16%)", border: "1px solid hsl(145, 35%, 22%)" }}
                >
                  <span className="font-serif text-sm" style={{ color: "hsl(38, 55%, 62%)" }}>
                    {t.initials}
                  </span>
                </div>
                <div>
                  <p className="text-sm font-medium" style={{ color: "hsl(35, 25%, 82%)" }}>
                    {t.name}
                  </p>
                  <p className="text-xs mt-0.5" style={{ color: "hsl(35, 12%, 50%)" }}>
                    {t.project}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
