import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Sprout, Layers, Lightbulb, Waves } from "lucide-react";

const services = [
  {
    icon: Sprout,
    title: "Landscape Design",
    description:
      "Bespoke master plans that transform your property into a living work of art. We consider every sightline, seasonal shift, and ecological nuance to create spaces that evolve beautifully over time.",
  },
  {
    icon: Layers,
    title: "Hardscaping",
    description:
      "Premium stonework, custom terracing, outdoor kitchens, and structural elements crafted from the world's finest materials. Where architecture meets nature.",
  },
  {
    icon: Lightbulb,
    title: "Outdoor Lighting",
    description:
      "Cinematic illumination that extends your space into the evening hours. Low-voltage artistry that highlights texture, depth, and form after dark.",
  },
  {
    icon: Waves,
    title: "Water Features",
    description:
      "From serene reflecting pools to cascading naturalistic streams, our water features bring movement, sound, and life to every environment we create.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.15 },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } },
};

export default function ServicesSection() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section
      id="services"
      className="section-padding px-6 lg:px-12"
      style={{ backgroundColor: "hsl(20, 10%, 5%)" }}
      data-testid="section-services"
    >
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          className="mb-20 max-w-xl"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="gold-line" />
          <span className="text-xs uppercase tracking-[0.3em] mb-4 block" style={{ color: "hsl(38, 55%, 62%)" }}>
            What We Do
          </span>
          <h2
            className="font-serif font-light leading-tight mb-6"
            style={{ fontSize: "clamp(2.2rem, 5vw, 4rem)", color: "hsl(35, 25%, 88%)" }}
            data-testid="heading-services"
          >
            Outdoor Environments<br />Built to Last Generations
          </h2>
          <p className="text-base leading-relaxed" style={{ color: "hsl(35, 12%, 55%)" }}>
            Each project begins with listening. We immerse ourselves in how you live, what you value, and what you dream of — then translate that into a landscape that exceeds every expectation.
          </p>
        </motion.div>

        {/* Cards */}
        <motion.div
          ref={ref}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px"
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          style={{ backgroundColor: "rgba(255,255,255,0.05)" }}
        >
          {services.map((service, i) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={i}
                variants={cardVariants}
                className="group relative p-10 flex flex-col gap-6 cursor-default transition-all duration-500"
                style={{ backgroundColor: "hsl(20, 10%, 5%)" }}
                whileHover={{ backgroundColor: "hsl(20, 10%, 8%)" }}
                data-testid={`card-service-${i}`}
              >
                {/* Gold accent line on hover */}
                <div
                  className="absolute top-0 left-0 w-full h-px transition-all duration-500 opacity-0 group-hover:opacity-100"
                  style={{ backgroundColor: "hsl(38, 55%, 62%)" }}
                />

                {/* Icon */}
                <motion.div
                  className="w-12 h-12 rounded-full flex items-center justify-center"
                  style={{ backgroundColor: "hsl(145, 35%, 14%)", border: "1px solid hsl(145, 35%, 20%)" }}
                  whileHover={{ scale: 1.1 }}
                  transition={{ duration: 0.3 }}
                >
                  <Icon size={20} style={{ color: "hsl(38, 55%, 62%)" }} />
                </motion.div>

                {/* Text */}
                <div>
                  <h3
                    className="font-serif font-light text-2xl mb-4 transition-colors duration-300"
                    style={{ color: "hsl(35, 25%, 88%)" }}
                  >
                    {service.title}
                  </h3>
                  <p className="text-sm leading-relaxed" style={{ color: "hsl(35, 12%, 52%)" }}>
                    {service.description}
                  </p>
                </div>

                {/* Learn more */}
                <div className="mt-auto pt-6">
                  <span
                    className="text-xs uppercase tracking-[0.2em] transition-colors duration-300"
                    style={{ color: "hsl(35, 12%, 40%)" }}
                  >
                    Learn More
                    <span className="inline-block ml-2 transition-transform duration-300 group-hover:translate-x-1">→</span>
                  </span>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
