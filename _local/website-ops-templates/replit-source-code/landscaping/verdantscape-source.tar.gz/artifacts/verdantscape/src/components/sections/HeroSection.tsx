import { useRef, useMemo, Suspense, useState, useEffect } from "react";
import { motion } from "framer-motion";
import { WebGLErrorBoundary } from "@/components/WebGLErrorBoundary";

function detectWebGL(): boolean {
  try {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
    return !!ctx;
  } catch {
    return false;
  }
}

// ─── Hero Text & CTAs ───────────────────────────────────────────────────────
function HeroContent({ onExplore, onConsult }: { onExplore: () => void; onConsult: () => void }) {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 0.5 }}
        className="mb-6"
      >
        <span
          className="text-xs uppercase tracking-[0.4em] font-light"
          style={{ color: "hsl(38, 55%, 62%)" }}
          data-testid="text-hero-eyebrow"
        >
          Luxury Landscape Architecture
        </span>
      </motion.div>

      <motion.h1
        className="font-serif font-light mb-6"
        style={{
          fontSize: "clamp(2.8rem, 7vw, 6.5rem)",
          lineHeight: 1.05,
          color: "hsl(35, 25%, 94%)",
          letterSpacing: "-0.02em",
          textShadow: "0 2px 32px rgba(0,0,0,0.8)",
        }}
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.2, delay: 0.7, ease: [0.22, 1, 0.36, 1] }}
        data-testid="text-hero-headline"
      >
        Crafting Outdoor Spaces<br />
        <em style={{ color: "hsl(38, 55%, 68%)", fontStyle: "italic" }}>That Inspire</em>
      </motion.h1>

      <motion.p
        className="text-base md:text-xl font-light max-w-lg mb-14 leading-relaxed"
        style={{ color: "hsl(35, 15%, 72%)", letterSpacing: "0.02em", textShadow: "0 1px 8px rgba(0,0,0,0.7)" }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 1.0 }}
        data-testid="text-hero-subtext"
      >
        Luxury landscaping designed for modern living
      </motion.p>

      <motion.div
        className="flex flex-col sm:flex-row gap-5 items-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 1.2 }}
      >
        <motion.button
          onClick={onExplore}
          className="px-10 py-4 text-xs uppercase tracking-[0.25em] font-medium cursor-pointer"
          style={{
            backgroundColor: "hsl(145, 35%, 22%)",
            color: "hsl(35, 25%, 92%)",
            border: "1px solid hsl(145, 35%, 30%)",
          }}
          whileHover={{ scale: 1.04, backgroundColor: "hsl(145, 38%, 27%)" }}
          whileTap={{ scale: 0.97 }}
          data-testid="button-explore-work"
        >
          Explore Our Work
        </motion.button>
        <motion.button
          onClick={onConsult}
          className="px-10 py-4 text-xs uppercase tracking-[0.25em] font-medium cursor-pointer"
          style={{
            backgroundColor: "transparent",
            color: "hsl(38, 55%, 68%)",
            border: "1px solid hsl(38, 55%, 55%)",
          }}
          whileHover={{ scale: 1.04, backgroundColor: "hsl(38, 55%, 62%)", color: "hsl(20, 10%, 5%)", borderColor: "hsl(38, 55%, 62%)" }}
          whileTap={{ scale: 0.97 }}
          data-testid="button-request-consultation"
        >
          Request Consultation
        </motion.button>
      </motion.div>
    </div>
  );
}

// ─── CSS Parallax Background (always shown, optionally behind 3D) ───────────
function ParallaxBg() {
  return (
    <>
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: "url(https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=1800&q=85)",
          backgroundSize: "cover",
          backgroundPosition: "center 35%",
          filter: "brightness(0.28) saturate(0.7)",
        }}
      />
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at 20% 70%, hsl(145, 45%, 9%) 0%, transparent 55%), " +
            "radial-gradient(ellipse at 80% 20%, hsl(145, 30%, 6%) 0%, transparent 50%)",
        }}
      />
    </>
  );
}

// ─── Three.js Garden Scene ────────────────────────────────────────────────
function ThreeGarden() {
  const [Comp, setComp] = useState<React.ComponentType | null>(null);

  useEffect(() => {
    let cancelled = false;
    import("@/components/sections/ThreeGardenInner").then((mod) => {
      if (!cancelled) setComp(() => mod.default);
    }).catch(() => {});
    return () => { cancelled = true; };
  }, []);

  if (!Comp) return null;
  return <Comp />;
}

// ─── Main Hero ────────────────────────────────────────────────────────────
export default function HeroSection() {
  const [webglSupported, setWebglSupported] = useState<boolean | null>(null);

  useEffect(() => {
    setWebglSupported(detectWebGL());
  }, []);

  const onExplore = () => document.querySelector("#portfolio")?.scrollIntoView({ behavior: "smooth" });
  const onConsult = () => document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" });

  return (
    <section
      id="hero"
      className="relative w-full overflow-hidden"
      style={{ height: "100vh", minHeight: 600, backgroundColor: "#050906" }}
      data-testid="section-hero"
    >
      {/* ── Layer 1: Always-visible photo background ── */}
      <ParallaxBg />

      {/* ── Layer 2: Three.js canvas (if WebGL available) ── */}
      {webglSupported && (
        <div className="absolute inset-0">
          <WebGLErrorBoundary fallback={<></>}>
            <ThreeGarden />
          </WebGLErrorBoundary>
        </div>
      )}

      {/* ── Layer 3: Gradient overlays for text readability ── */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "linear-gradient(to bottom, rgba(5,9,6,0.55) 0%, rgba(5,9,6,0.25) 35%, rgba(5,9,6,0.55) 65%, rgba(5,9,6,0.95) 100%)",
        }}
      />
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse at 50% 50%, rgba(5,9,6,0.1) 0%, rgba(5,9,6,0.55) 100%)",
        }}
      />

      {/* ── Layer 4: Text content (always on top) ── */}
      <div className="absolute inset-0 z-10">
        <HeroContent onExplore={onExplore} onConsult={onConsult} />
      </div>

      {/* ── Scroll indicator ── */}
      <motion.div
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 z-20 pointer-events-none"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2.2, duration: 1 }}
      >
        <span className="text-[10px] uppercase tracking-[0.35em]" style={{ color: "hsl(35, 12%, 48%)" }}>
          Scroll
        </span>
        <motion.div
          style={{
            width: "1px",
            height: "48px",
            background: "linear-gradient(to bottom, hsl(38, 55%, 62%), transparent)",
          }}
          animate={{ scaleY: [1, 0.25, 1], opacity: [0.9, 0.3, 0.9] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        />
      </motion.div>
    </section>
  );
}
