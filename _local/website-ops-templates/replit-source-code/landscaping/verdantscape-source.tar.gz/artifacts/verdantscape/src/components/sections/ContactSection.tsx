import { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const contactSchema = z.object({
  name: z.string().min(2, "Please enter your full name"),
  email: z.string().email("Please enter a valid email"),
  projectType: z.string().min(1, "Please select a project type"),
  message: z.string().min(20, "Please describe your project in a few sentences"),
});

type ContactForm = z.infer<typeof contactSchema>;

const projectTypes = [
  "Residential Estate",
  "Coastal Property",
  "Urban Terrace / Rooftop",
  "Commercial Grounds",
  "Restoration Project",
  "Other",
];

const inputStyle: React.CSSProperties = {
  backgroundColor: "hsl(20, 10%, 8%)",
  border: "1px solid rgba(255,255,255,0.1)",
  color: "hsl(35, 25%, 88%)",
  padding: "14px 16px",
  fontSize: "14px",
  width: "100%",
  outline: "none",
  transition: "border-color 0.3s",
};

const labelStyle: React.CSSProperties = {
  fontSize: "10px",
  textTransform: "uppercase",
  letterSpacing: "0.25em",
  color: "hsl(35, 12%, 55%)",
  marginBottom: "8px",
  display: "block",
};

export default function ContactSection() {
  const [submitted, setSubmitted] = useState(false);

  const form = useForm<ContactForm>({
    resolver: zodResolver(contactSchema),
    defaultValues: { name: "", email: "", projectType: "", message: "" },
  });

  const onSubmit = (_data: ContactForm) => {
    setSubmitted(true);
  };

  return (
    <section
      id="contact"
      className="section-padding px-6 lg:px-12"
      style={{ backgroundColor: "hsl(20, 10%, 5%)" }}
      data-testid="section-contact"
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          {/* Left: copy */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="gold-line" />
            <span className="text-xs uppercase tracking-[0.3em] mb-4 block" style={{ color: "hsl(38, 55%, 62%)" }}>
              Begin Here
            </span>
            <h2
              className="font-serif font-light leading-tight mb-8"
              style={{ fontSize: "clamp(2.2rem, 5vw, 4rem)", color: "hsl(35, 25%, 88%)" }}
              data-testid="heading-contact"
            >
              Your Garden<br />Begins With<br />a Conversation
            </h2>
            <p className="text-base leading-relaxed mb-12" style={{ color: "hsl(35, 12%, 55%)" }}>
              We take on a limited number of projects each year so we can give each one our full attention. If you're considering something extraordinary, reach out. Every remarkable garden started with a single conversation.
            </p>

            {/* Details */}
            <div className="space-y-8">
              {[
                { label: "Studio Address", value: "1248 Jackson Street, Suite 400\nSan Francisco, CA 94109" },
                { label: "Phone", value: "+1 (415) 555-0180" },
                { label: "Email", value: "studio@verdantscape.com" },
                { label: "Studio Hours", value: "Monday – Friday, 9am – 6pm PST" },
              ].map((item, i) => (
                <div key={i} data-testid={`contact-detail-${i}`}>
                  <span className="text-xs uppercase tracking-[0.25em] block mb-1.5" style={{ color: "hsl(38, 55%, 62%)" }}>
                    {item.label}
                  </span>
                  <p className="text-sm whitespace-pre-line" style={{ color: "hsl(35, 25%, 70%)" }}>
                    {item.value}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Right: form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.8, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
          >
            {submitted ? (
              <motion.div
                className="h-full flex flex-col items-center justify-center text-center py-20"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
              >
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center mb-8"
                  style={{ backgroundColor: "hsl(145, 35%, 14%)", border: "1px solid hsl(145, 35%, 25%)" }}
                >
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="hsl(38, 55%, 62%)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <h3 className="font-serif font-light text-3xl mb-4" style={{ color: "hsl(35, 25%, 88%)" }}>
                  Thank You
                </h3>
                <p className="text-sm leading-relaxed max-w-xs" style={{ color: "hsl(35, 12%, 55%)" }}>
                  Your inquiry has been received. A member of our studio team will be in touch within two business days.
                </p>
              </motion.div>
            ) : (
              <div
                className="p-10"
                style={{ backgroundColor: "hsl(20, 10%, 7%)", border: "1px solid rgba(255,255,255,0.07)" }}
              >
                <h3 className="font-serif font-light text-2xl mb-8" style={{ color: "hsl(35, 25%, 88%)" }}>
                  Request a Consultation
                </h3>

                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6" data-testid="form-contact">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel style={labelStyle}>Full Name</FormLabel>
                          <FormControl>
                            <input
                              {...field}
                              style={inputStyle}
                              placeholder="Your full name"
                              onFocus={(e) => (e.currentTarget.style.borderColor = "hsl(38, 55%, 62%)")}
                              onBlur={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
                              data-testid="input-name"
                            />
                          </FormControl>
                          <FormMessage className="text-xs" style={{ color: "hsl(0, 62%, 55%)" }} />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel style={labelStyle}>Email Address</FormLabel>
                          <FormControl>
                            <input
                              {...field}
                              type="email"
                              style={inputStyle}
                              placeholder="your@email.com"
                              onFocus={(e) => (e.currentTarget.style.borderColor = "hsl(38, 55%, 62%)")}
                              onBlur={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
                              data-testid="input-email"
                            />
                          </FormControl>
                          <FormMessage className="text-xs" style={{ color: "hsl(0, 62%, 55%)" }} />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="projectType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel style={labelStyle}>Project Type</FormLabel>
                          <FormControl>
                            <select
                              {...field}
                              style={{ ...inputStyle, appearance: "none" as const, cursor: "pointer" }}
                              onFocus={(e) => (e.currentTarget.style.borderColor = "hsl(38, 55%, 62%)")}
                              onBlur={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
                              data-testid="select-project-type"
                            >
                              <option value="" disabled style={{ backgroundColor: "hsl(20, 10%, 8%)" }}>
                                Select project type
                              </option>
                              {projectTypes.map((pt) => (
                                <option key={pt} value={pt} style={{ backgroundColor: "hsl(20, 10%, 8%)" }}>
                                  {pt}
                                </option>
                              ))}
                            </select>
                          </FormControl>
                          <FormMessage className="text-xs" style={{ color: "hsl(0, 62%, 55%)" }} />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel style={labelStyle}>Tell Us About Your Project</FormLabel>
                          <FormControl>
                            <textarea
                              {...field}
                              rows={5}
                              style={{ ...inputStyle, resize: "vertical" }}
                              placeholder="Describe your vision, the property, and any particular aspirations..."
                              onFocus={(e) => (e.currentTarget.style.borderColor = "hsl(38, 55%, 62%)")}
                              onBlur={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
                              data-testid="textarea-message"
                            />
                          </FormControl>
                          <FormMessage className="text-xs" style={{ color: "hsl(0, 62%, 55%)" }} />
                        </FormItem>
                      )}
                    />

                    <motion.button
                      type="submit"
                      className="w-full py-4 text-xs uppercase tracking-[0.25em] font-medium cursor-pointer transition-all duration-300"
                      style={{ backgroundColor: "hsl(38, 55%, 62%)", color: "hsl(20, 10%, 5%)", border: "none" }}
                      whileHover={{ backgroundColor: "hsl(38, 55%, 70%)" }}
                      whileTap={{ scale: 0.99 }}
                      data-testid="button-submit-contact"
                    >
                      Send Inquiry
                    </motion.button>

                    <p className="text-xs text-center" style={{ color: "hsl(35, 10%, 40%)" }}>
                      We respond within two business days. All inquiries are confidential.
                    </p>
                  </form>
                </Form>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
