import { useRef } from "react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";

const steps = [
  {
    number: "01",
    title: "Consult",
    subtitle: "Deep Listening",
    description:
      "We begin not with sketches but with conversation. Understanding your life, your aspirations, and the unique character of your land is the foundation of everything we create.",
  },
  {
    number: "02",
    title: "Design",
    subtitle: "Visionary Planning",
    description:
      "Our design team translates insight into intention — detailed master plans, material palettes, and planting schemes that balance beauty with ecological intelligence.",
  },
  {
    number: "03",
    title: "Build",
    subtitle: "Masterful Execution",
    description:
      "Our craftsmen work with the precision of artisans. Every stone is placed, every plant positioned, every system installed with meticulous attention to the design vision.",
  },
  {
    number: "04",
    title: "Maintain",
    subtitle: "Enduring Care",
    description:
      "A living landscape requires expert stewardship. Our ongoing care programs ensure your environment flourishes through every season, growing more beautiful with each year.",
  },
];

function StepCard({ step, index }: { step: typeof steps[0]; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });

  return (
    <motion.div
      ref={ref}
      className="relative flex flex-col"
      initial={{ opacity: 0, y: 50 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.8, delay: index * 0.15, ease: [0.22, 1, 0.36, 1] }}
      data-testid={`card-process-${index}`}
    >
      {/* Step number */}
      <div className="mb-8 relative">
        <span
          className="font-serif"
          style={{
            fontSize: "5rem",
            lineHeight: 1,
            color: "rgba(255,255,255,0.04)",
            userSelect: "none",
            position: "absolute",
            top: "-1.5rem",
            left: "-0.5rem",
          }}
        >
          {step.number}
        </span>
        <div
          className="w-14 h-14 rounded-full flex items-center justify-center relative z-10"
          style={{
            border: "1px solid hsl(38, 55%, 62%)",
            backgroundColor: "hsl(20, 10%, 5%)",
          }}
        >
          <span className="font-serif text-sm" style={{ color: "hsl(38, 55%, 62%)" }}>
            {step.number}
          </span>
        </div>
      </div>

      {/* Connecting line (not last) */}
      {index < steps.length - 1 && (
        <div
          className="hidden lg:block absolute top-7 left-14 right-0"
          style={{ height: "1px", background: "linear-gradient(to right, hsl(38, 55%, 40%), transparent)" }}
        />
      )}

      <span className="text-xs uppercase tracking-[0.25em] mb-2 block" style={{ color: "hsl(38, 55%, 62%)" }}>
        {step.subtitle}
      </span>
      <h3
        className="font-serif font-light text-3xl mb-5"
        style={{ color: "hsl(35, 25%, 88%)" }}
      >
        {step.title}
      </h3>
      <p className="text-sm leading-relaxed" style={{ color: "hsl(35, 12%, 52%)" }}>
        {step.description}
      </p>
    </motion.div>
  );
}

export default function ProcessSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ["start end", "end start"] });
  const lineWidth = useTransform(scrollYProgress, [0.1, 0.7], ["0%", "100%"]);

  return (
    <section
      id="process"
      ref={sectionRef}
      className="section-padding px-6 lg:px-12 relative overflow-hidden"
      style={{ backgroundColor: "hsl(20, 10%, 5%)" }}
      data-testid="section-process"
    >
      {/* Background texture */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: "radial-gradient(ellipse at 80% 50%, hsl(145, 35%, 10%) 0%, transparent 60%)",
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          className="mb-24 max-w-xl"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8 }}
        >
          <div className="gold-line" />
          <span className="text-xs uppercase tracking-[0.3em] mb-4 block" style={{ color: "hsl(38, 55%, 62%)" }}>
            Our Approach
          </span>
          <h2
            className="font-serif font-light leading-tight"
            style={{ fontSize: "clamp(2.2rem, 5vw, 4rem)", color: "hsl(35, 25%, 88%)" }}
            data-testid="heading-process"
          >
            A Process as Refined<br />as the Result
          </h2>
        </motion.div>

        {/* Animated timeline bar */}
        <div className="mb-16 relative h-px" style={{ backgroundColor: "rgba(255,255,255,0.06)" }}>
          <motion.div
            className="absolute inset-y-0 left-0 h-full"
            style={{ width: lineWidth, backgroundColor: "hsl(38, 55%, 62%)" }}
          />
        </div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {steps.map((step, i) => (
            <StepCard key={i} step={step} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
