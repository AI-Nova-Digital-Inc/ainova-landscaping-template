import Navbar from "@/components/Navbar";
import HeroSection from "@/components/sections/HeroSection";
import ServicesSection from "@/components/sections/ServicesSection";
import PortfolioSection from "@/components/sections/PortfolioSection";
import ProcessSection from "@/components/sections/ProcessSection";
import MaterialsSection from "@/components/sections/MaterialsSection";
import TestimonialsSection from "@/components/sections/TestimonialsSection";
import ContactSection from "@/components/sections/ContactSection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="bg-charcoal min-h-screen" style={{ backgroundColor: "hsl(20, 10%, 5%)" }}>
      <Navbar />
      <HeroSection />
      <ServicesSection />
      <PortfolioSection />
      <ProcessSection />
      <MaterialsSection />
      <TestimonialsSection />
      <ContactSection />
      <Footer />
    </div>
  );
}
