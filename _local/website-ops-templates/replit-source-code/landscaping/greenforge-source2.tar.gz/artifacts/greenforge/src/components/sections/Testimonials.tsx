import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const reviews = [
  {
    name: "Sarah Jenkins",
    location: "Waterloo, ON",
    text: "GreenForge completely transformed our overgrown backyard into an oasis. The crew was incredibly professional, always on time, and left the site spotless every evening.",
  },
  {
    name: "Michael Chen",
    location: "Kitchener, ON",
    text: "We hired them for a new interlocking patio and fresh sod. The attention to detail is unmatched. It looks even better than the 3D design they showed us.",
  },
  {
    name: "Emily Robinson",
    location: "Guelph, ON",
    text: "Honest pricing and fantastic work. I've recommended them to three of my neighbors already. Best landscaping company in the region.",
  },
  {
    name: "David & Lisa Thompson",
    location: "Cambridge, ON",
    text: "They handled our seasonal cleanup and mulching. Fast, efficient, and reasonably priced. Our garden beds have never looked this sharp.",
  },
];

export function Testimonials() {
  return (
    <section id="reviews" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-serif font-bold mb-4">What Our Neighbors Say</h2>
          <p className="text-lg text-muted-foreground">Don't just take our word for it.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {reviews.map((review, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-card p-8 rounded-2xl shadow-sm border relative"
            >
              <Quote className="absolute top-6 right-6 w-12 h-12 text-muted/50" />
              <div className="flex items-center gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                ))}
              </div>
              <p className="text-lg mb-6 relative z-10">"{review.text}"</p>
              <div>
                <p className="font-bold text-foreground">{review.name}</p>
                <p className="text-sm text-muted-foreground">{review.location}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}