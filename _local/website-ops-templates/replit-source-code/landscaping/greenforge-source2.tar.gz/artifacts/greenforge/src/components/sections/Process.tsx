import { motion } from "framer-motion";

const steps = [
  { title: "Request Estimate", desc: "Contact us via form or phone to kick things off." },
  { title: "On-Site Consultation", desc: "We visit your property to measure and discuss options." },
  { title: "Custom Plan", desc: "You receive a detailed plan and transparent pricing." },
  { title: "Professional Installation", desc: "Our crew executes the work cleanly and efficiently." },
  { title: "Final Walkthrough", desc: "We ensure you are 100% happy with the result." },
];

export function Process() {
  return (
    <section className="py-24 bg-background overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-serif font-bold mb-4">How It Works</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A simple, stress-free process from your first call to the final reveal.
          </p>
        </div>

        <div className="relative">
          {/* Desktop Line */}
          <div className="hidden md:block absolute top-1/2 left-[10%] right-[10%] h-1 bg-border -translate-y-1/2" />
          {/* Mobile Line */}
          <div className="block md:hidden absolute top-[5%] bottom-[5%] left-8 w-1 bg-border" />

          <div className="flex flex-col md:flex-row justify-between gap-8 md:gap-4 relative z-10">
            {steps.map((step, index) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
                className="flex md:flex-col items-center md:text-center gap-6 md:gap-4 flex-1"
              >
                <div className="relative">
                  <div className="w-16 h-16 rounded-full bg-card border-4 border-background flex items-center justify-center text-xl font-bold text-primary shadow-lg z-10">
                    {index + 1}
                  </div>
                  {/* Active Line Fill (visual effect only) */}
                  <div className="absolute inset-0 bg-primary/10 rounded-full scale-150 -z-10 animate-pulse" />
                </div>
                
                <div className="flex-1">
                  <h4 className="text-xl font-bold mb-2">{step.title}</h4>
                  <p className="text-sm text-muted-foreground">{step.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}