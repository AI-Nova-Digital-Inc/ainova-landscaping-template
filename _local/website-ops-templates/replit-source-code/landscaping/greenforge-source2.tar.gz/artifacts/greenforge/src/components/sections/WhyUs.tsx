import { useEffect, useState, useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Shield, Clock, Users, FileText, Gem, HeartHandshake } from "lucide-react";

function AnimatedCounter({ end, suffix = "", duration = 2 }: { end: number, suffix?: string, duration?: number }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const increment = end / (duration * 60);
      const timer = setInterval(() => {
        start += increment;
        if (start >= end) {
          setCount(end);
          clearInterval(timer);
        } else {
          setCount(Math.floor(start));
        }
      }, 1000 / 60);
      return () => clearInterval(timer);
    }
  }, [end, duration, isInView]);

  return (
    <span ref={ref} className="text-4xl md:text-5xl font-bold text-primary font-serif">
      {count}{suffix}
    </span>
  );
}

const points = [
  { icon: Shield, title: "Licensed & Insured", desc: "Full coverage for your peace of mind." },
  { icon: Clock, title: "Fast Response Times", desc: "We respect your time and communicate clearly." },
  { icon: Users, title: "Clean & Respectful Crews", desc: "We leave your property spotless." },
  { icon: FileText, title: "Transparent Estimates", desc: "No hidden fees, ever." },
  { icon: Gem, title: "High-Quality Materials", desc: "Sourced from the best local nurseries and suppliers." },
  { icon: HeartHandshake, title: "Satisfaction Focused", desc: "We aren't done until you love it." },
];

export function WhyUs() {
  return (
    <section id="why-us" className="py-24 bg-primary text-primary-foreground relative overflow-hidden">
      {/* Decorative background shape */}
      <div className="absolute -top-[20%] -right-[10%] w-[50%] h-[140%] bg-primary-foreground/5 rounded-full blur-3xl rotate-12" />
      
      <div className="container relative z-10 mx-auto px-4 md:px-6">
        <div className="flex flex-col lg:flex-row gap-16">
          <div className="lg:w-1/3">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-3xl md:text-5xl font-serif font-bold mb-6"
            >
              Why Homeowners Choose GreenForge
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-primary-foreground/80 text-lg mb-12"
            >
              We don't just mow lawns or lay stone — we build lasting relationships with our neighbors through hard work and reliability.
            </motion.p>
            
            <div className="grid grid-cols-2 gap-8">
              <motion.div initial={{ opacity: 0, scale: 0.8 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: 0.2 }}>
                <AnimatedCounter end={250} suffix="+" />
                <p className="mt-2 text-sm font-medium text-primary-foreground/80 uppercase tracking-wider">Yards Transformed</p>
              </motion.div>
              <motion.div initial={{ opacity: 0, scale: 0.8 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: 0.3 }}>
                <div className="text-4xl md:text-5xl font-bold font-serif">4.9/5</div>
                <p className="mt-2 text-sm font-medium text-primary-foreground/80 uppercase tracking-wider">Customer Rating</p>
              </motion.div>
              <motion.div initial={{ opacity: 0, scale: 0.8 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: 0.4 }}>
                <AnimatedCounter end={10} suffix="+" />
                <p className="mt-2 text-sm font-medium text-primary-foreground/80 uppercase tracking-wider">Years Experience</p>
              </motion.div>
              <motion.div initial={{ opacity: 0, scale: 0.8 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: 0.5 }}>
                <AnimatedCounter end={100} suffix="%" />
                <p className="mt-2 text-sm font-medium text-primary-foreground/80 uppercase tracking-wider">Free Estimates</p>
              </motion.div>
            </div>
          </div>
          
          <div className="lg:w-2/3 grid grid-cols-1 md:grid-cols-2 gap-6">
            {points.map((point, i) => (
              <motion.div
                key={point.title}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
                className="bg-white/10 backdrop-blur-sm border border-white/10 p-6 rounded-2xl hover:bg-white/20 transition-colors"
              >
                <div className="w-12 h-12 bg-secondary rounded-xl flex items-center justify-center mb-4 text-secondary-foreground">
                  <point.icon className="w-6 h-6" />
                </div>
                <h4 className="text-xl font-bold mb-2">{point.title}</h4>
                <p className="text-primary-foreground/80">{point.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}