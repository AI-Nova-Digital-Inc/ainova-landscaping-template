import { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { CheckCircle2, PhoneCall, CalendarCheck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  name: z.string().min(2, "Name is required"),
  phone: z.string().min(10, "Valid phone number required"),
  email: z.string().email("Invalid email address"),
  city: z.string().min(2, "City is required"),
  service: z.string().min(1, "Please select a service"),
  details: z.string().optional(),
  contactMethod: z.enum(["phone", "email"]),
});

export function Contact() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      phone: "",
      email: "",
      city: "",
      service: "",
      details: "",
      contactMethod: "phone",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      toast({
        title: "Estimate Request Sent!",
        description: "We'll be in touch within 24 hours.",
      });
      form.reset();
    }, 1000);
  }

  return (
    <section id="contact" className="py-24 bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col lg:flex-row gap-16 max-w-6xl mx-auto">
          
          {/* Form */}
          <motion.div 
            className="w-full lg:w-3/5"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="mb-8">
              <h2 className="text-3xl md:text-5xl font-serif font-bold mb-4">Ready To Upgrade Your Outdoor Space?</h2>
              <p className="text-lg text-muted-foreground">Fill out the form below and we'll reach out to schedule your free on-site consultation.</p>
            </div>

            <div className="bg-card p-6 md:p-8 rounded-2xl shadow-sm border">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name *</FormLabel>
                          <FormControl><Input placeholder="John Doe" {...field} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number *</FormLabel>
                          <FormControl><Input placeholder="(555) 123-4567" {...field} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address *</FormLabel>
                          <FormControl><Input placeholder="john@example.com" {...field} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Property City *</FormLabel>
                          <FormControl><Input placeholder="Waterloo, ON" {...field} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="service"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Primary Service Needed *</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a service" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="maintenance">Lawn Care & Maintenance</SelectItem>
                            <SelectItem value="hardscaping">Hardscaping & Patios</SelectItem>
                            <SelectItem value="garden">Garden Design & Planting</SelectItem>
                            <SelectItem value="sod">Sod Installation</SelectItem>
                            <SelectItem value="cleanup">Seasonal Cleanup</SelectItem>
                            <SelectItem value="other">Other / Full Project</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="details"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Project Details</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Tell us a bit about what you're looking for..." className="resize-none" rows={4} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="contactMethod"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel>Preferred Contact Method</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex flex-col space-y-1"
                          >
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl><RadioGroupItem value="phone" /></FormControl>
                              <FormLabel className="font-normal">Phone Call</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl><RadioGroupItem value="email" /></FormControl>
                              <FormLabel className="font-normal">Email</FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" size="lg" className="w-full text-lg h-14" disabled={isSubmitting}>
                    {isSubmitting ? "Sending..." : "Request My Free Estimate"}
                  </Button>
                </form>
              </Form>
            </div>
          </motion.div>

          {/* Trust Panel */}
          <motion.div 
            className="w-full lg:w-2/5"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="bg-primary text-primary-foreground p-8 rounded-2xl sticky top-24">
              <h3 className="text-2xl font-serif font-bold mb-8">What Happens Next?</h3>
              
              <div className="space-y-8">
                <div className="flex gap-4">
                  <div className="mt-1"><PhoneCall className="w-6 h-6 text-secondary" /></div>
                  <div>
                    <h4 className="text-lg font-bold mb-1">Fast Response</h4>
                    <p className="text-primary-foreground/80 text-sm">We'll contact you within 24 business hours to discuss your needs.</p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="mt-1"><CalendarCheck className="w-6 h-6 text-secondary" /></div>
                  <div>
                    <h4 className="text-lg font-bold mb-1">Free Consultation</h4>
                    <p className="text-primary-foreground/80 text-sm">We'll schedule a time to visit your property, take measurements, and hear your ideas.</p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="mt-1"><CheckCircle2 className="w-6 h-6 text-secondary" /></div>
                  <div>
                    <h4 className="text-lg font-bold mb-1">No-Pressure Estimate</h4>
                    <p className="text-primary-foreground/80 text-sm">You'll receive a detailed, transparent quote with no obligation to proceed.</p>
                  </div>
                </div>
              </div>

              <div className="mt-12 pt-8 border-t border-primary-foreground/20">
                <p className="text-sm text-primary-foreground/80 mb-2">Prefer to call?</p>
                <a href="tel:555-0123" className="text-3xl font-bold font-serif hover:text-secondary transition-colors">
                  (555) 123-4567
                </a>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}