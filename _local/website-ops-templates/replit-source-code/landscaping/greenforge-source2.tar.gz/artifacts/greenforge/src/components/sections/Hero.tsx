import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Star, ShieldCheck, MapPin, CheckCircle2 } from "lucide-react";
import heroImg from "@/assets/hero.png";

const LeafParticles = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-10">
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-3 h-3 bg-secondary/30 rounded-full blur-[1px]"
          style={{
            borderRadius: "100% 0 100% 0",
            left: `${Math.random() * 100}%`,
            top: `-5%`,
          }}
          animate={{
            y: ["0vh", "110vh"],
            x: [0, Math.random() * 100 - 50, Math.random() * 100 - 50],
            rotate: [0, 360 * (Math.random() > 0.5 ? 1 : -1)],
          }}
          transition={{
            duration: 10 + Math.random() * 15,
            repeat: Infinity,
            ease: "linear",
            delay: Math.random() * 10,
          }}
        />
      ))}
    </div>
  );
};

export function Hero() {
  return (
    <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden bg-primary pb-20 md:pb-0">
      {/* Background Image with Slow Zoom */}
      <motion.div
        className="absolute inset-0 z-0"
        initial={{ scale: 1 }}
        animate={{ scale: 1.1 }}
        transition={{ duration: 20, repeat: Infinity, repeatType: "reverse", ease: "linear" }}
      >
        <div className="absolute inset-0 bg-black/40 z-10" />
        <img
          src={heroImg}
          alt="Beautifully manicured backyard landscaping"
          className="w-full h-full object-cover object-center"
        />
      </motion.div>

      <LeafParticles />

      <div className="container relative z-20 px-4 md:px-6 mt-20">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <span className="inline-block py-1 px-3 rounded-full bg-white/20 backdrop-blur-md text-white border border-white/30 text-sm font-medium mb-6">
              Award-Winning Local Landscapers
            </span>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-white leading-tight mb-6 drop-shadow-lg">
              Transform Your Yard Into a <span className="text-secondary-foreground italic">Space You Love</span>
            </h1>
            <p className="text-lg md:text-xl text-white/90 mb-10 max-w-2xl mx-auto drop-shadow-md">
              Professional landscaping, lawn care, and outdoor transformations designed to make your home look its best.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12"
          >
            <Button size="lg" className="w-full sm:w-auto text-lg h-14 px-8" asChild>
              <a href="#contact">Get Free Estimate</a>
            </Button>
            <Button size="lg" variant="outline" className="w-full sm:w-auto text-lg h-14 px-8 bg-white/10 text-white hover:bg-white hover:text-primary border-white/30 backdrop-blur-sm" asChild>
              <a href="#projects">View Our Work</a>
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.6 }}
            className="flex flex-wrap justify-center gap-6 md:gap-12 text-white/90 text-sm font-medium"
          >
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-secondary" />
              <span>Licensed & Insured</span>
            </div>
            <div className="flex items-center gap-2">
              <Star className="w-5 h-5 text-secondary fill-secondary" />
              <span>5-Star Rated</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-secondary" />
              <span>Free Estimates</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-secondary" />
              <span>Local Experts</span>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Floating Review Card */}
      <motion.div
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.8, delay: 1 }}
        className="absolute bottom-32 md:bottom-12 right-4 md:right-12 z-20 bg-white p-4 rounded-xl shadow-xl max-w-[240px] hidden md:block"
      >
        <div className="flex items-center gap-1 mb-2">
          {[...Array(5)].map((_, i) => (
            <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
          ))}
        </div>
        <p className="text-sm font-medium text-foreground mb-1">"Trusted by local homeowners"</p>
        <p className="text-xs text-muted-foreground">4.9/5 average rating based on 150+ reviews</p>
      </motion.div>
    </section>
  );
}