import { motion } from "framer-motion";
import { Leaf, Shovel, Trees, Scissors, SunMedium, PaintBucket } from "lucide-react";

const services = [
  {
    icon: Leaf,
    title: "Lawn Care & Maintenance",
    description: "Keep your grass lush, green, and healthy with our weekly mowing, fertilizing, and aeration services.",
  },
  {
    icon: PaintBucket,
    title: "Garden Design",
    description: "Custom garden layouts tailored to your property, featuring native plants and seasonal colors.",
  },
  {
    icon: Shovel,
    title: "Hardscaping & Interlocking",
    description: "Beautiful stone patios, walkways, and retaining walls built to last through harsh winters.",
  },
  {
    icon: Trees,
    title: "Mulch, Sod & Planting",
    description: "Instant green lawns with fresh sod, premium mulching, and professional tree planting.",
  },
  {
    icon: Scissors,
    title: "Seasonal Cleanup",
    description: "Spring preparation and fall leaf removal to keep your property pristine year-round.",
  },
  {
    icon: SunMedium,
    title: "Outdoor Lighting",
    description: "Illuminate your pathways and highlight architectural features with low-voltage landscape lighting.",
  },
];

export function Services() {
  return (
    <section id="services" className="py-24 bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-sm font-bold tracking-wider text-primary uppercase mb-3">Our Expertise</h2>
            <h3 className="text-3xl md:text-5xl font-serif font-bold text-foreground mb-6">
              Landscaping Services Built Around Your Home
            </h3>
            <p className="text-lg text-muted-foreground">
              From weekly maintenance to complete backyard transformations, our skilled team delivers exceptional results with meticulous attention to detail.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group bg-card p-8 rounded-2xl border hover:border-primary/50 hover:shadow-xl transition-all duration-300 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-secondary/10 rounded-bl-full -z-10 transition-transform group-hover:scale-110" />
              
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-6 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
                <service.icon className="w-7 h-7" />
              </div>
              
              <h4 className="text-xl font-bold mb-3 group-hover:text-primary transition-colors">{service.title}</h4>
              <p className="text-muted-foreground mb-6 line-clamp-3">
                {service.description}
              </p>
              
              <a href="#contact" className="inline-flex items-center text-sm font-semibold text-primary group-hover:underline">
                Learn More &rarr;
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}