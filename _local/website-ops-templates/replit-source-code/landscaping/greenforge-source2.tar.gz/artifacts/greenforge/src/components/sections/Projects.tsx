import { motion } from "framer-motion";
import { MapPin } from "lucide-react";
import project1 from "@/assets/project1.png";
import project2 from "@/assets/project2.png";
import project3 from "@/assets/project3.png";
import project4 from "@/assets/project4.png";

const projects = [
  {
    id: 1,
    title: "Modern Backyard Transformation",
    service: "Full Landscape & Hardscape",
    location: "Waterloo, ON",
    image: project1,
  },
  {
    id: 2,
    title: "Front Yard Garden Upgrade",
    service: "Garden Design & Planting",
    location: "Kitchener, ON",
    image: project2,
  },
  {
    id: 3,
    title: "Interlocking Patio Installation",
    service: "Hardscaping",
    location: "Cambridge, ON",
    image: project3,
  },
  {
    id: 4,
    title: "Fresh Sod & Lawn Restoration",
    service: "Lawn Care & Sod",
    location: "Guelph, ON",
    image: project4,
  },
];

export function Projects() {
  return (
    <section id="projects" className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="max-w-2xl"
          >
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-foreground mb-4">
              Recent Projects
            </h2>
            <p className="text-lg text-muted-foreground">
              Take a look at some of our favorite transformations. Every project is built with premium materials and expert craftsmanship.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {projects.map((project, i) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="group relative rounded-2xl overflow-hidden aspect-[4/3] cursor-pointer"
            >
              <img
                src={project.image}
                alt={project.title}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 transition-opacity duration-300" />
              
              <div className="absolute inset-0 p-6 md:p-8 flex flex-col justify-end transform transition-transform duration-300 translate-y-4 group-hover:translate-y-0">
                <div className="text-secondary font-medium text-sm mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100">
                  {project.service}
                </div>
                <h3 className="text-2xl md:text-3xl font-bold text-white mb-2">
                  {project.title}
                </h3>
                <div className="flex items-center gap-1 text-white/80 text-sm">
                  <MapPin className="w-4 h-4" />
                  {project.location}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}