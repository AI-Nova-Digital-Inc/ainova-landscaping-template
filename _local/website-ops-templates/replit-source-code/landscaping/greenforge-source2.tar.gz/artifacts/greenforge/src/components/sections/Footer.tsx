import { Leaf } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-foreground text-background py-16">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12 border-b border-white/10 pb-12">
          
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-6">
              <span className="text-2xl font-serif font-bold text-white">GreenForge</span>
            </div>
            <p className="text-white/60 mb-6">
              Premium residential landscaping and outdoor transformation services built on trust, quality, and craftsmanship.
            </p>
            <div className="flex gap-4">
              {/* Social icons placeholders */}
              <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-primary transition-colors cursor-pointer">
                <span className="font-bold text-sm">fb</span>
              </div>
              <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-primary transition-colors cursor-pointer">
                <span className="font-bold text-sm">ig</span>
              </div>
              <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-primary transition-colors cursor-pointer">
                <span className="font-bold text-sm">hz</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold text-white mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#services" className="text-white/60 hover:text-white transition-colors">Our Services</a></li>
              <li><a href="#projects" className="text-white/60 hover:text-white transition-colors">Project Gallery</a></li>
              <li><a href="#why-us" className="text-white/60 hover:text-white transition-colors">Why Choose Us</a></li>
              <li><a href="#reviews" className="text-white/60 hover:text-white transition-colors">Testimonials</a></li>
              <li><a href="#contact" className="text-white/60 hover:text-white transition-colors">Get an Estimate</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold text-white mb-6">Contact Us</h4>
            <ul className="space-y-3">
              <li className="text-white/60">123 Landscaping Way<br/>Waterloo, ON N2L 3G1</li>
              <li><a href="tel:555-0123" className="text-white/60 hover:text-white transition-colors font-medium">(555) 123-4567</a></li>
              <li><a href="mailto:hello@greenforge.com" className="text-white/60 hover:text-white transition-colors">hello@greenforge.com</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold text-white mb-6">Service Areas</h4>
            <ul className="space-y-2 text-white/60 grid grid-cols-2 gap-x-2">
              <li>Kitchener</li>
              <li>Waterloo</li>
              <li>Cambridge</li>
              <li>Guelph</li>
              <li>Milton</li>
              <li>Brantford</li>
              <li>Woodstock</li>
            </ul>
          </div>

        </div>

        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-white/40">
          <p>&copy; {new Date().getFullYear()} GreenForge Landscaping. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}