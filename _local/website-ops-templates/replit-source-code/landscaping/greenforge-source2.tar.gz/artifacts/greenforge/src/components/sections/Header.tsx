import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Menu, X, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Services", href: "#services" },
    { name: "Projects", href: "#projects" },
    { name: "Why Us", href: "#why-us" },
    { name: "Reviews", href: "#reviews" },
    { name: "Contact", href: "#contact" },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? "bg-white/90 backdrop-blur-md shadow-sm py-3"
            : "bg-transparent py-5"
        }`}
      >
        <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 z-50">
            <span className={`text-2xl font-serif font-bold tracking-tight ${isScrolled ? 'text-primary' : 'text-white'}`}>
              GreenForge
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            <div className="flex items-center gap-6">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className={`text-sm font-medium transition-colors hover:text-primary ${
                    isScrolled ? "text-foreground" : "text-white/90 hover:text-white"
                  }`}
                >
                  {link.name}
                </a>
              ))}
            </div>
            <div className="flex items-center gap-4">
              <a
                href="tel:555-0123"
                className={`flex items-center gap-2 text-sm font-semibold transition-colors ${
                  isScrolled ? "text-foreground hover:text-primary" : "text-white hover:text-primary-foreground"
                }`}
              >
                <Phone className="w-4 h-4" />
                (555) 123-4567
              </a>
              <Button asChild variant={isScrolled ? "default" : "secondary"}>
                <a href="#contact">Get Free Estimate</a>
              </Button>
            </div>
          </nav>

          {/* Mobile Menu Toggle */}
          <button
            className={`md:hidden z-50 p-2 -mr-2 ${isScrolled || isMobileMenuOpen ? 'text-foreground' : 'text-white'}`}
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Nav Overlay */}
        <div
          className={`fixed inset-0 bg-white z-40 transition-transform duration-300 ease-in-out ${
            isMobileMenuOpen ? "translate-x-0" : "translate-x-full"
          } md:hidden flex flex-col pt-24 px-6`}
        >
          <div className="flex flex-col gap-6">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-2xl font-serif font-medium text-foreground"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.name}
              </a>
            ))}
          </div>
          <div className="mt-12 flex flex-col gap-4">
            <a
              href="tel:555-0123"
              className="flex items-center justify-center gap-2 py-4 rounded-lg bg-muted text-foreground font-semibold"
            >
              <Phone className="w-5 h-5" />
              (555) 123-4567
            </a>
            <Button size="lg" className="w-full text-lg" asChild>
              <a href="#contact" onClick={() => setIsMobileMenuOpen(false)}>Get Free Estimate</a>
            </Button>
          </div>
        </div>
      </header>

      {/* Sticky Mobile Bottom Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t z-40 md:hidden flex gap-3 shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
        <Button variant="outline" className="flex-1" asChild>
          <a href="tel:555-0123">Call Now</a>
        </Button>
        <Button className="flex-1" asChild>
          <a href="#contact">Get Quote</a>
        </Button>
      </div>
    </>
  );
}