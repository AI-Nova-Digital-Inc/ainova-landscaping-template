import { motion } from "framer-motion";
import { MapPin } from "lucide-react";

const cities = ["Kitchener", "Waterloo", "Cambridge", "Guelph", "Milton", "Brantford", "Woodstock"];

export function ServiceAreas() {
  return (
    <section className="py-16 bg-white border-y">
      <div className="container mx-auto px-4 md:px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <div className="flex justify-center mb-6">
            <MapPin className="w-8 h-8 text-primary" />
          </div>
          <p className="text-xl md:text-2xl font-serif font-bold mb-8 max-w-3xl mx-auto">
            Proudly serving homeowners across the region with reliable landscaping and outdoor maintenance services.
          </p>
          <div className="flex flex-wrap justify-center gap-3 md:gap-4">
            {cities.map((city, i) => (
              <span 
                key={city}
                className="px-4 py-2 bg-muted text-foreground rounded-full text-sm font-medium"
              >
                {city}
              </span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}