import { useEffect, useRef } from "react";

export function NeuralOrb({ mouseX = 0, mouseY = 0 }: { mouseX?: number; mouseY?: number }) {
  const orbRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!orbRef.current) return;
    orbRef.current.style.transform = `rotateX(${mouseY * 15}deg) rotateY(${mouseX * 15}deg)`;
  }, [mouseX, mouseY]);

  return (
    <div className="w-full h-full flex items-center justify-center" style={{ perspective: "800px" }}>
      <div
        ref={orbRef}
        className="relative w-80 h-80 transition-transform duration-200"
        style={{ transformStyle: "preserve-3d" }}
      >
        {/* Outer glow ring */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background: "radial-gradient(circle, rgba(0,240,255,0.08) 0%, rgba(0,240,255,0.02) 60%, transparent 80%)",
            animation: "orbPulse 4s ease-in-out infinite",
          }}
        />

        {/* Rotating outer ring */}
        <div
          className="absolute inset-2 rounded-full border border-primary/20"
          style={{ animation: "orbSpin 12s linear infinite" }}
        >
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-primary shadow-[0_0_8px_rgba(0,240,255,0.8)]" />
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-1.5 h-1.5 rounded-full bg-primary/60" />
        </div>

        {/* Rotating middle ring */}
        <div
          className="absolute inset-8 rounded-full border border-secondary/30"
          style={{ animation: "orbSpinReverse 8s linear infinite" }}
        >
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-secondary shadow-[0_0_8px_rgba(176,85,255,0.8)]" />
          <div className="absolute right-0 top-1/2 translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-secondary/60" />
        </div>

        {/* Inner rotating ring */}
        <div
          className="absolute inset-16 rounded-full border border-accent/25"
          style={{ animation: "orbSpin 6s linear infinite" }}
        >
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-accent shadow-[0_0_6px_rgba(51,136,255,0.8)]" />
        </div>

        {/* Core sphere */}
        <div className="absolute inset-20 rounded-full flex items-center justify-center"
          style={{
            background: "radial-gradient(circle at 35% 35%, rgba(0,240,255,0.25), rgba(176,85,255,0.15), rgba(5,7,13,0.9))",
            boxShadow: "0 0 40px rgba(0,240,255,0.15), inset 0 0 30px rgba(0,240,255,0.05)",
            animation: "coreBreath 4s ease-in-out infinite",
          }}
        />

        {/* Floating particles */}
        {Array.from({ length: 12 }).map((_, i) => {
          const angle = (i / 12) * Math.PI * 2;
          const r = 120 + Math.sin(i * 1.3) * 30;
          const x = 50 + Math.cos(angle) * (r / 3.2);
          const y = 50 + Math.sin(angle) * (r / 3.2);
          return (
            <div
              key={i}
              className="absolute w-1 h-1 rounded-full"
              style={{
                left: `${x}%`,
                top: `${y}%`,
                background: i % 3 === 0 ? "rgba(0,240,255,0.8)" : i % 3 === 1 ? "rgba(176,85,255,0.7)" : "rgba(51,136,255,0.7)",
                boxShadow: `0 0 6px currentColor`,
                animation: `particleFloat ${3 + (i % 4)}s ease-in-out infinite`,
                animationDelay: `${i * 0.3}s`,
              }}
            />
          );
        })}

        {/* Connection lines SVG */}
        <svg className="absolute inset-0 w-full h-full opacity-20" viewBox="0 0 320 320">
          {[
            [60, 60, 260, 260], [60, 260, 260, 60],
            [160, 20, 160, 300], [20, 160, 300, 160],
            [90, 30, 30, 90], [230, 30, 290, 90],
            [90, 290, 30, 230], [230, 290, 290, 230],
          ].map(([x1, y1, x2, y2], i) => (
            <line
              key={i}
              x1={x1} y1={y1} x2={x2} y2={y2}
              stroke={i % 2 === 0 ? "rgba(0,240,255,0.5)" : "rgba(176,85,255,0.4)"}
              strokeWidth="0.5"
            />
          ))}
        </svg>
      </div>

      <style>{`
        @keyframes orbSpin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes orbSpinReverse {
          from { transform: rotate(0deg); }
          to { transform: rotate(-360deg); }
        }
        @keyframes orbPulse {
          0%, 100% { opacity: 0.6; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.05); }
        }
        @keyframes coreBreath {
          0%, 100% { transform: scale(1); box-shadow: 0 0 40px rgba(0,240,255,0.15), inset 0 0 30px rgba(0,240,255,0.05); }
          50% { transform: scale(1.08); box-shadow: 0 0 60px rgba(0,240,255,0.25), inset 0 0 40px rgba(0,240,255,0.1); }
        }
        @keyframes particleFloat {
          0%, 100% { transform: translate(0, 0) scale(1); opacity: 0.7; }
          50% { transform: translate(0, -8px) scale(1.3); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
