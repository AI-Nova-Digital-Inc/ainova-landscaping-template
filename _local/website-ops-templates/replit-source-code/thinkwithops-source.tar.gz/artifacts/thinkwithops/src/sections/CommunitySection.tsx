import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Play, Users, ArrowRight, Linkedin, Github, Youtube } from "lucide-react";

const socials = [
  {
    icon: Linkedin,
    name: "LinkedIn",
    handle: "@thinkwithops",
    desc: "Professional insights, career tips, and AI + DevOps thought leadership.",
    color: "text-blue-400",
    border: "hover:border-blue-400/40",
    glow: "hover:shadow-[0_0_20px_rgba(59,130,246,0.2)]",
    bg: "bg-blue-500/10",
    cta: "Connect",
  },
  {
    icon: Github,
    name: "GitHub",
    handle: "@thinkwithops",
    desc: "All open-source projects, code, and infrastructure templates.",
    color: "text-foreground",
    border: "hover:border-white/20",
    glow: "hover:shadow-[0_0_20px_rgba(255,255,255,0.1)]",
    bg: "bg-white/5",
    cta: "Follow",
  },
  {
    icon: Youtube,
    name: "YouTube",
    handle: "ThinkWithOps",
    desc: "Weekly AI and DevOps tutorials, project breakdowns, and engineering deep-dives.",
    color: "text-red-400",
    border: "hover:border-red-400/40",
    glow: "hover:shadow-[0_0_20px_rgba(248,113,113,0.2)]",
    bg: "bg-red-500/10",
    cta: "Subscribe",
  },
];

export function CommunitySection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="community" ref={ref} className="py-24 relative">
      <div className="absolute right-0 top-0 w-80 h-80 bg-accent/4 blur-[120px] rounded-full pointer-events-none" />

      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-14"
        >
          <span className="text-primary text-sm font-semibold tracking-widest uppercase mb-4 block">Community</span>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Join the{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">journey</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Weekly content, open-source code, and a growing community of engineers building with AI and DevOps.
          </p>
        </motion.div>

        {/* YouTube Feature */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.15 }}
          className="mb-10 rounded-2xl bg-card border border-border overflow-hidden"
        >
          <div className="grid md:grid-cols-2 items-center">
            {/* Video placeholder */}
            <div className="relative h-64 md:h-80 bg-gradient-to-br from-red-900/20 to-red-700/5 flex items-center justify-center border-b md:border-b-0 md:border-r border-border">
              <div className="absolute inset-0 opacity-[0.05]" style={{
                backgroundImage: "linear-gradient(rgba(248,113,113,1) 1px, transparent 1px), linear-gradient(90deg, rgba(248,113,113,1) 1px, transparent 1px)",
                backgroundSize: "30px 30px"
              }} />
              <button
                className="w-16 h-16 rounded-full bg-red-500/20 border border-red-400/40 flex items-center justify-center hover:bg-red-500/30 transition-colors group"
                data-testid="btn-play-youtube"
              >
                <Play className="w-6 h-6 text-red-400 group-hover:scale-110 transition-transform ml-1" />
              </button>
            </div>
            {/* Channel info */}
            <div className="p-10">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                  <Youtube className="w-5 h-5 text-red-400" />
                </div>
                <div>
                  <div className="font-bold text-foreground">ThinkWithOps</div>
                  <div className="text-xs text-muted-foreground">YouTube Channel</div>
                </div>
              </div>
              <h3 className="text-2xl font-bold mb-3">Weekly AI + DevOps content</h3>
              <p className="text-muted-foreground text-sm mb-6 leading-relaxed">
                Project breakdowns, system design walkthroughs, and practical engineering content every week. No padding, no filler — just dense, useful stuff.
              </p>
              <div className="flex items-center gap-6 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-foreground">1K+</div>
                  <div className="text-xs text-muted-foreground">Subscribers</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-foreground">Weekly</div>
                  <div className="text-xs text-muted-foreground">Upload pace</div>
                </div>
              </div>
              <button
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-red-500/10 text-red-400 border border-red-400/20 hover:bg-red-500/20 transition-colors text-sm font-semibold"
                data-testid="btn-subscribe-youtube"
              >
                <Users className="w-4 h-4" /> Subscribe for Free
              </button>
            </div>
          </div>
        </motion.div>

        {/* Social links */}
        <div className="grid md:grid-cols-3 gap-5">
          {socials.map((social, i) => (
            <motion.div
              key={social.name}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.3 + i * 0.1 }}
              className={`group p-6 rounded-xl bg-card border border-border transition-all duration-300 cursor-pointer ${social.border} ${social.glow}`}
              data-testid={`social-${social.name.toLowerCase()}`}
            >
              <div className={`w-12 h-12 rounded-xl ${social.bg} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <social.icon className={`w-6 h-6 ${social.color}`} />
              </div>
              <div className="font-bold text-foreground mb-1">{social.name}</div>
              <div className={`text-sm ${social.color} mb-3`}>{social.handle}</div>
              <p className="text-sm text-muted-foreground mb-5 leading-relaxed">{social.desc}</p>
              <button className={`text-sm font-semibold ${social.color} flex items-center gap-1.5 hover:gap-2.5 transition-all`}>
                {social.cta} <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
