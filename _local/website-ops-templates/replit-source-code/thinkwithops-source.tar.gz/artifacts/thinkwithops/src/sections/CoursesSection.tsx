import { useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { Lock, GraduationCap, Rocket, Code2, Bell } from "lucide-react";

const courses = [
  {
    icon: GraduationCap,
    title: "AI for Beginners",
    description: "Foundation concepts, tools, and mental models every engineer needs to enter the AI space confidently.",
    level: "Beginner",
    levelColor: "text-primary bg-primary/10 border-primary/20",
    modules: "12 Modules",
  },
  {
    icon: Rocket,
    title: "DevOps to AI Engineer",
    description: "A structured career transition path for DevOps engineers ready to specialize in AI infrastructure.",
    level: "Intermediate",
    levelColor: "text-secondary bg-secondary/10 border-secondary/20",
    modules: "18 Modules",
  },
  {
    icon: Code2,
    title: "Real-World AI Projects",
    description: "Build 5 production-ready AI applications from scratch — each solving a genuine, marketable problem.",
    level: "Advanced",
    levelColor: "text-accent bg-accent/10 border-accent/20",
    modules: "24 Modules",
  },
];

export function CoursesSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleNotify = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) setSubmitted(true);
  };

  return (
    <section id="courses" ref={ref} className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute left-1/4 top-1/2 w-80 h-80 bg-primary/4 blur-[100px] rounded-full" />
        <div className="absolute right-1/4 bottom-1/4 w-60 h-60 bg-secondary/4 blur-[80px] rounded-full" />
      </div>

      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-14"
        >
          <span className="text-secondary text-sm font-semibold tracking-widest uppercase mb-4 block">Courses</span>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Coming Soon:{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary to-primary">
              Learn AI with ThinkWithOps
            </span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Structured courses built for engineers who learn by doing, not watching.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6 mb-14">
          {courses.map((course, i) => (
            <motion.div
              key={course.title}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.15 + i * 0.1 }}
              className="relative rounded-xl bg-card border border-border p-7 overflow-hidden"
              data-testid={`course-card-${course.title.toLowerCase().replace(/\s+/g, "-")}`}
            >
              {/* Locked overlay */}
              <div className="absolute top-4 right-4 flex items-center gap-1.5 text-xs text-muted-foreground bg-muted px-2.5 py-1 rounded-full">
                <Lock className="w-3 h-3" /> Coming Soon
              </div>

              {/* Blur overlay */}
              <div className="absolute inset-0 bg-background/30 backdrop-blur-[1px] pointer-events-none opacity-30" />

              <div className="relative">
                <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center mb-5">
                  <course.icon className="w-6 h-6 text-muted-foreground" />
                </div>

                <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${course.levelColor} mb-3 inline-block`}>
                  {course.level}
                </span>

                <h3 className="text-xl font-bold text-foreground mb-3">{course.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-5">{course.description}</p>

                <div className="text-xs text-muted-foreground">{course.modules} · Self-paced · Certificate</div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Notify CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.5 }}
          className="max-w-xl mx-auto text-center"
        >
          <div className="p-8 rounded-2xl bg-card border border-border relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-secondary/5 pointer-events-none" />
            <Bell className="w-8 h-8 text-primary mx-auto mb-3" />
            <h3 className="text-xl font-bold mb-2">Get notified when courses launch</h3>
            <p className="text-muted-foreground text-sm mb-6">Be first in line. No spam — just a single email when it's live.</p>
            {submitted ? (
              <div className="text-primary font-semibold py-3">You're on the list. We'll be in touch.</div>
            ) : (
              <form onSubmit={handleNotify} className="flex gap-3">
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  className="flex-1 px-4 py-3 rounded-lg bg-background border border-border text-sm focus:outline-none focus:border-primary/50 transition-colors"
                  required
                  data-testid="input-notify-email"
                />
                <button
                  type="submit"
                  className="px-5 py-3 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:shadow-[0_0_20px_rgba(0,240,255,0.4)] transition-all whitespace-nowrap"
                  data-testid="btn-notify-me"
                >
                  Notify Me
                </button>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
