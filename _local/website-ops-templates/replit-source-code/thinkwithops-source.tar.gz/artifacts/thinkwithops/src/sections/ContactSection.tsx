import { useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { Send, Briefcase, MessageCircle, Globe } from "lucide-react";

const collab = [
  { icon: Briefcase, label: "Project Consulting", desc: "AI and DevOps architecture consulting for startups and scale-ups." },
  { icon: Globe, label: "Content Partnerships", desc: "Co-create technical content for blogs, newsletters, and platforms." },
  { icon: MessageCircle, label: "Speaking & Advising", desc: "Available for tech talks, panels, and engineering team mentorship." },
];

export function ContactSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (form.name && form.email && form.message) setSent(true);
  };

  return (
    <section id="contact" ref={ref} className="py-24 relative">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute left-1/2 -translate-x-1/2 bottom-0 w-[600px] h-64 bg-primary/5 blur-[100px] rounded-full" />
      </div>

      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-14"
        >
          <span className="text-primary text-sm font-semibold tracking-widest uppercase mb-4 block">Contact</span>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Let's Build Something{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Smart</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Open to collaboration, consulting, and conversation. If you're building something with AI or DevOps at its core, let's talk.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Collaboration info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.15 }}
          >
            <h3 className="text-xl font-bold mb-7">Ways to collaborate</h3>
            <div className="space-y-5">
              {collab.map((c, i) => (
                <div key={c.label} className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <c.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <div className="font-semibold text-foreground mb-1">{c.label}</div>
                    <div className="text-sm text-muted-foreground">{c.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Contact form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.25 }}
          >
            {sent ? (
              <div className="p-10 rounded-2xl bg-card border border-primary/30 text-center">
                <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Send className="w-7 h-7 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">Message sent</h3>
                <p className="text-muted-foreground text-sm">Thanks for reaching out. I'll get back to you within 48 hours.</p>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="p-8 rounded-2xl bg-card border border-border space-y-5"
                data-testid="contact-form"
              >
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Name</label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                    placeholder="Your name"
                    className="w-full px-4 py-3 rounded-lg bg-background border border-border text-sm focus:outline-none focus:border-primary/50 transition-colors"
                    required
                    data-testid="input-contact-name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Email</label>
                  <input
                    type="email"
                    value={form.email}
                    onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                    placeholder="your@email.com"
                    className="w-full px-4 py-3 rounded-lg bg-background border border-border text-sm focus:outline-none focus:border-primary/50 transition-colors"
                    required
                    data-testid="input-contact-email"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Message</label>
                  <textarea
                    value={form.message}
                    onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                    placeholder="Tell me about your project or idea..."
                    rows={5}
                    className="w-full px-4 py-3 rounded-lg bg-background border border-border text-sm focus:outline-none focus:border-primary/50 transition-colors resize-none"
                    required
                    data-testid="input-contact-message"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-lg bg-primary text-primary-foreground font-semibold text-sm hover:shadow-[0_0_25px_rgba(0,240,255,0.5)] transition-all duration-300 flex items-center justify-center gap-2"
                  data-testid="btn-send-message"
                >
                  <Send className="w-4 h-4" /> Send Message
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
