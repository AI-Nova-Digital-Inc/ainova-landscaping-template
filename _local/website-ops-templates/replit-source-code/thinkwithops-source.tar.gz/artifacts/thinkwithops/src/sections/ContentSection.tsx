import { useRef } from "react";
import { motion, useInView } from "framer-motion";

const posts = [
  {
    title: "How AI + DevOps Will Merge",
    preview: "The convergence that will define the next decade of engineering. Platforms, pipelines, and intelligence are colliding — here's what it means for your career.",
    tag: "DevOps",
    tagColor: "text-accent",
    tagBg: "bg-accent/10 border-accent/20",
    readTime: "6 min read",
    gradient: "from-blue-500/20 to-indigo-500/10",
  },
  {
    title: "LLMOps Explained Simply",
    preview: "Making large language model operations accessible to every engineer. From prompt versioning to production monitoring — what you actually need to know.",
    tag: "MLOps",
    tagColor: "text-secondary",
    tagBg: "bg-secondary/10 border-secondary/20",
    readTime: "8 min read",
    gradient: "from-purple-500/20 to-violet-500/10",
  },
  {
    title: "Building Real AI Projects That Matter",
    preview: "Stop building toy projects. Here's a framework for identifying real problems, designing AI solutions, and shipping things people actually use.",
    tag: "AI",
    tagColor: "text-primary",
    tagBg: "bg-primary/10 border-primary/20",
    readTime: "5 min read",
    gradient: "from-cyan-500/20 to-teal-500/10",
  },
  {
    title: "Why Most People Learn AI Wrong",
    preview: "The approach most engineers take to learning AI is fundamentally backwards. Here's the mental model shift that changes everything about how fast you grow.",
    tag: "AI",
    tagColor: "text-primary",
    tagBg: "bg-primary/10 border-primary/20",
    readTime: "7 min read",
    gradient: "from-cyan-400/20 to-blue-600/10",
  },
];

export function ContentSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="content" ref={ref} className="py-24 relative">
      <div className="absolute right-0 bottom-0 w-80 h-80 bg-secondary/4 blur-[100px] rounded-full pointer-events-none" />

      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-14"
        >
          <span className="text-primary text-sm font-semibold tracking-widest uppercase mb-4 block">Content</span>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Latest{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Insights</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Deep-dives, frameworks, and perspectives on AI and DevOps engineering.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 gap-6">
          {posts.map((post, i) => (
            <motion.article
              key={post.title}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.1 + i * 0.1 }}
              className="group relative rounded-xl bg-card border border-border hover:border-opacity-60 transition-all duration-300 overflow-hidden cursor-pointer hover:shadow-lg"
              data-testid={`blog-card-${i}`}
            >
              {/* Top gradient bar */}
              <div className={`h-1.5 bg-gradient-to-r ${post.gradient}`} />

              <div className="p-7">
                <div className="flex items-center justify-between mb-5">
                  <span className={`text-xs font-semibold px-3 py-1 rounded-full border ${post.tagBg} ${post.tagColor}`}>
                    {post.tag}
                  </span>
                  <span className="text-xs text-muted-foreground">{post.readTime}</span>
                </div>

                <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors leading-snug">
                  {post.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-6">{post.preview}</p>

                <button
                  className="text-sm font-semibold text-primary hover:gap-2 flex items-center gap-1.5 transition-all"
                  data-testid={`btn-read-article-${i}`}
                >
                  Read Article <span className="group-hover:translate-x-1 transition-transform inline-block">→</span>
                </button>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
