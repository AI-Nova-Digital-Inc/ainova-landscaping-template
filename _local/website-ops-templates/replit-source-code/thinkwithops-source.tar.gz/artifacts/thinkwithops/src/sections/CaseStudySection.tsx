import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { AlertTriangle, Lightbulb, TrendingUp } from "lucide-react";

const tools = ["Python", "LangChain", "GPT-4", "FastAPI", "React", "Docker", "PostgreSQL", "Redis"];

const steps = [
  {
    icon: AlertTriangle,
    label: "Problem",
    title: "Architecture design is time-consuming and inconsistent",
    desc: "Engineers spend hours designing project structures, selecting tech stacks, and planning file organization — often inconsistently across teams.",
    color: "text-destructive",
    bg: "bg-destructive/10",
    border: "border-destructive/20",
  },
  {
    icon: Lightbulb,
    label: "Solution",
    title: "Multi-agent AI system for instant project scaffolding",
    desc: "Built a LangChain-powered multi-agent system where specialized agents handle requirements analysis, stack selection, and architecture generation in parallel.",
    color: "text-primary",
    bg: "bg-primary/10",
    border: "border-primary/20",
  },
  {
    icon: TrendingUp,
    label: "Impact",
    title: "90% reduction in project bootstrap time",
    desc: "Teams reduced project initialization from 4 hours to under 10 minutes. Generated architectures adopted as-is in 7 out of 10 cases.",
    color: "text-secondary",
    bg: "bg-secondary/10",
    border: "border-secondary/20",
  },
];

const lessons = [
  "Multi-agent orchestration outperforms single LLM calls for complex, multi-step tasks",
  "Prompt versioning is critical — small changes to system prompts have outsized quality effects",
  "Human-in-the-loop review gates significantly improve output adoption rates",
];

export function CaseStudySection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="case-study" ref={ref} className="py-24 relative">
      <div className="absolute left-0 top-1/3 w-64 h-64 bg-primary/5 blur-[100px] rounded-full pointer-events-none" />

      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-14"
        >
          <span className="text-primary text-sm font-semibold tracking-widest uppercase mb-4 block">Case Study</span>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            AI Project{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Generator</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            A deep-dive into building a multi-agent AI system for automated project architecture generation.
          </p>
        </motion.div>

        {/* Problem → Solution → Impact */}
        <div className="grid md:grid-cols-3 gap-6 mb-14">
          {steps.map((step, i) => (
            <motion.div
              key={step.label}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.15 + i * 0.12 }}
              className={`p-7 rounded-xl bg-card border ${step.border} relative overflow-hidden`}
              data-testid={`case-study-${step.label.toLowerCase()}`}
            >
              <div className={`w-10 h-10 rounded-lg ${step.bg} flex items-center justify-center mb-4`}>
                <step.icon className={`w-5 h-5 ${step.color}`} />
              </div>
              <div className={`text-xs font-bold uppercase tracking-widest ${step.color} mb-2`}>{step.label}</div>
              <h3 className="font-bold text-foreground mb-3 leading-snug">{step.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{step.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Architecture diagram */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.45 }}
          className="mb-14"
        >
          <h3 className="text-lg font-semibold mb-5">System Architecture</h3>
          <div className="p-8 rounded-xl bg-card border border-border relative overflow-hidden">
            <div className="absolute inset-0 opacity-[0.03]" style={{
              backgroundImage: "linear-gradient(rgba(0,240,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(0,240,255,1) 1px, transparent 1px)",
              backgroundSize: "30px 30px"
            }} />
            {/* Architecture nodes */}
            <div className="relative flex flex-col items-center gap-4">
              {/* Input */}
              <div className="px-6 py-3 rounded-lg bg-primary/10 border border-primary/30 text-sm font-medium text-primary">
                User Prompt Input
              </div>
              <div className="w-px h-6 bg-primary/30" />
              {/* Orchestrator */}
              <div className="px-6 py-3 rounded-lg bg-secondary/10 border border-secondary/30 text-sm font-medium text-secondary">
                LangChain Orchestrator Agent
              </div>
              <div className="w-px h-4 bg-border" />
              {/* Parallel agents */}
              <div className="flex gap-6 flex-wrap justify-center">
                {["Requirements Agent", "Stack Selector Agent", "Architecture Agent"].map(a => (
                  <div key={a} className="flex flex-col items-center gap-2">
                    <div className="w-px h-4 bg-border" />
                    <div className="px-4 py-2 rounded-lg bg-accent/10 border border-accent/20 text-xs font-medium text-accent">
                      {a}
                    </div>
                  </div>
                ))}
              </div>
              <div className="w-px h-4 bg-border" />
              {/* Output */}
              <div className="px-6 py-3 rounded-lg bg-card border border-border text-sm font-medium text-foreground">
                Generated Project Scaffold + Docs
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Tools */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.5 }}
          >
            <h3 className="text-lg font-semibold mb-4">Tools Used</h3>
            <div className="flex flex-wrap gap-2">
              {tools.map(t => (
                <span key={t} className="px-3 py-1.5 rounded-lg bg-card border border-border text-sm font-mono text-foreground">
                  {t}
                </span>
              ))}
            </div>
          </motion.div>

          {/* Lessons */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.55 }}
          >
            <h3 className="text-lg font-semibold mb-4">Lessons Learned</h3>
            <ul className="space-y-3">
              {lessons.map((l, i) => (
                <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                  <span className="text-primary font-bold mt-0.5">{i + 1}.</span>
                  {l}
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
