import { useState, useRef } from "react";
import { motion, useInView } from "framer-motion";
import { ExternalLink, BookOpen } from "lucide-react";

type Filter = "All" | "AI" | "DevOps" | "Automation" | "SaaS";

const filters: Filter[] = ["All", "AI", "DevOps", "Automation", "SaaS"];

const projects = [
  {
    title: "AI Project Generator",
    problem: "Automates full project architecture generation from a simple prompt.",
    stack: ["Python", "LangChain", "GPT-4", "FastAPI"],
    features: ["Multi-agent architecture design", "Auto-generates file structure", "Tech stack recommendations"],
    tags: ["AI", "Automation"] as Filter[],
    gradient: "from-cyan-500/20 to-blue-500/10",
    accent: "border-primary/30",
  },
  {
    title: "DevOps Command Center",
    problem: "Unified dashboard for monitoring and managing multi-cloud DevOps pipelines.",
    stack: ["React", "Kubernetes", "Grafana", "Prometheus"],
    features: ["Real-time pipeline visibility", "Multi-cluster K8s management", "Alert routing & escalation"],
    tags: ["DevOps"] as Filter[],
    gradient: "from-purple-500/20 to-indigo-500/10",
    accent: "border-secondary/30",
  },
  {
    title: "Local Business Lead Finder",
    problem: "AI-powered lead generation scraper for local businesses at scale.",
    stack: ["Python", "Playwright", "OpenAI", "PostgreSQL"],
    features: ["Geo-targeted scraping engine", "AI-powered lead scoring", "Automated outreach sequences"],
    tags: ["AI", "Automation"] as Filter[],
    gradient: "from-cyan-500/20 to-teal-500/10",
    accent: "border-primary/30",
  },
  {
    title: "CI/CD Pipeline Automation",
    problem: "End-to-end deployment pipeline eliminating manual release processes.",
    stack: ["GitHub Actions", "Terraform", "Docker", "ArgoCD"],
    features: ["Zero-downtime deployments", "Environment promotion gates", "Rollback-on-failure logic"],
    tags: ["DevOps", "Automation"] as Filter[],
    gradient: "from-blue-500/20 to-indigo-500/10",
    accent: "border-accent/30",
  },
  {
    title: "Kubernetes Deployment Platform",
    problem: "Simplified K8s cluster management platform for small-to-mid engineering teams.",
    stack: ["Kubernetes", "Helm", "ArgoCD", "Go"],
    features: ["One-click namespace provisioning", "Resource quota management", "Visual dependency graphs"],
    tags: ["DevOps"] as Filter[],
    gradient: "from-violet-500/20 to-purple-500/10",
    accent: "border-secondary/30",
  },
  {
    title: "AI Website Auditor",
    problem: "Automated site analysis that surfaces SEO, performance, and UX issues using AI.",
    stack: ["Puppeteer", "GPT-4", "Next.js", "Redis"],
    features: ["Lighthouse CI integration", "AI-powered fix suggestions", "Automated weekly reports"],
    tags: ["AI", "SaaS"] as Filter[],
    gradient: "from-cyan-500/20 to-blue-400/10",
    accent: "border-primary/30",
  },
  {
    title: "ToddlerTrip AI Planner",
    problem: "Family travel planning assistant that generates toddler-friendly itineraries.",
    stack: ["React", "OpenAI", "Maps API", "Supabase"],
    features: ["Age-appropriate activity filtering", "Real-time venue safety scores", "Offline-ready trip packs"],
    tags: ["AI", "SaaS"] as Filter[],
    gradient: "from-pink-500/15 to-purple-500/10",
    accent: "border-secondary/30",
  },
];

export function ProjectsSection() {
  const [activeFilter, setActiveFilter] = useState<Filter>("All");
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  const filtered = projects.filter(
    p => activeFilter === "All" || p.tags.includes(activeFilter)
  );

  return (
    <section id="projects" ref={ref} className="py-24 relative">
      <div className="absolute right-0 top-1/3 w-96 h-96 rounded-full bg-primary/4 blur-[120px] pointer-events-none" />

      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-14"
        >
          <span className="text-primary text-sm font-semibold tracking-widest uppercase mb-4 block">Projects</span>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Built to solve{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">real problems</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Every project here started with a genuine problem. Here's what got built.
          </p>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 0.2 }}
          className="flex flex-wrap justify-center gap-2 mb-12"
        >
          {filters.map(f => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-5 py-2 rounded-full text-sm font-medium border transition-all duration-200 ${
                activeFilter === f
                  ? "bg-primary text-primary-foreground border-primary shadow-[0_0_15px_rgba(0,240,255,0.4)]"
                  : "border-border text-muted-foreground hover:border-primary/40 hover:text-primary"
              }`}
              data-testid={`filter-${f.toLowerCase()}`}
            >
              {f}
            </button>
          ))}
        </motion.div>

        {/* Project Grid */}
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
          {filtered.map((project, i) => (
            <motion.div
              key={project.title}
              layout
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ delay: i * 0.07 }}
              className={`group relative rounded-xl bg-card border ${project.accent} hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col`}
              data-testid={`project-card-${project.title.toLowerCase().replace(/\s+/g, "-")}`}
            >
              {/* Gradient Header */}
              <div className={`h-36 bg-gradient-to-br ${project.gradient} relative overflow-hidden`}>
                <div className="absolute inset-0 opacity-30" style={{
                  backgroundImage: "linear-gradient(rgba(0,240,255,0.15) 1px, transparent 1px), linear-gradient(90deg, rgba(0,240,255,0.15) 1px, transparent 1px)",
                  backgroundSize: "20px 20px"
                }} />
                <div className="absolute bottom-3 left-4 flex gap-2 flex-wrap">
                  {project.tags.map(tag => (
                    <span key={tag} className="text-xs px-2 py-0.5 rounded-full bg-background/60 text-primary border border-primary/20 backdrop-blur-sm">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div className="p-6 flex flex-col flex-1">
                <h3 className="text-lg font-bold text-foreground mb-2">{project.title}</h3>
                <p className="text-sm text-muted-foreground mb-4">{project.problem}</p>

                {/* Stack */}
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {project.stack.map(s => (
                    <span key={s} className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground font-mono">
                      {s}
                    </span>
                  ))}
                </div>

                {/* Features */}
                <ul className="space-y-1.5 mb-6 flex-1">
                  {project.features.map(f => (
                    <li key={f} className="text-xs text-muted-foreground flex items-start gap-2">
                      <span className="text-primary mt-0.5">▹</span> {f}
                    </li>
                  ))}
                </ul>

                {/* CTAs */}
                <div className="flex gap-3 mt-auto">
                  <button
                    className="flex-1 text-xs py-2 rounded-lg border border-border hover:border-primary/40 hover:text-primary transition-colors flex items-center justify-center gap-1.5"
                    data-testid={`btn-case-study-${project.title.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    <BookOpen className="w-3.5 h-3.5" /> Case Study
                  </button>
                  <button
                    className="flex-1 text-xs py-2 rounded-lg bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground transition-colors flex items-center justify-center gap-1.5"
                    data-testid={`btn-demo-${project.title.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    <ExternalLink className="w-3.5 h-3.5" /> Live Demo
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
