import { useState, useEffect, useRef, Suspense, lazy } from "react";
import { motion } from "framer-motion";
import { ArrowRight, BookOpen, Users } from "lucide-react";

const NeuralOrb = lazy(() => import("@/components/three/NeuralOrb").then(m => ({ default: m.NeuralOrb })));

const metrics = [
  { value: "12+", label: "Projects Built" },
  { value: "3+", label: "Years DevOps Exp" },
  { value: "8+", label: "AI Systems" },
  { value: "Weekly", label: "Content" },
];

function AnimatedGridBg() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0,240,255,1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,240,255,1) 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-primary/5 blur-[120px]" />
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] rounded-full bg-secondary/5 blur-[100px]" />
    </div>
  );
}

export function HeroSection() {
  const [mouseX, setMouseX] = useState(0);
  const [mouseY, setMouseY] = useState(0);
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth - 0.5) * 2;
      const y = (e.clientY / window.innerHeight - 0.5) * 2;
      setMouseX(x);
      setMouseY(y);
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <section
      ref={ref}
      id="hero"
      className="relative min-h-screen flex items-center pt-20 overflow-hidden"
    >
      <AnimatedGridBg />

      <div className="container mx-auto px-6 py-20 grid lg:grid-cols-2 gap-12 items-center">
        {/* Left Content */}
        <div className="relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-primary/20 bg-primary/5 text-primary text-xs font-medium mb-8"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            AI + DevOps Engineering Platform
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-5xl md:text-6xl xl:text-7xl font-bold leading-[1.05] tracking-tight mb-6"
          >
            Think With{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">AI.</span>
            <br />
            Build With{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary to-primary">Ops.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
            className="text-lg text-muted-foreground leading-relaxed mb-10 max-w-xl"
          >
            Exploring AI, DevOps, MLOps, and LLM systems through real-world projects, systems thinking, and practical learning.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45 }}
            className="flex flex-wrap gap-3 mb-16"
          >
            <a
              href="#projects"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-primary text-primary-foreground font-semibold text-sm hover:shadow-[0_0_30px_rgba(0,240,255,0.5)] transition-all duration-300 hover:scale-105"
              data-testid="btn-explore-projects"
            >
              Explore Projects <ArrowRight className="w-4 h-4" />
            </a>
            <a
              href="#learn"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg border border-border hover:border-primary/40 text-foreground font-semibold text-sm transition-all duration-300 hover:bg-primary/5"
              data-testid="btn-learn-ai"
            >
              <BookOpen className="w-4 h-4" /> Learn AI
            </a>
            <a
              href="#community"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg text-muted-foreground hover:text-primary font-semibold text-sm transition-all duration-300"
              data-testid="btn-follow-journey"
            >
              <Users className="w-4 h-4" /> Follow Journey
            </a>
          </motion.div>

          {/* Metrics */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="grid grid-cols-2 sm:grid-cols-4 gap-6"
          >
            {metrics.map((m, i) => (
              <motion.div
                key={m.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.65 + i * 0.08 }}
                className="text-center"
                data-testid={`metric-${m.label.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <div className="text-3xl font-bold text-primary mb-1">{m.value}</div>
                <div className="text-xs text-muted-foreground">{m.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Right: 3D Orb */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="relative h-[480px] lg:h-[600px] hidden md:block"
        >
          <div className="absolute inset-0">
            <Suspense fallback={
              <div className="w-full h-full flex items-center justify-center">
                <div className="w-48 h-48 rounded-full border border-primary/20 animate-pulse" />
              </div>
            }>
              <NeuralOrb mouseX={mouseX} mouseY={mouseY} />
            </Suspense>
          </div>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-64 h-64 rounded-full bg-primary/5 blur-[80px]" />
          </div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <div className="w-px h-12 bg-gradient-to-b from-primary/50 to-transparent" />
        <span className="text-xs text-muted-foreground">Scroll</span>
      </motion.div>
    </section>
  );
}
