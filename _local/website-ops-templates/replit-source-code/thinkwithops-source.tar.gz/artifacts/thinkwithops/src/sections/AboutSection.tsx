import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Brain, Server, BookOpen, GraduationCap } from "lucide-react";

const cards = [
  {
    icon: Brain,
    title: "AI Projects",
    description: "Building end-to-end AI systems — from LLM pipelines to autonomous agents that solve real business problems.",
    color: "text-primary",
    glow: "group-hover:shadow-[0_0_20px_rgba(0,240,255,0.25)]",
    border: "group-hover:border-primary/40",
  },
  {
    icon: Server,
    title: "DevOps Systems",
    description: "Designing resilient CI/CD pipelines, Kubernetes orchestration, and infrastructure-as-code at scale.",
    color: "text-secondary",
    glow: "group-hover:shadow-[0_0_20px_rgba(176,85,255,0.25)]",
    border: "group-hover:border-secondary/40",
  },
  {
    icon: BookOpen,
    title: "Learning Content",
    description: "Translating complex AI and DevOps concepts into practical, digestible content engineers actually use.",
    color: "text-accent",
    glow: "group-hover:shadow-[0_0_20px_rgba(51,136,255,0.25)]",
    border: "group-hover:border-accent/40",
  },
  {
    icon: GraduationCap,
    title: "Future Courses",
    description: "Structured learning paths for engineers ready to transition from DevOps into AI engineering.",
    color: "text-primary",
    glow: "group-hover:shadow-[0_0_20px_rgba(0,240,255,0.25)]",
    border: "group-hover:border-primary/40",
  },
];

export function AboutSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" ref={ref} className="py-24 relative">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute left-0 top-1/2 w-96 h-96 rounded-full bg-secondary/5 blur-[100px]" />
      </div>

      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          {/* Text */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <span className="text-primary text-sm font-semibold tracking-widest uppercase mb-4 block">About</span>
            <h2 className="text-4xl md:text-5xl font-bold leading-tight mb-6">
              Engineering meets{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
                storytelling
              </span>
            </h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                ThinkWithOps is a platform built on a simple belief: AI and DevOps should be accessible to every engineer, not just those inside big-tech walls. The mission is to simplify complex systems through real-world projects, honest documentation, and practical education.
              </p>
              <p>
                Every project here was built to solve a real problem. Every piece of content is written for engineers who are hands-on and want to understand the "why" behind the "how." This is engineering distilled — no fluff, no theory-only tutorials.
              </p>
              <p>
                The intersection of AI and DevOps is where the next decade of engineering lives. ThinkWithOps is the guide for that journey.
              </p>
            </div>
          </motion.div>

          {/* Avatar */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="flex justify-center"
          >
            <div className="relative">
              <div className="w-56 h-56 rounded-2xl bg-gradient-to-br from-primary/20 via-card to-secondary/20 border border-border flex items-center justify-center text-5xl font-bold text-primary">
                TWO
              </div>
              <div className="absolute -inset-1 rounded-2xl bg-gradient-to-br from-primary/30 to-secondary/30 blur-xl -z-10" />
              <div className="absolute -bottom-4 -right-4 px-4 py-2 rounded-lg bg-card border border-border text-sm font-medium">
                <span className="text-primary">AI</span> + <span className="text-secondary">DevOps</span> Engineer
              </div>
            </div>
          </motion.div>
        </div>

        {/* What I'm Building cards */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <h3 className="text-xl font-semibold text-center mb-8 text-muted-foreground">What I'm Building</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {cards.map((card, i) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.4 + i * 0.1 }}
                className={`group relative p-6 rounded-xl bg-card border border-border transition-all duration-300 cursor-default ${card.glow} ${card.border}`}
                data-testid={`about-card-${card.title.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <div className={`w-10 h-10 rounded-lg bg-background flex items-center justify-center mb-4 ${card.color}`}>
                  <card.icon className="w-5 h-5" />
                </div>
                <h4 className="font-semibold text-foreground mb-2">{card.title}</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">{card.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
