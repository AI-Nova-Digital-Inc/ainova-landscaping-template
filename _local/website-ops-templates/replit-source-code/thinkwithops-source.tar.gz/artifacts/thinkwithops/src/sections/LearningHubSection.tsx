import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Cpu, BarChart2, GitBranch, MessageSquare, Wand2, Bot, Settings, Cloud } from "lucide-react";

const topics = [
  {
    icon: Cpu,
    title: "AI Fundamentals",
    description: "Core concepts, neural networks, and the architectural foundations every AI engineer needs.",
    color: "text-primary",
    bg: "bg-primary/10",
    glow: "group-hover:shadow-[0_0_25px_rgba(0,240,255,0.2)]",
  },
  {
    icon: BarChart2,
    title: "Machine Learning Basics",
    description: "Supervised and unsupervised learning, model evaluation, and real-world training loops.",
    color: "text-secondary",
    bg: "bg-secondary/10",
    glow: "group-hover:shadow-[0_0_25px_rgba(176,85,255,0.2)]",
  },
  {
    icon: GitBranch,
    title: "MLOps",
    description: "Productionizing ML models: versioning, monitoring, deployment pipelines, and drift detection.",
    color: "text-accent",
    bg: "bg-accent/10",
    glow: "group-hover:shadow-[0_0_25px_rgba(51,136,255,0.2)]",
  },
  {
    icon: MessageSquare,
    title: "LLMOps",
    description: "Operating large language models at scale — from prompt caching to RAG and fine-tuning.",
    color: "text-primary",
    bg: "bg-primary/10",
    glow: "group-hover:shadow-[0_0_25px_rgba(0,240,255,0.2)]",
  },
  {
    icon: Wand2,
    title: "Prompt Engineering",
    description: "Advanced prompting patterns — chain-of-thought, few-shot, and system prompt architecture.",
    color: "text-secondary",
    bg: "bg-secondary/10",
    glow: "group-hover:shadow-[0_0_25px_rgba(176,85,255,0.2)]",
  },
  {
    icon: Bot,
    title: "AI Agents",
    description: "Building autonomous AI agents with tool use, memory, and multi-agent orchestration.",
    color: "text-accent",
    bg: "bg-accent/10",
    glow: "group-hover:shadow-[0_0_25px_rgba(51,136,255,0.2)]",
  },
  {
    icon: Settings,
    title: "DevOps for AI",
    description: "Infrastructure patterns for AI workloads — GPU scheduling, model serving, and cost optimization.",
    color: "text-primary",
    bg: "bg-primary/10",
    glow: "group-hover:shadow-[0_0_25px_rgba(0,240,255,0.2)]",
  },
  {
    icon: Cloud,
    title: "Cloud + AI Systems",
    description: "Deploying AI systems on AWS, GCP, and Azure — managed services, serverless inference, and more.",
    color: "text-secondary",
    bg: "bg-secondary/10",
    glow: "group-hover:shadow-[0_0_25px_rgba(176,85,255,0.2)]",
  },
];

export function LearningHubSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="learn" ref={ref} className="py-24 relative">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-primary/3 blur-[100px] rounded-full" />
      </div>

      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-14"
        >
          <span className="text-primary text-sm font-semibold tracking-widest uppercase mb-4 block">Learning Hub</span>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Master the{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary to-primary">AI stack</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Curated paths through the tools, concepts, and systems defining modern AI engineering.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {topics.map((topic, i) => (
            <motion.div
              key={topic.title}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.1 + i * 0.07 }}
              className={`group relative p-6 rounded-xl bg-card border border-border transition-all duration-300 cursor-pointer ${topic.glow} hover:border-opacity-50 hover:scale-[1.02]`}
              data-testid={`topic-card-${topic.title.toLowerCase().replace(/\s+/g, "-")}`}
            >
              <div className={`w-12 h-12 rounded-xl ${topic.bg} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <topic.icon className={`w-6 h-6 ${topic.color}`} />
              </div>
              <h3 className="font-bold text-foreground mb-2">{topic.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">{topic.description}</p>
              <button
                className={`text-sm font-medium ${topic.color} hover:underline flex items-center gap-1`}
                data-testid={`btn-explore-${topic.title.toLowerCase().replace(/\s+/g, "-")}`}
              >
                Explore →
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
