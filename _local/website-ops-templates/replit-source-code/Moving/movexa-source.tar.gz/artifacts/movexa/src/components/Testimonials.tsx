import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const testimonials = [
  {
    name: "Eleanor Sterling",
    location: "Upper East Side",
    quote: "MoveXa handled our fine art collection with more care than the gallery did. The team was impeccably professional.",
  },
  {
    name: "James Chen",
    location: "Silicon Valley",
    quote: "Our corporate relocation was flawless. Not a single hour of downtime for our engineering team. Worth every penny.",
  },
  {
    name: "Victoria & David Ross",
    location: "Miami",
    quote: "Moving across the country is stressful, but the MoveXa concierge made it feel like a luxury hotel check-in.",
  },
  {
    name: "Arthur Pendelton",
    location: "Chicago",
    quote: "The attention to detail is staggering. They even arranged our library exactly as it was in our previous home.",
  },
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-24 bg-primary text-white overflow-hidden relative">
      <div className="absolute inset-0 opacity-5 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent" />
      
      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Client Endorsements</h2>
            <p className="text-blue-100 text-lg">
              Don't just take our word for it. Hear from those who expect the best.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((t, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors">
                <CardContent className="p-6 flex flex-col h-full">
                  <div className="flex gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-accent text-accent" />
                    ))}
                  </div>
                  <p className="text-white/90 mb-6 flex-grow leading-relaxed">"{t.quote}"</p>
                  <div>
                    <p className="font-bold text-white">{t.name}</p>
                    <p className="text-sm text-blue-200">{t.location}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
