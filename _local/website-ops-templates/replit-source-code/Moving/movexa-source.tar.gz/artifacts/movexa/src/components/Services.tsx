import { motion } from "framer-motion";
import { Truck, MapPin, Package, Warehouse } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const services = [
  {
    title: "Local Moving",
    description: "Expert local moves handled with precision and care — your valuables arrive exactly as they left.",
    icon: Truck,
  },
  {
    title: "Long Distance",
    description: "Cross-state and cross-country relocations managed end-to-end with real-time tracking.",
    icon: MapPin,
  },
  {
    title: "Professional Packing",
    description: "Museum-grade packing materials and techniques for everything from fine art to furniture.",
    icon: Package,
  },
  {
    title: "Climate Storage",
    description: "Temperature-controlled, 24/7-monitored storage units for short and long-term needs.",
    icon: Warehouse,
  },
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-gray-50/50">
      <div className="container mx-auto px-4 md:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Premium Services</h2>
            <p className="text-muted-foreground text-lg">
              Comprehensive relocation solutions tailored to your unique requirements.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full border-none shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white group">
                <CardContent className="p-8">
                  <div className="w-14 h-14 rounded-xl bg-blue-50 flex items-center justify-center mb-6 group-hover:bg-primary group-hover:text-white transition-colors duration-300">
                    <service.icon className="w-7 h-7 text-primary group-hover:text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-3 text-foreground">{service.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
