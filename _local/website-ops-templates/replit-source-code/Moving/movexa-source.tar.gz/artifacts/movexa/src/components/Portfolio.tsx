import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

const portfolio = [
  {
    title: "Penthouse Relocation",
    location: "Manhattan, NY",
    description: "Full service pack and move for a 4-bedroom luxury penthouse, including art curation.",
    image: "/images/portfolio-1.png",
  },
  {
    title: "Corporate Headquarters",
    location: "San Francisco, CA",
    description: "Seamless weekend transition for a 200-employee tech firm to minimize downtime.",
    image: "/images/portfolio-2.png",
  },
  {
    title: "Estate Transition",
    location: "Beverly Hills, CA",
    description: "White-glove moving service utilizing our premium climate-controlled fleet.",
    image: "/images/portfolio-3.png",
  },
];

export default function Portfolio() {
  return (
    <section id="portfolio" className="py-24 bg-gray-50/50">
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="max-w-2xl"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Proven Experience</h2>
            <p className="text-muted-foreground text-lg">
              We handle the most demanding relocations with absolute discretion and care.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {portfolio.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="overflow-hidden border-none shadow-md group cursor-pointer h-full">
                <div className="relative aspect-[4/3] overflow-hidden bg-muted">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-primary/80 via-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                    <p className="text-white/90 text-sm font-medium mb-2">{item.location}</p>
                    <p className="text-white text-sm line-clamp-2">{item.description}</p>
                  </div>
                </div>
                <CardContent className="p-6 bg-white">
                  <h3 className="text-xl font-bold text-foreground mb-1 group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">{item.location}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
