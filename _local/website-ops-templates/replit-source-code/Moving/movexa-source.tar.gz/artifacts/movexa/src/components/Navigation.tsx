import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Phone } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-background/80 backdrop-blur-md border-b shadow-sm py-4"
          : "bg-transparent py-6"
      }`}
    >
      <div className="container mx-auto px-4 md:px-8 flex items-center justify-between">
        <Link href="/" className="text-2xl font-bold tracking-tight text-primary">
          MoveXa<span className="text-accent">.</span>
        </Link>

        <nav className="hidden md:flex items-center space-x-8">
          {["Services", "Process", "Portfolio", "Testimonials", "Contact"].map((item) => (
            <button
              key={item}
              onClick={() => scrollTo(item.toLowerCase())}
              className={`text-sm font-medium transition-colors hover:text-accent ${
                scrolled ? "text-foreground" : "text-white"
              }`}
            >
              {item}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <div className={`hidden lg:flex items-center gap-2 text-sm font-semibold ${scrolled ? "text-foreground" : "text-white"}`}>
            <Phone className="w-4 h-4 text-accent" />
            <span>(800) 555-0199</span>
          </div>
          <Button onClick={() => scrollTo("contact")} className="bg-accent text-accent-foreground hover:bg-accent/90">
            Get a Quote
          </Button>
        </div>
      </div>
    </header>
  );
}
