import { motion } from "framer-motion";
import { Star, ShieldCheck, Clock, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Hero() {
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden bg-primary pt-20">
      {/* Background with animated gradient and lines */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/90 to-blue-900/80" />
        <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-white/20" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div className="container relative z-10 mx-auto px-4 md:px-8 flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-3xl"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-white/90 text-xs font-semibold tracking-wide uppercase mb-6">
            <Star className="w-3 h-3 text-accent fill-accent" />
            <span>Premium Relocation Services</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-extrabold text-white tracking-tight mb-6 leading-tight">
            Moving Made <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent to-yellow-200">Effortless</span>
          </h1>

          <p className="text-lg md:text-xl text-blue-100 mb-10 max-w-2xl mx-auto leading-relaxed">
            Premium relocation services designed for a seamless experience. 
            From fine art to entire households, we handle every detail with unhurried confidence and clean precision.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <Button size="lg" onClick={() => scrollTo("contact")} className="w-full sm:w-auto text-base h-14 px-8 bg-accent text-accent-foreground hover:bg-accent/90 shadow-lg shadow-accent/20">
              Get a Free Quote
            </Button>
            <Button size="lg" variant="outline" onClick={() => scrollTo("services")} className="w-full sm:w-auto text-base h-14 px-8 border-white/30 text-white hover:bg-white/10 hover:text-white backdrop-blur-sm">
              View Services
            </Button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 pt-8 border-t border-white/10 w-full max-w-4xl"
        >
          {[
            { icon: Star, text: "5-Star Rating" },
            { icon: ShieldCheck, text: "Fully Insured" },
            { icon: Clock, text: "10+ Years Experience" },
            { icon: CheckCircle, text: "500+ Moves Completed" },
          ].map((badge, i) => (
            <div key={i} className="flex flex-col items-center gap-2 text-white/80">
              <badge.icon className="w-6 h-6 text-accent" />
              <span className="text-sm font-medium">{badge.text}</span>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
