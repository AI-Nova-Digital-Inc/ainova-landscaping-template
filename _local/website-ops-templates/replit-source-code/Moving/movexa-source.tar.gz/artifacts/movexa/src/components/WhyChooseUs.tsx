import { motion } from "framer-motion";
import { Shield, Clock, Star, UserCheck } from "lucide-react";

const benefits = [
  { icon: Shield, title: "Fully Insured & Bonded" },
  { icon: Clock, title: "On-Time Guarantee" },
  { icon: Star, title: "Damage Protection" },
  { icon: UserCheck, title: "Dedicated Move Coordinator" },
];

export default function WhyChooseUs() {
  return (
    <section className="py-20 bg-primary text-white">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 divide-y sm:divide-y-0 sm:divide-x divide-white/10">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex items-center gap-4 py-6 sm:py-0 sm:px-6 first:pl-0 last:pr-0"
            >
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                <benefit.icon className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-lg font-semibold leading-tight">{benefit.title}</h3>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
