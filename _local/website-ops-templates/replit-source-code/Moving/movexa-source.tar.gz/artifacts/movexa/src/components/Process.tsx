import { motion } from "framer-motion";
import { ClipboardList, Package, Truck, Home } from "lucide-react";

const steps = [
  {
    id: 1,
    title: "Plan",
    description: "We assess your needs and create a custom relocation timeline.",
    icon: ClipboardList,
  },
  {
    id: 2,
    title: "Pack",
    description: "Certified packers wrap and protect every item to our exacting standards.",
    icon: Package,
  },
  {
    id: 3,
    title: "Move",
    description: "Our fleet of climate-controlled vehicles transport your belongings safely.",
    icon: Truck,
  },
  {
    id: 4,
    title: "Deliver",
    description: "White-glove unpacking and setup at your new home or office.",
    icon: Home,
  },
];

export default function Process() {
  return (
    <section id="process" className="py-24 bg-white relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-8">
        <div className="text-center max-w-2xl mx-auto mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Flawless Process</h2>
            <p className="text-muted-foreground text-lg">
              A systematic approach ensuring nothing is overlooked.
            </p>
          </motion.div>
        </div>

        <div className="relative">
          {/* Connector Line */}
          <div className="hidden lg:block absolute top-12 left-[10%] right-[10%] h-0.5 bg-gray-200 -z-10" />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
            {steps.map((step, index) => (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
                className="relative flex flex-col items-center text-center"
              >
                <div className="w-24 h-24 rounded-full bg-white border-4 border-gray-50 shadow-lg flex items-center justify-center mb-6 relative z-10">
                  <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-sm font-bold shadow-md">
                    {step.id}
                  </div>
                  <step.icon className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-foreground">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
