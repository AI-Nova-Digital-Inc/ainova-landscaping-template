import { motion } from "framer-motion";
import { Truck, Map, Box, Zap } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

const services = [
  {
    title: "Local Moves",
    description: "Fast, efficient local moving within your city. We know the streets and how to get you settled quickly.",
    icon: Truck,
  },
  {
    title: "Long Distance",
    description: "Cross-state or cross-country, your belongings are safe with our dedicated long-haul team.",
    icon: Map,
  },
  {
    title: "Packing & Unpacking",
    description: "Hate packing? Let us handle it. We bring the boxes, carefully pack everything, and can even unpack.",
    icon: Box,
  },
  {
    title: "Same-Day Moves",
    description: "Need to move right now? We offer emergency same-day services depending on availability.",
    icon: Zap,
  }
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export function ServicesGrid() {
  return (
    <section id="services" className="py-24 bg-gray-50/50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Moving Services Tailored for You</h2>
          <p className="text-lg text-muted-foreground">
            Whether you're moving down the street or across the country, we have the right service to make it stress-free.
          </p>
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {services.map((service, i) => (
            <motion.div key={i} variants={itemVariants}>
              <Card className="h-full hover:shadow-xl hover:-translate-y-1 transition-all duration-300 border-0 bg-white">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4 text-primary group-hover:bg-primary group-hover:text-white transition-colors duration-300">
                    <service.icon className="w-6 h-6" />
                  </div>
                  <CardTitle className="text-xl mb-2">{service.title}</CardTitle>
                  <CardDescription className="text-base leading-relaxed">
                    {service.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
