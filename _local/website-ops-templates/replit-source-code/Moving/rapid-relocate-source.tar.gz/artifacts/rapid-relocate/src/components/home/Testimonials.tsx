import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const reviews = [
  {
    name: "Sarah Jenkins",
    role: "Homeowner",
    text: "The best moving experience I've ever had. They showed up early, packed everything perfectly, and didn't scratch a single wall.",
    rating: 5
  },
  {
    name: "Michael Chen",
    role: "Cross-country move",
    text: "Moving from CA to TX was daunting, but RapidRelocate made it seamless. Transparent pricing and great communication throughout.",
    rating: 5
  },
  {
    name: "Emily Rodriguez",
    role: "Apartment renter",
    text: "Fast, polite, and very careful with my fragile items. The crew was energetic and actually made moving day fun!",
    rating: 5
  }
];

export function Testimonials() {
  return (
    <section id="reviews" className="py-24 bg-primary/5">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Don't Just Take Our Word For It</h2>
          <p className="text-lg text-muted-foreground">
            Read what your neighbors have to say about moving with us.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="h-full bg-white border-0 shadow-lg shadow-primary/5">
                <CardContent className="p-8">
                  <div className="flex gap-1 mb-6 text-accent">
                    {[...Array(review.rating)].map((_, j) => (
                      <Star key={j} className="w-5 h-5 fill-current" />
                    ))}
                  </div>
                  <p className="text-lg text-foreground mb-6 italic">"{review.text}"</p>
                  <div>
                    <p className="font-bold">{review.name}</p>
                    <p className="text-sm text-muted-foreground">{review.role}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
