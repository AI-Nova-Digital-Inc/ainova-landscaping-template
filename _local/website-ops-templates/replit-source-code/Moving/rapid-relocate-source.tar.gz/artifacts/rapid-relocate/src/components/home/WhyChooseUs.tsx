import { motion } from "framer-motion";
import { ShieldCheck, Star, Zap, MapPin } from "lucide-react";

const badges = [
  {
    icon: ShieldCheck,
    title: "Licensed & Insured",
    desc: "Fully covered for your peace of mind.",
    stat: "$2M"
  },
  {
    icon: Star,
    title: "5-Star Reviews",
    desc: "Hundreds of happy homeowners.",
    stat: "4.9/5"
  },
  {
    icon: Zap,
    title: "Fast Response",
    desc: "Quotes in minutes, not days.",
    stat: "< 15m"
  },
  {
    icon: MapPin,
    title: "Nationwide Coverage",
    desc: "Moving you anywhere in the US.",
    stat: "50"
  }
];

export function WhyChooseUs() {
  return (
    <section id="why-us" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose RapidRelocate?</h2>
          <p className="text-lg text-muted-foreground">
            We set the standard for professional moving services. Here's why our customers trust us.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {badges.map((badge, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="text-center p-6 rounded-2xl bg-gray-50 border border-border/50 hover:bg-gray-100 transition-colors"
            >
              <div className="w-16 h-16 mx-auto bg-white rounded-2xl shadow-sm flex items-center justify-center mb-6 text-primary">
                <badge.icon className="w-8 h-8" />
              </div>
              <div className="text-3xl font-extrabold text-foreground mb-2">{badge.stat}</div>
              <h3 className="font-bold text-lg mb-2">{badge.title}</h3>
              <p className="text-muted-foreground text-sm">{badge.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
