import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Calculator } from "lucide-react";

export function QuoteEstimator() {
  const [size, setSize] = useState<string>("");
  const [distance, setDistance] = useState<string>("");
  const [date, setDate] = useState<string>("");

  const estimate = useMemo(() => {
    if (!size || !distance) return null;
    
    let base = 0;
    switch(size) {
      case "studio": base = 300; break;
      case "1br": base = 500; break;
      case "2br": base = 800; break;
      case "3br": base = 1200; break;
      case "4br+": base = 1800; break;
    }

    let mult = 1;
    switch(distance) {
      case "local": mult = 1; break;
      case "short": mult = 1.5; break;
      case "long": mult = 3; break;
    }

    return base * mult;
  }, [size, distance]);

  return (
    <section className="py-20 bg-white relative z-20 -mt-10">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto"
        >
          <Card className="border-0 shadow-2xl shadow-primary/5 overflow-hidden">
            <div className="flex flex-col md:flex-row">
              <div className="flex-1 p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center text-primary">
                    <Calculator className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">Instant Quote Estimator</h3>
                    <p className="text-sm text-muted-foreground">Get a rough idea before you book.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Move Size</Label>
                    <Select value={size} onValueChange={setSize}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select home size" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="studio">Studio</SelectItem>
                        <SelectItem value="1br">1 Bedroom</SelectItem>
                        <SelectItem value="2br">2 Bedrooms</SelectItem>
                        <SelectItem value="3br">3 Bedrooms</SelectItem>
                        <SelectItem value="4br+">4+ Bedrooms</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Distance</Label>
                    <Select value={distance} onValueChange={setDistance}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select distance" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="local">Local (&lt; 25mi)</SelectItem>
                        <SelectItem value="short">Short Distance (25-100mi)</SelectItem>
                        <SelectItem value="long">Long Distance (100mi+)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              
              <div className="w-full md:w-1/3 bg-gray-50 p-8 flex flex-col justify-center items-center text-center border-t md:border-t-0 md:border-l border-border">
                <p className="text-sm font-medium text-muted-foreground mb-2">Estimated Cost</p>
                <div className="text-4xl font-extrabold text-primary mb-6">
                  {estimate ? `$${estimate.toLocaleString()}` : '---'}
                </div>
                <Button 
                  className="w-full" 
                  size="lg" 
                  disabled={!estimate}
                  onClick={() => document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' })}
                >
                  Book This Move
                </Button>
                <p className="text-xs text-muted-foreground mt-4">
                  *Final price may vary based on specific inventory and access.
                </p>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
