import { motion } from "framer-motion";

export function ExperienceSection() {
  return (
    <section className="py-24 overflow-hidden bg-primary text-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <h2 className="text-4xl md:text-5xl font-bold leading-tight">
              From packed up to settled in.
            </h2>
            <p className="text-xl text-primary-foreground/80 leading-relaxed">
              We don't just move boxes; we move lives. Experience the relief of walking into your new home, completely set up and ready for the next chapter.
            </p>
            <ul className="space-y-4 pt-4">
              {[
                "Careful handling of fragile items",
                "Floor and wall protection included",
                "Furniture disassembly & reassembly",
                "No hidden fees or surprise charges"
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-lg">
                  <div className="w-6 h-6 rounded-full bg-accent flex items-center justify-center shrink-0">
                    <span className="text-white text-sm font-bold">✓</span>
                  </div>
                  {item}
                </li>
              ))}
            </ul>
          </motion.div>

          <div className="relative h-[600px] w-full">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="absolute top-0 right-0 w-3/4 h-2/3 rounded-2xl overflow-hidden shadow-2xl border-4 border-white/10 z-10"
            >
              <img 
                src="/before-boxes.png" 
                alt="Packed boxes" 
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-4 left-4 bg-black/50 backdrop-blur-sm text-white px-4 py-2 rounded-lg text-sm font-medium">
                Before: Stressful
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="absolute bottom-0 left-0 w-3/4 h-2/3 rounded-2xl overflow-hidden shadow-2xl border-4 border-white/10 z-20"
            >
              <img 
                src="/after-settled.png" 
                alt="Settled living room" 
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-4 left-4 bg-accent text-white px-4 py-2 rounded-lg text-sm font-medium">
                After: Relaxing
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
