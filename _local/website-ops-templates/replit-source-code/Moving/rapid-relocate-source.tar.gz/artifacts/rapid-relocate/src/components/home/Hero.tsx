import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock } from "lucide-react";

export function Hero() {
  return (
    <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden min-h-[90vh] flex items-center">
      {/* Background with slight tint */}
      <div className="absolute inset-0 bg-primary/5 -z-10" />
      
      {/* Decorative background shape */}
      <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-[800px] h-[800px] bg-primary/10 rounded-full blur-3xl -z-10" />
      <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-[600px] h-[600px] bg-accent/10 rounded-full blur-3xl -z-10" />

      <div className="container mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl"
        >
          <Badge variant="secondary" className="mb-6 py-1.5 px-4 bg-white shadow-sm border-primary/20 text-primary font-medium flex items-center gap-2 w-fit">
            <Clock className="w-4 h-4" />
            Limited slots available this week
          </Badge>
          
          <h1 className="text-5xl md:text-7xl font-extrabold text-foreground tracking-tight leading-[1.1] mb-6">
            Move Faster.<br />
            <span className="text-primary">Stress Less.</span>
          </h1>
          
          <p className="text-xl text-muted-foreground mb-8 leading-relaxed max-w-lg">
            Affordable, reliable moving services you can trust. We show up on time, handle your belongings with care, and make the whole process effortless.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" className="text-lg h-14 px-8" onClick={() => document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' })}>
              Get Free Estimate
            </Button>
            <Button size="lg" variant="outline" className="text-lg h-14 px-8 bg-white hover:bg-gray-50" onClick={() => document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' })}>
              Book Your Move
            </Button>
          </div>
          
          <div className="mt-10 flex items-center gap-4 text-sm font-medium text-muted-foreground">
            <div className="flex -space-x-2">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-gray-200" />
              ))}
            </div>
            <p>Trusted by 500+ homeowners this year</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          <motion.div
            animate={{ y: [0, -15, 0] }}
            transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
            className="relative z-10 rounded-2xl overflow-hidden shadow-2xl border border-white/20 aspect-video lg:aspect-square"
          >
            <img 
              src="/hero-moving.png" 
              alt="Professional moving truck" 
              className="w-full h-full object-cover"
            />
          </motion.div>
          
          {/* Floating decorative elements */}
          <motion.div 
            animate={{ y: [0, 10, 0], rotate: [0, 5, 0] }}
            transition={{ repeat: Infinity, duration: 5, ease: "easeInOut", delay: 1 }}
            className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-xl border border-gray-100 z-20"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-accent/20 rounded-full flex items-center justify-center">
                <span className="text-accent text-xl font-bold">✓</span>
              </div>
              <div>
                <p className="font-bold text-sm">Fully Insured</p>
                <p className="text-xs text-muted-foreground">$2M Coverage</p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
