import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Hero } from "@/components/home/Hero";
import { QuoteEstimator } from "@/components/home/QuoteEstimator";
import { ServicesGrid } from "@/components/home/ServicesGrid";
import { ExperienceSection } from "@/components/home/ExperienceSection";
import { WhyChooseUs } from "@/components/home/WhyChooseUs";
import { Testimonials } from "@/components/home/Testimonials";
import { BookingWizard } from "@/components/home/BookingWizard";

export default function Home() {
  return (
    <div className="min-h-screen bg-background font-sans">
      <Header />
      <main>
        <Hero />
        <QuoteEstimator />
        <ServicesGrid />
        <ExperienceSection />
        <WhyChooseUs />
        <Testimonials />
        <BookingWizard />
      </main>
      <Footer />
    </div>
  );
}
