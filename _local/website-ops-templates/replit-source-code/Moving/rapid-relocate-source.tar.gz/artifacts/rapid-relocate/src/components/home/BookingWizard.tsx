import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon, ArrowRight, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

export function BookingWizard() {
  const [step, setStep] = useState(1);
  const [date, setDate] = useState<Date>();

  const nextStep = () => setStep(s => Math.min(s + 1, 4));
  const prevStep = () => setStep(s => Math.max(s - 1, 1));

  return (
    <section id="booking" className="py-24 bg-white relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1/2 bg-primary/5 -z-10" />
      
      <div className="container mx-auto px-4 max-w-3xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Book Your Move Today</h2>
          <p className="text-lg text-muted-foreground">
            Fill out the details below and we'll confirm your slot.
          </p>
        </div>

        <Card className="border-0 shadow-2xl overflow-hidden">
          <CardHeader className="bg-gray-50 border-b border-border/50 px-8 py-6">
            <div className="flex items-center justify-between">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center">
                  <div className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-colors",
                    step >= i ? "bg-primary text-white" : "bg-gray-200 text-muted-foreground",
                    step === 4 && "bg-accent text-white"
                  )}>
                    {step > i || step === 4 ? <CheckCircle2 className="w-5 h-5" /> : i}
                  </div>
                  {i < 3 && (
                    <div className={cn(
                      "h-1 w-12 sm:w-24 mx-2 rounded-full transition-colors",
                      step > i ? "bg-primary" : "bg-gray-200"
                    )} />
                  )}
                </div>
              ))}
            </div>
          </CardHeader>

          <CardContent className="p-8 min-h-[400px] relative">
            <AnimatePresence mode="wait">
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <CardTitle className="text-2xl mb-6">Contact Information</CardTitle>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>First Name</Label>
                      <Input placeholder="John" />
                    </div>
                    <div className="space-y-2">
                      <Label>Last Name</Label>
                      <Input placeholder="Doe" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input type="email" placeholder="john@example.com" />
                  </div>
                  <div className="space-y-2">
                    <Label>Phone Number</Label>
                    <Input type="tel" placeholder="(555) 123-4567" />
                  </div>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <CardTitle className="text-2xl mb-6">Move Details</CardTitle>
                  <div className="space-y-2">
                    <Label>Moving From (Zip Code)</Label>
                    <Input placeholder="e.g. 94105" />
                  </div>
                  <div className="space-y-2">
                    <Label>Moving To (Zip Code)</Label>
                    <Input placeholder="e.g. 90210" />
                  </div>
                  <div className="space-y-2">
                    <Label>Home Size</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select home size" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="studio">Studio</SelectItem>
                        <SelectItem value="1br">1 Bedroom</SelectItem>
                        <SelectItem value="2br">2 Bedrooms</SelectItem>
                        <SelectItem value="3br">3 Bedrooms</SelectItem>
                        <SelectItem value="4br+">4+ Bedrooms</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </motion.div>
              )}

              {step === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <CardTitle className="text-2xl mb-6">Preferred Date</CardTitle>
                  <div className="space-y-2 flex flex-col">
                    <Label>Select Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !date && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {date ? format(date, "PPP") : <span>Pick a date</span>}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={date}
                          onSelect={setDate}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="bg-primary/5 p-4 rounded-lg mt-6 border border-primary/10">
                    <h4 className="font-bold text-primary mb-2">Almost done!</h4>
                    <p className="text-sm text-muted-foreground">
                      We'll review your details and call you within 15 minutes to confirm pricing and availability.
                    </p>
                  </div>
                </motion.div>
              )}

              {step === 4 && (
                <motion.div
                  key="step4"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center justify-center text-center h-full space-y-6 pt-8"
                >
                  <div className="w-24 h-24 bg-accent/10 rounded-full flex items-center justify-center text-accent mb-4">
                    <CheckCircle2 className="w-12 h-12" />
                  </div>
                  <h3 className="text-3xl font-bold">Request Received!</h3>
                  <p className="text-lg text-muted-foreground max-w-md">
                    Thank you! Our team is reviewing your details. We'll be in touch shortly to confirm your move.
                  </p>
                  <Button variant="outline" className="mt-8" onClick={() => setStep(1)}>
                    Submit Another Request
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>

            {step < 4 && (
              <div className="absolute bottom-8 left-8 right-8 flex justify-between">
                <Button 
                  variant="ghost" 
                  onClick={prevStep}
                  disabled={step === 1}
                  className={step === 1 ? "invisible" : ""}
                >
                  Back
                </Button>
                <Button onClick={nextStep} className="gap-2">
                  {step === 3 ? "Schedule Your Move" : "Next Step"}
                  {step < 3 && <ArrowRight className="w-4 h-4" />}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
