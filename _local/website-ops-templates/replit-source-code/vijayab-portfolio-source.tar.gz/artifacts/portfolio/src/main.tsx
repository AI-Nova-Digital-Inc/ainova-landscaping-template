import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

document.documentElement.classList.add('dark');
if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
// Aggressively keep page at top on initial load
let _topFrames = 0;
const _keepTop = () => { window.scrollTo(0, 0); if (_topFrames++ < 30) requestAnimationFrame(_keepTop); };
requestAnimationFrame(_keepTop);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);