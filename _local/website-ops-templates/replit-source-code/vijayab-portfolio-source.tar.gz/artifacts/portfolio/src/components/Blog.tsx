import { useRef } from "react";
import { motion, useInView, useReducedMotion } from "framer-motion";
import { ArrowRight } from "lucide-react";

export default function Blog() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const shouldReduceMotion = useReducedMotion();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.2 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  const articles = [
    {
      category: "CI/CD",
      title: "How I Think About Reliable CI/CD at Scale",
      excerpt: "Pipeline failures are expensive. Here's how I approach Jenkins reliability engineering — from retry logic to dynamic agent provisioning to actionable failure telemetry.",
      color: "text-cyan-400"
    },
    {
      category: "Kubernetes",
      title: "Kubernetes Lessons from Regulated Environments",
      excerpt: "Running Kubernetes in healthcare isn't just about uptime. It's about audit trails, RBAC rigidity, change management, and zero-surprise releases.",
      color: "text-violet-400"
    },
    {
      category: "AI + DevOps",
      title: "Why AI Engineers Need Strong DevOps Foundations",
      excerpt: "AI systems fail in production the same ways software does — silently, intermittently, and at the worst possible time. The engineers who will own AI reliability are the ones who already understand delivery pipelines.",
      color: "text-emerald-400"
    }
  ];

  return (
    <section id="blog" className="py-24 relative z-10 bg-background/30">
      <div className="container mx-auto px-4 md:px-6">
        <div className="mb-12 flex justify-between items-end">
          <h2 className="text-3xl md:text-4xl font-bold font-display inline-block">
            Insights & Writing
            <div className="h-1 w-full bg-cyan-500 mt-2 rounded-full" />
          </h2>
        </div>

        <motion.div 
          ref={ref}
          variants={shouldReduceMotion ? {} : containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-3 gap-8"
        >
          {articles.map((article, idx) => (
            <motion.div 
              key={idx}
              variants={itemVariants}
              className="glass rounded-xl overflow-hidden group hover:border-cyan-500/30 transition-colors flex flex-col h-full"
            >
              <div className="p-6 md:p-8 flex flex-col h-full">
                <span className={`text-xs font-bold uppercase tracking-wider mb-4 block ${article.color}`}>
                  {article.category}
                </span>
                <h3 className="text-xl font-bold font-display text-foreground mb-4 group-hover:text-cyan-100 transition-colors">
                  {article.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-8 flex-grow">
                  {article.excerpt}
                </p>
                <a 
                  href="#" 
                  onClick={(e) => e.preventDefault()}
                  className="flex items-center text-sm font-medium text-foreground group-hover:text-cyan-400 transition-colors mt-auto"
                >
                  Read Article <ArrowRight className="ml-2 w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                </a>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
