import { useRef } from "react";
import { motion, useInView, useReducedMotion } from "framer-motion";
import { 
  GitBranch, Cloud, Database, FileCode2, 
  Container, ShieldCheck, Activity, Terminal 
} from "lucide-react";

export default function Skills() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const shouldReduceMotion = useReducedMotion();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  const skills = [
    {
      icon: <GitBranch className="w-6 h-6 text-cyan-400" />,
      title: "CI/CD & Automation",
      desc: "Building resilient pipelines that catch errors early and deploy confidently.",
      tags: ["Jenkins", "GitHub Actions", "GitLab CI/CD", "Azure DevOps", "YAML", "Groovy"]
    },
    {
      icon: <Cloud className="w-6 h-6 text-violet-400" />,
      title: "Cloud AWS",
      desc: "Architecting scalable, secure, and cost-effective environments on AWS.",
      tags: ["EC2", "S3", "IAM", "Lambda", "CloudFormation", "Organizations"]
    },
    {
      icon: <Database className="w-6 h-6 text-cyan-400" />,
      title: "Cloud Azure",
      desc: "Enterprise-grade deployments leveraging Azure's ecosystem.",
      tags: ["AKS", "App Services", "Key Vault", "ARM Templates", "Azure AD"]
    },
    {
      icon: <FileCode2 className="w-6 h-6 text-violet-400" />,
      title: "Infrastructure as Code",
      desc: "Managing infrastructure through code to eliminate configuration drift.",
      tags: ["Terraform", "Ansible", "Helm Charts", "CloudFormation", "ARM"]
    },
    {
      icon: <Container className="w-6 h-6 text-cyan-400" />,
      title: "Containers & Orchestration",
      desc: "Running microservices efficiently at scale in regulated environments.",
      tags: ["Docker", "Kubernetes", "Helm", "Rancher", "AKS", "EKS"]
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-violet-400" />,
      title: "DevSecOps",
      desc: "Integrating security scanning directly into the deployment lifecycle.",
      tags: ["SonarQube", "Fortify", "GHAS", "RBAC", "Secret Rotation"]
    },
    {
      icon: <Activity className="w-6 h-6 text-cyan-400" />,
      title: "Observability",
      desc: "Setting up telemetry to detect and resolve incidents before users notice.",
      tags: ["Prometheus", "Grafana", "ELK", "Dynatrace", "CloudWatch"]
    },
    {
      icon: <Terminal className="w-6 h-6 text-violet-400" />,
      title: "Scripting & Languages",
      desc: "Writing the glue code that connects disparate systems together.",
      tags: ["Python", "Bash", "PowerShell", "Groovy", "Linux"]
    }
  ];

  return (
    <section id="skills" className="py-24 relative z-10">
      <div className="container mx-auto px-4 md:px-6">
        <div className="mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-display inline-block">
            Technical Arsenal
            <div className="h-1 w-full bg-cyan-500 mt-2 rounded-full" />
          </h2>
        </div>

        <motion.div 
          ref={ref}
          variants={shouldReduceMotion ? {} : containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-2 gap-6"
        >
          {skills.map((skill, idx) => (
            <motion.div 
              key={idx}
              variants={itemVariants}
              className="glass p-6 rounded-xl hover:glow-cyan transition-all duration-300 border-l-4 border-l-transparent hover:border-l-cyan-500 group"
            >
              <div className="flex items-start gap-4">
                <div className="p-3 glass rounded-lg group-hover:bg-cyan-500/10 transition-colors">
                  {skill.icon}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold font-display mb-2">{skill.title}</h3>
                  <p className="text-muted-foreground text-sm mb-4 leading-relaxed">{skill.desc}</p>
                  <div className="flex flex-wrap gap-2">
                    {skill.tags.map((tag, tIdx) => (
                      <span 
                        key={tIdx} 
                        className={`text-xs px-2 py-1 rounded-md border ${
                          tIdx % 2 === 0 
                            ? 'bg-cyan-500/10 text-cyan-300 border-cyan-500/20' 
                            : 'bg-violet-500/10 text-violet-300 border-violet-500/20'
                        }`}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
