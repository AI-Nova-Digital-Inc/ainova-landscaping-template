import { useEffect, useRef } from "react";
import { motion } from "framer-motion";

export default function HeroOrb() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const dx = (e.clientX - centerX) / rect.width;
      const dy = (e.clientY - centerY) / rect.height;
      container.style.setProperty("--mouse-x", `${dx * 12}deg`);
      container.style.setProperty("--mouse-y", `${-dy * 12}deg`);
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full flex items-center justify-center"
      style={{ perspective: "1000px" }}
    >
      <motion.div
        animate={{ rotateY: 360 }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        style={{
          transformStyle: "preserve-3d",
          transform: "rotateX(var(--mouse-y, 0deg)) rotateY(var(--mouse-x, 0deg))",
        }}
        className="relative w-72 h-72 md:w-80 md:h-80"
      >
        {/* Core orb */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-cyan-400/20 via-violet-500/10 to-transparent border border-cyan-400/30 glow-cyan-strong" />

        {/* Inner glow sphere */}
        <motion.div
          animate={{ scale: [1, 1.06, 1] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className="absolute inset-8 rounded-full bg-gradient-to-br from-cyan-400/30 via-violet-500/20 to-cyan-400/10"
          style={{
            boxShadow: "inset 0 0 60px rgba(0,240,255,0.2), 0 0 80px rgba(0,240,255,0.15)",
          }}
        />

        {/* Orbiting ring 1 */}
        <motion.div
          animate={{ rotateZ: 360 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          className="absolute inset-0 rounded-full"
          style={{ transformStyle: "preserve-3d" }}
        >
          <div
            className="absolute inset-0 rounded-full border border-cyan-400/40"
            style={{ transform: "rotateX(70deg)" }}
          />
        </motion.div>

        {/* Orbiting ring 2 */}
        <motion.div
          animate={{ rotateZ: -360 }}
          transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
          className="absolute inset-4 rounded-full"
          style={{ transformStyle: "preserve-3d" }}
        >
          <div
            className="absolute inset-0 rounded-full border border-violet-500/30"
            style={{ transform: "rotateX(70deg) rotateY(45deg)" }}
          />
        </motion.div>

        {/* Orbiting ring 3 */}
        <motion.div
          animate={{ rotateZ: 360 }}
          transition={{ duration: 16, repeat: Infinity, ease: "linear" }}
          className="absolute inset-8 rounded-full"
          style={{ transformStyle: "preserve-3d" }}
        >
          <div
            className="absolute inset-0 rounded-full border border-cyan-400/20"
            style={{ transform: "rotateX(40deg) rotateY(20deg)" }}
          />
        </motion.div>

        {/* Orbiting dots */}
        {[0, 72, 144, 216, 288].map((deg, i) => (
          <motion.div
            key={i}
            animate={{ rotateZ: 360 }}
            transition={{ duration: 6 + i * 1.5, repeat: Infinity, ease: "linear", delay: i * 0.3 }}
            className="absolute inset-0"
            style={{ transformOrigin: "center center" }}
          >
            <div
              className="absolute"
              style={{
                top: "50%",
                left: "50%",
                transform: `rotate(${deg}deg) translateX(${130 + i * 6}px)`,
              }}
            >
              <div
                className="w-2 h-2 rounded-full bg-cyan-400"
                style={{
                  boxShadow: "0 0 8px rgba(0,240,255,0.8), 0 0 16px rgba(0,240,255,0.4)",
                  marginTop: "-4px",
                  marginLeft: "-4px",
                }}
              />
            </div>
          </motion.div>
        ))}

        {/* Hexagonal grid overlay */}
        <div
          className="absolute inset-0 rounded-full overflow-hidden opacity-10"
          style={{
            backgroundImage: `
              radial-gradient(circle, transparent 30%, rgba(0,240,255,0.05) 70%),
              repeating-linear-gradient(0deg, rgba(0,240,255,0.15) 0px, transparent 1px, transparent 20px),
              repeating-linear-gradient(60deg, rgba(0,240,255,0.15) 0px, transparent 1px, transparent 20px),
              repeating-linear-gradient(120deg, rgba(0,240,255,0.15) 0px, transparent 1px, transparent 20px)
            `,
          }}
        />

        {/* Center core pulse */}
        <motion.div
          animate={{ scale: [0.8, 1.2, 0.8], opacity: [0.4, 0.8, 0.4] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          className="absolute inset-[35%] rounded-full bg-cyan-400"
          style={{ boxShadow: "0 0 30px rgba(0,240,255,0.6), 0 0 60px rgba(0,240,255,0.3)" }}
        />
      </motion.div>

      {/* Floating tech labels */}
      {[
        { label: "Kubernetes", angle: -30, radius: 200 },
        { label: "Terraform", angle: 60, radius: 190 },
        { label: "AWS", angle: 150, radius: 195 },
        { label: "CI/CD", angle: 220, radius: 200 },
      ].map(({ label, angle, radius }) => {
        const rad = (angle * Math.PI) / 180;
        const x = Math.cos(rad) * radius;
        const y = Math.sin(rad) * radius;
        return (
          <motion.div
            key={label}
            animate={{ opacity: [0.5, 1, 0.5], y: [0, -4, 0] }}
            transition={{ duration: 3 + Math.random() * 2, repeat: Infinity, ease: "easeInOut", delay: Math.random() * 2 }}
            className="absolute text-xs font-mono text-cyan-400/70 px-2 py-1 rounded border border-cyan-400/20 bg-background/50 backdrop-blur-sm pointer-events-none"
            style={{
              transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y}px))`,
              top: "50%",
              left: "50%",
            }}
          >
            {label}
          </motion.div>
        );
      })}

      {/* Outer glow halo */}
      <div
        className="absolute inset-0 rounded-full pointer-events-none"
        style={{
          background: "radial-gradient(circle, transparent 40%, rgba(0,240,255,0.04) 70%, transparent 100%)",
        }}
      />
    </div>
  );
}
