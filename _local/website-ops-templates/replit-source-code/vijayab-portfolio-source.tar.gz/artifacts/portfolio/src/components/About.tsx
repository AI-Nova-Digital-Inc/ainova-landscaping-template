import { motion, useInView, useReducedMotion } from "framer-motion";
import { useRef } from "react";

export default function About() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const shouldReduceMotion = useReducedMotion();

  const containerVariants = {
    hidden: { opacity: 0, y: 40 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, staggerChildren: 0.2 } }
  };

  return (
    <section id="about" className="py-24 relative z-10 bg-background/50 border-y border-white/5">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div 
          ref={ref}
          variants={shouldReduceMotion ? {} : containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-12 gap-12 items-center"
        >
          <div className="md:col-span-4 flex justify-center md:justify-start">
            <div className="relative w-64 h-64 md:w-full md:h-80 max-w-sm rounded-2xl overflow-hidden glass p-1 glow-cyan-strong">
              <div className="w-full h-full bg-gradient-to-br from-card to-background rounded-xl flex items-center justify-center border border-white/5">
                <span className="text-6xl md:text-8xl font-bold font-display text-transparent bg-clip-text bg-gradient-to-br from-cyan-400 to-violet-500">VB</span>
              </div>
              {/* Decorative elements */}
              <div className="absolute top-4 left-4 w-2 h-2 bg-cyan-400 rounded-full" />
              <div className="absolute bottom-4 right-4 w-2 h-2 bg-violet-400 rounded-full" />
              <div className="absolute -right-2 top-1/2 w-4 h-12 bg-cyan-500/20 blur-md" />
            </div>
          </div>

          <div className="md:col-span-8 space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold font-display text-foreground">
              About <span className="text-cyan-400 border-b-2 border-cyan-400/30 pb-1">Me</span>
            </h2>
            
            <div className="prose prose-invert max-w-none text-muted-foreground text-lg leading-relaxed">
              <p>
                I'm Vijaya B, a DevOps and cloud automation engineer who's spent 7+ years untangling the infrastructure problems that slow engineering teams down. I've worked inside healthcare SaaS platforms and global consulting firms — environments where uptime isn't a preference, it's a contractual obligation.
              </p>
              <p>
                My work lives at the intersection of cloud governance, CI/CD reliability, Kubernetes operations, and secure delivery. I care deeply about automation not because it's trendy, but because manual processes create the kind of invisible debt that compounds until something breaks in production at 3am.
              </p>
              <p>
                I've reduced deployment failures, eliminated manual overhead, and built systems that teams trust to run without babysitting. Based in Mississauga, ON, Canada — open to remote and hybrid opportunities.
              </p>
            </div>

            <div className="glass-strong p-6 rounded-xl border-l-4 border-l-cyan-500 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 blur-3xl rounded-full" />
              <h3 className="text-sm uppercase tracking-widest text-cyan-400 font-semibold mb-2">Engineering Philosophy</h3>
              <p className="text-xl font-medium text-foreground italic relative z-10">
                "Automate what repeats. Secure what matters. Observe what runs. Improve what slows teams down."
              </p>
            </div>

            <div className="flex flex-wrap gap-4 pt-4 border-t border-white/10">
              <div className="glass px-4 py-2 rounded-lg text-sm">
                <span className="text-muted-foreground block text-xs uppercase">Location</span>
                <span className="font-medium">Mississauga, ON</span>
              </div>
              <div className="glass px-4 py-2 rounded-lg text-sm">
                <span className="text-muted-foreground block text-xs uppercase">Experience</span>
                <span className="font-medium">7+ Years</span>
              </div>
              <div className="glass px-4 py-2 rounded-lg text-sm">
                <span className="text-muted-foreground block text-xs uppercase">Email</span>
                <a href="mailto:bvijaycloud@gmail.com" className="font-medium text-cyan-400 hover:underline">bvijaycloud@gmail.com</a>
              </div>
              <div className="glass px-4 py-2 rounded-lg text-sm">
                <span className="text-muted-foreground block text-xs uppercase">LinkedIn</span>
                <a href="https://linkedin.com/in/b-vijaya" target="_blank" rel="noopener noreferrer" className="font-medium text-cyan-400 hover:underline">linkedin.com/in/b-vijaya</a>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
