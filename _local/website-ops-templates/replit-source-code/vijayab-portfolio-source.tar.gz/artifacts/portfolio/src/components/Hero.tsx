import { Button } from "@/components/ui/button";
import RoboCharacter from "./RoboCharacter";
import RoboTerminal from "./RoboTerminal";

const stats = [
  { v: "7+", u: "Yrs", label: "Experience" },
  { v: "30–40", u: "%", label: "Deploy Failures Cut" },
  { v: "90", u: "%", label: "Manual Effort Removed" },
  { v: "99.9", u: "%", label: "Uptime Supported" },
];

export default function Hero() {
  return (
    <section
      id="home"
      className="relative w-full grid-bg"
      style={{ minHeight: "100vh" }}
    >
      {/* Sticky wrapper — fills full viewport height and centers the grid */}
      <div style={{
        position: "sticky",
        top: 0,
        height: "100vh",
        display: "flex",
        alignItems: "center",
        paddingTop: 64,
        paddingBottom: 32,
        boxSizing: "border-box",
      }}>
        <div className="container mx-auto px-6 w-full">
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 48, alignItems: "start" }}>

            {/* ── LEFT COLUMN ── */}
            <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
              <div className="inline-flex items-center gap-2 self-start px-3 py-1.5 rounded-full border border-cyan-500/30 bg-cyan-500/10 text-cyan-400 text-sm font-medium">
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                Available for Opportunities
              </div>

              <h1 className="font-display font-bold leading-[1.08] tracking-tight text-white"
                style={{ fontSize: "clamp(1.8rem, 2.6vw, 2.8rem)", margin: 0 }}>
                I Build{" "}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-violet-500">
                  AI-Ready
                </span>{" "}
                Cloud Platforms That Scale, Secure, and Automate Enterprise Delivery.
              </h1>

              <p className="text-muted-foreground leading-relaxed" style={{ fontSize: 15, margin: 0 }}>
                DevOps Engineer with 7+ years across AWS, Azure, Kubernetes, CI/CD,
                IaC, DevSecOps, and observability — helping teams reduce failures,
                automate operations, and ship with confidence.
              </p>

              <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
                <Button asChild size="lg" className="bg-cyan-500 text-black hover:bg-cyan-400 font-semibold glow-cyan">
                  <a href="#case-studies">View Case Studies</a>
                </Button>
                <Button asChild size="lg" variant="outline" className="border-cyan-500/40 text-cyan-400 hover:bg-cyan-500/10">
                  <a href="/assets/resume.pdf" target="_blank" rel="noopener noreferrer">Download Resume</a>
                </Button>
                <Button asChild size="lg" variant="ghost" className="text-foreground/70 hover:text-cyan-400">
                  <a href="#contact">Contact Me</a>
                </Button>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12, paddingTop: 16, borderTop: "1px solid rgba(255,255,255,0.07)" }}>
                {stats.map((s, i) => (
                  <div key={i}>
                    <div className="font-display font-bold text-cyan-400" style={{ fontSize: 20, lineHeight: 1 }}>
                      {s.v}<span style={{ fontSize: 13 }}>{s.u}</span>
                    </div>
                    <div className="text-muted-foreground" style={{ fontSize: 9, marginTop: 5, textTransform: "uppercase", letterSpacing: "0.07em", lineHeight: 1.3 }}>
                      {s.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* ── RIGHT COLUMN ── */}
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {/* Robot card */}
              <div style={{
                height: 300,
                borderRadius: 18,
                border: "1px solid rgba(0,240,255,0.28)",
                background: "linear-gradient(145deg, rgba(4,18,38,0.96) 0%, rgba(2,10,22,0.98) 100%)",
                boxShadow: "0 0 40px rgba(0,240,255,0.08), 0 0 0 1px rgba(0,240,255,0.05) inset",
                position: "relative",
                overflow: "hidden",
              }}>
                <div style={{ position: "absolute", top: 10, left: 10, width: 16, height: 16, borderTop: "2px solid rgba(0,240,255,0.7)", borderLeft: "2px solid rgba(0,240,255,0.7)", borderRadius: "3px 0 0 0" }} />
                <div style={{ position: "absolute", top: 10, right: 10, width: 16, height: 16, borderTop: "2px solid rgba(139,92,246,0.7)", borderRight: "2px solid rgba(139,92,246,0.7)", borderRadius: "0 3px 0 0" }} />
                <div style={{ position: "absolute", bottom: 10, left: 10, width: 16, height: 16, borderBottom: "2px solid rgba(139,92,246,0.7)", borderLeft: "2px solid rgba(139,92,246,0.7)", borderRadius: "0 0 0 3px" }} />
                <div style={{ position: "absolute", bottom: 10, right: 10, width: 16, height: 16, borderBottom: "2px solid rgba(0,240,255,0.7)", borderRight: "2px solid rgba(0,240,255,0.7)", borderRadius: "0 0 3px 0" }} />
                <RoboCharacter />
              </div>
              <RoboTerminal />
            </div>

          </div>
        </div>
      </div>
    </section>
  );
}
