export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-cyan-500/20 bg-background/80 py-8 relative z-10">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-center md:text-left">
            <p className="text-foreground font-medium mb-1">Vijaya B — DevOps Engineer & Cloud Automation</p>
            <p className="text-sm text-muted-foreground">&copy; {currentYear} All rights reserved.</p>
          </div>
          
          <div className="flex items-center gap-6">
            <a href="#home" className="text-sm text-muted-foreground hover:text-cyan-400 transition-colors">Home</a>
            <a href="#about" className="text-sm text-muted-foreground hover:text-cyan-400 transition-colors">About</a>
            <a href="#case-studies" className="text-sm text-muted-foreground hover:text-cyan-400 transition-colors">Work</a>
            <a href="https://linkedin.com/in/b-vijaya" target="_blank" rel="noopener noreferrer" className="text-sm text-muted-foreground hover:text-cyan-400 transition-colors">LinkedIn</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
