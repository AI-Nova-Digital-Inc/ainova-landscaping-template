import { useRef } from "react";
import { motion, useInView, useReducedMotion } from "framer-motion";
import { Quote } from "lucide-react";

export default function Testimonials() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const shouldReduceMotion = useReducedMotion();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.2 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  const testimonials = [
    {
      quote: "Vijaya brings a rare combination of deep technical knowledge and genuine reliability engineering instinct. His Jenkins automation work single-handedly reduced our pipeline failure rate, and he did it without needing hand-holding.",
      name: "Alex M.",
      title: "Engineering Manager"
    },
    {
      quote: "Working with Vijaya on AWS governance at scale was impressive. He automated processes that took our team days per week and made it disappear entirely. The kind of engineer you build long-term around.",
      name: "Priya S.",
      title: "Cloud Architect"
    }
  ];

  return (
    <section id="testimonials" className="py-24 relative z-10">
      <div className="container mx-auto px-4 md:px-6">
        <div className="mb-16 text-center">
          <h2 className="text-3xl md:text-4xl font-bold font-display inline-block">
            What People Say
            <div className="h-1 w-full bg-violet-500 mt-2 rounded-full mx-auto" />
          </h2>
        </div>

        <motion.div 
          ref={ref}
          variants={shouldReduceMotion ? {} : containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto"
        >
          {testimonials.map((t, idx) => (
            <motion.div 
              key={idx}
              variants={itemVariants}
              className="glass-strong p-8 rounded-2xl relative border border-white/10"
            >
              <Quote className="w-10 h-10 text-cyan-500/20 absolute top-6 left-6" />
              <p className="text-lg text-foreground italic leading-relaxed relative z-10 mb-6 pt-4">
                "{t.quote}"
              </p>
              <div className="flex items-center justify-between border-t border-white/5 pt-4 mt-auto relative z-10">
                <div>
                  <h4 className="font-bold text-cyan-400">{t.name}</h4>
                  <span className="text-sm text-muted-foreground">{t.title}</span>
                </div>
                {/* Replace with real testimonial from colleague or manager */}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
