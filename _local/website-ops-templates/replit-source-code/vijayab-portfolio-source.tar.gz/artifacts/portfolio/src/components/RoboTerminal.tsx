import { useState, useEffect, useRef } from "react";

const SEQUENCES = [
  {
    cmd: "kubectl get pods --all-namespaces",
    output: [
      { text: "NAMESPACE     NAME                          READY   STATUS    RESTARTS", color: "#8b9db5" },
      { text: "prod          api-gateway-7d9f8b-xk2p9      1/1     Running   0", color: "#10b981" },
      { text: "prod          auth-service-6cf9d-m4nv7      1/1     Running   0", color: "#10b981" },
      { text: "monitoring    prometheus-0                  1/1     Running   0", color: "#10b981" },
      { text: "monitoring    grafana-5d8c7f-p9qt2          1/1     Running   0", color: "#10b981" },
    ],
  },
  {
    cmd: "terraform plan -out=prod.tfplan",
    output: [
      { text: "Refreshing state... aws_iam_role.lambda_exec", color: "#8b9db5" },
      { text: "Plan: 3 to add, 1 to change, 0 to destroy.", color: "#00f0ff" },
      { text: "  + aws_lambda_function.governance_check", color: "#10b981" },
      { text: "  + aws_cloudwatch_event_rule.daily_audit", color: "#10b981" },
      { text: "  ~ aws_iam_policy.tagging_enforcer", color: "#f59e0b" },
    ],
  },
  {
    cmd: "helm upgrade --install app ./chart -n prod",
    output: [
      { text: "Release \"app\" does not exist. Installing now.", color: "#8b9db5" },
      { text: "W: Coercing \"1\" to int. Use dquotes: \"1\"", color: "#f59e0b" },
      { text: "STATUS: deployed", color: "#10b981" },
      { text: "REVISION: 12", color: "#00f0ff" },
      { text: "NOTES: App deployed. Access via ingress.", color: "#8b9db5" },
    ],
  },
  {
    cmd: "aws iam list-users --query 'Users[*].UserName'",
    output: [
      { text: "[", color: "#8b9db5" },
      { text: '    "vijaya.b",', color: "#00f0ff" },
      { text: '    "svc-lambda-exec",', color: "#00f0ff" },
      { text: '    "svc-governance-bot",', color: "#00f0ff" },
      { text: "]", color: "#8b9db5" },
    ],
  },
  {
    cmd: "ansible-playbook deploy.yml --check -i prod",
    output: [
      { text: "PLAY [Deploy microservices] ****", color: "#8b9db5" },
      { text: "TASK [Pull latest Docker image] ok: [prod-node-01]", color: "#10b981" },
      { text: "TASK [Restart services]        ok: [prod-node-01]", color: "#10b981" },
      { text: "PLAY RECAP: prod-node-01 ok=2  changed=0  failed=0", color: "#00f0ff" },
    ],
  },
];

type Line = { text: string; color: string; isCmd?: boolean };

export default function RoboTerminal() {
  const [lines, setLines] = useState<Line[]>([]);
  const [typing, setTyping] = useState("");
  const [seqIdx, setSeqIdx] = useState(0);
  const [phase, setPhase] = useState<"typing" | "output" | "pause">("typing");
  const [outputIdx, setOutputIdx] = useState(0);
  const [charIdx, setCharIdx] = useState(0);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [lines, typing]);

  useEffect(() => {
    const seq = SEQUENCES[seqIdx % SEQUENCES.length];

    if (phase === "typing") {
      if (charIdx < seq.cmd.length) {
        const t = setTimeout(() => {
          setTyping(seq.cmd.slice(0, charIdx + 1));
          setCharIdx((c) => c + 1);
        }, 40 + Math.random() * 30);
        return () => clearTimeout(t);
      } else {
        const t = setTimeout(() => {
          setLines((l) => [...l, { text: typing, isCmd: true, color: "#00f0ff" }]);
          setTyping("");
          setPhase("output");
          setOutputIdx(0);
        }, 300);
        return () => clearTimeout(t);
      }
    }

    if (phase === "output") {
      if (outputIdx < seq.output.length) {
        const t = setTimeout(() => {
          setLines((l) => [...l, seq.output[outputIdx]]);
          setOutputIdx((i) => i + 1);
        }, 90);
        return () => clearTimeout(t);
      } else {
        const t = setTimeout(() => {
          setPhase("pause");
        }, 1200);
        return () => clearTimeout(t);
      }
    }

    if (phase === "pause") {
      const t = setTimeout(() => {
        // Keep last 20 lines max to avoid overflow
        setLines((l) => (l.length > 20 ? l.slice(l.length - 20) : l));
        setSeqIdx((i) => i + 1);
        setCharIdx(0);
        setPhase("typing");
      }, 1500);
      return () => clearTimeout(t);
    }
  }, [phase, charIdx, outputIdx, seqIdx, typing]);

  return (
    <div className="w-full rounded-xl overflow-hidden border border-cyan-400/15 bg-[#050d18]/90 backdrop-blur-md shadow-2xl"
      style={{ boxShadow: "0 0 40px rgba(0,240,255,0.08), 0 8px 32px rgba(0,0,0,0.6)" }}>
      {/* Title bar */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5 bg-[#070f1c]">
        <span className="w-3 h-3 rounded-full bg-red-500/80" />
        <span className="w-3 h-3 rounded-full bg-yellow-500/80" />
        <span className="w-3 h-3 rounded-full bg-green-500/80" />
        <span className="ml-3 text-xs font-mono text-[#4a7a8a] tracking-wider">vijaya@devops-cluster:~$</span>
        <span className="ml-auto text-xs font-mono text-[#2a4a5a]">SSH · prod-cluster-01</span>
      </div>

      {/* Terminal body */}
      <div className="px-4 py-3 font-mono text-xs leading-5 h-48 overflow-hidden relative">
        {/* Scan line overlay */}
        <div className="absolute inset-0 pointer-events-none"
          style={{
            background: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.06) 2px, rgba(0,0,0,0.06) 4px)",
          }}
        />

        {lines.map((line, i) => (
          <div key={i} className="flex gap-2 items-start">
            {line.isCmd && (
              <span className="text-violet-400 shrink-0">›</span>
            )}
            <span style={{ color: line.color, wordBreak: "break-all" }}>{line.text}</span>
          </div>
        ))}

        {/* Active typing line */}
        {phase === "typing" && (
          <div className="flex gap-2 items-center">
            <span className="text-violet-400 shrink-0">›</span>
            <span className="text-cyan-400">{typing}</span>
            <span className="inline-block w-2 h-3.5 bg-cyan-400 ml-0.5 animate-pulse" />
          </div>
        )}

        {/* Idle cursor when not typing */}
        {phase !== "typing" && (
          <div className="flex gap-2 items-center">
            <span className="text-violet-400 shrink-0">›</span>
            <span className="inline-block w-2 h-3.5 bg-cyan-400/70 animate-pulse" />
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Status bar */}
      <div className="flex items-center gap-4 px-4 py-2 border-t border-white/5 bg-[#070f1c]/80">
        <span className="flex items-center gap-1.5 text-[10px] font-mono text-green-400">
          <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
          Connected
        </span>
        <span className="text-[10px] font-mono text-[#2a5a6a]">AKS · us-east-1</span>
        <span className="ml-auto text-[10px] font-mono text-[#2a5a6a]">
          {new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </span>
      </div>
    </div>
  );
}
