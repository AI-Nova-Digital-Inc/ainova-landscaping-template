import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Mail, MapPin, Github, Linkedin } from "lucide-react";

export default function Contact() {
  const [status, setStatus] = useState<"idle" | "success">("idle");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("success");
    setTimeout(() => setStatus("idle"), 5000);
  };

  return (
    <section id="contact" className="py-24 relative z-10 bg-background/50 border-t border-white/5">
      <div className="container mx-auto px-4 md:px-6 max-w-6xl">
        <div className="mb-12">
          <h2 className="text-3xl md:text-5xl font-bold font-display text-foreground max-w-2xl">
            Have a cloud, AI, or automation project in mind? Let's build something reliable.
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-12 lg:gap-24">
          {/* Form */}
          <div className="glass p-6 md:p-8 rounded-2xl border border-white/10">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-muted-foreground">Name</Label>
                <Input id="name" required className="bg-background/50 border-white/10 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email" className="text-muted-foreground">Email</Label>
                <Input id="email" type="email" required className="bg-background/50 border-white/10 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subject" className="text-muted-foreground">Subject</Label>
                <Input id="subject" required className="bg-background/50 border-white/10 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="message" className="text-muted-foreground">Message</Label>
                <Textarea id="message" required rows={5} className="bg-background/50 border-white/10 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 resize-none" />
              </div>

              {status === "success" ? (
                <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-md text-sm font-medium">
                  Message sent! I'll get back to you within 24 hours.
                </div>
              ) : (
                <Button type="submit" className="w-full bg-cyan-500 text-black hover:bg-cyan-400 glow-cyan">
                  Send Message
                </Button>
              )}
            </form>
          </div>

          {/* Contact Info */}
          <div className="flex flex-col justify-center space-y-8">
            <div className="flex items-start gap-4">
              <div className="p-3 glass rounded-lg text-cyan-400">
                <Mail size={24} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-1">Email</h3>
                <a href="mailto:bvijaycloud@gmail.com" className="text-muted-foreground hover:text-cyan-400 transition-colors">
                  bvijaycloud@gmail.com
                </a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-3 glass rounded-lg text-violet-400">
                <MapPin size={24} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-1">Location</h3>
                <p className="text-muted-foreground">Mississauga, ON, Canada</p>
              </div>
            </div>

            <div className="pt-8 border-t border-white/10">
              <h3 className="text-lg font-semibold text-foreground mb-4">Connect</h3>
              <div className="flex gap-4">
                <a href="https://linkedin.com/in/b-vijaya" target="_blank" rel="noopener noreferrer" className="p-3 glass rounded-lg text-foreground hover:text-cyan-400 hover:glow-cyan transition-all" aria-label="LinkedIn">
                  <Linkedin size={24} />
                </a>
                <a href="#" target="_blank" rel="noopener noreferrer" className="p-3 glass rounded-lg text-foreground hover:text-violet-400 hover:glow-violet transition-all" aria-label="GitHub">
                  <Github size={24} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
