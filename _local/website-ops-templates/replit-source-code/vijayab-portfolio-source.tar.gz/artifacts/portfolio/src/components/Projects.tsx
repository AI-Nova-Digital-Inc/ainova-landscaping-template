import { useRef } from "react";
import { motion, useInView, useReducedMotion } from "framer-motion";
import { Github, ExternalLink } from "lucide-react";

export default function Projects() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const shouldReduceMotion = useReducedMotion();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.15 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  const projects = [
    {
      title: "Kubernetes Microservices Deployment Platform",
      desc: "A reusable deployment system helping engineering teams ship microservices faster using Docker, Helm, Kubernetes, Jenkins, and GitHub Actions.",
      tags: ["Kubernetes", "Helm", "Docker", "Jenkins", "GitHub Actions"]
    },
    {
      title: "AWS Account Governance Automation",
      desc: "A Python/Boto3 automation framework helping cloud teams enforce tagging, OU placement, IAM baselines, and compliance across AWS accounts.",
      tags: ["Python", "Boto3", "AWS Lambda", "EventBridge", "CloudWatch", "Organizations"]
    },
    {
      title: "CI/CD Pipeline Reliability Toolkit",
      desc: "A Jenkins automation toolkit reducing build failures using retries, dynamic agents, validation stages, and better failure handling.",
      tags: ["Jenkins", "Groovy", "GitHub Actions", "YAML", "Bash"]
    },
    {
      title: "DevSecOps Security Gate Pipeline",
      desc: "A secure delivery workflow blocking unsafe deployments using SonarQube, Fortify, secret scanning, and policy validation.",
      tags: ["SonarQube", "Fortify", "GitHub Advanced Security", "NexusIQ", "Ansible"]
    },
    {
      title: "Observability Command Center",
      desc: "A monitoring solution using Prometheus, Grafana, Alertmanager, Dynatrace, CloudWatch, and ELK to reduce incident response time by 40%.",
      tags: ["Prometheus", "Grafana", "Alertmanager", "Dynatrace", "ELK", "CloudWatch"]
    }
  ];

  return (
    <section id="projects" className="py-24 relative z-10 bg-background/50 border-y border-white/5">
      <div className="container mx-auto px-4 md:px-6">
        <div className="mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-display inline-block">
            Projects
            <div className="h-1 w-full bg-violet-500 mt-2 rounded-full" />
          </h2>
        </div>

        <motion.div 
          ref={ref}
          variants={shouldReduceMotion ? {} : containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {projects.map((project, idx) => (
            <motion.div 
              key={idx}
              variants={itemVariants}
              className="glass p-6 rounded-xl flex flex-col h-full relative group overflow-hidden border border-white/5"
            >
              {/* Top animated border */}
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-500 to-violet-500 transform origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
              
              <h3 className="text-xl font-bold font-display text-foreground mb-3">{project.title}</h3>
              <p className="text-sm text-muted-foreground mb-6 flex-grow leading-relaxed">
                {project.desc}
              </p>
              
              <div className="flex flex-wrap gap-2 mb-6 mt-auto">
                {project.tags.map((tag, tIdx) => (
                  <span key={tIdx} className="text-[10px] px-2 py-1 bg-background rounded border border-white/10 text-muted-foreground">
                    {tag}
                  </span>
                ))}
              </div>

              <div className="flex items-center gap-4 pt-4 border-t border-white/10">
                <a href="#" className="flex items-center text-xs font-medium text-foreground hover:text-cyan-400 transition-colors gap-1.5" onClick={(e) => e.preventDefault()}>
                  <Github size={14} /> Source
                </a>
                <a href="#case-studies" className="flex items-center text-xs font-medium text-foreground hover:text-violet-400 transition-colors gap-1.5">
                  <ExternalLink size={14} /> Case Study
                </a>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
