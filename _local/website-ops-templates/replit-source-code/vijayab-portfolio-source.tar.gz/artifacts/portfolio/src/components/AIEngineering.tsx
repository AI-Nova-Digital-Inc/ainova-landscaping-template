import { useRef } from "react";
import { motion, useInView, useReducedMotion } from "framer-motion";
import { Brain, Bot, LineChart, Network, Settings, Fingerprint } from "lucide-react";

export default function AIEngineering() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const shouldReduceMotion = useReducedMotion();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.15 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  const features = [
    {
      icon: <Brain className="w-6 h-6 text-cyan-400" />,
      title: "AI-Assisted CI/CD Analysis",
      desc: "Using LLMs to analyze pipeline failure patterns, predict flaky tests, and suggest fixes before engineers even look at logs."
    },
    {
      icon: <Fingerprint className="w-6 h-6 text-violet-400" />,
      title: "Automated Incident Insights",
      desc: "AI-powered runbooks that correlate alerts, surface root causes, and reduce mean time to resolution."
    },
    {
      icon: <LineChart className="w-6 h-6 text-emerald-400" />,
      title: "Cloud Cost Intelligence",
      desc: "Anomaly detection on cloud spend using ML models trained on historical billing and usage patterns."
    },
    {
      icon: <Network className="w-6 h-6 text-cyan-400" />,
      title: "Infrastructure Automation",
      desc: "AI-generated Terraform and Ansible code that adapts to environment context and enforces compliance automatically."
    },
    {
      icon: <Bot className="w-6 h-6 text-violet-400" />,
      title: "LLM-Powered Internal Tools",
      desc: "Building internal chatbots and copilots that give teams instant access to runbooks, incident history, and infrastructure documentation."
    },
    {
      icon: <Settings className="w-6 h-6 text-emerald-400" />,
      title: "AI Agent Workflows",
      desc: "Autonomous agents that monitor deployment health, trigger rollbacks, file tickets, and page on-call — with zero human intervention."
    }
  ];

  return (
    <section id="ai-engineering" className="py-24 relative z-10 grid-bg">
      <div className="absolute inset-0 bg-background/80 pointer-events-none" />
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="mb-12 max-w-3xl">
          <h2 className="text-3xl md:text-4xl font-bold font-display mb-4 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-violet-500">
            AI-Ready Engineering
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            The next evolution of DevOps isn't just automation — it's intelligence. I'm building at the intersection of AI capabilities and enterprise infrastructure.
          </p>
        </div>

        <motion.div 
          ref={ref}
          variants={shouldReduceMotion ? {} : containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16"
        >
          {features.map((feat, idx) => (
            <motion.div 
              key={idx}
              variants={itemVariants}
              className="glass p-6 rounded-xl border border-white/5 hover:border-cyan-500/20 transition-colors"
            >
              <div className="bg-background/50 w-12 h-12 rounded-lg flex items-center justify-center mb-4 border border-white/5">
                {feat.icon}
              </div>
              <h3 className="text-lg font-semibold font-display text-foreground mb-2">{feat.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{feat.desc}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* Pipeline Visualization */}
        <div className="mt-16 glass-strong p-8 rounded-2xl overflow-x-auto">
          <div className="min-w-[800px] flex items-center justify-between relative">
            {/* Connecting line */}
            <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-white/10 -translate-y-1/2 z-0" />
            <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-cyan-500 via-violet-500 to-emerald-500 -translate-y-1/2 z-0 animate-pulse" />
            
            {["DATA", "AUTOMATION", "CLOUD", "DEPLOYMENT", "MONITORING", "FEEDBACK"].map((node, i) => (
              <div key={i} className="relative z-10 flex flex-col items-center">
                <div className="w-4 h-4 rounded-full bg-background border-2 border-cyan-400 mb-2 glow-cyan" />
                <span className="text-xs font-mono font-medium text-foreground tracking-wider bg-background px-2 py-1 rounded border border-white/10">{node}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
