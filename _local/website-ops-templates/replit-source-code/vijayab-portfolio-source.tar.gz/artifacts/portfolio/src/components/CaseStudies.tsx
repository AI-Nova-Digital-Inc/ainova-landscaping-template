import { useRef, useState } from "react";
import { motion, useInView, useReducedMotion } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

export default function CaseStudies() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const shouldReduceMotion = useReducedMotion();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.2 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  const studies = [
    {
      title: "Jenkins Reliability Engineering",
      problem: "Production pipelines were failing due to Git checkout issues, connectivity failures, and unstable agents.",
      solution: "Added retry logic, try/catch blocks, dynamic agent provisioning, and improved pipeline resilience.",
      impact: "Reduced Jenkins pipeline build failures by 30%",
      tech: ["Jenkins", "Groovy", "GitHub Actions", "Bash", "YAML"],
      breakdown: "Implemented Groovy-based retry wrappers around checkout steps with exponential backoff. Created dynamic agent provisioning via Jenkins Kubernetes plugin. Added try/catch blocks at stage and pipeline level with structured failure reporting to Slack. Configured agent pool auto-scaling based on queue depth."
    },
    {
      title: "AWS Cloud Governance Automation",
      problem: "Governance across 50+ AWS accounts required manual oversight and consistent security enforcement.",
      solution: "Built Python/Boto3 + Lambda automations for governance, tagging, OU placement, IAM controls, and reporting.",
      impact: "Reduced manual oversight by 90% and achieved 100% compliance with AWS security standards",
      tech: ["Python", "Boto3", "AWS Lambda", "EventBridge", "CloudWatch", "Organizations"],
      breakdown: "Built event-driven Lambda functions triggered by EventBridge to auto-assign accounts to correct OUs. Created daily IAM key rotation system (scan → rotate at 90 days → disable at 100 → delete at 110). Automated tagging compliance audits with S3 report generation and SNS alerts for non-compliant teams."
    },
    {
      title: "Kubernetes Microservice Delivery",
      problem: "Microservice onboarding and deployment needed standardization and speed across engineering teams.",
      solution: "Built Helm-based Kubernetes deployments, Docker workflows, and Python/Jenkins automation for manifest and job generation.",
      impact: "Reduced per-service setup time by 50% and release cycle duration by 25%",
      tech: ["Kubernetes", "Helm", "Docker", "Jenkins", "Python", "AKS"],
      breakdown: "Built a Python tool integrated with Jenkins that auto-generates build jobs and Kubernetes manifests for new microservices. Created standardized Helm chart templates with zero-downtime rolling deployment strategies. Provisioned CI/CD agents and supporting infra via Terraform and Ansible to eliminate configuration drift."
    },
    {
      title: "DevSecOps Quality Gates",
      problem: "Vulnerabilities and misconfigurations were reaching deployment environments, creating security and compliance risk.",
      solution: "Integrated SonarQube, Fortify, GitHub Actions, Jenkins, Azure Key Vault scanning, and pre-merge validation into a unified security gate.",
      impact: "Reduced post-deployment security defects by 30%",
      tech: ["SonarQube", "Fortify SSC/FoD", "GHAS", "Ansible", "Jenkins"],
      breakdown: "Enforced SonarQube quality gates blocking merges on quality threshold failures. Integrated Fortify SSC and FoD for SAST scanning in both Jenkins and GitHub Actions. Built pre-merge configuration validation pipeline using Ansible that enforces syntax checks and Azure Key Vault secret scanning."
    }
  ];

  return (
    <section id="case-studies" className="py-24 relative z-10 bg-background/30">
      <div className="container mx-auto px-4 md:px-6">
        <div className="mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-display inline-block">
            Case Studies
            <div className="h-1 w-full bg-violet-500 mt-2 rounded-full" />
          </h2>
        </div>

        <motion.div 
          ref={ref}
          variants={shouldReduceMotion ? {} : containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid gap-8"
        >
          {studies.map((study, idx) => (
            <CaseStudyCard key={idx} study={study} variants={itemVariants} />
          ))}
        </motion.div>
      </div>
    </section>
  );
}

function CaseStudyCard({ study, variants }: { study: any, variants: any }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <motion.div 
      variants={variants}
      className="glass rounded-2xl overflow-hidden hover:scale-[1.01] transition-transform duration-300 border border-white/5 hover:border-violet-500/30 hover:glow-violet"
    >
      <div className="p-6 md:p-8">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="flex-1 space-y-4">
            <h3 className="text-2xl font-bold font-display text-foreground">{study.title}</h3>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-sm text-red-400 font-medium mb-1 uppercase tracking-wider">Problem</h4>
                <p className="text-muted-foreground text-sm leading-relaxed">{study.problem}</p>
              </div>
              <div>
                <h4 className="text-sm text-emerald-400 font-medium mb-1 uppercase tracking-wider">Solution</h4>
                <p className="text-muted-foreground text-sm leading-relaxed">{study.solution}</p>
              </div>
            </div>

            <div className="bg-violet-500/10 border border-violet-500/20 p-4 rounded-lg mt-4 inline-block">
              <h4 className="text-xs text-violet-300 font-medium uppercase tracking-wider mb-1">Business Impact</h4>
              <p className="text-violet-100 font-semibold">{study.impact}</p>
            </div>
          </div>

          <div className="md:w-64 flex-shrink-0">
            <h4 className="text-xs text-muted-foreground font-medium mb-2 uppercase tracking-wider">Tech Stack</h4>
            <div className="flex flex-wrap gap-2">
              {study.tech.map((t: string, i: number) => (
                <span key={i} className="text-xs px-2 py-1 bg-white/5 border border-white/10 rounded text-foreground">
                  {t}
                </span>
              ))}
            </div>
          </div>
        </div>

        <Collapsible open={isOpen} onOpenChange={setIsOpen} className="mt-6 border-t border-white/10 pt-4">
          <CollapsibleTrigger className="flex items-center gap-2 text-sm font-medium text-cyan-400 hover:text-cyan-300 transition-colors w-full">
            <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
            View Technical Breakdown
          </CollapsibleTrigger>
          <CollapsibleContent className="pt-4 text-sm text-muted-foreground leading-relaxed animate-in slide-in-from-top-2">
            {study.breakdown}
          </CollapsibleContent>
        </Collapsible>
      </div>
    </motion.div>
  );
}
