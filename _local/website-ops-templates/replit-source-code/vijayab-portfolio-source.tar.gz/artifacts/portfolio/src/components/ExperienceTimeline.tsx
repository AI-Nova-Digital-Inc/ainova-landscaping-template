import { useRef } from "react";
import { motion, useInView, useReducedMotion } from "framer-motion";

export default function ExperienceTimeline() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const shouldReduceMotion = useReducedMotion();

  const experiences = [
    {
      role: "DevOps Analyst",
      company: "PointClickCare",
      period: "Mar 2024 – Present",
      location: "Mississauga, ON",
      desc: "Healthcare SaaS platform serving 1,500+ users. Driving CI/CD reliability, Kubernetes operations on AKS, IaC with Terraform/Ansible, DevSecOps tooling integration, and Atlassian suite administration.",
      wins: [
        "30% pipeline failure reduction",
        "50% microservice onboarding speedup",
        "40% faster incident response",
        "60% less manual Jira ticket logging"
      ],
      tags: ["Kubernetes", "Jenkins", "GH Actions", "Terraform", "SonarQube"]
    },
    {
      role: "Sr. Systems Engineer – Cloud & Automation",
      company: "Deloitte",
      period: "Nov 2022 – Feb 2024",
      location: "Toronto, ON",
      desc: "Global consulting firm. Owned AWS multi-account cloud governance, IAM security automation, and hybrid observability across 50+ AWS accounts.",
      wins: [
        "90% manual oversight reduction",
        "100% AWS compliance",
        "80% provisioning error reduction",
        "50% faster incident detection"
      ],
      tags: ["AWS", "Python", "Boto3", "Lambda", "Dynatrace"]
    },
    {
      role: "DevOps Engineer",
      company: "Roche",
      period: "Mar 2022 – Oct 2022",
      location: "Mississauga, ON",
      desc: "Regulated healthcare environment. On-prem Kubernetes operations via Rancher, GitLab CI/CD pipelines, and L3 operational support.",
      wins: [
        "20% cluster uptime improvement",
        "25% fewer failed deployments",
        "30% fewer configuration errors"
      ],
      tags: ["Kubernetes", "Rancher", "GitLab CI/CD", "Helm"]
    },
    {
      role: "IT Support Specialist & System Administrator",
      company: "BLS International",
      period: "Apr 2017 – Feb 2022",
      location: "Mississauga, ON",
      desc: "Administered Windows-based systems and databases for consular visa/passport services. Maintained 99.9% application uptime.",
      wins: [
        "99.9% uptime",
        "40% fewer system failures",
        "100% regulatory compliance"
      ],
      tags: ["Windows Server", "Active Directory", "Linux"]
    }
  ];

  return (
    <section id="experience" className="py-24 relative z-10">
      <div className="container mx-auto px-4 md:px-6">
        <div className="mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-display inline-block">
            Career Timeline
            <div className="h-1 w-full bg-cyan-500 mt-2 rounded-full" />
          </h2>
        </div>

        <div ref={ref} className="relative max-w-4xl mx-auto">
          {/* Center Line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-cyan-500 via-violet-500 to-transparent transform md:-translate-x-1/2" />

          {experiences.map((exp, idx) => (
            <TimelineItem 
              key={idx} 
              exp={exp} 
              index={idx} 
              isInView={isInView} 
              shouldReduceMotion={shouldReduceMotion} 
            />
          ))}
        </div>
      </div>
    </section>
  );
}

function TimelineItem({ exp, index, isInView, shouldReduceMotion }: { exp: any, index: number, isInView: boolean, shouldReduceMotion: boolean }) {
  const isEven = index % 2 === 0;
  
  const variants = {
    hidden: { opacity: 0, x: shouldReduceMotion ? 0 : (isEven ? -50 : 50) },
    visible: { 
      opacity: 1, 
      x: 0, 
      transition: { duration: 0.6, delay: index * 0.2 } 
    }
  };

  return (
    <div className={`relative flex flex-col md:flex-row items-center mb-12 ${isEven ? 'md:flex-row-reverse' : ''}`}>
      {/* Node */}
      <div className="absolute left-4 md:left-1/2 w-4 h-4 rounded-full bg-background border-2 border-cyan-400 transform -translate-x-[7px] md:-translate-x-1/2 mt-6 md:mt-0 z-10 glow-cyan" />

      {/* Spacer for alternating layout */}
      <div className="hidden md:block w-1/2 px-8" />

      {/* Content Card */}
      <motion.div 
        variants={variants}
        initial="hidden"
        animate={isInView ? "visible" : "hidden"}
        className="w-full pl-12 md:pl-0 md:w-1/2 md:px-8 mt-4 md:mt-0"
      >
        <div className="glass p-6 rounded-xl border border-white/5 hover:border-cyan-500/30 transition-colors relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1 h-full bg-cyan-500 transform origin-top scale-y-0 group-hover:scale-y-100 transition-transform duration-300" />
          
          <div className="flex flex-col gap-1 mb-4">
            <span className="text-cyan-400 font-mono text-sm">{exp.period}</span>
            <h3 className="text-xl font-bold text-foreground font-display">{exp.role}</h3>
            <span className="text-muted-foreground text-sm font-medium">{exp.company} • {exp.location}</span>
          </div>

          <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
            {exp.desc}
          </p>

          <div className="mb-4">
            <h4 className="text-xs uppercase tracking-wider text-foreground mb-2">Key Wins:</h4>
            <ul className="grid grid-cols-1 gap-1">
              {exp.wins.map((win: string, i: number) => (
                <li key={i} className="text-xs text-muted-foreground flex items-start">
                  <span className="text-cyan-400 mr-2 mt-0.5">▹</span> {win}
                </li>
              ))}
            </ul>
          </div>

          <div className="flex flex-wrap gap-2 pt-2 border-t border-white/5">
            {exp.tags.map((tag: string, i: number) => (
              <span key={i} className="text-[10px] px-2 py-1 bg-white/5 rounded text-foreground">
                {tag}
              </span>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
