import { useEffect, useRef, useState, useCallback } from "react";

const ROBO_CSS = `
@keyframes rf { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-10px)} }
@keyframes rb { 0%,100%{opacity:1} 50%{opacity:0.18} }
@keyframes rs { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
@keyframes rp { 0%,100%{r:5.5;opacity:0.85} 50%{r:7.5;opacity:1} }
@keyframes rm { 0%,40%,60%,100%{width:40px} 50%{width:60px} }
@keyframes ra-l { 0%,100%{transform:rotate(-4deg)} 50%{transform:rotate(4deg)} }
@keyframes ra-r { 0%,100%{transform:rotate(4deg)} 50%{transform:rotate(-4deg)} }
@keyframes rv { 0%{transform:translateY(0)} 100%{transform:translateY(56px)} }
@keyframes rg { 0%,100%{opacity:0.5} 50%{opacity:1} }
`;

export default function RoboCharacter() {
  const elRef = useRef<HTMLDivElement>(null);
  const [ex, setEx] = useState(0);
  const [ey, setEy] = useState(0);
  const [blink, setBlink] = useState(false);
  const bTimer = useRef<ReturnType<typeof setTimeout>>();

  const nextBlink = useCallback(() => {
    bTimer.current = setTimeout(() => {
      setBlink(true);
      setTimeout(() => { setBlink(false); nextBlink(); }, 110);
    }, 2800 + Math.random() * 2200);
  }, []);

  useEffect(() => { nextBlink(); return () => clearTimeout(bTimer.current); }, [nextBlink]);

  useEffect(() => {
    const fn = (e: MouseEvent) => {
      const r = elRef.current?.getBoundingClientRect();
      if (!r) return;
      setEx(Math.max(-1, Math.min(1, (e.clientX - r.left - r.width / 2) / 350)) * 4.5);
      setEy(Math.max(-1, Math.min(1, (e.clientY - r.top - r.height / 2) / 350)) * 3);
    };
    window.addEventListener("mousemove", fn);
    return () => window.removeEventListener("mousemove", fn);
  }, []);

  return (
    <div
      ref={elRef}
      style={{
        width: "100%", height: "100%",
        display: "flex", alignItems: "center", justifyContent: "center",
        position: "relative",
      }}
    >
      <style>{ROBO_CSS}</style>

      {/* Ground glow */}
      <div style={{
        position: "absolute", bottom: 0, left: "50%", transform: "translateX(-50%)",
        width: 140, height: 12, borderRadius: "50%", pointerEvents: "none",
        background: "rgba(0,240,255,0.14)", filter: "blur(8px)",
        animation: "rg 3.5s ease-in-out infinite",
      }} />

      {/* Robot — floating */}
      <div style={{ animation: "rf 3.6s ease-in-out infinite", filter: "drop-shadow(0 4px 28px rgba(0,240,255,0.3))" }}>
        <svg viewBox="0 0 200 270" width="190" height="250" xmlns="http://www.w3.org/2000/svg" aria-label="AI DevOps robot character">
          <defs>
            <linearGradient id="g-body" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#0d1e30" /><stop offset="100%" stopColor="#06101e" />
            </linearGradient>
            <linearGradient id="g-head" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#0f2438" /><stop offset="100%" stopColor="#060d1a" />
            </linearGradient>
            <radialGradient id="g-eye" cx="50%" cy="40%" r="55%">
              <stop offset="0%" stopColor="#00f0ff" />
              <stop offset="55%" stopColor="#00b8cc" stopOpacity="0.65" />
              <stop offset="100%" stopColor="#00f0ff" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="g-core" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#a78bfa" />
              <stop offset="60%" stopColor="#7c3aed" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#7c3aed" stopOpacity="0" />
            </radialGradient>
            <filter id="f-glow">
              <feGaussianBlur stdDeviation="2.5" result="b" />
              <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
            <filter id="f-glow2">
              <feGaussianBlur stdDeviation="5" result="b" />
              <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
            <clipPath id="cp-visor"><rect x="52" y="46" width="96" height="56" rx="10" /></clipPath>
          </defs>

          {/* ANTENNA */}
          <line x1="100" y1="30" x2="100" y2="10" stroke="#1c3d54" strokeWidth="3" strokeLinecap="round" />
          <circle cx="100" cy="8" r="5" fill="#00f0ff" filter="url(#f-glow)" style={{ animation: "rb 1.3s ease-in-out infinite" }} />

          {/* HEAD */}
          <rect x="42" y="28" width="116" height="92" rx="18" fill="url(#g-head)" stroke="#1c3d54" strokeWidth="1.5" />
          <g stroke="#0e2336" strokeWidth="0.8" opacity="0.6">
            <polyline points="58,40 72,40 72,50" fill="none" />
            <polyline points="142,40 128,40 128,50" fill="none" />
            <polyline points="58,108 72,108 72,100" fill="none" />
            <polyline points="142,108 128,108 128,100" fill="none" />
          </g>

          {/* VISOR */}
          <rect x="52" y="46" width="96" height="56" rx="10" fill="#030b15" stroke="rgba(0,240,255,0.22)" strokeWidth="1" />
          <rect x="52" y="0" width="96" height="3" fill="rgba(0,240,255,0.07)" clipPath="url(#cp-visor)"
            style={{ animation: "rv 2.8s linear infinite", transformOrigin: "52px 46px" }} />

          {/* LEFT EYE */}
          <circle cx="76" cy="72" r="14" fill="#040e1a" stroke="rgba(0,240,255,0.28)" strokeWidth="1" />
          <circle cx={76 + ex} cy={72 + ey} r="9" fill="url(#g-eye)" />
          <circle cx={76 + ex} cy={72 + ey} r="4.5" fill="#00f0ff" filter="url(#f-glow)" />
          <circle cx={77.5 + ex} cy={70.5 + ey} r="1.5" fill="white" opacity="0.65" />
          {blink && <rect x="62" y="64" width="28" height="16" rx="7" fill="#040e1a" />}

          {/* RIGHT EYE */}
          <circle cx="124" cy="72" r="14" fill="#040e1a" stroke="rgba(0,240,255,0.28)" strokeWidth="1" />
          <circle cx={124 + ex} cy={72 + ey} r="9" fill="url(#g-eye)" />
          <circle cx={124 + ex} cy={72 + ey} r="4.5" fill="#00f0ff" filter="url(#f-glow)" />
          <circle cx={125.5 + ex} cy={70.5 + ey} r="1.5" fill="white" opacity="0.65" />
          {blink && <rect x="110" y="64" width="28" height="16" rx="7" fill="#040e1a" />}

          {/* MOUTH */}
          <rect x="68" y="108" width="64" height="6" rx="3" fill="#060f1c" />
          <rect x="68" y="108" width="40" height="6" rx="3" fill="#00f0ff" filter="url(#f-glow)"
            style={{ animation: "rm 5s ease-in-out infinite" }} />

          {/* NECK */}
          <rect x="86" y="120" width="28" height="14" rx="5" fill="#080f1e" stroke="#1c3d54" strokeWidth="1" />
          <line x1="93" y1="121" x2="93" y2="133" stroke="#1c3d54" strokeWidth="1" />
          <line x1="100" y1="121" x2="100" y2="133" stroke="#1c3d54" strokeWidth="1" />
          <line x1="107" y1="121" x2="107" y2="133" stroke="#1c3d54" strokeWidth="1" />

          {/* BODY */}
          <rect x="34" y="134" width="132" height="86" rx="14" fill="url(#g-body)" stroke="#1c3d54" strokeWidth="1.5" />
          <g stroke="#0b1e2e" strokeWidth="0.8" opacity="0.55">
            <polyline points="54,150 88,150 88,162 70,162" fill="none" />
            <polyline points="146,150 112,150 112,162 130,162" fill="none" />
            <line x1="54" y1="196" x2="146" y2="196" />
            <line x1="75" y1="196" x2="75" y2="210" />
            <line x1="125" y1="196" x2="125" y2="210" />
          </g>

          {/* CORE */}
          <rect x="72" y="148" width="56" height="44" rx="8" fill="#060d1a" stroke="rgba(139,92,246,0.35)" strokeWidth="1.5" />
          <circle cx="100" cy="170" r="14" fill="url(#g-core)" />
          <g style={{ transformOrigin: "100px 170px", animation: "rs 5s linear infinite" }}>
            <circle cx="100" cy="170" r="10" fill="none" stroke="#8b5cf6" strokeWidth="1.5" strokeDasharray="8 4" filter="url(#f-glow)" />
          </g>
          <circle cx="100" cy="170" r="5.5" fill="#a78bfa" filter="url(#f-glow2)" style={{ animation: "rp 2.2s ease-in-out infinite" }} />

          {/* SIDE LEDS */}
          <circle cx="48" cy="152" r="3.5" fill="#00f0ff" filter="url(#f-glow)" style={{ animation: "rb 1.6s ease-in-out infinite 0s" }} />
          <circle cx="152" cy="152" r="3.5" fill="#10b981" filter="url(#f-glow)" style={{ animation: "rb 1.6s ease-in-out infinite 0.5s" }} />
          <circle cx="48" cy="200" r="3" fill="#8b5cf6" filter="url(#f-glow)" style={{ animation: "rb 1.6s ease-in-out infinite 1s" }} />
          <circle cx="152" cy="200" r="3" fill="#00f0ff" filter="url(#f-glow)" style={{ animation: "rb 1.6s ease-in-out infinite 0.8s" }} />

          {/* LEFT ARM */}
          <g style={{ transformOrigin: "21px 140px", animation: "ra-l 3.2s ease-in-out infinite" }}>
            <rect x="8" y="134" width="27" height="70" rx="10" fill="url(#g-body)" stroke="#1c3d54" strokeWidth="1.5" />
            <rect x="13" y="148" width="17" height="7" rx="3" fill="#060d1a" />
            <rect x="13" y="148" width="6" height="7" rx="3" fill="#00f0ff" filter="url(#f-glow)" style={{ animation: "rm 3s ease-in-out infinite" }} />
            <rect x="10" y="198" width="23" height="11" rx="5.5" fill="#080f1e" stroke="#1c3d54" strokeWidth="1" />
          </g>

          {/* RIGHT ARM */}
          <g style={{ transformOrigin: "179px 140px", animation: "ra-r 3.2s ease-in-out infinite" }}>
            <rect x="165" y="134" width="27" height="70" rx="10" fill="url(#g-body)" stroke="#1c3d54" strokeWidth="1.5" />
            <rect x="170" y="148" width="17" height="7" rx="3" fill="#060d1a" />
            <rect x="170" y="148" width="6" height="7" rx="3" fill="#10b981" filter="url(#f-glow)" style={{ animation: "rm 3s ease-in-out infinite 0.7s" }} />
            <rect x="167" y="198" width="23" height="11" rx="5.5" fill="#080f1e" stroke="#1c3d54" strokeWidth="1" />
          </g>

          {/* LEGS */}
          <rect x="58" y="220" width="34" height="36" rx="8" fill="url(#g-body)" stroke="#1c3d54" strokeWidth="1.5" />
          <rect x="108" y="220" width="34" height="36" rx="8" fill="url(#g-body)" stroke="#1c3d54" strokeWidth="1.5" />
          <rect x="52" y="248" width="44" height="12" rx="6" fill="#070e1c" stroke="#1c3d54" strokeWidth="1" />
          <rect x="104" y="248" width="44" height="12" rx="6" fill="#070e1c" stroke="#1c3d54" strokeWidth="1" />
          <circle cx="75" cy="232" r="2.5" fill="#00f0ff" filter="url(#f-glow)" style={{ animation: "rb 2s ease-in-out infinite" }} />
          <circle cx="125" cy="232" r="2.5" fill="#8b5cf6" filter="url(#f-glow)" style={{ animation: "rb 2s ease-in-out infinite 1s" }} />
        </svg>
      </div>

      {/* Status badge */}
      <div style={{
        position: "absolute", top: 8, right: 0,
        fontSize: 11, fontFamily: "monospace",
        padding: "3px 8px", borderRadius: 6,
        border: "1px solid rgba(0,240,255,0.22)",
        background: "rgba(6,15,30,0.8)",
        backdropFilter: "blur(8px)",
        color: "#00f0ff",
        display: "flex", alignItems: "center", gap: 5,
        pointerEvents: "none",
      }}>
        <span style={{
          display: "inline-block", width: 7, height: 7, borderRadius: "50%",
          background: "#10b981", animation: "rb 1.2s ease-in-out infinite",
        }} />
        SYSTEM ONLINE
      </div>
    </div>
  );
}
