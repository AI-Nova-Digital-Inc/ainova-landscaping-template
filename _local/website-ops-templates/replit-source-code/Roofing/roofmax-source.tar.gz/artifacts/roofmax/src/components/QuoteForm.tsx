import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, ArrowLeft } from 'lucide-react';

const quoteSchema = z.object({
  name: z.string().min(2, "Name is required"),
  phone: z.string().min(10, "Valid phone number is required"),
  issue: z.string().min(10, "Please describe the issue"),
  address: z.string().min(5, "Address is required")
});

type FormValues = z.infer<typeof quoteSchema>;

export function QuoteForm() {
  const [step, setStep] = useState(1);
  const totalSteps = 4;

  const form = useForm<FormValues>({
    resolver: zodResolver(quoteSchema),
    defaultValues: {
      name: "",
      phone: "",
      issue: "",
      address: ""
    }
  });

  const onSubmit = (data: FormValues) => {
    toast.success("Inspection Requested! We will call you within 5 minutes.");
    form.reset();
    setStep(1);
  };

  const nextStep = async (fieldsToValidate: (keyof FormValues)[]) => {
    const isValid = await form.trigger(fieldsToValidate);
    if (isValid) {
      setStep(prev => Math.min(prev + 1, totalSteps));
    }
  };

  const prevStep = () => {
    setStep(prev => Math.max(prev - 1, 1));
  };

  const slideVariants = {
    initial: { x: 50, opacity: 0 },
    animate: { x: 0, opacity: 1, transition: { duration: 0.3 } },
    exit: { x: -50, opacity: 0, transition: { duration: 0.3 } }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 relative overflow-hidden min-h-[350px]">
        {/* Progress Bar */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-secondary rounded-full overflow-hidden">
          <motion.div 
            className="h-full bg-primary"
            initial={{ width: `${((step - 1) / totalSteps) * 100}%` }}
            animate={{ width: `${(step / totalSteps) * 100}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>

        <div className="pt-6">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div key="step1" variants={slideVariants} initial="initial" animate="animate" exit="exit" className="space-y-6">
                <div className="mb-4">
                  <h3 className="text-2xl font-black uppercase text-white mb-2">Who are we helping?</h3>
                  <p className="text-gray-400 font-medium">Let's start with your name.</p>
                </div>
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="uppercase font-black text-sm tracking-wider text-white">Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" className="h-16 bg-secondary border-2 border-border focus-visible:ring-primary focus-visible:border-primary rounded-none text-xl" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="button" onClick={() => nextStep(['name'])} className="w-full h-16 text-xl font-black uppercase tracking-widest bg-primary hover:bg-white hover:text-black transition-all border-none">
                  Next <ChevronRight className="ml-2 h-6 w-6" />
                </Button>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div key="step2" variants={slideVariants} initial="initial" animate="animate" exit="exit" className="space-y-6">
                <div className="mb-4">
                  <h3 className="text-2xl font-black uppercase text-white mb-2">How can we reach you?</h3>
                  <p className="text-gray-400 font-medium">We'll call you within 5 minutes.</p>
                </div>
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="uppercase font-black text-sm tracking-wider text-white">Phone Number</FormLabel>
                      <FormControl>
                        <Input placeholder="(555) 123-4567" className="h-16 bg-secondary border-2 border-border focus-visible:ring-primary focus-visible:border-primary rounded-none text-xl" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex gap-4">
                  <Button type="button" variant="outline" onClick={prevStep} className="h-16 px-6 bg-secondary border-2 border-border hover:bg-white hover:text-black">
                    <ArrowLeft className="h-6 w-6" />
                  </Button>
                  <Button type="button" onClick={() => nextStep(['phone'])} className="flex-1 h-16 text-xl font-black uppercase tracking-widest bg-primary hover:bg-white hover:text-black transition-all border-none">
                    Next <ChevronRight className="ml-2 h-6 w-6" />
                  </Button>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div key="step3" variants={slideVariants} initial="initial" animate="animate" exit="exit" className="space-y-6">
                <div className="mb-4">
                  <h3 className="text-2xl font-black uppercase text-white mb-2">Where is the property?</h3>
                  <p className="text-gray-400 font-medium">So we can dispatch our team.</p>
                </div>
                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="uppercase font-black text-sm tracking-wider text-white">Property Address</FormLabel>
                      <FormControl>
                        <Input placeholder="123 Main St, City, ST" className="h-16 bg-secondary border-2 border-border focus-visible:ring-primary focus-visible:border-primary rounded-none text-xl" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex gap-4">
                  <Button type="button" variant="outline" onClick={prevStep} className="h-16 px-6 bg-secondary border-2 border-border hover:bg-white hover:text-black">
                    <ArrowLeft className="h-6 w-6" />
                  </Button>
                  <Button type="button" onClick={() => nextStep(['address'])} className="flex-1 h-16 text-xl font-black uppercase tracking-widest bg-primary hover:bg-white hover:text-black transition-all border-none">
                    Next <ChevronRight className="ml-2 h-6 w-6" />
                  </Button>
                </div>
              </motion.div>
            )}

            {step === 4 && (
              <motion.div key="step4" variants={slideVariants} initial="initial" animate="animate" exit="exit" className="space-y-6">
                <div className="mb-4">
                  <h3 className="text-2xl font-black uppercase text-white mb-2">What's happening?</h3>
                  <p className="text-gray-400 font-medium">Describe the damage.</p>
                </div>
                <FormField
                  control={form.control}
                  name="issue"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="uppercase font-black text-sm tracking-wider text-white">Damage Description</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Leaking in the living room..." className="resize-none min-h-[120px] bg-secondary border-2 border-border focus-visible:ring-primary focus-visible:border-primary rounded-none text-xl" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex gap-4">
                  <Button type="button" variant="outline" onClick={prevStep} className="h-16 px-6 bg-secondary border-2 border-border hover:bg-white hover:text-black">
                    <ArrowLeft className="h-6 w-6" />
                  </Button>
                  <Button type="submit" className="flex-1 h-16 text-xl font-black uppercase tracking-widest bg-primary hover:bg-white hover:text-black transition-all border-none animate-pulse hover:animate-none">
                    Submit Request
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </form>
    </Form>
  );
}
