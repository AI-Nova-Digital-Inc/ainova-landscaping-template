import React from 'react';
import { Shield, Phone, Clock, FileText, CheckCircle2, ChevronRight, AlertTriangle, CloudLightning, Home, ArrowRight, Star, ShieldCheck, MapPin, Hammer, Wrench, HardHat, FileSignature, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { motion } from 'framer-motion';

import { RainEffect } from '@/components/RainEffect';
import { QuoteForm } from '@/components/QuoteForm';

import heroBg from '@/assets/hero-bg.png';
import roofBefore from '@/assets/roof-before.png';
import roofAfter from '@/assets/roof-after.png';
import service1 from '@/assets/service-1.png';

const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

export default function RoofMaxApp() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans selection:bg-primary selection:text-white overflow-x-hidden">
      {/* Sticky Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-8 w-8 text-primary" />
            <span className="text-2xl font-black uppercase tracking-tighter">RoofMax</span>
          </div>
          <nav className="hidden md:flex items-center gap-8 text-sm font-bold uppercase tracking-wider text-muted-foreground">
            <a href="#services" className="hover:text-primary transition-colors">Services</a>
            <a href="#work" className="hover:text-primary transition-colors">Our Work</a>
            <a href="#insurance" className="hover:text-primary transition-colors">Insurance</a>
            <a href="#quote" className="hover:text-primary transition-colors">Free Quote</a>
          </nav>
          <div className="flex items-center gap-4">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-black uppercase tracking-wider hidden sm:flex border-none">
              <Phone className="mr-2 h-5 w-5" />
              1-800-ROOFMAX
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative w-full h-[90vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0 bg-black">
          <img src={heroBg} alt="Stormy Sky" className="w-full h-full object-cover opacity-60 mix-blend-screen" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
          <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-30 pointer-events-none mix-blend-overlay" />
          <RainEffect />
        </div>
        
        <div className="container relative z-10 px-4 mx-auto text-center max-w-4xl">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="inline-flex items-center gap-2 px-5 py-2 rounded-sm bg-primary text-white border-2 border-primary mb-8 font-black uppercase tracking-widest text-sm shadow-[0_0_20px_rgba(220,38,38,0.5)]">
              <AlertTriangle className="h-5 w-5 animate-pulse" />
              Same-Day Emergency Service Available
            </div>
            <h1 className="text-6xl md:text-8xl lg:text-9xl font-black uppercase tracking-tighter leading-[0.85] mb-8 text-white drop-shadow-2xl">
              Roof Damage? <br/> <span className="text-primary">We Fix It Fast.</span>
            </h1>
            <p className="text-xl md:text-3xl text-gray-300 font-medium mb-12 max-w-3xl mx-auto drop-shadow-md">
              Storm damage, leaks, or total replacement. Don't wait for it to get worse. We handle everything from tarping to insurance claims.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <Button size="lg" onClick={() => document.getElementById('quote')?.scrollIntoView({ behavior: 'smooth' })} className="w-full sm:w-auto h-20 px-10 text-xl font-black uppercase tracking-wider bg-primary hover:bg-white hover:text-black transition-all border-none shadow-[0_0_30px_rgba(220,38,38,0.4)] hover:scale-105">
                Get Free Inspection <ChevronRight className="ml-2 h-8 w-8" />
              </Button>
              <Button size="lg" variant="outline" className="w-full sm:w-auto h-20 px-10 text-xl font-black uppercase tracking-wider border-4 border-white text-white hover:bg-white hover:text-black bg-transparent hover:scale-105 transition-transform">
                <Phone className="mr-2 h-6 w-6" /> Call Now
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Emergency Strip */}
      <section className="bg-primary py-8 relative z-20 border-y-4 border-black shadow-[0_10px_30px_rgba(220,38,38,0.2)]">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 divide-y md:divide-y-0 md:divide-x-2 divide-black/20">
            <motion.div whileHover={{ scale: 1.05 }} className="flex items-center justify-center gap-4 py-2 cursor-pointer group">
              <CloudLightning className="h-12 w-12 text-black group-hover:text-white transition-colors" />
              <div>
                <h3 className="font-black text-black uppercase text-2xl group-hover:text-white transition-colors">Storm Damage?</h3>
                <p className="text-black/80 font-bold text-sm uppercase tracking-wider group-hover:text-white/90">Fast emergency tarping</p>
              </div>
            </motion.div>
            <motion.div whileHover={{ scale: 1.05 }} className="flex items-center justify-center gap-4 py-2 cursor-pointer group">
              <AlertTriangle className="h-12 w-12 text-black group-hover:text-white transition-colors" />
              <div>
                <h3 className="font-black text-black uppercase text-2xl group-hover:text-white transition-colors">Leaking Roof?</h3>
                <p className="text-black/80 font-bold text-sm uppercase tracking-wider group-hover:text-white/90">Stop water damage now</p>
              </div>
            </motion.div>
            <motion.div whileHover={{ scale: 1.05 }} className="flex items-center justify-center gap-4 py-2 cursor-pointer group">
              <Hammer className="h-12 w-12 text-black group-hover:text-white transition-colors" />
              <div>
                <h3 className="font-black text-black uppercase text-2xl group-hover:text-white transition-colors">Missing Shingles?</h3>
                <p className="text-black/80 font-bold text-sm uppercase tracking-wider group-hover:text-white/90">Quick repairs before rain</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-32 bg-background relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-7xl font-black uppercase tracking-tighter mb-6">Our Services</h2>
            <p className="text-xl text-muted-foreground font-medium max-w-2xl mx-auto">We deploy military-grade precision to every roofing project. No corners cut. No excuses.</p>
          </div>
          
          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
          >
            {[
              { title: "Emergency Repair", icon: AlertTriangle, desc: "24/7 rapid response to stop leaks and prevent further damage immediately." },
              { title: "Full Replacement", icon: Home, desc: "Tear-off and pristine installation of new architectural shingle or metal roofs." },
              { title: "Storm Damage", icon: CloudLightning, desc: "Hail, wind, and debris impact repairs handled by certified storm specialists." },
              { title: "Roof Inspection", icon: ShieldCheck, desc: "Comprehensive drone and manual inspection to find hidden structural issues." }
            ].map((service, i) => (
              <motion.div key={i} variants={fadeInUp}>
                <Card className="bg-card border-border border-2 hover:border-primary transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_10px_30px_rgba(220,38,38,0.15)] group h-full cursor-pointer">
                  <CardHeader>
                    <div className="h-16 w-16 bg-background rounded-sm flex items-center justify-center mb-6 group-hover:bg-primary transition-colors border-2 border-border group-hover:border-primary">
                      <service.icon className="h-8 w-8 text-primary group-hover:text-white transition-colors" />
                    </div>
                    <CardTitle className="text-2xl font-black uppercase tracking-tight">{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base text-muted-foreground font-medium mb-6">
                      {service.desc}
                    </CardDescription>
                    <Button variant="link" className="p-0 text-primary font-bold uppercase tracking-wider group-hover:text-white">
                      Learn More <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Before / After */}
      <section id="work" className="py-32 bg-secondary border-y border-border relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 pointer-events-none" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-7xl font-black uppercase tracking-tighter mb-6 text-white">The Proof Is In The Work</h2>
            <p className="text-xl text-gray-400 font-medium max-w-2xl mx-auto">See the difference a professional, uncompromising contractor makes.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center max-w-6xl mx-auto">
            <div className="relative group rounded-lg overflow-hidden border-4 border-border hover:border-primary transition-colors duration-500">
              <img src={roofBefore} alt="Damaged roof before" className="w-full h-[400px] object-cover grayscale group-hover:grayscale-0 transition-all duration-500" />
              <div className="absolute top-6 left-6 bg-black text-white px-6 py-2 font-black uppercase tracking-widest text-xl border-2 border-white/20">Before</div>
              <div className="absolute inset-0 bg-black/40 group-hover:bg-transparent transition-colors duration-500" />
            </div>
            
            <div className="relative group rounded-lg overflow-hidden border-4 border-primary shadow-[0_0_40px_rgba(220,38,38,0.3)]">
              <img src={roofAfter} alt="Repaired roof after" className="w-full h-[400px] object-cover transition-transform duration-700 group-hover:scale-105" />
              <div className="absolute top-6 left-6 bg-primary text-white px-6 py-2 font-black uppercase tracking-widest text-xl shadow-lg">After</div>
            </div>
          </div>
        </div>
      </section>

      {/* Insurance Section */}
      <section id="insurance" className="py-32 bg-black relative border-b border-border">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <div className="inline-flex items-center gap-2 px-5 py-2 rounded-sm bg-primary/20 text-primary border border-primary/50 mb-6 font-black uppercase tracking-widest text-sm">
                <DollarSign className="h-5 w-5" />
                Insurance Claim Experts
              </div>
              <h2 className="text-5xl md:text-6xl font-black uppercase tracking-tighter mb-6 text-white">We Fight The Insurance Company For You.</h2>
              <p className="text-xl text-gray-400 font-medium">Filing a claim is stressful. Adjusters try to minimize payouts. We step in, document everything, and ensure your new roof is fully covered.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { step: "01", title: "Damage Assessment", desc: "We document every inch of damage to build an undeniable case.", icon: ShieldCheck },
                { step: "02", title: "Adjuster Meeting", desc: "We meet your adjuster on-site to ensure they don't miss a thing.", icon: HardHat },
                { step: "03", title: "Claim Approval", desc: "We handle the paperwork and begin building your perfect new roof.", icon: FileSignature }
              ].map((item, i) => (
                <div key={i} className="bg-card border-2 border-border p-8 hover:border-primary transition-colors relative group">
                  <div className="text-7xl font-black text-white/5 absolute right-4 top-4 group-hover:text-primary/10 transition-colors pointer-events-none">{item.step}</div>
                  <item.icon className="h-12 w-12 text-primary mb-6" />
                  <h3 className="text-2xl font-black uppercase tracking-tight text-white mb-4">{item.title}</h3>
                  <p className="text-gray-400 font-medium">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-32 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-16 items-center">
            <div className="lg:w-1/2 relative">
              <div className="absolute -inset-4 bg-primary/20 transform -skew-y-3 z-0" />
              <img src={service1} alt="Roofing Team" className="relative z-10 rounded-none border-4 border-border w-full object-cover h-[600px] shadow-2xl" />
            </div>
            <div className="lg:w-1/2">
              <h2 className="text-5xl md:text-6xl font-black uppercase tracking-tighter mb-8 leading-tight">We Don't Make Excuses. <br/><span className="text-primary">We Fix Roofs.</span></h2>
              <p className="text-xl text-muted-foreground mb-12 font-medium">
                When your home is exposed to the elements, you don't need a salesman. You need a contractor who shows up, assesses the damage, and executes the repair with military precision.
              </p>
              
              <div className="space-y-8">
                {[
                  { icon: ShieldCheck, title: "Fully Licensed & Insured", desc: "Your property is completely protected while we work." },
                  { icon: Clock, title: "Fast Response Time", desc: "Emergency tarping available same-day to stop leaks immediately." },
                  { icon: FileText, title: "Insurance Experts", desc: "We negotiate with adjusters so you get what you deserve." },
                  { icon: Home, title: "500+ Homes Repaired", desc: "A proven track record of excellence in your community." }
                ].map((item, i) => (
                  <div key={i} className="flex gap-6 items-start">
                    <div className="bg-primary/10 p-4 rounded-sm border border-primary/30">
                      <item.icon className="h-8 w-8 text-primary" />
                    </div>
                    <div>
                      <h4 className="text-2xl font-black uppercase tracking-tight mb-2">{item.title}</h4>
                      <p className="text-muted-foreground font-medium text-lg">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-32 bg-card border-y border-border">
        <div className="container mx-auto px-4">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-7xl font-black uppercase tracking-tighter mb-6 text-white">Trusted By 500+ Homes</h2>
          </div>
          
          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto"
          >
            {[
              { quote: "A tree fell on our roof at 2 AM. RoofMax was here by 4 AM tarping it. Unbelievable response time and the new roof looks incredible.", author: "Mike T.", location: "Dallas, TX" },
              { quote: "They handled the entire insurance process. I didn't have to argue with my adjuster once. The crew was professional and fast.", author: "Sarah L.", location: "Fort Worth, TX" },
              { quote: "No BS. They gave me a price, showed up when they said they would, and finished in one day. The clean up was spotless.", author: "David R.", location: "Arlington, TX" }
            ].map((t, i) => (
              <motion.div key={i} variants={fadeInUp}>
                <Card className="bg-background border-2 border-border hover:border-primary transition-colors h-full">
                  <CardContent className="p-8 h-full flex flex-col justify-between">
                    <div>
                      <div className="flex gap-1 mb-6">
                        {[...Array(5)].map((_, i) => <Star key={i} className="h-5 w-5 fill-primary text-primary" />)}
                      </div>
                      <p className="text-lg font-medium italic text-muted-foreground mb-8">"{t.quote}"</p>
                    </div>
                    <div>
                      <p className="font-black uppercase text-lg text-white">{t.author}</p>
                      <p className="text-primary font-bold text-sm uppercase tracking-wider">{t.location}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Quote Form Section */}
      <section id="quote" className="py-32 bg-black relative overflow-hidden">
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/30 via-transparent to-transparent" />
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-5xl mx-auto bg-card border-4 border-primary rounded-none shadow-[0_0_50px_rgba(220,38,38,0.2)] flex flex-col md:flex-row">
            
            <div className="p-12 md:w-1/2 bg-secondary border-b-4 md:border-b-0 md:border-r-4 border-border flex flex-col justify-center">
              <h2 className="text-4xl font-black uppercase tracking-tighter mb-6 text-white leading-tight">Request Emergency Inspection</h2>
              <p className="text-gray-400 font-medium mb-8 text-lg">Don't let a small leak turn into thousands in structural damage. Fill out the form or call now.</p>
              <div className="space-y-6">
                <div className="flex items-center gap-4 text-white font-bold text-xl uppercase tracking-wider">
                  <Phone className="h-8 w-8 text-primary" /> 1-800-ROOFMAX
                </div>
                <div className="flex items-center gap-4 text-white font-bold text-xl uppercase tracking-wider">
                  <MapPin className="h-8 w-8 text-primary" /> Serving the Metroplex
                </div>
                <div className="flex items-center gap-4 text-white font-bold text-xl uppercase tracking-wider">
                  <Clock className="h-8 w-8 text-primary" /> 24/7 Emergency Service
                </div>
              </div>
            </div>

            <div className="p-12 md:w-1/2 bg-background flex flex-col justify-center">
              <QuoteForm />
            </div>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-black py-12 border-t-4 border-primary">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <Shield className="h-8 w-8 text-primary" />
                <span className="text-3xl font-black uppercase tracking-tighter text-white">RoofMax</span>
              </div>
              <p className="text-gray-400 font-medium max-w-sm text-lg">
                The premier emergency roofing contractor. We fix what the storms break, fast.
              </p>
            </div>
            <div>
              <h4 className="text-white font-black uppercase tracking-wider mb-6 text-xl">Quick Links</h4>
              <ul className="space-y-4 text-gray-400 font-bold uppercase tracking-wider text-sm">
                <li><a href="#services" className="hover:text-primary transition-colors">Services</a></li>
                <li><a href="#work" className="hover:text-primary transition-colors">Our Work</a></li>
                <li><a href="#insurance" className="hover:text-primary transition-colors">Insurance Claims</a></li>
                <li><a href="#quote" className="hover:text-primary transition-colors">Free Inspection</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-black uppercase tracking-wider mb-6 text-xl">Contact</h4>
              <ul className="space-y-4 text-gray-400 font-bold text-sm uppercase tracking-wider">
                <li className="flex items-center gap-2"><Phone className="h-4 w-4 text-primary"/> 1-800-ROOFMAX</li>
                <li className="flex items-center gap-2"><MapPin className="h-4 w-4 text-primary"/> Dallas / Fort Worth</li>
                <li className="flex items-center gap-2"><Clock className="h-4 w-4 text-primary"/> 24/7 Emergency Service</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center text-gray-500 font-bold text-xs uppercase tracking-widest">
            <p>&copy; {new Date().getFullYear()} RoofMax Contractors. All rights reserved.</p>
            <p className="mt-4 md:mt-0">Lic #123456789</p>
          </div>
        </div>
      </footer>

      {/* Floating CTA */}
      <motion.div 
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 1, type: "spring", stiffness: 200 }}
      >
        <Button size="icon" className="h-20 w-20 rounded-full bg-primary hover:bg-white group transition-all shadow-[0_0_30px_rgba(220,38,38,0.5)] hover:shadow-[0_0_40px_rgba(255,255,255,0.5)] border-none">
          <Phone className="h-10 w-10 text-white group-hover:text-black transition-colors" />
        </Button>
      </motion.div>

    </div>
  );
}
