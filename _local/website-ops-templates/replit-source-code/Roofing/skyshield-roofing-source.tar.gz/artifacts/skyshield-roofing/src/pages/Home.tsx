import React, { useRef, useState } from "react";
import { Link } from "wouter";
import { motion, useInView } from "framer-motion";
import {
  Menu,
  X,
  Wrench,
  Home as HomeIcon,
  Search,
  Hammer,
  ShieldCheck,
  Package,
  BadgeCheck,
  Clock,
  Phone,
  Mail,
  MapPin,
  Star,
  CheckCircle2,
  FileText,
  Users,
  Building2,
  Check
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm, Controller } from "react-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const fadeUpVariant = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const staggerItem = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
};

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const heroRef = useRef(null);
  const isHeroInView = useInView(heroRef, { once: true });
  
  const servicesRef = useRef(null);
  const isServicesInView = useInView(servicesRef, { once: true, margin: "-100px" });

  const projectsRef = useRef(null);
  const isProjectsInView = useInView(projectsRef, { once: true, margin: "-100px" });

  const materialsRef = useRef(null);
  const isMaterialsInView = useInView(materialsRef, { once: true, margin: "-100px" });

  const processRef = useRef(null);
  const isProcessInView = useInView(processRef, { once: true, margin: "-100px" });

  const whyUsRef = useRef(null);
  const isWhyUsInView = useInView(whyUsRef, { once: true, margin: "-100px" });

  const testimonialsRef = useRef(null);
  const isTestimonialsInView = useInView(testimonialsRef, { once: true, margin: "-100px" });

  const contactRef = useRef(null);
  const isContactInView = useInView(contactRef, { once: true, margin: "-100px" });

  const contactSchema = z.object({
    fullName: z.string().min(1, "Name is required"),
    email: z.string().email("Invalid email address"),
    phone: z.string().min(1, "Phone is required"),
    issueType: z.string().min(1, "Please select an issue type"),
    message: z.string().min(1, "Message is required")
  });

  return (
    <div className="min-h-[100dvh] w-full bg-background text-foreground selection:bg-primary selection:text-primary-foreground overflow-x-hidden">
      {/* 1. Sticky Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border/40">
        <div className="container mx-auto px-4 md:px-6 h-20 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 group" data-testid="link-home">
            <div className="w-8 h-8 bg-primary rounded-sm flex items-center justify-center text-primary-foreground group-hover:bg-primary/90 transition-colors">
              <ShieldCheck size={20} strokeWidth={2.5} />
            </div>
            <span className="font-serif text-2xl font-bold tracking-tight text-foreground">
              SkyShield<span className="text-primary">.</span>
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground">
            <a href="#services" className="hover:text-primary transition-colors" data-testid="nav-services">Services</a>
            <a href="#projects" className="hover:text-primary transition-colors" data-testid="nav-projects">Projects</a>
            <a href="#process" className="hover:text-primary transition-colors" data-testid="nav-process">Process</a>
            <a href="#why-us" className="hover:text-primary transition-colors" data-testid="nav-why-us">Why Us</a>
            <a href="#contact" className="hover:text-primary transition-colors" data-testid="nav-contact">Contact</a>
          </nav>

          <div className="hidden md:block">
            <Button asChild size="lg" className="font-semibold" data-testid="button-quote-header">
              <a href="#contact">Get Free Quote</a>
            </Button>
          </div>

          <button 
            className="md:hidden text-foreground p-2" 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="button-mobile-menu"
          >
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden absolute top-20 left-0 w-full bg-card border-b border-border p-4 flex flex-col gap-4 shadow-xl">
            <a href="#services" className="block p-3 text-lg font-medium border-b border-border/50" onClick={() => setMobileMenuOpen(false)}>Services</a>
            <a href="#projects" className="block p-3 text-lg font-medium border-b border-border/50" onClick={() => setMobileMenuOpen(false)}>Projects</a>
            <a href="#process" className="block p-3 text-lg font-medium border-b border-border/50" onClick={() => setMobileMenuOpen(false)}>Process</a>
            <a href="#why-us" className="block p-3 text-lg font-medium border-b border-border/50" onClick={() => setMobileMenuOpen(false)}>Why Us</a>
            <a href="#contact" className="block p-3 text-lg font-medium" onClick={() => setMobileMenuOpen(false)}>Contact</a>
            <Button asChild size="lg" className="w-full mt-4 font-semibold">
              <a href="#contact" onClick={() => setMobileMenuOpen(false)}>Get Free Quote</a>
            </Button>
          </div>
        )}
      </header>

      {/* 2. Hero Section */}
      <section 
        ref={heroRef}
        className="relative pt-32 pb-20 md:pt-48 md:pb-32 min-h-[90vh] flex flex-col justify-center overflow-hidden"
      >
        <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-secondary via-background to-background"></div>
        <div className="absolute inset-0 z-0 opacity-20">
           <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
             <polygon fill="currentColor" className="text-secondary" points="0,100 100,100 100,80 50,20 0,80" />
           </svg>
        </div>
        <div className="absolute inset-0 z-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay pointer-events-none"></div>

        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div 
            className="max-w-4xl"
            initial="hidden"
            animate={isHeroInView ? "visible" : "hidden"}
            variants={staggerContainer}
          >
            <motion.h1 
              variants={staggerItem}
              className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold text-foreground leading-[1.1] mb-6 tracking-tight"
            >
              Protecting What <br className="hidden md:block"/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-yellow-600">Matters Most.</span>
            </motion.h1>
            
            <motion.p 
              variants={staggerItem}
              className="text-lg md:text-2xl text-muted-foreground mb-10 max-w-2xl leading-relaxed font-light"
            >
              Premium roofing solutions built to last — for homes and businesses that demand the best.
            </motion.p>
            
            <motion.div 
              variants={staggerItem}
              className="flex flex-col sm:flex-row gap-4 mb-16"
            >
              <Button asChild size="lg" className="h-14 px-8 text-lg font-semibold w-full sm:w-auto" data-testid="button-hero-primary">
                <a href="#contact">Request Inspection</a>
              </Button>
              <Button asChild variant="outline" size="lg" className="h-14 px-8 text-lg font-semibold w-full sm:w-auto border-primary text-primary hover:bg-primary/10" data-testid="button-hero-secondary">
                <a href="#projects">View Projects</a>
              </Button>
            </motion.div>

            <motion.div 
              variants={staggerItem}
              className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8 border-t border-border/40"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-primary">
                  <ShieldCheck size={20} />
                </div>
                <span className="font-medium text-sm md:text-base text-foreground">Licensed & Insured</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-primary">
                  <FileText size={20} />
                </div>
                <span className="font-medium text-sm md:text-base text-foreground">Insurance Claim Support</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-primary">
                  <Clock size={20} />
                </div>
                <span className="font-medium text-sm md:text-base text-foreground">10+ Years Experience</span>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* 3. Services Section */}
      <section id="services" ref={servicesRef} className="py-24 bg-card relative">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial="hidden"
            animate={isServicesInView ? "visible" : "hidden"}
            variants={fadeUpVariant}
            className="mb-16 md:mb-24"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">Our Services.</h2>
            <div className="w-20 h-1 bg-primary"></div>
          </motion.div>

          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
            initial="hidden"
            animate={isServicesInView ? "visible" : "hidden"}
            variants={staggerContainer}
          >
            {[
              { icon: Wrench, title: "Roof Repair", desc: "Expert diagnostics and permanent fixes for leaks, storm damage, and wear." },
              { icon: HomeIcon, title: "Roof Replacement", desc: "Complete tear-offs and new roof systems installed with premium materials." },
              { icon: Search, title: "Roof Inspection", desc: "Comprehensive structural analysis for peace of mind or real estate transactions." },
              { icon: Hammer, title: "New Installation", desc: "Custom roofing solutions for new construction homes and commercial buildings." }
            ].map((service, i) => (
              <motion.div 
                key={i}
                variants={staggerItem}
                className="group p-8 rounded-xl bg-background border border-border hover:border-primary/50 transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_10px_40px_-10px_rgba(245,158,11,0.15)]"
                data-testid={`card-service-${i}`}
              >
                <div className="w-14 h-14 rounded-lg bg-secondary flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform duration-300">
                  <service.icon size={28} />
                </div>
                <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {service.desc}
                </p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* 4. Portfolio / Projects Section */}
      <section id="projects" ref={projectsRef} className="py-24 bg-background">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial="hidden"
            animate={isProjectsInView ? "visible" : "hidden"}
            variants={fadeUpVariant}
            className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6"
          >
            <div>
              <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">Our Work.</h2>
              <div className="w-20 h-1 bg-primary"></div>
            </div>
            <Button variant="outline" className="w-fit" data-testid="button-view-all-projects">View All Projects</Button>
          </motion.div>

          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            initial="hidden"
            animate={isProjectsInView ? "visible" : "hidden"}
            variants={staggerContainer}
          >
            {[
              { title: "Heritage Oak Estates", desc: "Premium Architectural Shingles", bg: "from-slate-900 to-slate-800" },
              { title: "Cascade Commercial", desc: "TPO Flat Roof System", bg: "from-zinc-900 to-stone-800" },
              { title: "Ridgewood Residence", desc: "Standing Seam Metal Roof", bg: "from-neutral-900 to-neutral-800" },
              { title: "Lakeview Tower", desc: "Commercial EPDM Installation", bg: "from-slate-800 to-zinc-900" },
              { title: "Maple Ridge HOA", desc: "Multi-Family Roof Replacement", bg: "from-stone-900 to-neutral-800" },
              { title: "Stonecrest Medical", desc: "Modified Bitumen System", bg: "from-zinc-900 to-slate-900" },
            ].map((project, i) => (
              <motion.div 
                key={i}
                variants={staggerItem}
                className={`relative aspect-[4/3] rounded-xl overflow-hidden group bg-gradient-to-br ${project.bg} cursor-pointer`}
                data-testid={`card-project-${i}`}
              >
                {/* Simulated rooftop texture pattern */}
                <div className="absolute inset-0 opacity-10 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4IiBoZWlnaHQ9IjgiPgo8cmVjdCB3aWR0aD0iOCIgaGVpZ2h0PSI4IiBmaWxsPSIjZmZmIiBmaWxsLW9wYWNpdHk9IjAuMSIvPgo8cGF0aCBkPSJNMCAwTDggOFpNOCAwTDAgOFoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLW9wYWNpdHk9IjAuMSIvPgo8L3N2Zz4=')] mix-blend-overlay"></div>
                
                <div className="absolute inset-0 bg-black/60 md:bg-black/40 group-hover:bg-black/70 transition-colors duration-500"></div>
                
                <div className="absolute inset-0 p-6 flex flex-col justify-end translate-y-4 md:translate-y-8 group-hover:translate-y-0 transition-transform duration-500">
                  <div className="w-10 h-1 bg-primary mb-4 opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100"></div>
                  <h3 className="text-2xl font-bold text-white mb-2">{project.title}</h3>
                  <p className="text-gray-300 opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-200">
                    {project.desc}
                  </p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* 5. Roof Types Section */}
      <section ref={materialsRef} className="py-24 bg-card border-y border-border">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial="hidden"
            animate={isMaterialsInView ? "visible" : "hidden"}
            variants={fadeUpVariant}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">Roofing Materials.</h2>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
              We source only the highest grade materials from trusted manufacturers to ensure your investment lasts decades.
            </p>
          </motion.div>

          <motion.div 
            className="flex flex-col gap-6"
            initial="hidden"
            animate={isMaterialsInView ? "visible" : "hidden"}
            variants={staggerContainer}
          >
            {[
              { 
                title: "Asphalt Shingles", 
                accent: "bg-blue-500/10 text-blue-500 border-blue-500/20",
                icon: HomeIcon,
                points: ["Cost-effective durability", "Wide variety of colors & styles", "Class 4 impact resistance available", "Excellent wind uplift ratings"]
              },
              { 
                title: "Metal Roofing", 
                accent: "bg-zinc-500/10 text-zinc-400 border-zinc-500/20",
                icon: Building2,
                points: ["50+ year lifespan", "Energy efficient & reflective", "Premium architectural aesthetic", "Fire and extreme weather resistant"]
              },
              { 
                title: "Flat Roofing Systems", 
                accent: "bg-amber-500/10 text-primary border-primary/20",
                icon: Package,
                points: ["TPO, EPDM, and Modified Bitumen", "Superior waterproofing", "Ideal for commercial properties", "Low maintenance requirements"]
              }
            ].map((material, i) => (
              <motion.div 
                key={i}
                variants={staggerItem}
                className="flex flex-col md:flex-row bg-background rounded-xl border border-border overflow-hidden"
                data-testid={`card-material-${i}`}
              >
                <div className={`md:w-64 p-8 flex flex-col items-center justify-center text-center ${material.accent} border-b md:border-b-0 md:border-r`}>
                  <material.icon size={48} className="mb-4" />
                  <h3 className="font-serif text-2xl font-bold text-foreground">{material.title}</h3>
                </div>
                <div className="p-8 flex-1 flex flex-col justify-center">
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                    {material.points.map((point, j) => (
                      <li key={j} className="flex items-start gap-3">
                        <Check className="text-primary mt-1 shrink-0" size={18} />
                        <span className="text-muted-foreground">{point}</span>
                      </li>
                    ))}
                  </ul>
                  <a href="#contact" className="text-primary font-medium hover:underline w-fit flex items-center gap-2" data-testid={`link-learn-more-${i}`}>
                    Learn more about {material.title.toLowerCase()} <span aria-hidden="true">→</span>
                  </a>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* 6. Process Section */}
      <section id="process" ref={processRef} className="py-24 bg-background">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial="hidden"
            animate={isProcessInView ? "visible" : "hidden"}
            variants={fadeUpVariant}
            className="mb-20"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">How It Works.</h2>
            <div className="w-20 h-1 bg-primary"></div>
          </motion.div>

          <div className="relative">
            {/* Horizontal Line for Desktop */}
            <div className="hidden md:block absolute top-8 left-0 w-full h-[2px] bg-border z-0"></div>
            
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-4 gap-12 relative z-10"
              initial="hidden"
              animate={isProcessInView ? "visible" : "hidden"}
              variants={staggerContainer}
            >
              {[
                { step: "01", title: "Free Inspection", desc: "Complete evaluation of your roof's current condition." },
                { step: "02", title: "Detailed Estimate", desc: "Transparent pricing with no hidden fees or surprises." },
                { step: "03", title: "Professional Installation", desc: "Expert craftsmanship using premium grade materials." },
                { step: "04", title: "Final Walkthrough", desc: "Rigorous quality check to ensure absolute perfection." }
              ].map((item, i) => (
                <motion.div key={i} variants={staggerItem} className="relative flex flex-col md:items-center text-left md:text-center group">
                  <div className="hidden md:block absolute top-8 left-1/2 w-full h-[2px] bg-primary scale-x-0 origin-left group-hover:scale-x-100 transition-transform duration-500 z-[-1]"></div>
                  
                  <div className="w-16 h-16 rounded-full bg-card border-4 border-background flex items-center justify-center text-primary font-bold text-xl mb-6 shadow-lg shadow-black/50 mx-0 md:mx-auto">
                    {item.step}
                  </div>
                  <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                  <p className="text-muted-foreground">{item.desc}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* 7. Why Choose Us Section */}
      <section id="why-us" ref={whyUsRef} className="py-24 bg-card border-t border-border">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <motion.div 
              initial="hidden"
              animate={isWhyUsInView ? "visible" : "hidden"}
              variants={fadeUpVariant}
            >
              <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">Why SkyShield.</h2>
              <div className="w-20 h-1 bg-primary mb-8"></div>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                A roof is a significant investment. We built our firm on the principle that precision, transparency, and superior materials shouldn't be luxury add-ons — they should be the standard.
              </p>
              <Button size="lg" className="h-12 px-8" data-testid="button-about-us">More About Our Firm</Button>
            </motion.div>

            <motion.div 
              className="grid grid-cols-1 sm:grid-cols-2 gap-6"
              initial="hidden"
              animate={isWhyUsInView ? "visible" : "hidden"}
              variants={staggerContainer}
            >
              {[
                { icon: ShieldCheck, title: "Certified Installers", desc: "Factory-trained crews adhering to strict manufacturer specs." },
                { icon: Package, title: "Premium Materials", desc: "We only install architectural-grade systems." },
                { icon: BadgeCheck, title: "Warranty Protection", desc: "Industry-leading labor and material warranties." },
                { icon: Clock, title: "Fast Turnaround", desc: "Efficient execution minimizing disruption to your life." }
              ].map((block, i) => (
                <motion.div 
                  key={i} 
                  variants={staggerItem}
                  className="p-6 bg-background rounded-xl border border-border"
                >
                  <block.icon className="text-primary mb-4" size={32} />
                  <h3 className="font-bold text-lg mb-2">{block.title}</h3>
                  <p className="text-sm text-muted-foreground">{block.desc}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* 8. Testimonials Section */}
      <section ref={testimonialsRef} className="py-24 bg-background">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            initial="hidden"
            animate={isTestimonialsInView ? "visible" : "hidden"}
            variants={fadeUpVariant}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">What Our Clients Say.</h2>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
          </motion.div>

          <motion.div 
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
            initial="hidden"
            animate={isTestimonialsInView ? "visible" : "hidden"}
            variants={staggerContainer}
          >
            {[
              {
                quote: "After massive hail damage, SkyShield stepped in, handled the insurance adjusters directly, and had a beautiful new roof installed in under a week. Absolute professionals.",
                author: "James T.",
                location: "Austin, TX"
              },
              {
                quote: "We needed a full replacement on a complex architectural roof. The crew was meticulous, cleaned up completely every day, and the final result is stunning.",
                author: "Maria & David R.",
                location: "Denver, CO"
              },
              {
                quote: "Awarded them a multi-building commercial contract. They executed flawlessly, on schedule, and communicative throughout. Highly recommend for large-scale jobs.",
                author: "Henderson Properties Group",
                location: "Phoenix, AZ"
              }
            ].map((testimonial, i) => (
              <motion.div 
                key={i}
                variants={staggerItem}
                className="p-8 bg-card rounded-xl border border-border relative"
                data-testid={`card-testimonial-${i}`}
              >
                <div className="flex gap-1 text-primary mb-6">
                  {[1,2,3,4,5].map(star => <Star key={star} size={20} fill="currentColor" />)}
                </div>
                <p className="text-lg text-foreground italic font-serif mb-8 leading-relaxed">
                  "{testimonial.quote}"
                </p>
                <div className="mt-auto">
                  <p className="font-bold text-foreground">{testimonial.author}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* 9. Contact Section */}
      <section id="contact" ref={contactRef} className="py-24 bg-card border-t border-border">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 bg-background rounded-2xl border border-border overflow-hidden">
            
            {/* Left Col: Info */}
            <motion.div 
              className="p-10 lg:p-16 bg-secondary text-secondary-foreground"
              initial="hidden"
              animate={isContactInView ? "visible" : "hidden"}
              variants={fadeUpVariant}
            >
              <h2 className="text-3xl md:text-4xl font-serif font-bold mb-8 text-foreground">Schedule Your<br/>Roof Inspection.</h2>
              <p className="text-muted-foreground mb-12">
                Contact us today for a comprehensive evaluation of your property. Our experts provide honest assessments and detailed solutions.
              </p>

              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-background rounded-full flex items-center justify-center text-primary shrink-0">
                    <Phone size={24} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Call Us 24/7</p>
                    <p className="text-xl font-bold text-foreground tracking-wider">1-800-SKYSHIELD</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-background rounded-full flex items-center justify-center text-primary shrink-0">
                    <Mail size={24} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Email</p>
                    <p className="text-lg font-medium text-foreground">info@skyshieldroofing.com</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-background rounded-full flex items-center justify-center text-primary shrink-0">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Corporate Office</p>
                    <p className="text-lg font-medium text-foreground">450 Roofline Ave<br/>Austin, TX 78701</p>
                  </div>
                </div>
              </div>

              <div className="mt-12 pt-8 border-t border-border/50">
                <h4 className="font-bold text-foreground mb-4">Operating Hours</h4>
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">Monday - Friday</span>
                  <span className="font-medium text-foreground">7:00 AM - 7:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Saturday</span>
                  <span className="font-medium text-foreground">8:00 AM - 4:00 PM</span>
                </div>
              </div>
            </motion.div>

            {/* Right Col: Form */}
            <motion.div 
              className="p-10 lg:p-16"
              initial="hidden"
              animate={isContactInView ? "visible" : "hidden"}
              variants={staggerContainer}
            >
              <h3 className="text-2xl font-bold mb-8">Send Us A Message</h3>
              
              <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); alert("Form submitted successfully!"); }}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">Full Name</label>
                    <Input className="h-12 bg-input border-transparent focus-visible:ring-primary" placeholder="John Doe" data-testid="input-name" required />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-muted-foreground mb-2">Email</label>
                      <Input type="email" className="h-12 bg-input border-transparent focus-visible:ring-primary" placeholder="john@example.com" data-testid="input-email" required />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-muted-foreground mb-2">Phone</label>
                      <Input type="tel" className="h-12 bg-input border-transparent focus-visible:ring-primary" placeholder="(555) 123-4567" data-testid="input-phone" required />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">Type of Issue</label>
                    <Select data-testid="select-issue">
                      <SelectTrigger className="h-12 bg-input border-transparent focus:ring-primary">
                        <SelectValue placeholder="Select an option" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="inspection">Free Inspection</SelectItem>
                        <SelectItem value="repair">Roof Repair</SelectItem>
                        <SelectItem value="replacement">Full Replacement</SelectItem>
                        <SelectItem value="commercial">Commercial Roofing</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-2">Message</label>
                    <Textarea 
                      className="min-h-[120px] bg-input border-transparent focus-visible:ring-primary resize-none" 
                      placeholder="Please describe your roofing needs..."
                      data-testid="input-message"
                      required
                    />
                  </div>
                </div>

                <Button type="submit" size="lg" className="w-full h-14 text-lg font-bold" data-testid="button-submit-contact">
                  Request Free Inspection
                </Button>
                <p className="text-xs text-center text-muted-foreground mt-4">
                  By submitting this form, you agree to our privacy policy. We will contact you within 24 hours.
                </p>
              </form>
            </motion.div>

          </div>
        </div>
      </section>

      {/* 10. Footer */}
      <footer className="bg-[#0a0f1a] pt-16 pb-8 border-t border-border/20">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-sm flex items-center justify-center text-primary-foreground">
                  <ShieldCheck size={20} strokeWidth={2.5} />
                </div>
                <span className="font-serif text-2xl font-bold tracking-tight text-white">
                  SkyShield<span className="text-primary">.</span>
                </span>
              </div>
              <p className="text-gray-400 max-w-sm">
                Premium roofing solutions for homes and businesses that demand the absolute best in materials and craftsmanship.
              </p>
            </div>

            <div className="flex flex-wrap gap-x-8 gap-y-4 text-sm font-medium text-gray-400">
              <a href="#services" className="hover:text-primary transition-colors">Services</a>
              <a href="#projects" className="hover:text-primary transition-colors">Projects</a>
              <a href="#process" className="hover:text-primary transition-colors">Process</a>
              <a href="#why-us" className="hover:text-primary transition-colors">Why Us</a>
              <a href="#contact" className="hover:text-primary transition-colors">Contact</a>
            </div>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center pt-8 border-t border-white/10 text-xs text-gray-500 gap-4 text-center md:text-left">
            <p>&copy; {new Date().getFullYear()} SkyShield Roofing LLC. All rights reserved.</p>
            <p>Fully Licensed, Bonded, and Insured. State License #ROOF-48291X</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
