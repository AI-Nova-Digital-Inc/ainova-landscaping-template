import { motion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";
import heroMockup from "@/assets/hero-mockup.jpg";

export function Hero() {
  return (
    <section id="top" className="relative pt-36 pb-24 sm:pt-44 sm:pb-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-hero pointer-events-none" />
      <div className="absolute inset-0 grid-pattern pointer-events-none" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mx-auto max-w-4xl text-center"
        >
          <div className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-medium text-muted-foreground mb-8">
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            Premium websites for local service businesses
          </div>

          <h1 className="font-display text-5xl sm:text-6xl md:text-7xl font-bold tracking-tight leading-[1.05]">
            Professional Websites <br className="hidden sm:block" />
            for <span className="text-gradient-primary">Local Businesses</span>
          </h1>

          <p className="mt-6 text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            We build modern, mobile-friendly websites for construction, HVAC, roofing,
            plumbing, landscaping, cleaning, and service businesses — designed to help
            customers find you, trust you, and contact you.
          </p>

          <div className="mt-10 flex flex-col sm:flex-row gap-3 justify-center">
            <a
              href="#contact"
              className="group inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary text-primary-foreground px-7 py-3.5 font-semibold glow-primary hover:opacity-95 transition"
            >
              Request a Website Quote
              <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
            </a>
            <a
              href="#packages"
              className="inline-flex items-center justify-center rounded-full glass px-7 py-3.5 font-semibold hover:bg-white/10 transition"
            >
              View Website Packages
            </a>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative mt-16 sm:mt-20 mx-auto max-w-5xl"
        >
          <div className="absolute -inset-8 bg-gradient-primary opacity-20 blur-3xl rounded-full" />
          <div className="relative rounded-3xl overflow-hidden card-elevated">
            <img
              src={heroMockup}
              alt="Local business website mockups on laptop and phone"
              width={1600}
              height={1200}
              className="w-full h-auto"
            />
          </div>
        </motion.div>

        <div className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-3xl mx-auto">
          {[
            ["48h", "Initial Concept"],
            ["100%", "Mobile Optimized"],
            ["$199+", "Starting Price"],
            ["Local", "Business Focus"],
          ].map(([k, v]) => (
            <div key={v} className="text-center">
              <div className="text-2xl sm:text-3xl font-display font-bold text-gradient-primary">
                {k}
              </div>
              <div className="text-xs sm:text-sm text-muted-foreground mt-1">{v}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
