import {
  Palette, Smartphone, Zap, Hammer, DollarSign, MessageCircle, LifeBuoy,
} from "lucide-react";

const items = [
  { icon: Palette, title: "Modern Professional Design", desc: "Premium aesthetics that make your business look established and trustworthy." },
  { icon: Smartphone, title: "Mobile-Friendly Websites", desc: "Over 60% of local searches happen on mobile — we design for it first." },
  { icon: Zap, title: "Fast Turnaround", desc: "Most starter sites are live within a week. No endless waiting." },
  { icon: Hammer, title: "Local Business Focused", desc: "We specialize in trades and service businesses — not generic templates." },
  { icon: DollarSign, title: "Affordable Starting Packages", desc: "Real value at every tier. No hidden fees, no bloated retainers." },
  { icon: MessageCircle, title: "Easy Communication", desc: "Direct, jargon-free updates. You always know what's happening." },
  { icon: LifeBuoy, title: "Ongoing Support Available", desc: "Need a change next month? We're here when you need us." },
];

export function WhyUs() {
  return (
    <section className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="max-w-2xl">
          <div className="text-xs font-medium uppercase tracking-widest text-primary mb-3">
            Why Ainova
          </div>
          <h2 className="text-4xl sm:text-5xl font-display font-bold tracking-tight">
            Built for trades. <span className="text-gradient-primary">Designed to convert.</span>
          </h2>
        </div>

        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map((i, idx) => (
            <div
              key={i.title}
              className={`rounded-2xl card-elevated p-6 ${
                idx === 0 ? "lg:row-span-2 lg:bg-gradient-to-br lg:from-primary/10 lg:to-transparent" : ""
              }`}
            >
              <div className="inline-flex h-11 w-11 items-center justify-center rounded-xl glass mb-4">
                <i.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="text-lg font-semibold">{i.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{i.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
