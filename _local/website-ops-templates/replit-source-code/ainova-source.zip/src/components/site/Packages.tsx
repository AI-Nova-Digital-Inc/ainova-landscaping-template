import { Check } from "lucide-react";

const packages = [
  {
    name: "Starter Website",
    price: "$199",
    suffix: "starting at",
    desc: "Get online fast with a clean, professional one-page site.",
    features: [
      "1-page modern design",
      "Mobile-friendly layout",
      "Contact form",
      "Google Maps embed",
      "Basic SEO setup",
      "Hosting guidance",
    ],
    cta: "Start with Starter",
    highlight: false,
  },
  {
    name: "Business Website",
    price: "$499",
    suffix: "starting at",
    desc: "A complete multi-page site built to win local customers.",
    features: [
      "Up to 5 custom pages",
      "Quote request form",
      "Service area pages",
      "Google Business setup",
      "On-page SEO basics",
      "Photo gallery",
      "30 days post-launch support",
    ],
    cta: "Choose Business",
    highlight: true,
  },
  {
    name: "Custom Website / Web App",
    price: "Custom",
    suffix: "tailored quote",
    desc: "Bookings, dashboards, integrations — anything you need.",
    features: [
      "Custom features & integrations",
      "Booking & scheduling systems",
      "Customer portals",
      "Payment processing",
      "Automations & AI features",
      "Dedicated project lead",
    ],
    cta: "Request a Custom Quote",
    highlight: false,
  },
];

export function Packages() {
  return (
    <section id="packages" className="relative py-24 sm:py-32">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="max-w-2xl mx-auto text-center">
          <div className="text-xs font-medium uppercase tracking-widest text-primary mb-3">
            Website Packages
          </div>
          <h2 className="text-4xl sm:text-5xl font-display font-bold tracking-tight">
            Simple pricing. <span className="text-gradient-primary">Real results.</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Transparent packages built for local businesses of every size.
          </p>
        </div>

        <div className="mt-14 grid grid-cols-1 md:grid-cols-3 gap-5">
          {packages.map((p) => (
            <div
              key={p.name}
              className={`relative rounded-3xl p-7 flex flex-col ${
                p.highlight
                  ? "bg-gradient-to-b from-primary/15 to-surface border border-primary/40 shadow-[var(--shadow-glow)]"
                  : "card-elevated"
              }`}
            >
              {p.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-primary text-primary-foreground text-xs font-semibold px-3 py-1">
                  Most Popular
                </div>
              )}
              <div className="text-sm text-muted-foreground">{p.name}</div>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-4xl sm:text-5xl font-display font-bold tracking-tight">
                  {p.price}
                </span>
                <span className="text-xs text-muted-foreground">{p.suffix}</span>
              </div>
              <p className="mt-3 text-sm text-muted-foreground">{p.desc}</p>

              <ul className="mt-6 space-y-3 flex-1">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-3 text-sm">
                    <div className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-primary/15 text-primary">
                      <Check className="h-3 w-3" />
                    </div>
                    <span>{f}</span>
                  </li>
                ))}
              </ul>

              <a
                href="#contact"
                className={`mt-8 inline-flex items-center justify-center rounded-full px-5 py-3 text-sm font-semibold transition ${
                  p.highlight
                    ? "bg-gradient-primary text-primary-foreground hover:opacity-95"
                    : "glass hover:bg-white/10"
                }`}
              >
                {p.cta}
              </a>
            </div>
          ))}
        </div>

        <p className="mt-10 max-w-3xl mx-auto text-center text-xs sm:text-sm text-muted-foreground">
          Pricing depends on pages, features, content, hosting, forms, booking systems,
          SEO setup, and custom requirements. We'll send a clear quote after a quick
          consultation — no surprises.
        </p>
      </div>
    </section>
  );
}
