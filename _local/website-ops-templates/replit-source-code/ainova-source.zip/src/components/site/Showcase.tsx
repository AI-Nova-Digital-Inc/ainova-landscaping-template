import construction from "@/assets/showcase-construction.jpg";
import hvac from "@/assets/showcase-hvac.jpg";
import roofing from "@/assets/showcase-roofing.jpg";
import plumbing from "@/assets/showcase-plumbing.jpg";

const items = [
  { img: construction, label: "Construction", tag: "Multi-page site" },
  { img: hvac, label: "HVAC", tag: "Booking-ready" },
  { img: roofing, label: "Roofing", tag: "Quote requests" },
  { img: plumbing, label: "Plumbing", tag: "Emergency CTA" },
];

export function Showcase() {
  return (
    <section id="showcase" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6">
          <div className="max-w-2xl">
            <div className="text-xs font-medium uppercase tracking-widest text-primary mb-3">
              Showcase
            </div>
            <h2 className="text-4xl sm:text-5xl font-display font-bold tracking-tight">
              Websites built for <span className="text-gradient-primary">real trades.</span>
            </h2>
            <p className="mt-4 text-muted-foreground">
              Sample concepts showing the kind of clean, conversion-focused design we
              ship for local service businesses.
            </p>
          </div>
        </div>

        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 gap-5">
          {items.map((it, i) => (
            <div
              key={it.label}
              className={`group relative rounded-3xl overflow-hidden card-elevated ${
                i % 3 === 0 ? "md:row-span-1" : ""
              }`}
            >
              <div className="aspect-[4/3] overflow-hidden bg-surface">
                <img
                  src={it.img}
                  alt={`${it.label} website concept`}
                  loading="lazy"
                  width={1024}
                  height={768}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
              </div>
              <div className="absolute inset-x-0 bottom-0 p-5 sm:p-6 bg-gradient-to-t from-black/80 via-black/30 to-transparent">
                <div className="flex items-end justify-between gap-4">
                  <div>
                    <div className="text-xs text-primary font-medium">{it.tag}</div>
                    <div className="text-xl font-display font-semibold mt-1">
                      {it.label} Website
                    </div>
                  </div>
                  <div className="rounded-full glass-strong px-3 py-1 text-xs">Concept</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
