export function Footer() {
  return (
    <footer className="relative border-t border-white/5 py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 flex flex-col sm:flex-row gap-6 items-center justify-between">
        <div className="flex items-center gap-2 font-display font-bold">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-primary text-primary-foreground text-xs">
            A
          </span>
          AINOVA DIGITAL INC
        </div>
        <div className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} Ainova Digital Inc. — Websites for local businesses.
        </div>
        <div className="flex gap-5 text-xs text-muted-foreground">
          <a href="#services" className="hover:text-foreground">Services</a>
          <a href="#packages" className="hover:text-foreground">Packages</a>
          <a href="#contact" className="hover:text-foreground">Contact</a>
        </div>
      </div>
    </footer>
  );
}
