import {
  Globe, Smartphone, MessageSquare, MapPin, Search, Server, Wrench,
  Cog, Cloud, Brain, Code2,
} from "lucide-react";

const primary = [
  { icon: Globe, title: "Website Development", desc: "Custom-built sites that load fast and convert visitors into calls." },
  { icon: Smartphone, title: "Mobile-Friendly Design", desc: "Beautiful on phones, tablets, and desktops — every pixel polished." },
  { icon: MessageSquare, title: "Contact & Quote Forms", desc: "Lead-capture forms that send inquiries straight to your inbox." },
  { icon: MapPin, title: "Google Business Profile", desc: "Setup and optimization so locals find you on Maps and Search." },
  { icon: Search, title: "Basic SEO Setup", desc: "Clean structure, meta tags, and on-page basics done right." },
  { icon: Server, title: "Hosting & Domain Guidance", desc: "We handle the technical setup so you don't have to." },
  { icon: Wrench, title: "Website Maintenance", desc: "Updates, backups, and ongoing support whenever you need it." },
];

const secondary = [
  { icon: Cog, title: "IT Consulting" },
  { icon: Cloud, title: "Cloud & DevOps Consulting" },
  { icon: Brain, title: "AI & Automation Solutions" },
  { icon: Code2, title: "Custom Web Applications" },
];

export function Services() {
  return (
    <section id="services" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="max-w-2xl">
          <div className="text-xs font-medium uppercase tracking-widest text-primary mb-3">
            What we do
          </div>
          <h2 className="text-4xl sm:text-5xl font-display font-bold tracking-tight">
            Everything your business <span className="text-gradient-primary">needs online.</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            From your first website to ongoing maintenance — we handle it all so you can
            focus on running your business.
          </p>
        </div>

        <div className="mt-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {primary.map((s) => (
            <div
              key={s.title}
              className="group relative rounded-2xl card-elevated p-6 hover:border-primary/30 transition-all hover:-translate-y-0.5"
            >
              <div className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-primary text-primary-foreground mb-4 shadow-[var(--shadow-glow)]">
                <s.icon className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-20">
          <h3 className="text-2xl sm:text-3xl font-display font-bold tracking-tight">
            Additional Technology Services
          </h3>
          <p className="mt-2 text-muted-foreground">Need more than a website? We've got you covered.</p>

          <div className="mt-8 grid grid-cols-2 lg:grid-cols-4 gap-4">
            {secondary.map((s) => (
              <div
                key={s.title}
                className="rounded-2xl glass p-5 flex items-center gap-3 hover:bg-white/[0.07] transition"
              >
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-white/5">
                  <s.icon className="h-4 w-4 text-primary" />
                </div>
                <div className="text-sm font-medium">{s.title}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
