const steps = [
  { n: "01", title: "Consultation", desc: "We learn about your business, goals, and customers in a quick call." },
  { n: "02", title: "Design & Development", desc: "We design, then build a mobile-friendly site tailored to your brand." },
  { n: "03", title: "Review & Launch", desc: "You review, we refine, and we launch your site to the world." },
  { n: "04", title: "Ongoing Support", desc: "Updates, edits, and maintenance whenever you need them." },
];

export function Process() {
  return (
    <section id="process" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="max-w-2xl">
          <div className="text-xs font-medium uppercase tracking-widest text-primary mb-3">
            How it works
          </div>
          <h2 className="text-4xl sm:text-5xl font-display font-bold tracking-tight">
            Four simple steps to <span className="text-gradient-primary">your new website.</span>
          </h2>
        </div>

        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 relative">
          {steps.map((s, i) => (
            <div key={s.n} className="relative rounded-2xl card-elevated p-7">
              <div className="font-display text-5xl font-bold text-gradient-primary opacity-80">
                {s.n}
              </div>
              <h3 className="mt-4 text-xl font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
              {i < steps.length - 1 && (
                <div className="hidden lg:block absolute top-12 -right-2 h-px w-4 bg-gradient-to-r from-primary/40 to-transparent" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
