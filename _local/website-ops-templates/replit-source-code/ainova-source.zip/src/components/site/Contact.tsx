import { useState } from "react";
import { z } from "zod";
import { ArrowRight, Mail, Phone, MapPin } from "lucide-react";
import { toast } from "sonner";

const schema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100),
  business: z.string().trim().min(1, "Business name is required").max(120),
  email: z.string().trim().email("Enter a valid email").max(255),
  phone: z.string().trim().min(7, "Enter a valid phone").max(30),
  service: z.string().min(1, "Choose a service"),
  message: z.string().trim().min(10, "Tell us a bit more").max(1500),
});

const services = [
  "Starter Website",
  "Business Website",
  "Custom Website / Web App",
  "IT Consulting",
  "Cloud & DevOps",
  "AI & Automation",
  "Not sure yet",
];

export function Contact() {
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>;
    const parsed = schema.safeParse(data);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Please check your details.");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      e.currentTarget.reset();
      toast.success("Thanks! We'll be in touch within one business day.");
    }, 700);
  };

  return (
    <section id="contact" className="relative py-24 sm:py-32">
      <div className="absolute inset-0 bg-gradient-hero pointer-events-none" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-start">
          <div>
            <div className="text-xs font-medium uppercase tracking-widest text-primary mb-3">
              Get in touch
            </div>
            <h2 className="text-4xl sm:text-5xl font-display font-bold tracking-tight">
              Get Your Business <span className="text-gradient-primary">Online Today.</span>
            </h2>
            <p className="mt-4 text-lg text-muted-foreground max-w-md">
              Tell us about your business and what you need. We'll send a clear quote
              within one business day — no pressure, no spam.
            </p>

            <div className="mt-10 space-y-4">
              {[
                { icon: Mail, label: "hello@ainovadigital.com" },
                { icon: Phone, label: "Available Mon–Fri, 9am–6pm" },
                { icon: MapPin, label: "Serving local businesses across North America" },
              ].map((c) => (
                <div key={c.label} className="flex items-center gap-4">
                  <div className="grid h-11 w-11 place-items-center rounded-xl glass">
                    <c.icon className="h-4 w-4 text-primary" />
                  </div>
                  <span className="text-sm text-muted-foreground">{c.label}</span>
                </div>
              ))}
            </div>
          </div>

          <form
            onSubmit={onSubmit}
            className="rounded-3xl glass-strong p-6 sm:p-8 space-y-4"
          >
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Your Name" name="name" placeholder="Jane Doe" />
              <Field label="Business Name" name="business" placeholder="Acme Roofing" />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Email" name="email" type="email" placeholder="you@business.com" />
              <Field label="Phone" name="phone" type="tel" placeholder="(555) 123-4567" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-2">
                Service Needed
              </label>
              <select
                name="service"
                defaultValue=""
                className="w-full rounded-xl bg-white/5 border border-white/10 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
              >
                <option value="" disabled>Select a service…</option>
                {services.map((s) => (
                  <option key={s} value={s} className="bg-surface">{s}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-2">
                Message
              </label>
              <textarea
                name="message"
                rows={4}
                placeholder="Tell us about your business and what you'd like to build…"
                maxLength={1500}
                className="w-full rounded-xl bg-white/5 border border-white/10 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
              />
            </div>
            <button
              type="submit"
              disabled={submitting}
              className="group w-full inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary text-primary-foreground px-6 py-3.5 font-semibold glow-primary hover:opacity-95 transition disabled:opacity-60"
            >
              {submitting ? "Sending…" : "Get Your Business Online Today"}
              <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

function Field({
  label, name, type = "text", placeholder,
}: { label: string; name: string; type?: string; placeholder?: string }) {
  return (
    <div>
      <label className="block text-xs font-medium text-muted-foreground mb-2">{label}</label>
      <input
        type={type}
        name={name}
        placeholder={placeholder}
        maxLength={255}
        className="w-full rounded-xl bg-white/5 border border-white/10 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
      />
    </div>
  );
}
