import { motion, useScroll, useTransform } from 'framer-motion';
import {
  Axe,
  Hammer,
  House,
  DraftingCompass,
  Star,
  MapPin,
  Phone,
  Mail,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

const staggerContainer = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.15 }
  }
};

const itemUp = {
  hidden: { y: 40, opacity: 0 },
  show: { y: 0, opacity: 1, transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] } }
};

export default function Home() {
  const { scrollYProgress } = useScroll();
  const yHero = useTransform(scrollYProgress, [0, 1], [0, 400]);
  const opacityHero = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  return (
    <div className="w-full min-h-screen bg-background overflow-hidden selection:bg-primary selection:text-primary-foreground">
      
      {/* 1. HERO */}
      <section className="relative h-[100svh] w-full overflow-hidden flex items-center justify-center">
        <motion.div 
          className="absolute inset-0 z-0"
          style={{ y: yHero, opacity: opacityHero }}
        >
          <div className="absolute inset-0 bg-background/60 mix-blend-multiply z-10" />
          <motion.div
            className="absolute inset-0 w-full h-full bg-cover bg-center"
            style={{ backgroundImage: 'url(/images/hero.png)' }}
            initial={{ scale: 1.1 }}
            animate={{ scale: 1 }}
            transition={{ duration: 10, ease: "easeOut" }}
          />
        </motion.div>
        
        <div className="relative z-20 container mx-auto px-6 text-center flex flex-col items-center pb-28">
          <motion.div
            initial="hidden"
            animate="show"
            variants={staggerContainer}
            className="max-w-4xl"
          >
            <motion.h2 variants={itemUp} className="text-primary font-sans uppercase tracking-[0.3em] text-sm md:text-base font-semibold mb-6">
              WoodCraft Elite
            </motion.h2>
            <motion.h1 variants={itemUp} className="text-5xl md:text-7xl lg:text-8xl font-serif text-white font-medium leading-tight mb-8">
              Craftsmanship That <br className="hidden md:block"/> Defines Your Space.
            </motion.h1>
            <motion.p variants={itemUp} className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto mb-12 font-sans font-light">
              Custom woodwork designed with precision and passion. We transform raw timber into bespoke architectural elements for luxury interiors.
            </motion.p>
            <motion.div variants={itemUp} className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" className="h-14 px-8 text-base tracking-wide bg-primary hover:bg-primary/90 text-primary-foreground rounded-none border border-primary transition-all duration-300 uppercase font-medium">
                View Our Work
              </Button>
              <Button size="lg" variant="outline" className="h-14 px-8 text-base tracking-wide border-white/30 text-white hover:bg-white/10 rounded-none transition-all duration-300 uppercase font-medium">
                Request Consultation
              </Button>
            </motion.div>
          </motion.div>
        </div>
        
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2">
          <span className="text-xs uppercase tracking-widest text-white/50">Scroll</span>
          <motion.div 
            animate={{ y: [0, 8, 0] }} 
            transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
            className="w-[1px] h-12 bg-gradient-to-b from-primary to-transparent"
          />
        </div>
      </section>

      {/* 2. PORTFOLIO GALLERY */}
      <section className="py-32 px-6 md:px-12 bg-background relative z-30 border-t border-border">
        <div className="container mx-auto max-w-7xl">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            className="mb-16"
          >
            <h3 className="text-primary font-sans uppercase tracking-[0.2em] text-sm font-semibold mb-4">Selected Works</h3>
            <h2 className="text-4xl md:text-5xl font-serif text-foreground">The Mastery Portfolio</h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { img: '/images/portfolio-kitchen.png', title: 'Walnut Kitchen Cabintery', desc: 'Sleek, modern architectural finish.' },
              { img: '/images/portfolio-deck.png', title: 'Teak Outdoor Living', desc: 'Weather-resistant luxury deck.' },
              { img: '/images/portfolio-shelving.png', title: 'Library Built-ins', desc: 'Floor-to-ceiling reclaimed timber.' },
              { img: '/images/portfolio-wardrobe.png', title: 'Bespoke Wardrobe', desc: 'Soft gold accents on dark grain.' },
              { img: '/images/portfolio-table.png', title: 'Live-Edge Dining', desc: 'Minimalist luxury centerpiece.' },
              { img: '/images/portfolio-study.png', title: 'Acoustic Paneling', desc: 'Intimate study wall treatment.' },
            ].map((item, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ delay: i * 0.1, duration: 0.7 }}
                className="group relative aspect-[4/5] overflow-hidden bg-muted cursor-pointer"
              >
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/60 transition-colors duration-500 z-10" />
                <motion.div 
                  className="absolute inset-0 w-full h-full bg-cover bg-center transition-transform duration-700 ease-out group-hover:scale-105"
                  style={{ backgroundImage: `url(${item.img})` }}
                />
                <div className="absolute inset-0 z-20 flex flex-col justify-end p-8 translate-y-8 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-500 ease-out">
                  <div className="w-8 h-[2px] bg-primary mb-4" />
                  <h4 className="text-2xl font-serif text-white mb-2">{item.title}</h4>
                  <p className="text-white/70 font-sans font-light">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. SERVICES */}
      <section className="py-32 px-6 md:px-12 bg-secondary/30 border-t border-border">
        <div className="container mx-auto max-w-7xl">
          <div className="text-center mb-20">
            <h3 className="text-primary font-sans uppercase tracking-[0.2em] text-sm font-semibold mb-4">Our Expertise</h3>
            <h2 className="text-4xl md:text-5xl font-serif text-foreground">Artisan Services</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              { icon: House, title: 'Custom Cabinets', desc: 'Precision-engineered cabinetry designed to elevate kitchens, bathrooms, and living spaces. Built with premium hardwoods and state-of-the-art hardware.' },
              { icon: Axe, title: 'Deck Construction', desc: 'Luxurious outdoor living spaces crafted from weather-resistant exotic woods like Teak and Ipe. Built to endure and age beautifully.' },
              { icon: DraftingCompass, title: 'Interior Woodwork', desc: 'Architectural paneling, custom molding, and built-in shelving that add depth, texture, and character to high-end interiors.' },
              { icon: Hammer, title: 'Renovations & Restorations', desc: 'Meticulous restoration of historical woodwork and integration of new custom pieces that respect the original architectural integrity.' }
            ].map((service, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="group bg-background p-10 border border-border hover:border-primary/50 transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-primary/5"
              >
                <div className="w-14 h-14 bg-secondary flex items-center justify-center rounded-none mb-8 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-500">
                  <service.icon strokeWidth={1.5} size={28} />
                </div>
                <h4 className="text-2xl font-serif text-foreground mb-4">{service.title}</h4>
                <p className="text-muted-foreground font-light leading-relaxed">{service.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. MATERIALS & PROCESS */}
      <section className="py-32 bg-background border-t border-border overflow-hidden">
        <div className="container mx-auto max-w-7xl px-6 md:px-12">
          <div className="flex flex-col lg:flex-row gap-20">
            
            {/* Materials */}
            <div className="lg:w-1/2">
              <h3 className="text-primary font-sans uppercase tracking-[0.2em] text-sm font-semibold mb-4">Raw Elements</h3>
              <h2 className="text-4xl md:text-5xl font-serif text-foreground mb-8">Premium Timbers</h2>
              <p className="text-muted-foreground font-light leading-relaxed mb-12">
                We source only the finest sustainable hardwoods, treating each piece with hand-rubbed oils to bring out its unique grain, character, and tactile warmth.
              </p>
              <div className="flex gap-4">
                {[
                  { name: 'White Oak', img: '/images/mat-oak.png' },
                  { name: 'Black Walnut', img: '/images/mat-walnut.png' },
                  { name: 'Cedar', img: '/images/mat-cedar.png' },
                ].map((mat, i) => (
                  <div key={i} className="flex-1 group">
                    <div className="aspect-square bg-muted mb-4 overflow-hidden">
                      <img src={mat.img} alt={mat.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                    </div>
                    <span className="text-sm uppercase tracking-wider text-foreground font-medium">{mat.name}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Process */}
            <div className="lg:w-1/2">
              <h3 className="text-primary font-sans uppercase tracking-[0.2em] text-sm font-semibold mb-4">Our Method</h3>
              <h2 className="text-4xl md:text-5xl font-serif text-foreground mb-12">The Craftsman's Process</h2>
              
              <div className="space-y-10 relative before:absolute before:inset-0 before:ml-[15px] before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-[2px] before:bg-border">
                {[
                  { step: '01', title: 'Consultation', desc: 'We meet to understand your vision, space, and aesthetic requirements.' },
                  { step: '02', title: 'Design & Drafting', desc: 'Detailed architectural drawings and material selection for your approval.' },
                  { step: '03', title: 'Master Build', desc: 'Precision crafting in our studio using traditional and modern techniques.' },
                  { step: '04', title: 'Installation', desc: 'Flawless white-glove installation respecting your home and schedule.' }
                ].map((item, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.15 }}
                    className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active"
                  >
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-secondary border-2 border-primary text-primary shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10 shadow-[0_0_0_8px_hsl(var(--background))]">
                      <span className="text-xs font-bold">{item.step}</span>
                    </div>
                    <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-6 bg-card border border-border">
                      <h4 className="font-serif text-xl text-foreground mb-2">{item.title}</h4>
                      <p className="text-sm text-muted-foreground font-light">{item.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
            
          </div>
        </div>
      </section>

      {/* 5. WHY CHOOSE US */}
      <section className="py-32 px-6 md:px-12 bg-secondary border-t border-border">
        <div className="container mx-auto max-w-7xl">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {[
              { num: '100%', title: 'Handcrafted Quality', desc: 'Every joint, edge, and finish is meticulously crafted by human hands, ensuring a level of detail mass production cannot match.' },
              { num: '∞', title: 'Bespoke Design', desc: 'We do not use templates. Every project is engineered specifically for your space, reflecting your personal taste and architectural context.' },
              { num: '25+', title: 'Years Experience', desc: 'Our master builders bring decades of specialized knowledge in high-end carpentry, handling complex structural and aesthetic challenges.' }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="flex flex-col"
              >
                <span className="text-5xl font-serif text-primary mb-6">{feature.num}</span>
                <h4 className="text-2xl font-serif text-foreground mb-4">{feature.title}</h4>
                <p className="text-muted-foreground font-light leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. TESTIMONIALS */}
      <section className="py-32 px-6 md:px-12 bg-background border-t border-border">
        <div className="container mx-auto max-w-7xl">
          <div className="text-center mb-20">
            <h3 className="text-primary font-sans uppercase tracking-[0.2em] text-sm font-semibold mb-4">Client Relations</h3>
            <h2 className="text-4xl md:text-5xl font-serif text-foreground">Words of Esteem</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { name: 'Eleanor Vance', role: 'Homeowner, Bel Air', text: 'The walnut built-ins completely transformed our study. The attention to detail is staggering. It feels like a room from a century ago, yet perfectly modern.' },
              { name: 'Marcus Thorne', role: 'Principal Architect', text: 'I specify WoodCraft Elite for all my high-end residential projects. Their understanding of wood movement and finish is unmatched in the industry.' },
              { name: 'Sarah Jenkins', role: 'Interior Designer', text: 'The custom dining table they crafted is the crown jewel of our client’s home. The raw edge combined with the buttery smooth oil finish is purely masterful.' }
            ].map((test, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="bg-card p-10 border border-border flex flex-col justify-between"
              >
                <div>
                  <div className="flex gap-1 mb-6 text-primary">
                    {[...Array(5)].map((_, j) => <Star key={j} size={16} fill="currentColor" />)}
                  </div>
                  <p className="text-foreground font-serif italic text-lg leading-relaxed mb-8">"{test.text}"</p>
                </div>
                <div>
                  <div className="w-10 h-[1px] bg-primary mb-4" />
                  <h5 className="text-foreground uppercase tracking-wider text-sm font-medium">{test.name}</h5>
                  <span className="text-muted-foreground text-xs">{test.role}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. CONTACT / CTA */}
      <section className="py-32 px-6 md:px-12 bg-card border-t border-border">
        <div className="container mx-auto max-w-6xl">
          <div className="bg-background border border-border p-8 md:p-16 flex flex-col lg:flex-row gap-16">
            
            <div className="lg:w-5/12">
              <h3 className="text-primary font-sans uppercase tracking-[0.2em] text-sm font-semibold mb-4">Commission A Piece</h3>
              <h2 className="text-4xl font-serif text-foreground mb-6">Start Your Project</h2>
              <p className="text-muted-foreground font-light mb-12">
                We accept a limited number of commissions each year to ensure uncompromising quality. Reach out to discuss your vision.
              </p>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <MapPin className="text-primary mt-1" size={20} />
                  <div>
                    <h5 className="text-foreground text-sm uppercase tracking-wider font-medium mb-1">Studio</h5>
                    <p className="text-muted-foreground font-light text-sm">482 Timberline Road<br/>Portland, OR 97205</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Phone className="text-primary mt-1" size={20} />
                  <div>
                    <h5 className="text-foreground text-sm uppercase tracking-wider font-medium mb-1">Direct</h5>
                    <p className="text-muted-foreground font-light text-sm">+1 (503) 555-8924</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Mail className="text-primary mt-1" size={20} />
                  <div>
                    <h5 className="text-foreground text-sm uppercase tracking-wider font-medium mb-1">Email</h5>
                    <p className="text-muted-foreground font-light text-sm">inquiries@woodcraftelite.com</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:w-7/12">
              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-wider text-muted-foreground">Full Name</label>
                    <Input className="bg-secondary/50 border-border rounded-none h-12 focus-visible:ring-primary" placeholder="John Doe" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-wider text-muted-foreground">Email Address</label>
                    <Input className="bg-secondary/50 border-border rounded-none h-12 focus-visible:ring-primary" placeholder="john@example.com" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-wider text-muted-foreground">Project Type</label>
                  <select defaultValue="" className="flex h-12 w-full items-center justify-between rounded-none border border-border bg-secondary/50 px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                    <option value="" disabled>Select an option</option>
                    <option value="cabinets">Custom Cabinetry</option>
                    <option value="furniture">Bespoke Furniture</option>
                    <option value="deck">Outdoor Decking</option>
                    <option value="interior">Interior Built-ins</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-wider text-muted-foreground">Project Details</label>
                  <Textarea className="bg-secondary/50 border-border rounded-none min-h-[150px] focus-visible:ring-primary" placeholder="Describe your vision, timeline, and space..." />
                </div>
                <Button className="w-full h-14 bg-primary hover:bg-primary/90 text-primary-foreground rounded-none uppercase tracking-widest text-sm transition-colors flex items-center justify-center gap-2">
                  Submit Inquiry <ArrowRight size={16} />
                </Button>
              </form>
            </div>

          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-black py-12 px-6 md:px-12 border-t border-border/30">
        <div className="container mx-auto max-w-7xl flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-primary font-sans uppercase tracking-[0.3em] text-sm font-semibold">
            WoodCraft Elite
          </div>
          <p className="text-muted-foreground text-xs font-light tracking-wide">
            &copy; {new Date().getFullYear()} WoodCraft Elite. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}