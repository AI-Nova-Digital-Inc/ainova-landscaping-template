import { motion } from "framer-motion";
import { Cloud } from "lucide-react";
import { 
  SiPython, SiPytorch, SiKubernetes,
  SiGooglecloud, SiApachekafka, SiDocker, SiNvidia, SiTerraform
} from "react-icons/si";

const techStack = [
  { name: "Python", icon: SiPython, isLucide: false },
  { name: "PyTorch", icon: SiPytorch, isLucide: false },
  { name: "CUDA / Nvidia", icon: SiNvidia, isLucide: false },
  { name: "Kubernetes", icon: SiKubernetes, isLucide: false },
  { name: "Docker", icon: SiDocker, isLucide: false },
  { name: "AWS", icon: null, isLucide: true },
  { name: "GCP", icon: SiGooglecloud, isLucide: false },
  { name: "Kafka", icon: SiApachekafka, isLucide: false },
  { name: "Terraform", icon: SiTerraform, isLucide: false },
];

export default function TechStack() {
  return (
    <section id="tech-stack" className="py-32 bg-background relative z-20 border-t border-white/5 border-b">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-xs font-mono text-primary uppercase tracking-widest mb-3"
          >
            Our Arsenal
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-5xl font-bold tracking-tight mb-4"
          >
            Core Technologies
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-muted-foreground text-lg"
          >
            The engineering foundation we build on.
          </motion.p>
        </div>

        <div className="flex flex-wrap justify-center gap-8 md:gap-12">
          {techStack.map((tech, index) => (
            <motion.div
              key={tech.name}
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              whileInView={{ opacity: 1, scale: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.07 }}
              whileHover={{ y: -8, scale: 1.05 }}
              className="flex flex-col items-center gap-4 group cursor-default"
              data-testid={`tech-${tech.name.toLowerCase().replace(/\s/g, "-")}`}
            >
              <div className="w-20 h-20 rounded-2xl border border-white/5 bg-white/3 backdrop-blur-sm flex items-center justify-center group-hover:bg-white/8 group-hover:border-primary/40 transition-all duration-300 shadow-lg group-hover:shadow-primary/10">
                {tech.isLucide ? (
                  <Cloud className="w-10 h-10 text-muted-foreground group-hover:text-primary transition-colors duration-300" />
                ) : (
                  tech.icon && <tech.icon className="w-10 h-10 text-muted-foreground group-hover:text-primary transition-colors duration-300" />
                )}
              </div>
              <span className="font-mono text-sm text-muted-foreground group-hover:text-primary transition-colors">
                {tech.name}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
