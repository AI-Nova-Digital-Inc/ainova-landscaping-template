import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const stages = [
  {
    id: "ingestion",
    name: "Data Ingestion",
    details: "High-throughput streaming pipelines via Kafka and Spark. Real-time data validation and schema enforcement.",
    color: "#00d4ff"
  },
  {
    id: "training",
    name: "Model Training",
    details: "Distributed PyTorch/JAX training across multi-node GPU clusters with Ray and DeepSpeed.",
    color: "#3b82f6"
  },
  {
    id: "evaluation",
    name: "Evaluation",
    details: "Automated benchmark suites, A/B testing, and model quality gating before deployment.",
    color: "#6366f1"
  },
  {
    id: "deployment",
    name: "Deployment",
    details: "Triton Inference Server on Kubernetes with auto-scaling based on queue depth and GPU utilization.",
    color: "#8b5cf6"
  },
  {
    id: "monitoring",
    name: "Monitoring",
    details: "Data drift detection, latency tracking, and automated retraining triggers via Prometheus & Grafana.",
    color: "#a855f7"
  }
];

export default function Pipeline() {
  const [activeStage, setActiveStage] = useState(stages[1].id);

  return (
    <section id="pipeline" className="py-32 bg-background relative z-20 overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-20 text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">AI Pipeline Architecture</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Our reference implementation for end-to-end machine learning operationalization.
          </p>
        </motion.div>

        <div className="flex flex-col lg:flex-row gap-12 items-center">
          {/* Interactive Flow Diagram */}
          <div className="w-full lg:w-1/2 relative">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/10 to-transparent blur-3xl -z-10" />
            
            <div className="flex flex-col space-y-4 relative">
              {stages.map((stage, index) => {
                const isActive = activeStage === stage.id;
                
                return (
                  <div key={stage.id} className="relative flex items-center group">
                    {/* Connecting line to next node */}
                    {index < stages.length - 1 && (
                      <div className="absolute left-6 top-12 bottom-[-16px] w-[2px] bg-white/10">
                        {isActive && (
                          <motion.div 
                            className="w-full bg-primary"
                            initial={{ height: 0, top: 0 }}
                            animate={{ height: "100%" }}
                            transition={{ duration: 1.5, repeat: Infinity }}
                          />
                        )}
                      </div>
                    )}
                    
                    <button
                      className={`w-12 h-12 rounded-full border-2 flex items-center justify-center z-10 transition-all duration-300 ${
                        isActive 
                          ? "border-primary bg-primary/20 shadow-[0_0_20px_rgba(0,212,255,0.5)]" 
                          : "border-white/20 bg-background hover:border-white/50"
                      }`}
                      onClick={() => setActiveStage(stage.id)}
                      data-interactive="true"
                    >
                      <div className={`w-4 h-4 rounded-full ${isActive ? "bg-primary" : "bg-white/20 group-hover:bg-white/50"}`} />
                    </button>
                    
                    <div 
                      className={`ml-8 py-4 px-6 rounded-lg glass-panel transition-all duration-300 cursor-pointer flex-1 ${
                        isActive ? "border-primary/50 bg-white/5" : "hover:bg-white/5 border-transparent"
                      }`}
                      onClick={() => setActiveStage(stage.id)}
                      data-interactive="true"
                    >
                      <h4 className={`text-xl font-bold ${isActive ? "text-primary" : "text-white"}`}>
                        {stage.name}
                      </h4>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Details Panel */}
          <div className="w-full lg:w-1/2 h-[400px]">
            <div className="glass-panel h-full p-10 rounded-2xl relative overflow-hidden border border-white/10">
              {/* Animated grid background */}
              <div className="absolute inset-0 opacity-10" 
                   style={{ backgroundImage: 'linear-gradient(#ffffff 1px, transparent 1px), linear-gradient(90deg, #ffffff 1px, transparent 1px)', backgroundSize: '30px 30px' }}>
              </div>
              
              <AnimatePresence mode="wait">
                {stages.map((stage) => (
                  stage.id === activeStage && (
                    <motion.div
                      key={stage.id}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.3 }}
                      className="relative z-10 h-full flex flex-col justify-center"
                    >
                      <div className="inline-block px-3 py-1 bg-white/10 rounded-full text-xs font-mono mb-6 w-fit" style={{ color: stage.color }}>
                        STAGE: {stage.id.toUpperCase()}
                      </div>
                      <h3 className="text-3xl font-bold mb-6 text-white">{stage.name}</h3>
                      <p className="text-xl text-muted-foreground leading-relaxed">
                        {stage.details}
                      </p>
                      
                      <div className="mt-8 flex gap-4 font-mono text-sm opacity-70">
                        <span className="px-2 py-1 bg-black/40 border border-white/10 rounded">LATENCY &lt; 5ms</span>
                        <span className="px-2 py-1 bg-black/40 border border-white/10 rounded">99.99% UPTIME</span>
                      </div>
                    </motion.div>
                  )
                ))}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
