import { useState, useEffect } from "react";
import { motion } from "framer-motion";

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <motion.nav
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled ? "py-4 glass-panel border-b border-white/5" : "py-6 bg-transparent"
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
    >
      <div className="container mx-auto px-6 flex items-center justify-between">
        <div 
          className="text-2xl font-bold tracking-tighter cursor-pointer flex items-center gap-2"
          onClick={() => scrollTo("hero")}
          data-interactive="true"
        >
          <div className="w-6 h-6 bg-primary rounded-sm shadow-[0_0_15px_rgba(0,212,255,0.6)]" />
          <span>QUANTUM<span className="text-primary">FORGE</span></span>
        </div>
        
        <div className="hidden md:flex items-center gap-8 text-sm font-medium tracking-wide">
          <button onClick={() => scrollTo("capabilities")} className="hover:text-primary transition-colors" data-interactive="true">Capabilities</button>
          <button onClick={() => scrollTo("pipeline")} className="hover:text-primary transition-colors" data-interactive="true">Pipeline</button>
          <button onClick={() => scrollTo("case-studies")} className="hover:text-primary transition-colors" data-interactive="true">Case Studies</button>
          <button onClick={() => scrollTo("tech-stack")} className="hover:text-primary transition-colors" data-interactive="true">Tech Stack</button>
          <button 
            onClick={() => scrollTo("contact")}
            className="px-5 py-2 bg-primary/10 border border-primary/30 text-primary hover:bg-primary/20 hover:shadow-[0_0_20px_rgba(0,212,255,0.3)] transition-all rounded-sm"
            data-interactive="true"
          >
            Engage
          </button>
        </div>
      </div>
    </motion.nav>
  );
}
