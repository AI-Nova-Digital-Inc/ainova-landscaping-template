import { useEffect, useRef } from "react";

interface Node {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  pulseOffset: number;
}

interface Pulse {
  fromIdx: number;
  toIdx: number;
  progress: number;
  speed: number;
}

export default function NeuralNetwork() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animFrameId: number;
    const nodeCount = 120;
    const connectionDist = 160;
    const nodes: Node[] = [];
    const pulses: Pulse[] = [];

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    for (let i = 0; i < nodeCount; i++) {
      nodes.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        radius: Math.random() * 2 + 1,
        pulseOffset: Math.random() * Math.PI * 2,
      });
    }

    const spawnPulse = () => {
      const fromIdx = Math.floor(Math.random() * nodeCount);
      const candidates: number[] = [];
      const from = nodes[fromIdx];
      for (let j = 0; j < nodeCount; j++) {
        if (j === fromIdx) continue;
        const dx = from.x - nodes[j].x;
        const dy = from.y - nodes[j].y;
        if (Math.sqrt(dx * dx + dy * dy) < connectionDist) candidates.push(j);
      }
      if (candidates.length > 0) {
        pulses.push({
          fromIdx,
          toIdx: candidates[Math.floor(Math.random() * candidates.length)],
          progress: 0,
          speed: 0.008 + Math.random() * 0.012,
        });
      }
    };

    let lastPulseTime = 0;

    const onMouseMove = (e: MouseEvent) => {
      mouseRef.current = { x: e.clientX, y: e.clientY };
    };
    window.addEventListener("mousemove", onMouseMove);

    const animate = (time: number) => {
      animFrameId = requestAnimationFrame(animate);
      const { width, height } = canvas;

      ctx.clearRect(0, 0, width, height);

      if (time - lastPulseTime > 200) {
        spawnPulse();
        lastPulseTime = time;
      }

      const mouse = mouseRef.current;

      for (const node of nodes) {
        node.x += node.vx;
        node.y += node.vy;
        if (node.x < 0 || node.x > width) node.vx *= -1;
        if (node.y < 0 || node.y > height) node.vy *= -1;

        const mdx = mouse.x - node.x;
        const mdy = mouse.y - node.y;
        const md = Math.sqrt(mdx * mdx + mdy * mdy);
        if (md < 120) {
          node.vx -= (mdx / md) * 0.08;
          node.vy -= (mdy / md) * 0.08;
          const speed = Math.sqrt(node.vx * node.vx + node.vy * node.vy);
          if (speed > 2) { node.vx *= 0.8; node.vy *= 0.8; }
        }
      }

      for (let i = 0; i < nodeCount; i++) {
        for (let j = i + 1; j < nodeCount; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < connectionDist) {
            const alpha = (1 - dist / connectionDist) * 0.25;
            const gradient = ctx.createLinearGradient(
              nodes[i].x, nodes[i].y, nodes[j].x, nodes[j].y
            );
            gradient.addColorStop(0, `rgba(0,212,255,${alpha})`);
            gradient.addColorStop(1, `rgba(139,92,246,${alpha})`);
            ctx.beginPath();
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.strokeStyle = gradient;
            ctx.lineWidth = 0.8;
            ctx.stroke();
          }
        }
      }

      for (let pi = pulses.length - 1; pi >= 0; pi--) {
        const p = pulses[pi];
        p.progress += p.speed;
        if (p.progress >= 1) {
          pulses.splice(pi, 1);
          continue;
        }
        const from = nodes[p.fromIdx];
        const to = nodes[p.toIdx];
        const px = from.x + (to.x - from.x) * p.progress;
        const py = from.y + (to.y - from.y) * p.progress;
        const glow = ctx.createRadialGradient(px, py, 0, px, py, 10);
        glow.addColorStop(0, "rgba(0,212,255,0.9)");
        glow.addColorStop(0.5, "rgba(139,92,246,0.4)");
        glow.addColorStop(1, "rgba(0,212,255,0)");
        ctx.beginPath();
        ctx.arc(px, py, 10, 0, Math.PI * 2);
        ctx.fillStyle = glow;
        ctx.fill();
      }

      for (const node of nodes) {
        const pulse = 0.5 + 0.5 * Math.sin(Date.now() * 0.002 + node.pulseOffset);
        const alpha = 0.4 + 0.6 * pulse;
        const r = node.radius * (1 + 0.3 * pulse);
        const glow = ctx.createRadialGradient(node.x, node.y, 0, node.x, node.y, r * 3);
        glow.addColorStop(0, `rgba(0,212,255,${alpha})`);
        glow.addColorStop(1, "rgba(0,212,255,0)");
        ctx.beginPath();
        ctx.arc(node.x, node.y, r * 3, 0, Math.PI * 2);
        ctx.fillStyle = glow;
        ctx.fill();

        ctx.beginPath();
        ctx.arc(node.x, node.y, r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0,212,255,${alpha})`;
        ctx.fill();
      }
    };

    animFrameId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animFrameId);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", onMouseMove);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 z-0 pointer-events-none opacity-70"
    />
  );
}
