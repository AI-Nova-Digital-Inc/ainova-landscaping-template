import { motion } from "framer-motion";
import { Server, Database, Cloud } from "lucide-react";

const capabilities = [
  {
    id: "ai-infra",
    title: "AI Infrastructure",
    description: "High-performance GPU clusters and distributed training environments optimized for foundational model development.",
    icon: Server,
    features: ["Hardware Acceleration", "Distributed Training", "Inference Optimization"]
  },
  {
    id: "mlops",
    title: "MLOps Platform Engineering",
    description: "End-to-end continuous training pipelines, model registries, and automated deployment architectures.",
    icon: Database,
    features: ["Feature Stores", "Model Versioning", "Automated Pipelines"]
  },
  {
    id: "cloud-native",
    title: "Cloud-Native Architecture",
    description: "Resilient, scalable Kubernetes-based microservices designed to handle massive data throughput.",
    icon: Cloud,
    features: ["Kubernetes Orchestration", "Service Mesh", "Zero-Trust Security"]
  }
];

export default function Capabilities() {
  return (
    <section id="capabilities" className="py-32 bg-background relative z-20">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">Capabilities</h2>
          <div className="h-1 w-24 bg-gradient-to-r from-primary to-secondary" />
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {capabilities.map((cap, index) => (
            <motion.div
              key={cap.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="glass-panel p-8 group hover:-translate-y-2 transition-transform duration-500"
              data-interactive="true"
            >
              <div className="w-16 h-16 rounded-lg bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                <cap.icon className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-4">{cap.title}</h3>
              <p className="text-muted-foreground mb-8 line-clamp-3">
                {cap.description}
              </p>
              
              <div className="space-y-3">
                {cap.features.map((feature, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-secondary" />
                    <span className="text-sm font-medium text-gray-300">{feature}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
