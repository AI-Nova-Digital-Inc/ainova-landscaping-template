import { motion } from "framer-motion";
import NeuralNetwork from "../NeuralNetwork";

export default function Hero() {
  const text = "Engineering Intelligence at Scale";
  const words = text.split(" ");

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background">
      <NeuralNetwork />
      
      <div className="container relative z-10 mx-auto px-6 pt-20">
        <div className="max-w-5xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex items-center gap-4 mb-6"
          >
            <div className="h-[1px] w-12 bg-primary" />
            <span className="text-primary font-mono tracking-widest text-sm uppercase">QuantumForge Systems</span>
          </motion.div>

          <h1 className="text-6xl md:text-8xl font-bold tracking-tighter leading-tight mb-8 text-white">
            {words.map((word, i) => (
              <span key={i} className="inline-block overflow-hidden mr-4">
                <motion.span
                  className="inline-block"
                  initial={{ y: "100%" }}
                  animate={{ y: 0 }}
                  transition={{
                    duration: 0.8,
                    delay: 0.5 + i * 0.1,
                    ease: [0.2, 0.65, 0.3, 0.9],
                  }}
                >
                  {word === "Intelligence" ? (
                    <span className="text-gradient">{word}</span>
                  ) : (
                    word
                  )}
                </motion.span>
              </span>
            ))}
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.2 }}
            className="text-xl md:text-2xl text-muted-foreground max-w-2xl font-light leading-relaxed mb-12"
          >
            We architect and deploy enterprise-grade AI infrastructure, distributed systems, and cloud-native platforms for the world's most demanding workloads.
          </motion.p>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 1.5 }}
            className="flex items-center gap-6"
          >
            <button 
              className="px-8 py-4 bg-primary text-primary-foreground font-bold tracking-wide hover:shadow-[0_0_30px_rgba(0,212,255,0.4)] transition-all relative overflow-hidden group"
              data-interactive="true"
            >
              <span className="relative z-10">Initialize Project</span>
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out" />
            </button>
            
            <button 
              className="px-8 py-4 border border-white/10 text-white font-medium hover:bg-white/5 transition-all"
              data-interactive="true"
            >
              View Architecture
            </button>
          </motion.div>
        </div>
      </div>
      
      {/* Gradient fade at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent z-10" />
    </section>
  );
}
