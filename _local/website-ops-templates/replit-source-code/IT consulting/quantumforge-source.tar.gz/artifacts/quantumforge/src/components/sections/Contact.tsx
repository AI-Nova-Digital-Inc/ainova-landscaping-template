import { useState } from "react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

export default function Contact() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate network request
    setTimeout(() => {
      setIsSubmitting(false);
      toast({
        title: "Transmission Received",
        description: "An architect will review your request and initialize contact.",
        duration: 5000,
      });
      (e.target as HTMLFormElement).reset();
    }, 1500);
  };

  return (
    <section id="contact" className="py-32 bg-[#080b13] relative z-20">
      <div className="container mx-auto px-6 max-w-5xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-5xl font-bold tracking-tight mb-6">Initialize<br/><span className="text-primary">Contact</span></h2>
            <p className="text-xl text-muted-foreground mb-12">
              Ready to scale? Connect with our lead engineers to discuss your infrastructure challenges.
            </p>
            
            <div className="space-y-6 text-gray-400 font-mono text-sm">
              <div className="flex items-center gap-4">
                <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
                <span>HQ: San Francisco, CA</span>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-2 h-2 bg-secondary rounded-full animate-pulse" style={{ animationDelay: "1s" }} />
                <span>STATUS: Accepting Enterprise Clients</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="glass-panel p-8 rounded-2xl border border-white/10"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-mono text-gray-400 uppercase tracking-wider">Name</label>
                <input 
                  type="text" 
                  required
                  className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary transition-colors focus:bg-white/5"
                  data-interactive="true"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-mono text-gray-400 uppercase tracking-wider">Company</label>
                <input 
                  type="text" 
                  required
                  className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary transition-colors focus:bg-white/5"
                  data-interactive="true"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-mono text-gray-400 uppercase tracking-wider">Email</label>
                <input 
                  type="email" 
                  required
                  className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary transition-colors focus:bg-white/5"
                  data-interactive="true"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-mono text-gray-400 uppercase tracking-wider">Message / Architecture Needs</label>
                <textarea 
                  required
                  rows={4}
                  className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary transition-colors focus:bg-white/5 resize-none"
                  data-interactive="true"
                ></textarea>
              </div>
              
              <button 
                type="submit" 
                disabled={isSubmitting}
                className="w-full py-4 bg-primary text-primary-foreground font-bold tracking-wide hover:shadow-[0_0_20px_rgba(0,212,255,0.4)] transition-all rounded-lg disabled:opacity-50 disabled:cursor-not-allowed flex justify-center items-center gap-2"
                data-interactive="true"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-background border-t-transparent rounded-full animate-spin" />
                    <span>Transmitting...</span>
                  </>
                ) : (
                  "Initiate Secure Channel"
                )}
              </button>
            </form>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
