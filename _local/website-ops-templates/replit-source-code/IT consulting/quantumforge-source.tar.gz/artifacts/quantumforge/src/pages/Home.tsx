import Nav from "@/components/Nav";
import CustomCursor from "@/components/CustomCursor";
import Hero from "@/components/sections/Hero";
import Capabilities from "@/components/sections/Capabilities";
import Pipeline from "@/components/sections/Pipeline";
import CaseStudies from "@/components/sections/CaseStudies";
import TechStack from "@/components/sections/TechStack";
import Contact from "@/components/sections/Contact";

export default function Home() {
  return (
    <div className="bg-background min-h-screen text-foreground font-sans selection:bg-primary/30 selection:text-white">
      <CustomCursor />
      <Nav />
      
      <main>
        <Hero />
        <Capabilities />
        <Pipeline />
        <CaseStudies />
        <TechStack />
        <Contact />
      </main>
      
      <footer className="py-8 bg-[#05070a] border-t border-white/5 text-center relative z-20">
        <p className="text-muted-foreground font-mono text-sm">
          &copy; {new Date().getFullYear()} QuantumForge Systems. Engineering Intelligence.
        </p>
      </footer>
    </div>
  );
}
