import { motion } from "framer-motion";
import caseStudy1 from "@/assets/images/case-study-1.png";
import caseStudy2 from "@/assets/images/case-study-2.png";
import caseStudy3 from "@/assets/images/case-study-3.png";

const caseStudies = [
  {
    id: "cs1",
    client: "Global Financial Org",
    title: "Fraud Detection at Scale",
    metrics: ["10x Inference Throughput", "sub-5ms Latency"],
    image: caseStudy1,
    description: "Re-architected legacy ML pipeline to handle 100k TPS using Triton and TensorRT."
  },
  {
    id: "cs2",
    client: "Autonomous Driving Startup",
    title: "Petabyte-Scale Training",
    metrics: ["40% Infra Cost Reduction", "3x Faster Training"],
    image: caseStudy2,
    description: "Designed a distributed GPU orchestration layer on Kubernetes with Ray."
  },
  {
    id: "cs3",
    client: "Healthcare Provider",
    title: "Secure LLM Deployment",
    metrics: ["HIPAA Compliant", "Zero-Trust Network"],
    image: caseStudy3,
    description: "Deployed private foundational models within a highly restricted on-premise air-gapped environment."
  }
];

export default function CaseStudies() {
  return (
    <section id="case-studies" className="py-32 bg-[#080b13] relative z-20">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16 flex flex-col md:flex-row md:items-end justify-between gap-8"
        >
          <div>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">Proven Impact</h2>
            <div className="h-1 w-24 bg-primary" />
          </div>
          <p className="text-xl text-muted-foreground max-w-lg">
            Engineering solutions for organizations where downtime is not an option.
          </p>
        </motion.div>

        <div className="space-y-8">
          {caseStudies.map((study, index) => (
            <motion.div
              key={study.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group relative overflow-hidden rounded-2xl glass-panel border border-white/5"
              data-interactive="true"
            >
              <div className="absolute inset-0 bg-black/60 z-10" />
              
              {/* Background Image */}
              <div 
                className="absolute inset-0 z-0 bg-cover bg-center transition-transform duration-1000 group-hover:scale-105 group-hover:rotate-1 opacity-40 group-hover:opacity-50"
                style={{ backgroundImage: `url(${study.image})` }}
              />
              
              <div className="relative z-20 p-8 md:p-12 flex flex-col md:flex-row gap-8 md:items-center justify-between h-full">
                <div className="max-w-2xl">
                  <span className="text-secondary font-mono text-sm tracking-widest uppercase mb-2 block">
                    {study.client}
                  </span>
                  <h3 className="text-3xl md:text-4xl font-bold mb-4 text-white group-hover:text-primary transition-colors">
                    {study.title}
                  </h3>
                  <p className="text-lg text-gray-300 mb-0">
                    {study.description}
                  </p>
                </div>
                
                <div className="flex flex-wrap md:flex-col gap-4 shrink-0">
                  {study.metrics.map((metric, i) => (
                    <div key={i} className="glass-panel px-6 py-3 rounded-lg border border-white/10 bg-black/40 backdrop-blur-md">
                      <span className="font-mono text-primary font-semibold">{metric}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
