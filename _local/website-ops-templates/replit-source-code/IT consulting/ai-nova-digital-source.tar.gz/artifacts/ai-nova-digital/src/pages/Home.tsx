import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { 
  Cloud, Cpu, Layers, Layout, ChevronRight, CheckCircle2, MessageSquare, X, Send, 
  Menu, Github, Linkedin, Twitter
} from 'lucide-react';
import { 
  SiGooglecloud, SiKubernetes, SiDocker, SiTerraform, 
  SiPython, SiTensorflow, SiGithubactions, SiReact, SiPostgresql, 
  SiRedis, SiPrometheus, SiCloudflare 
} from 'react-icons/si';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// --- Components ---

function LoadingScreen({ onComplete }: { onComplete: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onComplete, 2500);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <motion.div 
      className="fixed inset-0 z-[100] flex items-center justify-center bg-background"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.8, ease: "easeInOut" } }}
    >
      <div className="relative flex flex-col items-center">
        <motion.div 
          className="w-16 h-16 rounded-full border-t-2 border-primary border-r-2 border-r-transparent animate-spin"
        />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="mt-6 text-2xl font-bold tracking-widest text-white"
        >
          AI NOVA DIGITAL
        </motion.div>
      </div>
    </motion.div>
  );
}

function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'glass py-3' : 'py-5 bg-transparent'}`}
    >
      <div className="container mx-auto px-6 flex items-center justify-between">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => scrollTo('hero')}>
          <div className="w-8 h-8 rounded bg-gradient-to-br from-primary to-accent flex items-center justify-center">
            <Layers className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-xl tracking-tight hidden sm:block">AI NOVA DIGITAL</span>
        </div>

        <div className="hidden md:flex items-center gap-8">
          <button onClick={() => scrollTo('services')} className="text-sm font-medium text-muted-foreground hover:text-white transition-colors">Services</button>
          <button onClick={() => scrollTo('case-studies')} className="text-sm font-medium text-muted-foreground hover:text-white transition-colors">Case Studies</button>
          <button onClick={() => scrollTo('metrics')} className="text-sm font-medium text-muted-foreground hover:text-white transition-colors">Why Us</button>
          <button onClick={() => scrollTo('tech-stack')} className="text-sm font-medium text-muted-foreground hover:text-white transition-colors">Tech Stack</button>
          <Button onClick={() => scrollTo('contact')} className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold">
            Book Consultation
          </Button>
        </div>

        <div className="md:hidden">
          <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X /> : <Menu />}
          </Button>
        </div>
      </div>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden glass border-t border-white/10 mt-3"
          >
            <div className="flex flex-col p-4 gap-4">
              <button onClick={() => scrollTo('services')} className="text-left font-medium p-2 hover:bg-white/5 rounded">Services</button>
              <button onClick={() => scrollTo('case-studies')} className="text-left font-medium p-2 hover:bg-white/5 rounded">Case Studies</button>
              <button onClick={() => scrollTo('metrics')} className="text-left font-medium p-2 hover:bg-white/5 rounded">Why Us</button>
              <button onClick={() => scrollTo('contact')} className="text-left font-medium p-2 hover:bg-white/5 rounded">Contact</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}

function NeuralNetworkCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(0);
  const mouseRef = useRef({ x: 0, y: 0 });

  const initCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const NODE_COUNT = 90;
    interface Node { x: number; y: number; vx: number; vy: number; radius: number; pulse: number; }
    const nodes: Node[] = Array.from({ length: NODE_COUNT }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.4,
      vy: (Math.random() - 0.5) * 0.4,
      radius: Math.random() * 2.5 + 1,
      pulse: Math.random() * Math.PI * 2,
    }));

    const CONNECT_DIST = 160;

    const draw = () => {
      if (!canvas || !ctx) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const mx = mouseRef.current.x;
      const my = mouseRef.current.y;

      nodes.forEach(n => {
        n.x += n.vx;
        n.y += n.vy;
        if (n.x < 0 || n.x > canvas.width) n.vx *= -1;
        if (n.y < 0 || n.y > canvas.height) n.vy *= -1;
        n.pulse += 0.02;
      });

      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < CONNECT_DIST) {
            const alpha = (1 - dist / CONNECT_DIST) * 0.45;
            const gradient = ctx.createLinearGradient(nodes[i].x, nodes[i].y, nodes[j].x, nodes[j].y);
            gradient.addColorStop(0, `rgba(99,130,255,${alpha})`);
            gradient.addColorStop(1, `rgba(147,100,255,${alpha})`);
            ctx.beginPath();
            ctx.strokeStyle = gradient;
            ctx.lineWidth = 0.8;
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.stroke();
          }
        }
      }

      nodes.forEach(n => {
        const distToMouse = Math.sqrt((n.x - mx) ** 2 + (n.y - my) ** 2);
        const highlight = distToMouse < 120;
        const pulsedRadius = n.radius + Math.sin(n.pulse) * 0.6;
        const grd = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, pulsedRadius * 3);
        grd.addColorStop(0, highlight ? 'rgba(147,180,255,0.95)' : 'rgba(99,130,255,0.85)');
        grd.addColorStop(1, 'rgba(99,130,255,0)');
        ctx.beginPath();
        ctx.arc(n.x, n.y, pulsedRadius * 3, 0, Math.PI * 2);
        ctx.fillStyle = grd;
        ctx.fill();
        ctx.beginPath();
        ctx.arc(n.x, n.y, pulsedRadius, 0, Math.PI * 2);
        ctx.fillStyle = highlight ? 'rgba(160,200,255,0.95)' : 'rgba(120,160,255,0.8)';
        ctx.fill();
      });

      animationRef.current = requestAnimationFrame(draw);
    };

    draw();

    const handleMouse = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };
    canvas.addEventListener('mousemove', handleMouse);

    return () => {
      window.removeEventListener('resize', resize);
      canvas.removeEventListener('mousemove', handleMouse);
      cancelAnimationFrame(animationRef.current);
    };
  }, []);

  useEffect(() => {
    const cleanup = initCanvas();
    return cleanup;
  }, [initCanvas]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full"
      style={{ opacity: 0.7 }}
    />
  );
}

function Hero() {
  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      <div className="absolute inset-0 z-0">
        <NeuralNetworkCanvas />
      </div>
      
      <div className="container relative z-10 mx-auto px-6 flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <span className="inline-block py-1 px-3 rounded-full bg-primary/10 border border-primary/20 text-primary font-medium text-sm mb-6">
            Enterprise Digital Transformation
          </span>
        </motion.div>
        
        <motion.h1 
          className="text-5xl md:text-7xl font-bold tracking-tight max-w-4xl mb-6 font-serif"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          Transforming Businesses with <span className="gradient-text">AI & Cloud</span>
        </motion.h1>
        
        <motion.p 
          className="text-lg md:text-xl text-muted-foreground max-w-2xl mb-10"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          Enterprise-grade AI, Cloud Engineering, and DevOps solutions that cut costs, accelerate delivery, and future-proof your infrastructure.
        </motion.p>
        
        <motion.div 
          className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          <Button size="lg" className="h-14 px-8 text-base bg-primary hover:bg-primary/90 rounded-full" onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}>
            Book a Free Consultation
          </Button>
          <Button size="lg" variant="outline" className="h-14 px-8 text-base border-white/20 hover:bg-white/5 rounded-full" onClick={() => document.getElementById('case-studies')?.scrollIntoView({ behavior: 'smooth' })}>
            View Our Work
          </Button>
        </motion.div>
      </div>
      
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-8 h-12 rounded-full border-2 border-white/20 flex justify-center p-2">
          <div className="w-1 h-3 bg-white/50 rounded-full" />
        </div>
      </div>
    </section>
  );
}

function Services() {
  const services = [
    { icon: <Cloud className="w-8 h-8 text-primary" />, title: "Cloud Engineering", desc: "AWS, Azure, Kubernetes infrastructure at scale." },
    { icon: <Cpu className="w-8 h-8 text-accent" />, title: "AI & Machine Learning", desc: "Custom models, MLOps pipelines, LLM integrations." },
    { icon: <Layers className="w-8 h-8 text-primary" />, title: "DevOps & Automation", desc: "CI/CD, Docker, Terraform, zero-downtime deployments." },
    { icon: <Layout className="w-8 h-8 text-accent" />, title: "Website & App Development", desc: "High-performance web and mobile products." }
  ];

  return (
    <section id="services" className="py-24 bg-background relative z-10">
      <div className="container mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold font-serif mb-4">What We Build For You</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">Scalable, secure, and modern solutions tailored for enterprise needs.</p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass-card p-8 rounded-2xl hover-glow group cursor-pointer"
            >
              <div className="mb-6 p-4 rounded-full bg-white/5 inline-block group-hover:scale-110 transition-transform">
                {s.icon}
              </div>
              <h3 className="text-xl font-bold mb-3">{s.title}</h3>
              <p className="text-muted-foreground">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CaseStudies() {
  const cases = [
    { title: "GlobalBank Financial", desc: "Reduced infrastructure costs 40% by migrating to AWS with Kubernetes. Improved deployment frequency from monthly to daily.", tags: ["Cloud", "Kubernetes", "AWS"] },
    { title: "MediCore Health Systems", desc: "Built HIPAA-compliant ML pipeline processing 2M patient records/day for predictive diagnostics.", tags: ["AI/ML", "Python", "Compliance"] },
    { title: "NovaTech Manufacturing", desc: "Deployed end-to-end DevOps automation reducing release cycles from 3 weeks to 4 hours across 12 global teams.", tags: ["DevOps", "Terraform", "CI/CD"] }
  ];

  return (
    <section id="case-studies" className="py-24 relative z-10 border-t border-white/5">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-5xl font-bold font-serif mb-4">Proven at Enterprise Scale</h2>
            <p className="text-muted-foreground text-lg max-w-xl">We've transformed infrastructure for industry leaders.</p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <Button variant="link" className="text-primary p-0 hover:text-primary/80">
              View all case studies <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </motion.div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {cases.map((c, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="glass-card rounded-2xl overflow-hidden group hover-glow flex flex-col"
            >
              <div className="h-48 bg-gradient-to-br from-white/5 to-white/10 p-6 flex flex-col justify-end relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-primary/20 blur-[50px] rounded-full group-hover:bg-primary/30 transition-colors" />
                <h3 className="text-2xl font-bold relative z-10">{c.title}</h3>
              </div>
              <div className="p-6 flex flex-col flex-grow">
                <p className="text-muted-foreground mb-6 flex-grow">{c.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {c.tags.map(t => (
                    <span key={t} className="text-xs font-medium px-2.5 py-1 rounded bg-white/10 text-white/80 border border-white/5">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Counter({ end, suffix = "", duration = 2 }: { end: number, suffix?: string, duration?: number }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });

  useEffect(() => {
    if (!inView) return;
    let start = 0;
    const step = end / (duration * 60);
    const timer = setInterval(() => {
      start += step;
      if (start > end) {
        setCount(end);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [inView, end, duration]);

  return <span ref={ref}>{count}{suffix}</span>;
}

function Metrics() {
  const points = [
    "Contract-free engagements",
    "Dedicated senior engineers, not juniors",
    "Security & compliance baked in",
    "24/7 monitoring & support"
  ];

  return (
    <section id="metrics" className="py-24 bg-primary/5 relative z-10">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold font-serif mb-4">Results That Speak</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">We measure our success by your bottom line.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-16">
          <div className="text-center">
            <div className="text-4xl md:text-5xl font-bold text-white mb-2"><Counter end={40} suffix="%" /></div>
            <div className="text-sm text-muted-foreground">Avg Cost Reduction</div>
          </div>
          <div className="text-center">
            <div className="text-4xl md:text-5xl font-bold text-white mb-2"><Counter end={10} suffix="x" /></div>
            <div className="text-sm text-muted-foreground">Faster Deployments</div>
          </div>
          <div className="text-center">
            <div className="text-4xl md:text-5xl font-bold text-white mb-2"><Counter end={150} suffix="+" /></div>
            <div className="text-sm text-muted-foreground">Enterprise Clients</div>
          </div>
          <div className="text-center">
            <div className="text-4xl md:text-5xl font-bold text-white mb-2"><Counter end={99.99} suffix="%" /></div>
            <div className="text-sm text-muted-foreground">SLA Uptime</div>
          </div>
          <div className="text-center col-span-2 md:col-span-1">
            <div className="text-4xl md:text-5xl font-bold text-white mb-2">$<Counter end={2} suffix="B+" /></div>
            <div className="text-sm text-muted-foreground">Infra Managed</div>
          </div>
        </div>

        <div className="flex flex-wrap justify-center gap-6 max-w-4xl mx-auto">
          {points.map((p, i) => (
            <div key={i} className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-primary" />
              <span className="font-medium text-white/90">{p}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TechStack() {
  const logos = [
    <SiGooglecloud size={48} />, <SiCloudflare size={48} />, <SiKubernetes size={48} />, 
    <SiDocker size={48} />, <SiTerraform size={48} />, <SiPython size={48} />, 
    <SiTensorflow size={48} />, <SiGithubactions size={48} />, <SiReact size={48} />, 
    <SiPostgresql size={48} />, <SiRedis size={48} />, <SiPrometheus size={48} />
  ];

  return (
    <section id="tech-stack" className="py-24 relative z-10 border-y border-white/5 overflow-hidden">
      <div className="container mx-auto px-6 text-center mb-12">
        <h2 className="text-3xl md:text-5xl font-bold font-serif mb-4">Built With Industry-Leading Tools</h2>
      </div>
      
      <div className="w-full inline-flex flex-nowrap overflow-hidden [mask-image:_linear-gradient(to_right,transparent_0,_black_128px,_black_calc(100%-128px),transparent_100%)]">
        <ul className="flex items-center justify-center md:justify-start [&_li]:mx-8 animate-marquee whitespace-nowrap">
          {logos.map((logo, i) => (
            <li key={i} className="text-muted-foreground/50 hover:text-white transition-colors duration-300">
              {logo}
            </li>
          ))}
        </ul>
        <ul className="flex items-center justify-center md:justify-start [&_li]:mx-8 animate-marquee whitespace-nowrap" aria-hidden="true">
          {logos.map((logo, i) => (
            <li key={i} className="text-muted-foreground/50 hover:text-white transition-colors duration-300">
              {logo}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

const contactFormSchema = z.object({
  fullName: z.string().min(2, "Name is required"),
  email: z.string().email("Invalid email address"),
  company: z.string().min(2, "Company name is required"),
  service: z.string().min(1, "Please select a service"),
  message: z.string().min(10, "Message must be at least 10 characters")
});

function Contact() {
  const { toast } = useToast();
  
  const form = useForm<z.infer<typeof contactFormSchema>>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      fullName: "",
      email: "",
      company: "",
      service: "",
      message: ""
    }
  });

  function onSubmit(values: z.infer<typeof contactFormSchema>) {
    console.log(values);
    toast({
      title: "Success!",
      description: "Thank you! We'll be in touch within 24 hours.",
    });
    form.reset();
  }

  return (
    <section id="contact" className="py-24 relative z-10">
      <div className="container mx-auto px-6 max-w-6xl">
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold font-serif mb-6">Ready to Transform Your Business?</h2>
            <p className="text-muted-foreground text-lg mb-8">Book a free 30-minute consultation with our senior engineers to discuss your architecture and challenges.</p>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-primary">
                  <MessageSquare />
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Email us</div>
                  <div className="font-medium text-lg">hello@ainovadigital.com</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-primary">
                  <span className="font-bold">#</span>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Call us</div>
                  <div className="font-medium text-lg">+1 (888) 264-6682</div>
                </div>
              </div>
            </div>
          </div>

          <div className="glass-card p-8 rounded-2xl">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" className="bg-white/5 border-white/10" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Company Email</FormLabel>
                        <FormControl>
                          <Input placeholder="john@company.com" className="bg-white/5 border-white/10" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="company"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Company Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Acme Corp" className="bg-white/5 border-white/10" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="service"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Service of Interest</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-white/5 border-white/10">
                            <SelectValue placeholder="Select a service" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-card border-white/10 text-white">
                          <SelectItem value="cloud">Cloud Engineering</SelectItem>
                          <SelectItem value="ai">AI/ML</SelectItem>
                          <SelectItem value="devops">DevOps</SelectItem>
                          <SelectItem value="web">Web/App Dev</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Message</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Tell us about your project..." 
                          className="min-h-[120px] bg-white/5 border-white/10 resize-none" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full h-12 text-base font-semibold bg-primary hover:bg-primary/90">
                  Book Free Consultation
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </section>
  );
}

function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user'|'bot', text: string}[]>([
    { role: 'bot', text: 'Hi there! I am the Nova AI Assistant. How can I help you today?' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSend = (text: string) => {
    if (!text.trim()) return;
    
    setMessages(prev => [...prev, { role: 'user', text }]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      let response = "I'd be happy to connect you with our senior engineers to discuss that further. Would you like to book a consultation?";
      if (text.toLowerCase().includes('cost') || text.toLowerCase().includes('price')) {
        response = "Our engagements typically start at $10k/month, but vary widely based on scope. We offer contract-free engagements to ensure value delivery.";
      } else if (text.toLowerCase().includes('service')) {
        response = "We specialize in Cloud Engineering, AI & Machine Learning, DevOps, and Custom Software Development.";
      }
      
      setIsTyping(false);
      setMessages(prev => [...prev, { role: 'bot', text: response }]);
    }, 1000);
  };

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-24 right-6 w-[350px] h-[500px] glass-card rounded-2xl flex flex-col overflow-hidden z-50 shadow-2xl border border-white/10"
          >
            <div className="p-4 bg-white/5 border-b border-white/10 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-primary/20 flex items-center justify-center relative">
                  <MessageSquare className="w-4 h-4 text-primary" />
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-background animate-pulse" />
                </div>
                <div>
                  <h4 className="font-medium text-sm">Nova AI Assistant</h4>
                  <p className="text-xs text-muted-foreground">Online</p>
                </div>
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => setIsOpen(false)}>
                <X className="w-4 h-4" />
              </Button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((m, i) => (
                <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${m.role === 'user' ? 'bg-primary text-white rounded-tr-sm' : 'bg-white/10 text-white/90 rounded-tl-sm'}`}>
                    {m.text}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="max-w-[80%] p-3 rounded-2xl bg-white/10 rounded-tl-sm flex gap-1">
                    <span className="w-2 h-2 bg-white/50 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-2 h-2 bg-white/50 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-2 h-2 bg-white/50 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-3 bg-white/5 border-t border-white/10">
              <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar mb-2">
                {['What services do you offer?', 'How much does it cost?', 'Book a consultation'].map((q) => (
                  <button 
                    key={q}
                    onClick={() => handleSend(q)}
                    className="text-xs whitespace-nowrap px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full transition-colors text-white/80"
                  >
                    {q}
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <Input 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend(input)}
                  placeholder="Type your message..."
                  className="bg-white/5 border-white/10 text-sm h-10"
                />
                <Button onClick={() => handleSend(input)} size="icon" className="h-10 w-10 bg-primary hover:bg-primary/90 shrink-0">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        className="fixed bottom-6 right-6 w-14 h-14 bg-primary hover:bg-primary/90 text-white rounded-full flex items-center justify-center shadow-lg z-40 transition-transform hover:scale-105"
        onClick={() => setIsOpen(!isOpen)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageSquare className="w-6 h-6" />}
      </motion.button>
    </>
  );
}

function Footer() {
  return (
    <footer className="bg-background border-t border-white/10 py-12 mt-20 relative z-10">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Layers className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-xl tracking-tight">AI NOVA DIGITAL</span>
            </div>
            <p className="text-muted-foreground text-sm max-w-sm mb-6">
              The elite navigator for enterprise digital transformation. Modernizing mission-critical infrastructure with AI, Cloud, and DevOps.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-muted-foreground hover:text-white transition-colors"><Github className="w-5 h-5" /></a>
              <a href="#" className="text-muted-foreground hover:text-white transition-colors"><Twitter className="w-5 h-5" /></a>
              <a href="#" className="text-muted-foreground hover:text-white transition-colors"><Linkedin className="w-5 h-5" /></a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Services</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-white transition-colors">Cloud Engineering</a></li>
              <li><a href="#" className="hover:text-white transition-colors">AI & Machine Learning</a></li>
              <li><a href="#" className="hover:text-white transition-colors">DevOps Automation</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Custom Software</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Company</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-white transition-colors">Case Studies</a></li>
              <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-muted-foreground">
          <div>© 2026 AI Nova Digital Inc. All rights reserved.</div>
          <div className="flex gap-4">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default function Home() {
  const [loading, setLoading] = useState(true);

  return (
    <>
      <AnimatePresence>
        {loading && <LoadingScreen onComplete={() => setLoading(false)} />}
      </AnimatePresence>
      
      {!loading && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="min-h-screen bg-background text-foreground overflow-x-hidden selection:bg-primary/30"
        >
          <Navigation />
          <main>
            <Hero />
            <Services />
            <CaseStudies />
            <Metrics />
            <TechStack />
            <Contact />
          </main>
          <Footer />
          <Chatbot />
        </motion.div>
      )}
    </>
  );
}
