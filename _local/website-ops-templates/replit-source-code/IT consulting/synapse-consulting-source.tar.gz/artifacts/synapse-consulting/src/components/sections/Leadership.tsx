import { motion } from "framer-motion";

const leaders = [
  {
    name: "Dr. Alexandra Chen",
    role: "Managing Director, Digital Strategy",
    bio: "20 years advising Fortune 500 boards on technology transformation and enterprise resilience.",
  },
  {
    name: "Marcus Webb",
    role: "Partner, Enterprise Architecture",
    bio: "Former CTO of two global banks. Expert in large-scale systems modernization.",
  },
  {
    name: "Dr. Priya Sharma",
    role: "Principal, Executive Advisory",
    bio: "Trusted counsel to 40+ C-suite leaders across financial services, healthcare, and energy.",
  }
];

export default function Leadership() {
  return (
    <section id="leadership" className="bg-background text-foreground py-32 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="mb-24"
        >
          <span className="text-xs font-sans tracking-[0.1em] uppercase text-muted-foreground">
            Leadership
          </span>
          <div className="h-[1px] w-full bg-border mt-6 relative overflow-hidden">
            <motion.div
              initial={{ x: "-100%" }}
              whileInView={{ x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1.5, ease: "easeInOut" }}
              className="absolute inset-0 bg-accent"
            />
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-16 md:gap-8">
          {leaders.map((leader, index) => (
            <motion.div
              key={leader.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 1, delay: index * 0.15, ease: "easeOut" }}
              className="flex flex-col items-center text-center group"
            >
              {/* Elegant CSS Avatar */}
              <div className="relative w-48 h-48 mb-8">
                {/* Accent Ring */}
                <div className="absolute inset-0 border border-border rounded-full transition-colors duration-700 group-hover:border-accent" />
                <div className="absolute inset-2 bg-muted rounded-full overflow-hidden flex items-center justify-center">
                  <div className="w-full h-full bg-gradient-to-br from-gray-100 to-gray-200" />
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-1000 bg-gradient-to-tr from-accent/10 to-transparent" />
                  {/* Subtle geometric pattern representing the person */}
                  <div className="absolute w-24 h-[1px] bg-foreground/10 rotate-45" />
                  <div className="absolute w-24 h-[1px] bg-foreground/10 -rotate-45" />
                </div>
              </div>

              <h3 className="font-serif text-3xl font-light mb-2">{leader.name}</h3>
              <p className="font-sans text-xs uppercase tracking-widest text-accent mb-6">
                {leader.role}
              </p>
              <p className="font-sans text-muted-foreground text-sm leading-relaxed max-w-sm">
                {leader.bio}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}