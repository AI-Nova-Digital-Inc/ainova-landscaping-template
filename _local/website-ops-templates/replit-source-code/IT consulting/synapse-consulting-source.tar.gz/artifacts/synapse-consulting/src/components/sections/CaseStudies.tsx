import { motion } from "framer-motion";

const cases = [
  {
    client: "Global Financial Institution",
    stat: "67%",
    description: "Reduced time-to-market for digital products by 67% through enterprise architecture overhaul. $2.4B in new revenue channels opened.",
  },
  {
    client: "Fortune 100 Healthcare Enterprise",
    stat: "34%",
    description: "End-to-end ERP transformation across 140 business units. 34% operational cost reduction in 18 months.",
  }
];

export default function CaseStudies() {
  return (
    <section id="impact" className="bg-[#FAFAFA] text-foreground py-32 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="mb-20"
        >
          <span className="text-xs font-sans tracking-[0.1em] uppercase text-muted-foreground">
            Client Impact
          </span>
          <div className="h-[1px] w-full bg-border mt-6 relative overflow-hidden">
            <motion.div
              initial={{ x: "-100%" }}
              whileInView={{ x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1.5, ease: "easeInOut" }}
              className="absolute inset-0 bg-accent"
            />
          </div>
        </motion.div>

        <div className="flex flex-col gap-12">
          {cases.map((caseStudy, index) => (
            <motion.div
              key={caseStudy.client}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 1, delay: index * 0.2, ease: "easeOut" }}
              className="group bg-[#0A0A0A] text-[#F5F5F0] p-12 md:p-20 relative overflow-hidden cursor-pointer"
            >
              {/* Left Accent Line */}
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-accent transform origin-bottom scale-y-0 group-hover:scale-y-100 transition-transform duration-700 ease-out" />
              
              <div className="flex flex-col md:flex-row items-start md:items-center gap-12 md:gap-24 relative z-10">
                <div className="md:w-1/3">
                  <h4 className="font-sans text-xs uppercase tracking-[0.15em] text-[#C9A84C] mb-4">
                    {caseStudy.client}
                  </h4>
                  <div className="font-serif text-7xl md:text-8xl lg:text-[10rem] font-light leading-none">
                    {caseStudy.stat}
                  </div>
                </div>
                
                <div className="md:w-2/3 flex flex-col items-start">
                  <p className="font-serif text-2xl md:text-3xl lg:text-4xl font-light leading-relaxed mb-10 text-[#E8E8E8]">
                    "{caseStudy.description}"
                  </p>
                  <span className="font-sans text-sm tracking-wider uppercase flex items-center gap-3 text-[#C9A84C]">
                    View Case Study
                    <span className="transform group-hover:translate-x-2 transition-transform duration-500">
                      &rarr;
                    </span>
                  </span>
                </div>
              </div>

              {/* Background gradient effect on hover */}
              <div className="absolute inset-0 bg-gradient-to-r from-accent/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 ease-out pointer-events-none" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}