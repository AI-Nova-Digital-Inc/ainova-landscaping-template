import { useState, useEffect } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Menu, X } from "lucide-react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 50;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, [scrolled]);

  return (
    <motion.nav
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 1, ease: "easeOut" }}
      className={`fixed top-0 left-0 right-0 z-50 transition-colors duration-500 ease-out ${
        scrolled
          ? "bg-white/95 backdrop-blur-md border-b border-border shadow-sm text-foreground"
          : "bg-transparent text-foreground"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between h-24">
        {/* Logo */}
        <Link href="/" className="font-serif text-2xl tracking-widest uppercase cursor-pointer">
          Synapse
        </Link>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-10">
          <a
            href="#capabilities"
            className="text-xs uppercase tracking-widest font-medium hover:text-accent transition-colors"
          >
            Capabilities
          </a>
          <a
            href="#insights"
            className="text-xs uppercase tracking-widest font-medium hover:text-accent transition-colors"
          >
            Insights
          </a>
          <a
            href="#impact"
            className="text-xs uppercase tracking-widest font-medium hover:text-accent transition-colors"
          >
            Impact
          </a>
          <a
            href="#leadership"
            className="text-xs uppercase tracking-widest font-medium hover:text-accent transition-colors"
          >
            Leadership
          </a>
          <a
            href="#contact"
            className="text-xs uppercase tracking-widest font-medium px-5 py-3 border border-accent text-accent hover:bg-accent hover:text-white transition-colors"
          >
            Request Consultation
          </a>
        </div>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden p-2 -mr-2"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white border-b border-border shadow-lg py-6 px-6 flex flex-col gap-6 text-foreground">
          <a
            href="#capabilities"
            onClick={() => setMobileMenuOpen(false)}
            className="text-xs uppercase tracking-widest font-medium"
          >
            Capabilities
          </a>
          <a
            href="#insights"
            onClick={() => setMobileMenuOpen(false)}
            className="text-xs uppercase tracking-widest font-medium"
          >
            Insights
          </a>
          <a
            href="#impact"
            onClick={() => setMobileMenuOpen(false)}
            className="text-xs uppercase tracking-widest font-medium"
          >
            Impact
          </a>
          <a
            href="#leadership"
            onClick={() => setMobileMenuOpen(false)}
            className="text-xs uppercase tracking-widest font-medium"
          >
            Leadership
          </a>
          <a
            href="#contact"
            onClick={() => setMobileMenuOpen(false)}
            className="text-xs uppercase tracking-widest font-medium text-accent"
          >
            Request Consultation
          </a>
        </div>
      )}
    </motion.nav>
  );
}