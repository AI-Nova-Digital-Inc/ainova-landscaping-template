import { motion } from "framer-motion";

const articles = [
  {
    title: "The Architecture of AI Readiness: What CIOs Must Build Before They Deploy",
    category: "Enterprise AI",
    readTime: "8 min read",
    featured: true,
  },
  {
    title: "Digital Transformation Isn't a Project. It's a Permanent Condition.",
    category: "Strategy",
    readTime: "6 min read",
    featured: false,
  },
  {
    title: "Why Most Technology Strategies Fail at the Board Level",
    category: "Leadership",
    readTime: "5 min read",
    featured: false,
  },
];

export default function Insights() {
  return (
    <section id="insights" className="bg-background text-foreground py-32 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="mb-20"
        >
          <span className="text-xs font-sans tracking-[0.1em] uppercase text-muted-foreground">
            Thought Leadership
          </span>
          <div className="h-[1px] w-full bg-border mt-6 relative overflow-hidden">
            <motion.div
              initial={{ x: "-100%" }}
              whileInView={{ x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1.5, ease: "easeInOut" }}
              className="absolute inset-0 bg-accent"
            />
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Featured Article */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="group cursor-pointer flex flex-col"
          >
            {/* CSS Art Placeholder */}
            <div className="w-full aspect-[4/3] bg-muted mb-8 relative overflow-hidden flex items-center justify-center">
              <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-200" />
              <div className="w-48 h-48 border border-accent/30 rounded-full absolute -top-12 -right-12" />
              <div className="w-64 h-64 border border-accent/20 rounded-full absolute -bottom-24 -left-12" />
              <div className="w-32 h-32 bg-accent/10 backdrop-blur-md absolute z-10 transition-transform duration-1000 group-hover:scale-110 group-hover:rotate-12" />
            </div>

            <div className="flex items-center gap-4 mb-4 text-xs font-sans uppercase tracking-wider">
              <span className="text-accent">{articles[0].category}</span>
              <span className="text-muted-foreground">|</span>
              <span className="text-muted-foreground">{articles[0].readTime}</span>
            </div>

            <h3 className="font-serif text-3xl md:text-4xl font-light leading-snug mb-6 group-hover:text-accent transition-colors duration-500">
              {articles[0].title}
            </h3>

            <span className="mt-auto font-sans text-sm tracking-wider uppercase flex items-center gap-2 group-hover:text-accent transition-colors duration-500">
              Read More
              <span className="transform group-hover:translate-x-1 transition-transform duration-500">
                &rarr;
              </span>
            </span>
          </motion.div>

          {/* Secondary Articles */}
          <div className="flex flex-col gap-12">
            {articles.slice(1).map((article, index) => (
              <motion.div
                key={article.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 1, delay: 0.2 + index * 0.15, ease: "easeOut" }}
                className="group cursor-pointer flex flex-col sm:flex-row gap-8"
              >
                {/* CSS Art Placeholder */}
                <div className="w-full sm:w-1/2 aspect-video bg-muted relative overflow-hidden flex items-center justify-center shrink-0">
                   <div className="absolute inset-0 bg-gradient-to-tr from-gray-50 to-gray-100" />
                   {index === 0 ? (
                     <div className="w-full h-[1px] bg-accent/20 absolute top-1/2 rotate-45 transition-transform duration-1000 group-hover:rotate-[60deg]" />
                   ) : (
                     <div className="w-20 h-20 border border-accent/30 absolute transition-transform duration-1000 group-hover:scale-125" />
                   )}
                </div>

                <div className="flex flex-col justify-center">
                  <div className="flex items-center gap-3 mb-3 text-[10px] font-sans uppercase tracking-wider">
                    <span className="text-accent">{article.category}</span>
                    <span className="text-muted-foreground">|</span>
                    <span className="text-muted-foreground">{article.readTime}</span>
                  </div>

                  <h3 className="font-serif text-2xl font-light leading-snug mb-4 group-hover:text-accent transition-colors duration-500">
                    {article.title}
                  </h3>

                  <span className="mt-auto font-sans text-xs tracking-wider uppercase flex items-center gap-2 group-hover:text-accent transition-colors duration-500">
                    Read More
                    <span className="transform group-hover:translate-x-1 transition-transform duration-500">
                      &rarr;
                    </span>
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}