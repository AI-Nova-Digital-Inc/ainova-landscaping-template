import Navbar from "@/components/layout/Navbar";
import Hero from "@/components/sections/Hero";
import Services from "@/components/sections/Services";
import Insights from "@/components/sections/Insights";
import CaseStudies from "@/components/sections/CaseStudies";
import Leadership from "@/components/sections/Leadership";
import Contact from "@/components/sections/Contact";
import Footer from "@/components/layout/Footer";

export default function Home() {
  return (
    <main className="min-h-screen bg-background text-foreground font-sans">
      <Navbar />
      <Hero />
      <Services />
      <Insights />
      <CaseStudies />
      <Leadership />
      <Contact />
      <Footer />
    </main>
  );
}