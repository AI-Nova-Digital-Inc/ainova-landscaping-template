export default function Footer() {
  return (
    <footer className="bg-[#0A0A0A] border-t border-[#1a1a1a] py-8 px-6 md:px-12 text-[#E8E8E8]/50">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-[10px] font-sans uppercase tracking-widest">
        <div className="flex items-center gap-4">
          <span className="font-serif normal-case text-xs tracking-widest text-[#F5F5F0]">SYNAPSE</span>
          <span>&copy; 2026 Synapse Consulting Group. All rights reserved.</span>
        </div>
        <div className="flex items-center gap-6">
          <a href="#" className="hover:text-[#C9A84C] transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-[#C9A84C] transition-colors">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
}