import { useRef, useEffect } from "react";
import { motion } from "framer-motion";

export default function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Neural Network Canvas Animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let nodes: Node[] = [];
    const numNodes = window.innerWidth < 768 ? 40 : 80;
    const connectionDistance = 150;

    class Node {
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;

      constructor() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.vx = (Math.random() - 0.5) * 0.5;
        this.vy = (Math.random() - 0.5) * 0.5;
        this.radius = Math.random() * 2 + 1;
      }

      update() {
        this.x += this.vx;
        this.y += this.vy;

        if (this.x < 0 || this.x > canvas.width) this.vx *= -1;
        if (this.y < 0 || this.y > canvas.height) this.vy *= -1;
      }

      draw() {
        if (!ctx) return;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(201, 168, 76, 0.6)"; // gold color for nodes
        ctx.fill();
      }
    }

    const init = () => {
      // Retain device pixel ratio for sharpness
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${rect.height}px`;

      nodes = Array.from({ length: numNodes }, () => new Node());
    };

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (let i = 0; i < nodes.length; i++) {
        nodes[i].update();
        nodes[i].draw();

        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < connectionDistance) {
            ctx.beginPath();
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            const alpha = 1 - dist / connectionDistance;
            ctx.strokeStyle = `rgba(201, 168, 76, ${alpha * 0.4})`; // gold lines
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }
      }

      animationFrameId = requestAnimationFrame(animate);
    };

    init();
    animate();

    const handleResize = () => {
      init();
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <section className="relative min-h-screen flex items-center pt-24 bg-background overflow-hidden">
      {/* Left Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 md:px-12 flex flex-col md:flex-row items-center">
        <motion.div
          className="w-full md:w-1/2"
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1.2, ease: "easeOut", delay: 0.2 }}
        >
          <h1 className="font-serif text-5xl sm:text-6xl md:text-7xl lg:text-[5rem] leading-[1.1] font-light text-foreground mb-8">
            Where Strategy <br />
            <span className="italic text-accent">Meets</span> Technology
          </h1>
          <p className="text-muted-foreground text-lg md:text-xl font-sans max-w-lg mb-12 leading-relaxed">
            Enterprise transformation for leaders who demand more than advice.
          </p>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
            <a
              href="#contact"
              className="bg-foreground text-background px-8 py-4 text-sm uppercase tracking-widest font-medium hover:bg-accent hover:text-white transition-colors duration-500"
            >
              Schedule a Conversation
            </a>
            <a
              href="#impact"
              className="text-foreground text-sm uppercase tracking-widest font-medium hover:text-accent transition-colors duration-500 flex items-center gap-2 group"
            >
              Explore Our Work
              <span className="transform group-hover:translate-x-1 transition-transform duration-500">
                &rarr;
              </span>
            </a>
          </div>
        </motion.div>

        {/* Right Canvas (Mobile: positioned absolutely, Desktop: relative flex child) */}
        <div className="absolute inset-0 md:relative md:w-1/2 md:h-[600px] pointer-events-none md:pointer-events-auto opacity-30 md:opacity-100">
          <canvas ref={canvasRef} className="w-full h-full" />
        </div>
      </div>
    </section>
  );
}