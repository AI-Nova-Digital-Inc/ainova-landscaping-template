import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const formSchema = z.object({
  name: z.string().min(2, "Name is required"),
  company: z.string().min(2, "Company is required"),
  title: z.string().min(2, "Title is required"),
  email: z.string().email("Invalid email address"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

export default function Contact() {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      company: "",
      title: "",
      email: "",
      message: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    // Static site - just console log and reset
    console.log(values);
    form.reset();
  }

  return (
    <section id="contact" className="bg-[#0A0A0A] text-[#F5F5F0] pt-32 px-6 md:px-12 relative">
      <div className="max-w-7xl mx-auto pb-32">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
          
          {/* Left: Copy */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            <h2 className="font-serif text-6xl md:text-7xl font-light leading-tight mb-8">
              Ready to <br/>
              <span className="italic text-[#C9A84C]">Transform?</span>
            </h2>
            <p className="font-sans text-xl text-[#E8E8E8]/70 leading-relaxed max-w-md">
              We engage selectively. If you're building something that matters, let's talk.
            </p>
          </motion.div>

          {/* Right: Form */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
          >
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input 
                            placeholder="Name" 
                            {...field} 
                            className="bg-transparent border-0 border-b border-[#E8E8E8]/20 rounded-none px-0 py-4 text-[#F5F5F0] placeholder:text-[#E8E8E8]/40 focus-visible:ring-0 focus-visible:border-[#C9A84C] transition-colors font-sans text-lg"
                          />
                        </FormControl>
                        <FormMessage className="text-[#C9A84C]" />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="company"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input 
                            placeholder="Company" 
                            {...field} 
                            className="bg-transparent border-0 border-b border-[#E8E8E8]/20 rounded-none px-0 py-4 text-[#F5F5F0] placeholder:text-[#E8E8E8]/40 focus-visible:ring-0 focus-visible:border-[#C9A84C] transition-colors font-sans text-lg"
                          />
                        </FormControl>
                        <FormMessage className="text-[#C9A84C]" />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input 
                            placeholder="Title" 
                            {...field} 
                            className="bg-transparent border-0 border-b border-[#E8E8E8]/20 rounded-none px-0 py-4 text-[#F5F5F0] placeholder:text-[#E8E8E8]/40 focus-visible:ring-0 focus-visible:border-[#C9A84C] transition-colors font-sans text-lg"
                          />
                        </FormControl>
                        <FormMessage className="text-[#C9A84C]" />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input 
                            placeholder="Email" 
                            type="email"
                            {...field} 
                            className="bg-transparent border-0 border-b border-[#E8E8E8]/20 rounded-none px-0 py-4 text-[#F5F5F0] placeholder:text-[#E8E8E8]/40 focus-visible:ring-0 focus-visible:border-[#C9A84C] transition-colors font-sans text-lg"
                          />
                        </FormControl>
                        <FormMessage className="text-[#C9A84C]" />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Textarea 
                          placeholder="Message" 
                          {...field} 
                          className="bg-transparent border-0 border-b border-[#E8E8E8]/20 rounded-none px-0 py-4 text-[#F5F5F0] placeholder:text-[#E8E8E8]/40 focus-visible:ring-0 focus-visible:border-[#C9A84C] transition-colors font-sans text-lg min-h-[120px] resize-none"
                        />
                      </FormControl>
                      <FormMessage className="text-[#C9A84C]" />
                    </FormItem>
                  )}
                />

                <button
                  type="submit"
                  className="mt-8 font-sans text-sm uppercase tracking-widest px-10 py-4 bg-[#C9A84C] text-[#0A0A0A] hover:bg-[#F5F5F0] transition-colors duration-500 w-full sm:w-auto"
                >
                  Submit Inquiry
                </button>
              </form>
            </Form>
          </motion.div>
        </div>

        {/* Locations */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 1, delay: 0.4, ease: "easeOut" }}
          className="mt-32 pt-16 flex flex-col md:flex-row justify-between items-center gap-8 relative"
        >
          {/* Subtle gold divider */}
          <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#C9A84C]/30 to-transparent" />
          
          <div className="font-sans text-xs uppercase tracking-[0.2em] text-[#E8E8E8]/60">
            New York &middot; London &middot; Singapore &middot; Dubai
          </div>
          
          <a href="#" className="font-sans text-xs uppercase tracking-[0.2em] text-[#C9A84C] hover:text-[#F5F5F0] transition-colors">
            LinkedIn
          </a>
        </motion.div>
      </div>
    </section>
  );
}