import { motion } from "framer-motion";

const services = [
  {
    numeral: "I",
    title: "Digital Transformation",
    description:
      "Reimagining enterprise operations from the inside out. We architect the change that makes disruption irrelevant.",
  },
  {
    numeral: "II",
    title: "Enterprise Architecture",
    description:
      "Building the systems that hold strategy together — scalable, resilient, and aligned to business intent.",
  },
  {
    numeral: "III",
    title: "Executive Advisory",
    description:
      "Direct counsel for technology leaders navigating high-stakes decisions. Strategy without the noise.",
  },
];

export default function Services() {
  return (
    <section id="capabilities" className="bg-[#0A0A0A] text-[#F5F5F0] py-32 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="mb-24"
        >
          <span className="text-xs font-sans tracking-[0.1em] uppercase text-[#E8E8E8]/60">
            Capabilities
          </span>
          <div className="h-[1px] w-full bg-[#E8E8E8]/10 mt-6 relative overflow-hidden">
            <motion.div
              initial={{ x: "-100%" }}
              whileInView={{ x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1.5, ease: "easeInOut" }}
              className="absolute inset-0 bg-[#C9A84C]"
            />
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 1, delay: index * 0.15, ease: "easeOut" }}
              className="group cursor-default"
            >
              {/* Animated top line */}
              <div className="h-[1px] w-12 bg-[#C9A84C] mb-8 transition-all duration-700 ease-out group-hover:w-full" />
              
              <span className="font-serif text-[#C9A84C] text-2xl italic mb-6 block">
                {service.numeral}.
              </span>
              
              <h3 className="font-serif text-3xl font-light mb-6 transition-transform duration-500 ease-out group-hover:translate-x-2">
                {service.title}
              </h3>
              
              <p className="font-sans text-[#E8E8E8]/70 text-lg leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}