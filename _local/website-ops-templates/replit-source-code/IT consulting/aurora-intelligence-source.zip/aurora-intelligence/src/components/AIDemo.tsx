import { useState, useEffect, useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const conversation = [
  {
    role: 'user' as const,
    text: 'What can Aurora Intelligence do for our startup?'
  },
  {
    role: 'ai' as const,
    text: 'Aurora Intelligence specializes in three core transformation vectors: (1) Production-grade LLM infrastructure with sub-100ms latency, (2) Autonomous agent systems that replace entire operational workflows, (3) Real-time ML pipelines processing billions of events daily.'
  },
  {
    role: 'user' as const,
    text: 'How quickly can we go from idea to deployment?'
  },
  {
    role: 'ai' as const,
    text: 'Our Rapid Intelligence Deployment framework compresses typical 6-month AI builds into 6-week sprints. We\'ve shipped production AI systems for Series A startups through Fortune 500 enterprises with zero-downtime deployment on day one.'
  }
];

const stats = [
  { label: 'AI Systems Deployed', value: 200, suffix: '+' },
  { label: 'API Calls / Day', value: 40, suffix: 'M+' },
  { label: 'System Uptime', value: 99.97, suffix: '%', decimals: 2 },
];

function useTypewriter(text: string, speed: number = 30, enabled: boolean = false) {
  const [displayed, setDisplayed] = useState('');
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!enabled) return;
    setDisplayed('');
    setDone(false);
    let i = 0;
    const interval = setInterval(() => {
      if (i < text.length) {
        setDisplayed(text.slice(0, i + 1));
        i++;
      } else {
        setDone(true);
        clearInterval(interval);
      }
    }, speed);
    return () => clearInterval(interval);
  }, [text, speed, enabled]);

  return { displayed, done };
}

function CountUp({ target, suffix, decimals = 0, enabled }: { target: number; suffix: string; decimals?: number; enabled: boolean }) {
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!enabled) return;
    let start = 0;
    const duration = 2000;
    const startTime = performance.now();

    const step = (now: number) => {
      const progress = Math.min((now - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = start + (target - start) * eased;
      setValue(current);
      if (progress < 1) requestAnimationFrame(step);
    };

    requestAnimationFrame(step);
  }, [target, enabled]);

  return (
    <span>
      {value.toFixed(decimals)}{suffix}
    </span>
  );
}

function ChatMessage({ msg, index, sectionInView }: {
  msg: typeof conversation[0];
  index: number;
  sectionInView: boolean;
}) {
  const [enabled, setEnabled] = useState(false);
  const { displayed, done } = useTypewriter(msg.text, msg.role === 'ai' ? 20 : 40, enabled);

  useEffect(() => {
    if (!sectionInView) return;
    const delay = index * 1800 + 500;
    const timer = setTimeout(() => setEnabled(true), delay);
    return () => clearTimeout(timer);
  }, [sectionInView, index]);

  if (!enabled) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
    >
      {msg.role === 'ai' && (
        <div className="w-6 h-6 rounded-sm bg-accent/20 border border-accent/40 flex items-center justify-center flex-shrink-0 mr-3 mt-1">
          <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
        </div>
      )}
      <div
        className={`max-w-[80%] px-4 py-3 rounded-sm text-sm leading-relaxed font-mono ${
          msg.role === 'user'
            ? 'bg-primary/15 border border-primary/20 text-white/80'
            : 'bg-card border border-border text-muted-foreground'
        }`}
      >
        {displayed}
        {!done && (
          <span className="inline-block w-1.5 h-3.5 bg-accent ml-0.5 animate-pulse align-text-bottom" />
        )}
      </div>
      {msg.role === 'user' && (
        <div className="w-6 h-6 rounded-sm bg-primary/20 border border-primary/40 flex items-center justify-center flex-shrink-0 ml-3 mt-1">
          <div className="w-2 h-2 rounded-full bg-primary" />
        </div>
      )}
    </motion.div>
  );
}

export default function AIDemo() {
  const ref = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: '-150px' });

  return (
    <section ref={ref} id="demo" className="py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-violet-950/10 to-transparent pointer-events-none" />

      <div className="container mx-auto px-6">
        <div className="mb-16">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="inline-block text-xs tracking-[0.3em] text-accent font-mono uppercase mb-4"
          >
            Experience Aurora Intelligence
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="text-5xl md:text-6xl font-bold text-white font-sans tracking-tight"
          >
            AI Interaction
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary to-accent"> Demo</span>
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="rounded-sm overflow-hidden border border-border"
            style={{ background: 'rgba(10, 14, 24, 0.9)', backdropFilter: 'blur(20px)' }}
          >
            <div className="flex items-center gap-2 px-4 py-3 border-b border-border">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/60" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
                <div className="w-3 h-3 rounded-full bg-green-500/60" />
              </div>
              <span className="text-xs font-mono text-muted-foreground ml-2">aurora-intelligence — terminal</span>
              <div className="ml-auto flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                <span className="text-xs font-mono text-accent">CONNECTED</span>
              </div>
            </div>

            <div className="p-6 flex flex-col gap-4 min-h-[400px]">
              <div className="flex items-center gap-2 font-mono text-xs text-muted-foreground mb-2">
                <span className="text-accent">$</span>
                <span>aurora connect --model gpt4-turbo --mode interactive</span>
              </div>

              {conversation.map((msg, i) => (
                <ChatMessage key={i} msg={msg} index={i} sectionInView={inView} />
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex flex-col gap-6"
          >
            <p className="text-muted-foreground leading-relaxed text-lg">
              Our AI systems aren&apos;t demos — they&apos;re production infrastructure handling millions of requests, with uptime and latency SLAs that match the world&apos;s most demanding platforms.
            </p>

            <div className="grid grid-cols-1 gap-4">
              {stats.map((stat, i) => (
                <motion.div
                  key={stat.label}
                  data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: i * 0.15 }}
                  className="p-6 rounded-sm border border-border"
                  style={{ background: 'rgba(13, 17, 23, 0.7)', backdropFilter: 'blur(10px)' }}
                >
                  <div className="text-4xl font-bold font-sans text-white mb-1">
                    <CountUp target={stat.value} suffix={stat.suffix} decimals={stat.decimals} enabled={inView} />
                  </div>
                  <div className="text-sm font-mono text-muted-foreground tracking-wider">{stat.label.toUpperCase()}</div>
                  <div className="mt-3 h-px bg-gradient-to-r from-primary/50 to-transparent" />
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
