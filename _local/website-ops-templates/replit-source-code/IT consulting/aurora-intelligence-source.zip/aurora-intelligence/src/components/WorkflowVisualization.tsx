import { useState, useEffect, useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const stages = [
  {
    id: 'input',
    label: 'INPUT',
    detail: 'Raw data, APIs, events, documents',
    color: '#0080ff',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
        <path d="M12 3v14M5 10l7-7 7 7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M5 21h14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      </svg>
    )
  },
  {
    id: 'ingest',
    label: 'INGEST',
    detail: 'Real-time streaming, ETL, validation',
    color: '#4d9fff',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
        <path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
        <path d="M17 14v6M14 17h6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      </svg>
    )
  },
  {
    id: 'ai-core',
    label: 'AI CORE',
    detail: 'LLMs, fine-tuned models, agents',
    color: '#00d4ff',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
        <circle cx="12" cy="12" r="4" stroke="currentColor" strokeWidth="1.5"/>
        <path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      </svg>
    )
  },
  {
    id: 'transform',
    label: 'TRANSFORM',
    detail: 'Post-processing, enrichment, routing',
    color: '#9b5cf6',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
        <path d="M7 8h10M7 12h7M7 16h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        <rect x="2" y="4" width="20" height="16" rx="2" stroke="currentColor" strokeWidth="1.5"/>
      </svg>
    )
  },
  {
    id: 'output',
    label: 'OUTPUT',
    detail: 'APIs, databases, dashboards, actions',
    color: '#7c3aed',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
        <path d="M12 21V7M5 14l7 7 7-7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M5 3h14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      </svg>
    )
  }
];

export default function WorkflowVisualization() {
  const ref = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });
  const [hoveredStage, setHoveredStage] = useState<string | null>(null);
  const [packetPos, setPacketPos] = useState(0);

  useEffect(() => {
    if (!inView) return;
    let start: number | null = null;
    const duration = 3000;

    const animate = (timestamp: number) => {
      if (!start) start = timestamp;
      const progress = ((timestamp - start) % duration) / duration;
      setPacketPos(progress);
      requestAnimationFrame(animate);
    };

    const id = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(id);
  }, [inView]);

  return (
    <section ref={ref} id="workflow" className="py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-950/8 to-transparent pointer-events-none" />

      <div className="container mx-auto px-6">
        <div className="mb-16">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="inline-block text-xs tracking-[0.3em] text-accent font-mono uppercase mb-4"
          >
            How We Work
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="text-5xl md:text-6xl font-bold text-white font-sans tracking-tight"
          >
            The Aurora
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent to-secondary"> Pipeline</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="mt-4 text-muted-foreground max-w-xl text-lg"
          >
            Every AI system we build follows a battle-tested five-stage architecture designed for reliability, scale, and zero-surprise production behavior.
          </motion.p>
        </div>

        <div className="relative">
          <div className="flex flex-col lg:flex-row items-stretch gap-0 lg:gap-0">
            {stages.map((stage, i) => (
              <div key={stage.id} className="flex flex-col lg:flex-row items-center flex-1">
                <motion.div
                  data-testid={`stage-${stage.id}`}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: i * 0.12 }}
                  onMouseEnter={() => setHoveredStage(stage.id)}
                  onMouseLeave={() => setHoveredStage(null)}
                  className="relative flex flex-col items-center p-6 rounded-sm cursor-default transition-all duration-300 w-full"
                  style={{
                    background: hoveredStage === stage.id
                      ? `rgba(13, 17, 23, 0.95)`
                      : 'rgba(13, 17, 23, 0.6)',
                    border: `1px solid ${hoveredStage === stage.id ? stage.color + '60' : 'rgba(255,255,255,0.06)'}`,
                    backdropFilter: 'blur(20px)',
                    transform: hoveredStage === stage.id ? 'translateY(-4px)' : 'translateY(0)',
                    boxShadow: hoveredStage === stage.id ? `0 8px 30px ${stage.color}25` : 'none',
                  }}
                >
                  <div
                    className="w-12 h-12 rounded-sm flex items-center justify-center mb-4 transition-all duration-300"
                    style={{
                      background: `${stage.color}20`,
                      color: stage.color,
                      boxShadow: hoveredStage === stage.id ? `0 0 15px ${stage.color}40` : 'none',
                    }}
                  >
                    {stage.icon}
                  </div>

                  <span className="text-xs font-mono tracking-[0.2em] mb-2 font-semibold" style={{ color: stage.color }}>
                    {stage.label}
                  </span>

                  <p className="text-xs text-center text-muted-foreground leading-relaxed">
                    {stage.detail}
                  </p>

                  <div
                    className="absolute bottom-0 left-4 right-4 h-px transition-all duration-300"
                    style={{
                      background: `linear-gradient(90deg, transparent, ${stage.color}, transparent)`,
                      opacity: hoveredStage === stage.id ? 1 : 0,
                    }}
                  />

                  <div
                    className="absolute top-0 left-0 right-0 h-px"
                    style={{
                      background: `linear-gradient(90deg, transparent, ${stage.color}50, transparent)`,
                      opacity: 0.5,
                    }}
                  />
                </motion.div>

                {i < stages.length - 1 && (
                  <div className="relative flex-shrink-0 w-full lg:w-12 h-6 lg:h-full flex items-center justify-center">
                    <div
                      className="w-full lg:w-px h-px lg:h-full opacity-30"
                      style={{
                        background: 'repeating-linear-gradient(90deg, rgba(0,128,255,0.4) 0, rgba(0,128,255,0.4) 4px, transparent 4px, transparent 12px)',
                      }}
                    />
                    {inView && (
                      <motion.div
                        className="absolute w-3 h-3 rounded-full"
                        style={{
                          background: 'radial-gradient(circle, #00d4ff, #0080ff)',
                          boxShadow: '0 0 12px #00d4ff, 0 0 4px #ffffff80',
                          left: `${packetPos * 100}%`,
                          transform: 'translate(-50%, -50%)',
                          top: '50%',
                        }}
                      />
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
