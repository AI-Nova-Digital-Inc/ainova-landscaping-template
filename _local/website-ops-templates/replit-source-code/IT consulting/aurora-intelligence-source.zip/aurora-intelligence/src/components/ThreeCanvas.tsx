import { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import RobotScene from './RobotScene';

export default function ThreeCanvas() {
  return (
    <Canvas camera={{ position: [0, 0, 8], fov: 45 }} className="w-full h-full">
      <ambientLight intensity={0.15} />
      <pointLight position={[5, 5, 5]} color="#0080ff" intensity={3} />
      <pointLight position={[-5, -5, -5]} color="#7c3aed" intensity={2} />
      <pointLight position={[0, 5, 0]} color="#00d4ff" intensity={1.5} />
      <Suspense fallback={null}>
        <RobotScene />
      </Suspense>
    </Canvas>
  );
}
