import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import HeroScene from './HeroScene';
import NeuralGrid from './NeuralGrid';

export default function HeroSection() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
  const yText = useTransform(scrollYProgress, [0, 1], [0, 120]);
  const yScene = useTransform(scrollYProgress, [0, 1], [0, 60]);
  const scrollOpacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  return (
    <section ref={ref} id="services" className="relative h-screen w-full flex items-center overflow-hidden">
      <NeuralGrid />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_70%_50%,rgba(0,128,255,0.08),transparent_60%)] pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10 flex flex-col md:flex-row items-center justify-between h-full pt-20">

        <motion.div
          className="w-full md:w-[55%] flex flex-col items-start justify-center gap-6"
          style={{ y: yText, opacity: scrollOpacity }}
        >
          <span className="inline-block text-xs tracking-[0.3em] text-accent font-mono uppercase border border-accent/30 px-3 py-1.5 rounded-sm hero-fade-1">
            AI Engineering Studio
          </span>

          <h1 className="text-5xl md:text-7xl xl:text-8xl font-bold font-sans tracking-tighter leading-[1.05] hero-fade-2">
            <span className="block text-white">INTELLIGENCE</span>
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-primary via-accent to-secondary">
              ENGINEERED
            </span>
            <span className="block text-white/50 text-4xl md:text-5xl xl:text-6xl">FOR THE FUTURE</span>
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground max-w-lg leading-relaxed hero-fade-3">
            Aurora Intelligence Systems builds the AI infrastructure that defines what's next — autonomous agents to real-time ML pipelines at scale.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 hero-fade-4">
            <a
              href="#contact"
              className="interactive px-8 py-4 bg-primary text-primary-foreground font-semibold rounded-sm hover:bg-primary/90 transition-all shadow-[0_0_30px_rgba(0,128,255,0.35)] hover:shadow-[0_0_50px_rgba(0,128,255,0.6)] text-center"
            >
              Start Your AI Journey
            </a>
            <a
              href="#capabilities"
              className="interactive px-8 py-4 border border-white/20 text-white font-medium rounded-sm hover:bg-white/5 hover:border-white/40 transition-all text-center"
            >
              Explore Capabilities
            </a>
          </div>
        </motion.div>

        <motion.div
          className="hidden md:flex w-[45%] h-[80%] absolute right-0 top-1/2 -translate-y-1/2"
          style={{ y: yScene, opacity: scrollOpacity }}
        >
          <HeroScene />
        </motion.div>
      </div>

      <motion.div
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 z-10"
        style={{ opacity: scrollOpacity }}
      >
        <span className="text-xs text-muted-foreground tracking-widest font-mono">SCROLL</span>
        <div className="w-px h-10 bg-gradient-to-b from-muted-foreground to-transparent animate-pulse" />
      </motion.div>

      <style>{`
        @keyframes heroFade {
          from { opacity: 0; transform: translateY(24px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        .hero-fade-1 { animation: heroFade 0.6s ease-out 0.0s both; }
        .hero-fade-2 { animation: heroFade 0.7s ease-out 0.1s both; }
        .hero-fade-3 { animation: heroFade 0.6s ease-out 0.2s both; }
        .hero-fade-4 { animation: heroFade 0.6s ease-out 0.3s both; }
      `}</style>
    </section>
  );
}
