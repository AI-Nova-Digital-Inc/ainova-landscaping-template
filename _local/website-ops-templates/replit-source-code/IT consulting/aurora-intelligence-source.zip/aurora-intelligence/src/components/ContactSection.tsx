import { useState } from 'react';
import { motion } from 'framer-motion';
import { Linkedin, Github } from 'lucide-react';

export default function ContactSection() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) setSubmitted(true);
  };

  return (
    <section id="contact" className="py-40 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full blur-[120px] opacity-15"
          style={{ background: 'radial-gradient(circle, #0080ff 0%, #7c3aed 50%, transparent 70%)' }} />
      </div>

      <div className="container mx-auto px-6 text-center relative z-10">
        <motion.span
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="inline-block text-xs tracking-[0.3em] text-accent font-mono uppercase mb-6"
        >
          Ready to Build the Future?
        </motion.span>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-5xl md:text-7xl font-bold text-white font-sans tracking-tighter mb-6"
        >
          Start Your
          <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-accent to-secondary">
            AI Journey
          </span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-xl text-muted-foreground max-w-lg mx-auto mb-12"
        >
          Let&apos;s engineer intelligence into your business. Drop your email and we&apos;ll be in touch within 24 hours.
        </motion.p>

        <motion.form
          onSubmit={handleSubmit}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto mb-16"
        >
          {submitted ? (
            <div className="flex-1 flex items-center justify-center gap-3 px-6 py-4 rounded-sm border border-accent/30 bg-accent/10">
              <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
              <span className="font-mono text-accent text-sm">Transmission received. We&apos;ll be in touch.</span>
            </div>
          ) : (
            <>
              <div className="flex-1 relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 font-mono text-accent text-sm select-none">$</span>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@company.com"
                  data-testid="input-email"
                  required
                  className="w-full pl-8 pr-4 py-4 bg-card border border-border rounded-sm font-mono text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 focus:shadow-[0_0_0_1px_rgba(0,128,255,0.3)] transition-all"
                />
              </div>
              <button
                type="submit"
                data-testid="button-get-in-touch"
                className="interactive px-8 py-4 bg-primary text-primary-foreground font-semibold rounded-sm hover:bg-primary/90 transition-all shadow-[0_0_20px_rgba(0,128,255,0.3)] hover:shadow-[0_0_35px_rgba(0,128,255,0.55)] whitespace-nowrap"
              >
                Get in Touch
              </button>
            </>
          )}
        </motion.form>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="flex items-center justify-center gap-8 mb-16"
        >
          <a
            href="https://linkedin.com"
            target="_blank"
            rel="noopener noreferrer"
            data-testid="link-linkedin"
            className="interactive flex items-center gap-2 text-muted-foreground hover:text-white transition-colors group"
          >
            <Linkedin className="w-5 h-5 group-hover:text-primary transition-colors" />
            <span className="text-sm font-mono">LinkedIn</span>
          </a>
          <div className="w-px h-4 bg-border" />
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            data-testid="link-github"
            className="interactive flex items-center gap-2 text-muted-foreground hover:text-white transition-colors group"
          >
            <Github className="w-5 h-5 group-hover:text-accent transition-colors" />
            <span className="text-sm font-mono">GitHub</span>
          </a>
        </motion.div>

        <div className="border-t border-border pt-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="font-bold text-primary font-sans">AURORA</span>
              <span className="w-1.5 h-1.5 rounded-full bg-primary shadow-[0_0_8px_rgba(0,128,255,0.8)] animate-pulse" />
              <span className="text-[10px] tracking-[0.2em] text-muted-foreground">INTELLIGENCE SYSTEMS</span>
            </div>
            <p className="text-xs text-muted-foreground font-mono">
              &copy; 2025 Aurora Intelligence Systems. Engineered for the future.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
