import { motion } from 'framer-motion';

const cases = [
  {
    id: 'fintech',
    tag: 'FinTech',
    title: 'AI Underwriting Platform',
    metric: '4 min',
    metricLabel: 'from 4 days',
    description: 'Reduced loan processing from 4 days to 4 minutes using autonomous AI agents with 98.2% accuracy.',
    stack: ['Fine-tuned LLM', 'Custom RAG', 'Real-time Decisioning'],
    result: '98.2% accuracy',
    color: '#0080ff',
  },
  {
    id: 'enterprise',
    tag: 'Enterprise',
    title: 'Automation Platform',
    metric: '340%',
    metricLabel: 'ROI in 90 days',
    description: 'Replaced 12 manual workflows with intelligent automation, delivering transformational ROI in under 3 months.',
    stack: ['Multi-agent Orchestration', 'Custom Connectors', 'Audit Trails'],
    result: '12 workflows automated',
    color: '#7c3aed',
  },
  {
    id: 'realtime',
    tag: 'Platform',
    title: 'Real-Time Intelligence',
    metric: '50M+',
    metricLabel: 'events / day',
    description: 'Processes 50M+ events daily with sub-20ms anomaly detection latency at global scale.',
    stack: ['Streaming ML', 'Vector Search', 'Auto-scaling Inference'],
    result: 'sub-20ms latency',
    color: '#00d4ff',
  },
];

export default function CaseStudies() {
  return (
    <section id="case-studies" className="py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-purple-950/8 to-transparent pointer-events-none" />

      <div className="container mx-auto px-6">
        <div className="mb-16">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="inline-block text-xs tracking-[0.3em] text-accent font-mono uppercase mb-4"
          >
            Transformations We&apos;ve Engineered
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="text-5xl md:text-6xl font-bold text-white font-sans tracking-tight"
          >
            Case
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary to-primary"> Studies</span>
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {cases.map((c, i) => (
            <motion.div
              key={c.id}
              data-testid={`card-case-study-${c.id}`}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: i * 0.15 }}
              whileHover={{ y: -6, transition: { duration: 0.25 } }}
              className="relative rounded-sm overflow-hidden flex flex-col group"
              style={{
                background: 'rgba(13, 17, 23, 0.8)',
                backdropFilter: 'blur(20px)',
                border: `1px solid ${c.color}30`,
              }}
            >
              <div
                className="absolute top-0 left-0 right-0 h-px"
                style={{ background: `linear-gradient(90deg, transparent, ${c.color}, transparent)` }}
              />

              <div className="absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl pointer-events-none"
                style={{ background: `${c.color}10` }} />

              <div className="p-8 flex flex-col flex-1">
                <div className="flex items-center justify-between mb-6">
                  <span
                    className="text-xs font-mono tracking-widest px-3 py-1 rounded-sm"
                    style={{ background: `${c.color}20`, color: c.color }}
                  >
                    {c.tag}
                  </span>
                  <div className="w-8 h-8 rounded-sm flex items-center justify-center border"
                    style={{ borderColor: `${c.color}30`, background: `${c.color}10` }}>
                    <svg viewBox="0 0 16 16" fill="none" className="w-4 h-4" style={{ color: c.color }}>
                      <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                </div>

                <div className="mb-6">
                  <div className="text-5xl font-bold font-sans text-white mb-1" style={{ textShadow: `0 0 20px ${c.color}60` }}>
                    {c.metric}
                  </div>
                  <div className="text-sm font-mono" style={{ color: c.color }}>{c.metricLabel}</div>
                </div>

                <h3 className="text-lg font-semibold text-white mb-3 font-sans">{c.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-6 flex-1">{c.description}</p>

                <div className="border-t pt-5" style={{ borderColor: `${c.color}20` }}>
                  <p className="text-xs font-mono text-muted-foreground mb-3 tracking-widest">TECH STACK</p>
                  <div className="flex flex-wrap gap-2">
                    {c.stack.map((s) => (
                      <span
                        key={s}
                        className="text-xs px-2 py-1 rounded-sm font-mono"
                        style={{
                          background: `${c.color}10`,
                          border: `1px solid ${c.color}20`,
                          color: `${c.color}cc`,
                        }}
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                  <div className="mt-4 text-xs font-mono font-semibold" style={{ color: c.color }}>
                    {c.result}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
