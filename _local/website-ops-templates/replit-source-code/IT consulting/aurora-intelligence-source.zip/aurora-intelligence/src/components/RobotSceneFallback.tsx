import { useEffect, useRef } from 'react';

export default function RobotSceneFallback() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const dx = (e.clientX - cx) / rect.width;
      const dy = (e.clientY - cy) / rect.height;
      container.style.setProperty('--rx', `${dy * 12}deg`);
      container.style.setProperty('--ry', `${-dx * 12}deg`);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div
      ref={containerRef}
      className="w-full h-full flex items-center justify-center"
      style={{ perspective: '800px', '--rx': '0deg', '--ry': '0deg' } as React.CSSProperties}
    >
      <div
        className="relative"
        style={{
          transform: 'rotateX(var(--rx)) rotateY(var(--ry))',
          transition: 'transform 0.1s ease-out',
          transformStyle: 'preserve-3d',
        }}
      >
        {/* Outer pulsing ring */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div
            className="rounded-full border border-accent/20 animate-ping"
            style={{ width: '420px', height: '420px', animationDuration: '3s' }}
          />
        </div>

        {/* Second ring */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div
            className="rounded-full border border-primary/10 animate-ping"
            style={{ width: '340px', height: '340px', animationDuration: '2.5s', animationDelay: '0.5s' }}
          />
        </div>

        {/* Orbit ring 1 */}
        <div
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
          style={{ animation: 'spin 8s linear infinite' }}
        >
          <div
            className="rounded-full border border-accent/30"
            style={{ width: '300px', height: '300px' }}
          >
            <div
              className="w-3 h-3 rounded-full bg-accent shadow-[0_0_12px_rgba(0,212,255,0.8)] absolute -top-1.5 left-1/2 -translate-x-1/2"
            />
          </div>
        </div>

        {/* Orbit ring 2 - reverse */}
        <div
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
          style={{ animation: 'spin 12s linear infinite reverse', transform: 'rotate(60deg)' }}
        >
          <div
            className="rounded-full border border-secondary/30"
            style={{ width: '240px', height: '240px' }}
          >
            <div
              className="w-2 h-2 rounded-full bg-secondary shadow-[0_0_10px_rgba(124,58,237,0.8)] absolute -top-1 left-1/2 -translate-x-1/2"
            />
          </div>
        </div>

        {/* Orbit ring 3 */}
        <div
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
          style={{ animation: 'spin 6s linear infinite', transform: 'rotate(-30deg) rotateX(70deg)' }}
        >
          <div
            className="rounded-full border border-primary/20"
            style={{ width: '180px', height: '180px' }}
          >
            <div
              className="w-2 h-2 rounded-full bg-primary shadow-[0_0_10px_rgba(0,128,255,0.8)] absolute -top-1 left-1/2 -translate-x-1/2"
            />
          </div>
        </div>

        {/* Core sphere */}
        <div className="relative flex items-center justify-center" style={{ width: '200px', height: '200px' }}>
          {/* Glow behind core */}
          <div
            className="absolute inset-0 rounded-full blur-2xl"
            style={{ background: 'radial-gradient(circle, rgba(0,128,255,0.4) 0%, rgba(0,212,255,0.15) 50%, transparent 70%)', animation: 'pulse 3s ease-in-out infinite' }}
          />

          {/* Core */}
          <div
            className="relative rounded-full flex items-center justify-center"
            style={{
              width: '120px',
              height: '120px',
              background: 'radial-gradient(circle at 35% 35%, rgba(0,212,255,0.9) 0%, rgba(0,128,255,0.7) 40%, rgba(10,14,40,0.95) 70%)',
              boxShadow: '0 0 40px rgba(0,128,255,0.5), 0 0 80px rgba(0,128,255,0.2), inset 0 0 30px rgba(0,212,255,0.2)',
              animation: 'pulse 4s ease-in-out infinite',
            }}
          >
            {/* Wireframe overlay */}
            <svg viewBox="0 0 120 120" className="absolute inset-0 w-full h-full opacity-40" style={{ animation: 'spin 20s linear infinite' }}>
              <ellipse cx="60" cy="60" rx="55" ry="20" fill="none" stroke="rgba(0,212,255,0.5)" strokeWidth="1"/>
              <ellipse cx="60" cy="60" rx="55" ry="20" fill="none" stroke="rgba(0,128,255,0.4)" strokeWidth="1" transform="rotate(60 60 60)"/>
              <ellipse cx="60" cy="60" rx="55" ry="20" fill="none" stroke="rgba(124,58,237,0.4)" strokeWidth="1" transform="rotate(120 60 60)"/>
              <circle cx="60" cy="60" r="55" fill="none" stroke="rgba(0,212,255,0.2)" strokeWidth="1"/>
            </svg>

            {/* Inner glow dot */}
            <div
              className="w-6 h-6 rounded-full bg-white"
              style={{
                boxShadow: '0 0 20px rgba(255,255,255,0.9), 0 0 40px rgba(0,212,255,0.8)',
                animation: 'pulse 2s ease-in-out infinite',
              }}
            />
          </div>
        </div>

        {/* Floating neurons */}
        {[
          { x: -120, y: -80, delay: '0s', color: 'rgba(0,212,255,0.7)' },
          { x: 120, y: -60, delay: '1s', color: 'rgba(0,128,255,0.7)' },
          { x: -100, y: 90, delay: '2s', color: 'rgba(124,58,237,0.7)' },
          { x: 110, y: 80, delay: '0.5s', color: 'rgba(0,212,255,0.6)' },
          { x: 0, y: -130, delay: '1.5s', color: 'rgba(0,128,255,0.5)' },
          { x: -140, y: 10, delay: '2.5s', color: 'rgba(124,58,237,0.5)' },
        ].map((n, i) => (
          <div
            key={i}
            className="absolute rounded-full"
            style={{
              width: '8px',
              height: '8px',
              left: `calc(50% + ${n.x}px)`,
              top: `calc(50% + ${n.y}px)`,
              transform: 'translate(-50%, -50%)',
              background: n.color,
              boxShadow: `0 0 8px ${n.color}`,
              animation: `float${i % 3} ${3 + i * 0.5}s ease-in-out infinite`,
              animationDelay: n.delay,
            }}
          />
        ))}
      </div>

      <style>{`
        @keyframes float0 { 0%, 100% { transform: translate(-50%, -50%) translateY(0); } 50% { transform: translate(-50%, -50%) translateY(-10px); } }
        @keyframes float1 { 0%, 100% { transform: translate(-50%, -50%) translateY(0); } 50% { transform: translate(-50%, -50%) translateY(8px); } }
        @keyframes float2 { 0%, 100% { transform: translate(-50%, -50%) translateY(0); } 50% { transform: translate(-50%, -50%) translateY(-6px); } }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
