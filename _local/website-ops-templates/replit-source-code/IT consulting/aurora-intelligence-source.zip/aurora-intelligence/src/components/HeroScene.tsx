import { Suspense, lazy, useState, useEffect } from 'react';
import RobotSceneFallback from './RobotSceneFallback';

const ThreeCanvas = lazy(() => import('./ThreeCanvas'));

function checkWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    return !!gl;
  } catch {
    return false;
  }
}

export default function HeroScene() {
  const [webglSupported, setWebglSupported] = useState<boolean | null>(null);

  useEffect(() => {
    setWebglSupported(checkWebGL());
  }, []);

  if (webglSupported === null) return null;

  if (!webglSupported) {
    return <RobotSceneFallback />;
  }

  return (
    <Suspense fallback={<RobotSceneFallback />}>
      <ThreeCanvas />
    </Suspense>
  );
}
