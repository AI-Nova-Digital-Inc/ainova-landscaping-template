import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Sphere, Torus, MeshDistortMaterial } from '@react-three/drei';
import * as THREE from 'three';

export default function RobotScene() {
  const groupRef = useRef<THREE.Group>(null);
  const coreRef = useRef<THREE.Mesh>(null);
  
  const mousePosition = useRef({ x: 0, y: 0 });

  useFrame((state) => {
    // Mouse tracking
    mousePosition.current.x = THREE.MathUtils.lerp(
      mousePosition.current.x,
      (state.mouse.x * Math.PI) / 4,
      0.1
    );
    mousePosition.current.y = THREE.MathUtils.lerp(
      mousePosition.current.y,
      (state.mouse.y * Math.PI) / 4,
      0.1
    );

    if (groupRef.current) {
      groupRef.current.rotation.y = mousePosition.current.x;
      groupRef.current.rotation.x = -mousePosition.current.y;
    }

    if (coreRef.current) {
      coreRef.current.rotation.x += 0.005;
      coreRef.current.rotation.y += 0.005;
    }
  });

  const neurons = useMemo(() => {
    return Array.from({ length: 15 }).map(() => ({
      position: new THREE.Vector3(
        (Math.random() - 0.5) * 4,
        (Math.random() - 0.5) * 4,
        (Math.random() - 0.5) * 4
      ).normalize().multiplyScalar(Math.random() * 1.5 + 2),
      speed: Math.random() * 0.02 + 0.01,
      axis: new THREE.Vector3(Math.random(), Math.random(), Math.random()).normalize()
    }));
  }, []);

  return (
    <group ref={groupRef}>
      {/* Core */}
      <Sphere ref={coreRef} args={[1, 32, 32]} scale={1}>
        <MeshDistortMaterial
          color="#0080ff"
          emissive="#0080ff"
          emissiveIntensity={2}
          wireframe={true}
          distort={0.4}
          speed={2}
        />
      </Sphere>

      {/* Inner solid core */}
      <Sphere args={[0.8, 32, 32]}>
        <meshStandardMaterial color="#0080ff" emissive="#0080ff" emissiveIntensity={1} />
      </Sphere>

      {/* Orbiting Rings */}
      <Torus args={[2, 0.02, 16, 100]} rotation={[Math.PI / 2, 0, 0]}>
        <meshStandardMaterial color="#00d4ff" emissive="#00d4ff" emissiveIntensity={2} />
      </Torus>
      <Torus args={[2.5, 0.01, 16, 100]} rotation={[0, Math.PI / 4, 0]}>
        <meshStandardMaterial color="#7c3aed" emissive="#7c3aed" emissiveIntensity={1.5} />
      </Torus>

      {/* Neurons */}
      {neurons.map((neuron, i) => (
        <Neuron key={i} {...neuron} />
      ))}
    </group>
  );
}

function Neuron({ position, speed, axis }: { position: THREE.Vector3, speed: number, axis: THREE.Vector3 }) {
  const ref = useRef<THREE.Mesh>(null);
  const orbitRef = useRef<THREE.Group>(null);

  useFrame(() => {
    if (orbitRef.current) {
      orbitRef.current.rotateOnAxis(axis, speed);
    }
  });

  return (
    <group ref={orbitRef}>
      <Sphere ref={ref} args={[0.05, 16, 16]} position={position}>
        <meshBasicMaterial color="#ffffff" />
      </Sphere>
    </group>
  );
}
