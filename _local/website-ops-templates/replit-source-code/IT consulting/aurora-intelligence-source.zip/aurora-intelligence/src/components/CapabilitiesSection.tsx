import { useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';

const capabilities = [
  {
    id: 'ai-engineering',
    title: 'AI Engineering',
    subtitle: 'LLMs · RAG · Agents',
    description: 'Custom large language model pipelines, retrieval-augmented generation systems, and autonomous multi-agent architectures built for production.',
    color: '#0080ff',
    icon: (
      <svg viewBox="0 0 40 40" fill="none" className="w-10 h-10">
        <circle cx="20" cy="20" r="8" stroke="currentColor" strokeWidth="1.5" />
        <path d="M20 4v4M20 32v4M4 20h4M32 20h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        <circle cx="20" cy="20" r="3" fill="currentColor" />
        <path d="M8.5 8.5l2.8 2.8M28.7 28.7l2.8 2.8M8.5 31.5l2.8-2.8M28.7 11.3l2.8-2.8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      </svg>
    )
  },
  {
    id: 'automation',
    title: 'Intelligent Automation',
    subtitle: 'RPA · Workflow AI · Orchestration',
    description: 'End-to-end process automation replacing manual workflows with intelligent agents that learn, adapt, and escalate intelligently.',
    color: '#7c3aed',
    icon: (
      <svg viewBox="0 0 40 40" fill="none" className="w-10 h-10">
        <rect x="4" y="12" width="10" height="16" rx="2" stroke="currentColor" strokeWidth="1.5"/>
        <rect x="26" y="12" width="10" height="16" rx="2" stroke="currentColor" strokeWidth="1.5"/>
        <rect x="15" y="8" width="10" height="8" rx="2" stroke="currentColor" strokeWidth="1.5"/>
        <rect x="15" y="24" width="10" height="8" rx="2" stroke="currentColor" strokeWidth="1.5"/>
        <path d="M14 20h-4M30 20h-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M20 16v8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      </svg>
    )
  },
  {
    id: 'cloud',
    title: 'Cloud Architecture',
    subtitle: 'MLOps · Distributed Systems · Infrastructure',
    description: 'Scalable distributed ML infrastructure, cloud-native deployments, and MLOps pipelines that keep your models performing at scale.',
    color: '#00d4ff',
    icon: (
      <svg viewBox="0 0 40 40" fill="none" className="w-10 h-10">
        <path d="M8 26a7 7 0 01.54-13.93A10 10 0 1130 20h2a4 4 0 010 8H8z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
        <path d="M20 22v-8M17 17l3-3 3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    )
  },
  {
    id: 'devops',
    title: 'DevOps & Platform',
    subtitle: 'CI/CD · Observability · SRE',
    description: 'Zero-downtime deployments, deep observability stacks, and platform engineering that gives your team superpowers.',
    color: '#22d3ee',
    icon: (
      <svg viewBox="0 0 40 40" fill="none" className="w-10 h-10">
        <path d="M20 4l4 8h8l-6 6 2 9-8-5-8 5 2-9-6-6h8l4-8z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
        <circle cx="20" cy="20" r="3" fill="currentColor"/>
      </svg>
    )
  }
];

function CapabilityCard({ cap, index }: { cap: typeof capabilities[0]; index: number }) {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    setMousePos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
  };

  return (
    <motion.div
      ref={cardRef}
      data-testid={`card-capability-${cap.id}`}
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-100px' }}
      transition={{ duration: 0.7, delay: index * 0.1, ease: [0.25, 0.46, 0.45, 0.94] }}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="relative rounded-sm overflow-hidden group cursor-default"
      style={{
        background: 'rgba(13, 17, 23, 0.7)',
        backdropFilter: 'blur(20px)',
        border: `1px solid ${isHovered ? cap.color + '60' : 'rgba(255,255,255,0.06)'}`,
        transition: 'border-color 0.3s ease',
      }}
    >
      {isHovered && (
        <div
          className="absolute inset-0 pointer-events-none transition-opacity duration-300"
          style={{
            background: `radial-gradient(300px circle at ${mousePos.x}px ${mousePos.y}px, ${cap.color}14, transparent 70%)`,
          }}
        />
      )}

      <div className="p-8">
        <div
          className="w-16 h-16 rounded-sm flex items-center justify-center mb-6 transition-all duration-300"
          style={{
            background: `${cap.color}15`,
            color: cap.color,
            boxShadow: isHovered ? `0 0 20px ${cap.color}30` : 'none',
          }}
        >
          {cap.icon}
        </div>

        <h3 className="text-xl font-bold text-white mb-1 font-sans">{cap.title}</h3>
        <p className="text-xs font-mono tracking-widest mb-4" style={{ color: cap.color }}>{cap.subtitle}</p>
        <p className="text-muted-foreground leading-relaxed text-sm">{cap.description}</p>

        <div
          className="mt-6 flex items-center gap-2 text-xs font-mono transition-all duration-300"
          style={{ color: isHovered ? cap.color : 'rgba(255,255,255,0.3)' }}
        >
          <span>LEARN MORE</span>
          <svg viewBox="0 0 16 16" fill="none" className="w-3 h-3">
            <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      </div>

      <div
        className="absolute bottom-0 left-0 right-0 h-px transition-opacity duration-300"
        style={{
          background: `linear-gradient(90deg, transparent, ${cap.color}, transparent)`,
          opacity: isHovered ? 1 : 0,
        }}
      />
    </motion.div>
  );
}

export default function CapabilitiesSection() {
  const ref = useRef<HTMLElement>(null);
  const titleInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section ref={ref} id="capabilities" className="py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-blue-950/5 to-transparent pointer-events-none" />

      <div className="container mx-auto px-6">
        <div className="mb-20">
          <motion.span
            initial={{ opacity: 0, x: -20 }}
            animate={titleInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="inline-block text-xs tracking-[0.3em] text-accent font-mono uppercase mb-4"
          >
            What We Engineer
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={titleInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="text-5xl md:text-6xl font-bold text-white font-sans tracking-tight"
          >
            Core
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent"> Capabilities</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={titleInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-4 text-muted-foreground max-w-2xl text-lg"
          >
            Four specializations. One mission — to build AI systems that work at the edge of what&apos;s possible.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {capabilities.map((cap, i) => (
            <CapabilityCard key={cap.id} cap={cap} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
