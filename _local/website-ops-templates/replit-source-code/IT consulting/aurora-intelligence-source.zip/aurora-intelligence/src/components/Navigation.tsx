import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const links = ['Services', 'Capabilities', 'Demo', 'Case Studies', 'Contact'];

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled 
          ? 'bg-background/70 backdrop-blur-md border-b border-white/5 py-4' 
          : 'bg-transparent py-6'
      }`}
    >
      <div className="container mx-auto px-6 flex items-center justify-between">
        <div className="flex items-center gap-2 cursor-pointer interactive">
          <span className="font-sans font-bold text-xl tracking-tight text-primary">AURORA</span>
          <span className="w-2 h-2 rounded-full bg-primary shadow-[0_0_10px_rgba(0,128,255,0.8)] animate-pulse" />
          <span className="text-[10px] tracking-[0.2em] text-muted-foreground ml-2 hidden sm:block">
            INTELLIGENCE SYSTEMS
          </span>
        </div>

        <div className="hidden md:flex items-center gap-8">
          {links.map((link) => (
            <a 
              key={link}
              href={`#${link.toLowerCase().replace(' ', '-')}`}
              className="text-sm text-muted-foreground hover:text-white transition-colors interactive font-medium tracking-wide"
            >
              {link}
            </a>
          ))}
        </div>

        <button className="interactive relative px-6 py-2 rounded border border-primary/50 text-primary text-sm font-medium overflow-hidden group hover:border-primary transition-colors">
          <span className="relative z-10">Get Started</span>
          <div className="absolute inset-0 bg-primary/10 translate-y-[100%] group-hover:translate-y-0 transition-transform duration-300" />
        </button>
      </div>
    </motion.nav>
  );
}
