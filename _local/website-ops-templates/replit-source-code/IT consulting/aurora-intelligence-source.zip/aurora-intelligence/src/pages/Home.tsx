import Navigation from '@/components/Navigation';
import HeroSection from '@/components/HeroSection';
import CapabilitiesSection from '@/components/CapabilitiesSection';
import AIDemo from '@/components/AIDemo';
import WorkflowVisualization from '@/components/WorkflowVisualization';
import CaseStudies from '@/components/CaseStudies';
import ContactSection from '@/components/ContactSection';

export default function Home() {
  return (
    <div className="w-full bg-background min-h-screen text-foreground overflow-x-hidden">
      <Navigation />
      <HeroSection />
      <CapabilitiesSection />
      <AIDemo />
      <WorkflowVisualization />
      <CaseStudies />
      <ContactSection />
    </div>
  );
}
