import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const NODES = [
  { id: "ingest", label: "Data Ingestion", sub: "APIs / DBs / Files", color: "#00f5ff" },
  { id: "process", label: "AI Processing", sub: "LLM + embeddings", color: "#bf5af2" },
  { id: "decision", label: "Decision Engine", sub: "Rules + thresholds", color: "#00f5ff" },
  { id: "dispatch", label: "Action Dispatch", sub: "Webhooks / queues", color: "#bf5af2" },
  { id: "result", label: "Result & Audit", sub: "Logs + analytics", color: "#00f5ff" },
];

export default function WorkflowSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const nodesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (nodesRef.current) {
        const nodes = nodesRef.current.querySelectorAll(".wf-node");
        const arrows = nodesRef.current.querySelectorAll(".wf-arrow");

        gsap.fromTo(
          nodes,
          { opacity: 0, scale: 0.7 },
          {
            opacity: 1,
            scale: 1,
            duration: 0.5,
            stagger: 0.18,
            ease: "back.out(1.4)",
            scrollTrigger: {
              trigger: sectionRef.current,
              start: "top 75%",
              once: true,
            },
          }
        );

        gsap.fromTo(
          arrows,
          { opacity: 0, scaleX: 0 },
          {
            opacity: 1,
            scaleX: 1,
            duration: 0.4,
            stagger: 0.18,
            delay: 0.2,
            ease: "power2.out",
            scrollTrigger: {
              trigger: sectionRef.current,
              start: "top 75%",
              once: true,
            },
          }
        );
      }
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section
      id="workflow"
      ref={sectionRef}
      className="relative py-28 px-4 md:px-6 overflow-hidden"
    >
      <div className="absolute inset-0 pointer-events-none z-0 grid-bg opacity-30" />
      <div className="absolute inset-0 pointer-events-none z-0">
        <div className="absolute right-0 bottom-0 w-96 h-96 rounded-full bg-primary/8 blur-[130px]" />
        <div className="absolute left-0 top-0 w-72 h-72 rounded-full bg-secondary/8 blur-[120px]" />
      </div>

      <div className="container mx-auto relative z-10">
        <div className="text-center mb-16">
          <span className="font-code text-primary/60 text-xs tracking-[0.3em] uppercase">
            NEUROLINK.WORKFLOW
          </span>
          <h2 className="font-orbitron text-4xl md:text-5xl font-bold mt-3 mb-4 text-foreground">
            How It{" "}
            <span className="gradient-text-cyan">Runs</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto font-light">
            Every automation follows a deterministic pipeline. Transparent,
            auditable, and blazing fast.
          </p>
        </div>

        {/* Desktop: horizontal pipeline */}
        <div
          ref={nodesRef}
          className="hidden md:flex items-center justify-center gap-0 overflow-x-auto pb-4"
        >
          {NODES.map((node, i) => (
            <div key={node.id} className="flex items-center">
              {/* Node */}
              <div
                className="wf-node flex flex-col items-center gap-3 w-40"
                data-testid={`workflow-node-${node.id}`}
              >
                {/* Icon circle */}
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center relative"
                  style={{
                    border: `1.5px solid ${node.color}50`,
                    background: `radial-gradient(circle, ${node.color}15 0%, transparent 70%)`,
                    boxShadow: `0 0 20px ${node.color}25`,
                  }}
                >
                  {/* Step number */}
                  <span
                    className="font-code font-bold text-lg"
                    style={{ color: node.color }}
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  {/* Pulse ring */}
                  <div
                    className="absolute inset-0 rounded-full animate-ping opacity-20"
                    style={{
                      border: `1px solid ${node.color}`,
                      animationDelay: `${i * 400}ms`,
                      animationDuration: "2.5s",
                    }}
                  />
                </div>
                <div className="text-center">
                  <div
                    className="font-orbitron text-sm font-bold leading-tight"
                    style={{ color: node.color }}
                  >
                    {node.label}
                  </div>
                  <div className="font-code text-[11px] text-muted-foreground mt-1">
                    {node.sub}
                  </div>
                </div>
              </div>

              {/* Arrow connector */}
              {i < NODES.length - 1 && (
                <div className="wf-arrow flex-shrink-0 w-12 flex items-center justify-center relative origin-left">
                  <svg width="48" height="24" viewBox="0 0 48 24" fill="none">
                    <defs>
                      <linearGradient id={`grad-${i}`} x1="0" y1="0" x2="1" y2="0">
                        <stop offset="0%" stopColor={NODES[i].color} stopOpacity="0.8" />
                        <stop offset="100%" stopColor={NODES[i + 1].color} stopOpacity="0.8" />
                      </linearGradient>
                    </defs>
                    <path
                      d="M0 12 L36 12"
                      stroke={`url(#grad-${i})`}
                      strokeWidth="1.5"
                      strokeDasharray="6 3"
                      className="flow-line"
                    />
                    <path
                      d="M34 7 L42 12 L34 17"
                      stroke={NODES[i + 1].color}
                      strokeWidth="1.5"
                      fill="none"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Mobile: vertical stack */}
        <div className="md:hidden flex flex-col items-center gap-0">
          {NODES.map((node, i) => (
            <div key={node.id} className="flex flex-col items-center">
              <div className="wf-node flex items-center gap-4 w-full max-w-xs bg-black/20 border border-white/6 rounded-xl px-4 py-3">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{
                    border: `1.5px solid ${node.color}50`,
                    boxShadow: `0 0 12px ${node.color}20`,
                  }}
                >
                  <span className="font-code font-bold text-sm" style={{ color: node.color }}>
                    {String(i + 1).padStart(2, "0")}
                  </span>
                </div>
                <div>
                  <div className="font-orbitron text-sm font-bold" style={{ color: node.color }}>
                    {node.label}
                  </div>
                  <div className="font-code text-[11px] text-muted-foreground">{node.sub}</div>
                </div>
              </div>
              {i < NODES.length - 1 && (
                <div className="w-px h-8 relative overflow-hidden">
                  <div
                    className="absolute inset-0"
                    style={{
                      background: `linear-gradient(to bottom, ${node.color}80, ${NODES[i + 1].color}80)`,
                    }}
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Bottom stats */}
        <div className="mt-16 grid grid-cols-3 gap-4 max-w-xl mx-auto text-center">
          {[
            { val: "< 50ms", label: "Pipeline latency" },
            { val: "99.99%", label: "Uptime SLA" },
            { val: "10B+", label: "Events processed" },
          ].map((stat) => (
            <div key={stat.label} className="flex flex-col gap-1">
              <span className="font-orbitron text-2xl font-bold gradient-text-cyan">
                {stat.val}
              </span>
              <span className="font-code text-[11px] text-muted-foreground tracking-wider">
                {stat.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
