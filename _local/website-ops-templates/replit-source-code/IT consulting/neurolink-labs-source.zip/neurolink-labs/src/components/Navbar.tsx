import React, { useEffect, useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b border-transparent ${
        scrolled ? "bg-background/80 backdrop-blur-md border-border/50 shadow-[0_4px_30px_rgba(0,0,0,0.5)]" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4 md:px-6 h-20 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 rounded relative overflow-hidden bg-primary/10 flex items-center justify-center border border-primary/30 group-hover:border-primary/60 transition-colors">
            <div className="absolute inset-0 bg-primary/20 blur-xl group-hover:bg-primary/40 transition-colors" />
            <svg viewBox="0 0 24 24" className="w-5 h-5 text-primary relative z-10" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
            </svg>
          </div>
          <span className="font-display font-bold text-xl tracking-wider text-foreground">
            NEURO<span className="text-primary">LINK</span>
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-8 text-sm font-mono tracking-widest text-muted-foreground">
          <a href="#solutions" className="hover:text-primary transition-colors uppercase">Solutions</a>
          <a href="#demo" className="hover:text-secondary transition-colors uppercase">Demo</a>
          <a href="#workflow" className="hover:text-primary transition-colors uppercase">Workflow</a>
          <a href="#case-studies" className="hover:text-secondary transition-colors uppercase">Impact</a>
        </nav>

        <div className="flex items-center gap-4">
          <Button variant="outline" className="hidden sm:flex border-primary/30 text-primary hover:bg-primary/10 hover:text-primary font-mono uppercase tracking-widest h-10 px-6 group relative overflow-hidden">
            <span className="relative z-10">Client Portal</span>
            <div className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/10 to-primary/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
          </Button>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90 font-display font-semibold tracking-wider shadow-[0_0_15px_rgba(0,245,255,0.3)] hover:shadow-[0_0_25px_rgba(0,245,255,0.5)] transition-all h-10 px-6">
            Get Started
          </Button>
        </div>
      </div>
    </header>
  );
}
