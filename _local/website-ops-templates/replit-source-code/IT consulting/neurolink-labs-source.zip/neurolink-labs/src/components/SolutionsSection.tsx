import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const solutions = [
  {
    id: "chatbots",
    icon: (
      <svg viewBox="0 0 40 40" className="w-10 h-10" fill="none">
        <rect x="4" y="8" width="32" height="22" rx="3" stroke="#00f5ff" strokeWidth="1.5"/>
        <circle cx="13" cy="19" r="2" fill="#00f5ff"/>
        <circle cx="20" cy="19" r="2" fill="#00f5ff"/>
        <circle cx="27" cy="19" r="2" fill="#00f5ff"/>
        <path d="M12 30 L20 38 L28 30" stroke="#00f5ff" strokeWidth="1.5"/>
      </svg>
    ),
    label: "// module_01",
    title: "AI Chatbots",
    description:
      "Conversational agents trained on your domain, deployed across channels. Zero hallucination tolerance. 99.9% uptime SLA.",
    metrics: ["< 200ms latency", "40+ integrations", "GPT-4o / Claude 3.5"],
    color: "cyan",
  },
  {
    id: "llm-apps",
    icon: (
      <svg viewBox="0 0 40 40" className="w-10 h-10" fill="none">
        <path d="M20 4 L36 12 L36 28 L20 36 L4 28 L4 12 Z" stroke="#bf5af2" strokeWidth="1.5"/>
        <path d="M20 4 L20 36M4 12 L36 28M36 12 L4 28" stroke="#bf5af2" strokeWidth="0.7" opacity="0.5"/>
        <circle cx="20" cy="20" r="3" fill="#bf5af2"/>
      </svg>
    ),
    label: "// module_02",
    title: "LLM Applications",
    description:
      "Full-stack AI applications on top of leading foundation models. RAG pipelines, fine-tuning, custom toolchains.",
    metrics: ["Multi-model routing", "Vector search", "Private cloud"],
    color: "purple",
  },
  {
    id: "automation",
    icon: (
      <svg viewBox="0 0 40 40" className="w-10 h-10" fill="none">
        <circle cx="20" cy="20" r="6" stroke="#00f5ff" strokeWidth="1.5"/>
        <path d="M20 4 L20 10M20 30 L20 36M4 20 L10 20M30 20 L36 20" stroke="#00f5ff" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M7.5 7.5 L11.8 11.8M28.2 28.2 L32.5 32.5M32.5 7.5 L28.2 11.8M11.8 28.2 L7.5 32.5" stroke="#00f5ff" strokeWidth="1.5" strokeLinecap="round" opacity="0.6"/>
        <circle cx="20" cy="20" r="2" fill="#00f5ff"/>
      </svg>
    ),
    label: "// module_03",
    title: "Automation Workflows",
    description:
      "End-to-end process automation. Connect data sources, trigger actions, orchestrate multi-step pipelines without code.",
    metrics: ["Visual editor", "1000+ triggers", "Real-time execution"],
    color: "cyan",
  },
];

export default function SolutionsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (cardsRef.current) {
        const cards = cardsRef.current.querySelectorAll(".solution-card");
        gsap.fromTo(
          cards,
          { opacity: 0, y: 60 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            stagger: 0.15,
            ease: "power3.out",
            scrollTrigger: {
              trigger: cardsRef.current,
              start: "top 80%",
              once: true,
            },
          }
        );
      }
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section id="solutions" ref={sectionRef} className="relative py-28 px-4 md:px-6 overflow-hidden">
      {/* bg blobs */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-secondary/10 blur-[120px]" />
        <div className="absolute right-0 top-1/3 w-72 h-72 rounded-full bg-primary/10 blur-[100px]" />
      </div>

      <div className="container mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="font-code text-primary/60 text-xs tracking-[0.3em] uppercase">
            NEUROLINK.SOLUTIONS
          </span>
          <h2 className="font-orbitron text-4xl md:text-5xl font-bold mt-3 mb-4 text-foreground">
            What We{" "}
            <span className="gradient-text-cyan">Build</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto font-light">
            Three core disciplines. One unified intelligence layer for your
            organization.
          </p>
        </div>

        {/* Cards */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {solutions.map((s) => (
            <div
              key={s.id}
              className="solution-card holo-card rounded-xl p-7 flex flex-col gap-5 cursor-default group"
              data-testid={`solution-card-${s.id}`}
            >
              <div className="flex items-start justify-between">
                <div className="p-3 rounded-lg bg-black/30 border border-white/5">
                  {s.icon}
                </div>
                <span className="font-code text-[10px] text-muted-foreground/50 tracking-widest">
                  {s.label}
                </span>
              </div>

              <div>
                <h3
                  className={`font-orbitron text-xl font-bold mb-2 ${
                    s.color === "cyan"
                      ? "text-primary group-hover:glow-cyan"
                      : "text-secondary group-hover:glow-purple"
                  } transition-all`}
                >
                  {s.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed font-light">
                  {s.description}
                </p>
              </div>

              <ul className="mt-auto flex flex-col gap-2">
                {s.metrics.map((m) => (
                  <li
                    key={m}
                    className="flex items-center gap-2 font-code text-xs text-muted-foreground"
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                        s.color === "cyan" ? "bg-primary" : "bg-secondary"
                      }`}
                    />
                    {m}
                  </li>
                ))}
              </ul>

              {/* Bottom glow bar */}
              <div
                className={`h-px w-full mt-2 ${
                  s.color === "cyan"
                    ? "bg-gradient-to-r from-transparent via-primary/50 to-transparent"
                    : "bg-gradient-to-r from-transparent via-secondary/50 to-transparent"
                } opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
