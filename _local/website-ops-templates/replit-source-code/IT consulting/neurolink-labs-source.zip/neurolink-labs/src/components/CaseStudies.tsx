import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const CASES = [
  {
    id: "nexus",
    company: "Nexus Corp",
    sector: "Enterprise SaaS",
    problem: "Tier-1 support overwhelmed. 2,400 tickets/week with 48h average resolution time.",
    solution:
      "Deployed NL-7 support agent trained on 3 years of ticket history. Integrated with Zendesk and Slack.",
    metric: "73%",
    metricLabel: "ticket deflection",
    metric2: "6h",
    metric2Label: "avg resolution",
    color: "cyan",
  },
  {
    id: "arclight",
    company: "Arclight Health",
    sector: "Digital Health",
    problem: "Patient onboarding required 12-step manual intake, causing 34% drop-off before activation.",
    solution:
      "AI-guided onboarding agent with adaptive form logic, insurance verification automation, and follow-up cadence.",
    metric: "41%",
    metricLabel: "activation lift",
    metric2: "3x",
    metric2Label: "faster intake",
    color: "purple",
  },
  {
    id: "strata",
    company: "Strata Finance",
    sector: "Fintech",
    problem: "Loan underwriting took 5–8 days due to manual document review and risk scoring.",
    solution:
      "LLM pipeline for document extraction, risk factor classification, and automated scoring with human-in-the-loop escalation.",
    metric: "82%",
    metricLabel: "time reduction",
    metric2: "$2.4M",
    metric2Label: "annual savings",
    color: "cyan",
  },
];

export default function CaseStudies() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const cards = sectionRef.current?.querySelectorAll(".case-card");
      if (cards) {
        gsap.fromTo(
          cards,
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            duration: 0.7,
            stagger: 0.15,
            ease: "power2.out",
            scrollTrigger: {
              trigger: sectionRef.current,
              start: "top 80%",
              once: true,
            },
          }
        );
      }
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section
      id="case-studies"
      ref={sectionRef}
      className="relative py-28 px-4 md:px-6 overflow-hidden"
    >
      <div className="absolute inset-0 pointer-events-none z-0">
        <div className="absolute left-1/4 bottom-0 w-80 h-80 rounded-full bg-secondary/8 blur-[120px]" />
        <div className="absolute right-1/4 top-0 w-64 h-64 rounded-full bg-primary/8 blur-[100px]" />
      </div>

      <div className="container mx-auto relative z-10">
        <div className="text-center mb-16">
          <span className="font-code text-secondary/60 text-xs tracking-[0.3em] uppercase">
            NEUROLINK.IMPACT
          </span>
          <h2 className="font-orbitron text-4xl md:text-5xl font-bold mt-3 mb-4 text-foreground">
            Verified{" "}
            <span
              className="text-secondary"
              style={{ textShadow: "0 0 20px #bf5af2, 0 0 40px #bf5af260" }}
            >
              Results
            </span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto font-light">
            Three clients. Three different problems. One outcome: machines doing
            the work that was slowing humans down.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {CASES.map((c) => (
            <div
              key={c.id}
              className="case-card group relative holo-card rounded-2xl p-6 flex flex-col gap-4 overflow-hidden"
              data-testid={`case-study-${c.id}`}
            >
              {/* Decorative corner */}
              <div
                className="absolute top-0 right-0 w-16 h-16 opacity-20"
                style={{
                  background: `radial-gradient(circle at top right, ${
                    c.color === "cyan" ? "#00f5ff" : "#bf5af2"
                  }, transparent)`,
                }}
              />

              {/* Header */}
              <div>
                <div className="flex items-start justify-between gap-2 mb-1">
                  <span
                    className="font-orbitron text-lg font-bold"
                    style={{
                      color: c.color === "cyan" ? "#00f5ff" : "#bf5af2",
                      textShadow:
                        c.color === "cyan"
                          ? "0 0 15px #00f5ff60"
                          : "0 0 15px #bf5af260",
                    }}
                  >
                    {c.company}
                  </span>
                </div>
                <span className="font-code text-[11px] text-muted-foreground tracking-widest uppercase">
                  {c.sector}
                </span>
              </div>

              {/* Problem */}
              <div>
                <div className="font-code text-[10px] text-muted-foreground/50 tracking-widest uppercase mb-1">
                  // PROBLEM
                </div>
                <p className="text-sm text-muted-foreground font-light leading-relaxed">
                  {c.problem}
                </p>
              </div>

              {/* Solution */}
              <div>
                <div className="font-code text-[10px] text-muted-foreground/50 tracking-widest uppercase mb-1">
                  // SOLUTION
                </div>
                <p className="text-sm text-muted-foreground font-light leading-relaxed">
                  {c.solution}
                </p>
              </div>

              {/* Metrics */}
              <div className="mt-auto pt-4 border-t border-white/6 grid grid-cols-2 gap-3">
                <div>
                  <div
                    className="font-orbitron text-2xl font-bold"
                    style={{
                      color: c.color === "cyan" ? "#00f5ff" : "#bf5af2",
                      textShadow:
                        c.color === "cyan"
                          ? "0 0 15px #00f5ff80"
                          : "0 0 15px #bf5af280",
                    }}
                  >
                    {c.metric}
                  </div>
                  <div className="font-code text-[10px] text-muted-foreground tracking-wider uppercase">
                    {c.metricLabel}
                  </div>
                </div>
                <div>
                  <div
                    className="font-orbitron text-2xl font-bold text-foreground"
                  >
                    {c.metric2}
                  </div>
                  <div className="font-code text-[10px] text-muted-foreground tracking-wider uppercase">
                    {c.metric2Label}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
