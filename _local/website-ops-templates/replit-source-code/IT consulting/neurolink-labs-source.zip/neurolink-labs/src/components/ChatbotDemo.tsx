import { useState, useRef, useEffect } from "react";

interface Message {
  role: "user" | "ai";
  text: string;
}

const SUGGESTIONS = [
  "How can AI reduce our support load?",
  "What's your RAG pipeline latency?",
  "Can you automate our onboarding flow?",
];

const AI_RESPONSES: Record<string, string> = {
  "How can AI reduce our support load?":
    "Deploying a domain-trained chatbot typically deflects 60–80% of tier-1 tickets within the first 30 days. Our NL-7 agents are trained on your docs, product specs, and historical ticket data — they resolve without escalation. You keep humans for the hard stuff.",
  "What's your RAG pipeline latency?":
    "Our retrieval-augmented generation stack runs at ~180ms p95 on standard deployments. Hybrid vector + BM25 retrieval, re-ranker pass, then generation. For latency-critical paths we offer streaming responses with < 60ms time-to-first-token.",
  "Can you automate our onboarding flow?":
    "Absolutely. We map your onboarding steps, identify friction points, then build agentic workflows that guide users through setup, validate completions, and trigger next steps automatically. Most clients see 40% faster activation within 2 weeks of deployment.",
};

function useTypingEffect(text: string, speed = 18) {
  const [displayed, setDisplayed] = useState("");
  const [done, setDone] = useState(false);

  useEffect(() => {
    setDisplayed("");
    setDone(false);
    if (!text) return;
    let i = 0;
    const id = setInterval(() => {
      i++;
      setDisplayed(text.slice(0, i));
      if (i >= text.length) {
        clearInterval(id);
        setDone(true);
      }
    }, speed);
    return () => clearInterval(id);
  }, [text, speed]);

  return { displayed, done };
}

function AIMessage({ text }: { text: string }) {
  const { displayed, done } = useTypingEffect(text);
  return (
    <div className="flex items-start gap-3">
      <div className="w-8 h-8 rounded-lg bg-primary/15 border border-primary/30 flex items-center justify-center flex-shrink-0">
        <span className="font-code text-primary text-[10px] font-bold">NL</span>
      </div>
      <div className="flex-1 bg-primary/5 border border-primary/15 rounded-2xl rounded-tl-none px-4 py-3 text-sm text-foreground font-light leading-relaxed">
        {displayed}
        {!done && (
          <span className="inline-block w-0.5 h-3.5 bg-primary ml-0.5 cursor-blink" />
        )}
      </div>
    </div>
  );
}

export default function ChatbotDemo() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "ai",
      text: "Hello. I'm NL-7, NeuroLink's intelligence layer. What are you building?",
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [lastAI, setLastAI] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const sendMessage = (text: string) => {
    if (!text.trim() || isTyping) return;
    const userMsg: Message = { role: "user", text: text.trim() };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    setTimeout(() => {
      const aiText =
        AI_RESPONSES[text.trim()] ||
        "Interesting use case. Our team typically starts with a discovery sprint to map your data flows and identify the highest-ROI automation targets. Want to schedule a technical deep-dive?";
      setIsTyping(false);
      setLastAI(aiText);
      setMessages((prev) => [...prev, { role: "ai", text: aiText }]);
    }, 800);
  };

  return (
    <section id="demo" className="relative py-28 px-4 md:px-6 overflow-hidden">
      <div className="absolute inset-0 pointer-events-none z-0">
        <div className="absolute left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-secondary/8 blur-[150px]" />
      </div>

      <div className="container mx-auto relative z-10 max-w-3xl">
        <div className="text-center mb-12">
          <span className="font-code text-secondary/60 text-xs tracking-[0.3em] uppercase">
            NEUROLINK.DEMO
          </span>
          <h2 className="font-orbitron text-4xl md:text-5xl font-bold mt-3 mb-4 text-foreground">
            Talk to{" "}
            <span className="text-secondary" style={{ textShadow: "0 0 20px #bf5af2, 0 0 40px #bf5af280" }}>
              NL-7
            </span>
          </h2>
          <p className="text-muted-foreground font-light">
            A live preview of our conversational AI. Ask anything.
          </p>
        </div>

        {/* Chat window */}
        <div
          className="rounded-2xl border border-white/8 overflow-hidden"
          style={{
            background: "rgba(5,8,16,0.95)",
            boxShadow: "0 0 40px rgba(191,90,242,0.12), 0 0 80px rgba(0,245,255,0.06)",
          }}
          data-testid="chatbot-window"
        >
          {/* Terminal title bar */}
          <div className="flex items-center gap-2 px-4 py-3 border-b border-white/6 bg-black/30">
            <div className="w-3 h-3 rounded-full bg-red-500/70" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
            <div className="w-3 h-3 rounded-full bg-green-500/70" />
            <span className="ml-3 font-code text-xs text-muted-foreground/50 tracking-widest">
              NL-7 INTERFACE &mdash; v2.1.4 &mdash; CONNECTED
            </span>
            <div className="ml-auto flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              <span className="font-code text-[10px] text-primary/70">LIVE</span>
            </div>
          </div>

          {/* Messages */}
          <div className="h-80 overflow-y-auto flex flex-col gap-4 p-5 scrollbar-thin">
            {messages.map((m, i) =>
              m.role === "user" ? (
                <div key={i} className="flex items-start gap-3 flex-row-reverse">
                  <div className="w-8 h-8 rounded-lg bg-secondary/15 border border-secondary/30 flex items-center justify-center flex-shrink-0">
                    <span className="font-code text-secondary text-[10px] font-bold">YOU</span>
                  </div>
                  <div className="bg-secondary/10 border border-secondary/20 rounded-2xl rounded-tr-none px-4 py-3 text-sm text-foreground font-light max-w-xs">
                    {m.text}
                  </div>
                </div>
              ) : m.text === lastAI && messages[messages.length - 1]?.role === "ai" ? (
                <AIMessage key={i} text={m.text} />
              ) : (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-primary/15 border border-primary/30 flex items-center justify-center flex-shrink-0">
                    <span className="font-code text-primary text-[10px] font-bold">NL</span>
                  </div>
                  <div className="flex-1 bg-primary/5 border border-primary/15 rounded-2xl rounded-tl-none px-4 py-3 text-sm text-foreground font-light leading-relaxed">
                    {m.text}
                  </div>
                </div>
              )
            )}
            {isTyping && (
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-primary/15 border border-primary/30 flex items-center justify-center flex-shrink-0">
                  <span className="font-code text-primary text-[10px] font-bold">NL</span>
                </div>
                <div className="bg-primary/5 border border-primary/15 rounded-2xl rounded-tl-none px-4 py-3 flex gap-1.5 items-center h-10">
                  {[0, 150, 300].map((delay) => (
                    <span
                      key={delay}
                      className="w-1.5 h-1.5 rounded-full bg-primary"
                      style={{ animation: `blink 1.2s ${delay}ms infinite` }}
                    />
                  ))}
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Suggestions */}
          <div className="px-5 pb-3 flex flex-wrap gap-2">
            {SUGGESTIONS.map((s) => (
              <button
                key={s}
                onClick={() => sendMessage(s)}
                disabled={isTyping}
                className="font-code text-[11px] text-primary/70 border border-primary/20 rounded-full px-3 py-1 hover:border-primary/50 hover:text-primary hover:bg-primary/5 transition-all disabled:opacity-40"
                data-testid={`suggestion-${s.slice(0, 10).replace(/\s/g, "-").toLowerCase()}`}
              >
                {s}
              </button>
            ))}
          </div>

          {/* Input */}
          <div className="px-4 pb-4">
            <div className="flex gap-2 border border-white/10 rounded-xl bg-black/20 overflow-hidden focus-within:border-primary/40 transition-colors">
              <span className="font-code text-primary/40 text-sm pl-4 flex items-center select-none">
                &gt;
              </span>
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendMessage(input)}
                placeholder="Ask NL-7 anything..."
                disabled={isTyping}
                className="flex-1 bg-transparent py-3 text-sm text-foreground placeholder:text-muted-foreground/40 font-code outline-none disabled:opacity-50"
                data-testid="input-chat"
              />
              <button
                onClick={() => sendMessage(input)}
                disabled={isTyping || !input.trim()}
                className="px-4 py-2 m-1 rounded-lg bg-primary/15 border border-primary/30 text-primary font-code text-xs uppercase tracking-widest hover:bg-primary/25 transition-all disabled:opacity-40"
                data-testid="button-send"
              >
                Send
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
