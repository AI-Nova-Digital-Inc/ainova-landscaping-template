import { useState, useRef, useEffect } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function ContactCTA() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (contentRef.current) {
        gsap.fromTo(
          contentRef.current,
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 0.9,
            ease: "power3.out",
            scrollTrigger: {
              trigger: sectionRef.current,
              start: "top 80%",
              once: true,
            },
          }
        );
      }
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubmitted(true);
    }
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative py-28 px-4 md:px-6 overflow-hidden"
    >
      {/* Background grid */}
      <div className="absolute inset-0 z-0 grid-bg opacity-20 pointer-events-none" />

      {/* Gradient blobs */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <div className="absolute left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 w-[700px] h-[400px] rounded-full bg-primary/8 blur-[150px]" />
        <div className="absolute left-1/4 bottom-0 w-48 h-48 rounded-full bg-secondary/15 blur-[80px]" />
        <div className="absolute right-1/4 top-0 w-48 h-48 rounded-full bg-primary/15 blur-[80px]" />
      </div>

      {/* Scanlines */}
      <div className="absolute inset-0 z-0 scanlines pointer-events-none" />

      <div className="container mx-auto relative z-10 max-w-3xl text-center" ref={contentRef}>
        <span className="font-code text-primary/60 text-xs tracking-[0.3em] uppercase">
          NEUROLINK.CONNECT
        </span>

        <h2 className="font-orbitron text-4xl md:text-6xl font-bold mt-4 mb-6 leading-tight text-foreground">
          Ready to build{" "}
          <span className="gradient-text-cyan block">the future?</span>
        </h2>

        <p className="text-muted-foreground font-light text-lg mb-10 max-w-xl mx-auto">
          Tell us what you&apos;re building. We&apos;ll tell you how fast we can
          automate it.
        </p>

        {!submitted ? (
          <form
            onSubmit={handleSubmit}
            className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto mb-10"
            data-testid="form-contact"
          >
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@startup.io"
              required
              className="flex-1 bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/40 font-code outline-none focus:border-primary/50 transition-colors"
              data-testid="input-email"
            />
            <button
              type="submit"
              className="px-6 py-3 rounded-xl bg-primary text-primary-foreground font-orbitron font-bold text-sm uppercase tracking-widest hover:bg-primary/90 transition-all"
              style={{ boxShadow: "0 0 20px rgba(0,245,255,0.4), 0 0 40px rgba(0,245,255,0.15)" }}
              data-testid="button-submit"
            >
              Launch
            </button>
          </form>
        ) : (
          <div className="max-w-md mx-auto mb-10 py-4 px-6 rounded-xl border border-primary/30 bg-primary/10 font-code text-primary text-sm tracking-wide">
            Transmission received. Expect contact within 24h.
          </div>
        )}

        {/* Social links */}
        <div className="flex items-center justify-center gap-5">
          {[
            {
              label: "GitHub",
              href: "#",
              icon: (
                <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
                  <path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0 1 12 6.844a9.59 9.59 0 0 1 2.504.337c1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.02 10.02 0 0 0 22 12.017C22 6.484 17.522 2 12 2z" />
                </svg>
              ),
            },
            {
              label: "X",
              href: "#",
              icon: (
                <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              ),
            },
            {
              label: "LinkedIn",
              href: "#",
              icon: (
                <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
                  <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                </svg>
              ),
            },
          ].map((social) => (
            <a
              key={social.label}
              href={social.href}
              aria-label={social.label}
              className="w-10 h-10 rounded-lg border border-white/10 flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/40 hover:bg-primary/8 transition-all"
              data-testid={`link-social-${social.label.toLowerCase()}`}
            >
              {social.icon}
            </a>
          ))}
        </div>

        {/* Footer note */}
        <div className="mt-16 pt-6 border-t border-white/6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-muted-foreground/40 font-code text-xs">
            <span>NEUROLINK LABS &copy; 2025 — ALL SYSTEMS OPERATIONAL</span>
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              <span className="text-primary/50">UPTIME 99.99%</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
