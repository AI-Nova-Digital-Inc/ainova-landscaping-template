import { useEffect, useRef } from "react";

export default function HologramCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w = canvas.offsetWidth;
    let h = canvas.offsetHeight;
    canvas.width = w;
    canvas.height = h;

    const NUM_PARTICLES = 120;
    const particles: { x: number; y: number; z: number; vx: number; vy: number; vz: number }[] = [];

    for (let i = 0; i < NUM_PARTICLES; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const r = 80 + Math.random() * 60;
      particles.push({
        x: r * Math.sin(phi) * Math.cos(theta),
        y: r * Math.sin(phi) * Math.sin(theta),
        z: r * Math.cos(phi),
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        vz: (Math.random() - 0.5) * 0.3,
      });
    }

    // Icosahedron vertices
    const phi = (1 + Math.sqrt(5)) / 2;
    const scale = 110;
    const icoVerts: [number, number, number][] = [
      [-1, phi, 0], [1, phi, 0], [-1, -phi, 0], [1, -phi, 0],
      [0, -1, phi], [0, 1, phi], [0, -1, -phi], [0, 1, -phi],
      [phi, 0, -1], [phi, 0, 1], [-phi, 0, -1], [-phi, 0, 1],
    ].map(([x, y, z]) => {
      const len = Math.sqrt(x * x + y * y + z * z);
      return [x / len * scale, y / len * scale, z / len * scale];
    });

    const icoEdges: [number, number][] = [
      [0,1],[0,5],[0,7],[0,10],[0,11],[1,5],[1,7],[1,8],[1,9],
      [2,3],[2,4],[2,6],[2,10],[2,11],[3,4],[3,6],[3,8],[3,9],
      [4,5],[4,9],[4,11],[5,9],[5,11],[6,7],[6,8],[6,10],[7,8],[7,10],
      [8,9],[10,11],
    ];

    let t = 0;
    let floatAngle = 0;

    const project = (x: number, y: number, z: number, cx: number, cy: number) => {
      const fov = 400;
      const pz = z + 350;
      const px = (x * fov) / pz + cx;
      const py = (y * fov) / pz + cy;
      const scale = fov / pz;
      return { px, py, scale };
    };

    const rotX = (x: number, y: number, z: number, a: number): [number, number, number] => [
      x, y * Math.cos(a) - z * Math.sin(a), y * Math.sin(a) + z * Math.cos(a),
    ];
    const rotY = (x: number, y: number, z: number, a: number): [number, number, number] => [
      x * Math.cos(a) + z * Math.sin(a), y, -x * Math.sin(a) + z * Math.cos(a),
    ];

    const draw = () => {
      animRef.current = requestAnimationFrame(draw);
      t += 0.008;
      floatAngle += 0.015;

      w = canvas.offsetWidth;
      h = canvas.offsetHeight;
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
      }

      ctx.clearRect(0, 0, w, h);

      const cx = w / 2;
      const cy = h / 2 + Math.sin(floatAngle) * 12;

      // Draw icosahedron wireframe (outer — cyan)
      const rotatedVerts = icoVerts.map(([x, y, z]) => {
        let [rx, ry, rz] = rotX(x, y, z, t * 0.7);
        [rx, ry, rz] = rotY(rx, ry, rz, t);
        return [rx, ry, rz] as [number, number, number];
      });

      icoEdges.forEach(([a, b]) => {
        const [ax, ay, az] = rotatedVerts[a];
        const [bx, by, bz] = rotatedVerts[b];
        const pa = project(ax, ay, az, cx, cy);
        const pb = project(bx, by, bz, cx, cy);

        const alpha = 0.3 + (az + bz) / 400;
        ctx.beginPath();
        ctx.moveTo(pa.px, pa.py);
        ctx.lineTo(pb.px, pb.py);
        ctx.strokeStyle = `rgba(0, 245, 255, ${Math.max(0.05, Math.min(0.7, alpha))})`;
        ctx.lineWidth = 0.8;
        ctx.stroke();
      });

      // Inner icosahedron (purple, smaller, counter-rotate)
      const innerVerts = icoVerts.map(([x, y, z]) => {
        let [rx, ry, rz] = rotX(x * 0.65, y * 0.65, z * 0.65, -t * 0.8);
        [rx, ry, rz] = rotY(rx, ry, rz, -t * 0.6);
        return [rx, ry, rz] as [number, number, number];
      });
      icoEdges.forEach(([a, b]) => {
        const [ax, ay, az] = innerVerts[a];
        const [bx, by, bz] = innerVerts[b];
        const pa = project(ax, ay, az, cx, cy);
        const pb = project(bx, by, bz, cx, cy);

        const alpha = 0.2 + (az + bz) / 500;
        ctx.beginPath();
        ctx.moveTo(pa.px, pa.py);
        ctx.lineTo(pb.px, pb.py);
        ctx.strokeStyle = `rgba(191, 90, 242, ${Math.max(0.04, Math.min(0.5, alpha))})`;
        ctx.lineWidth = 0.7;
        ctx.stroke();
      });

      // Vertices as glowing dots
      rotatedVerts.forEach(([x, y, z]) => {
        const { px, py, scale } = project(x, y, z, cx, cy);
        const r = scale * 2.5;
        const grad = ctx.createRadialGradient(px, py, 0, px, py, r * 2);
        grad.addColorStop(0, "rgba(0,245,255,0.9)");
        grad.addColorStop(1, "rgba(0,245,255,0)");
        ctx.beginPath();
        ctx.arc(px, py, r, 0, Math.PI * 2);
        ctx.fillStyle = grad;
        ctx.fill();
      });

      // Core glow
      const pulse = 0.5 + Math.sin(t * 2.5) * 0.3;
      const coreGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, 40 + pulse * 20);
      coreGrad.addColorStop(0, `rgba(0,245,255,${0.6 + pulse * 0.3})`);
      coreGrad.addColorStop(0.3, `rgba(0,245,255,${0.15 * pulse})`);
      coreGrad.addColorStop(1, "rgba(0,245,255,0)");
      ctx.beginPath();
      ctx.arc(cx, cy, 40 + pulse * 20, 0, Math.PI * 2);
      ctx.fillStyle = coreGrad;
      ctx.fill();

      // Orbiting ring (torus approximation)
      const ringAngle = t * 0.5;
      const ringR = 150;
      const ringSegments = 80;
      ctx.beginPath();
      for (let i = 0; i <= ringSegments; i++) {
        const a = (i / ringSegments) * Math.PI * 2;
        let rx = Math.cos(a) * ringR;
        let ry = 0;
        let rz = Math.sin(a) * ringR;

        let [tx, ty, tz] = rotX(rx, ry, rz, Math.PI / 4 + ringAngle * 0.3);
        [tx, ty, tz] = rotY(tx, ty, tz, ringAngle);

        const { px, py } = project(tx, ty, tz, cx, cy);
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.strokeStyle = `rgba(191,90,242,0.25)`;
      ctx.lineWidth = 1;
      ctx.stroke();

      // Second ring
      const ring2Angle = -t * 0.4;
      ctx.beginPath();
      for (let i = 0; i <= ringSegments; i++) {
        const a = (i / ringSegments) * Math.PI * 2;
        let rx = Math.cos(a) * (ringR + 25);
        let ry = 0;
        let rz = Math.sin(a) * (ringR + 25);

        let [tx, ty, tz] = rotX(rx, ry, rz, Math.PI / 6);
        [tx, ty, tz] = rotY(tx, ty, tz, ring2Angle);
        [tx, ty, tz] = rotX(tx, ty, tz, Math.PI / 5);

        const { px, py } = project(tx, ty, tz, cx, cy);
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.strokeStyle = `rgba(0,245,255,0.15)`;
      ctx.lineWidth = 0.8;
      ctx.stroke();

      // Particles
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.z += p.vz;
        const dist = Math.sqrt(p.x * p.x + p.y * p.y + p.z * p.z);
        if (dist > 200) {
          p.x *= 0.8;
          p.y *= 0.8;
          p.z *= 0.8;
        }

        const { px, py, scale: sc } = project(p.x, p.y, p.z + Math.sin(floatAngle) * 12, cx, cy);
        const rad = Math.max(0.5, sc * 1.5);
        ctx.beginPath();
        ctx.arc(px, py, rad, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(191,90,242,${0.3 + sc * 0.3})`;
        ctx.fill();
      });
    };

    draw();

    const handleResize = () => {
      w = canvas.offsetWidth;
      h = canvas.offsetHeight;
      canvas.width = w;
      canvas.height = h;
    };
    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return <canvas ref={canvasRef} className="w-full h-full" />;
}
