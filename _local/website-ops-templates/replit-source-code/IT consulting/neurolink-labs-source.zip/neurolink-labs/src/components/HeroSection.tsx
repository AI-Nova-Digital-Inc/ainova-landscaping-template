import React, { useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import HologramCanvas from "./HologramCanvas";
import gsap from "gsap";

export default function HeroSection() {
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const tl = gsap.timeline({ defaults: { ease: "power3.out" } });

    if (headlineRef.current) {
      const chars = headlineRef.current.innerText.split("");
      headlineRef.current.innerText = "";
      chars.forEach((char) => {
        const span = document.createElement("span");
        span.innerText = char === " " ? "\u00A0" : char;
        span.style.opacity = "0";
        span.style.display = "inline-block";
        span.style.transform = "translateY(20px)";
        headlineRef.current?.appendChild(span);
      });

      tl.to(headlineRef.current.children, {
        opacity: 1,
        y: 0,
        duration: 0.8,
        stagger: 0.05,
      });
    }

    if (subheadRef.current) {
      tl.fromTo(
        subheadRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 1 },
        "-=0.4"
      );
    }

    if (ctaRef.current) {
      tl.fromTo(
        ctaRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 1 },
        "-=0.6"
      );
    }
  }, []);

  return (
    <section className="relative min-h-[100dvh] w-full flex items-center pt-20 overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 z-0 opacity-20 pointer-events-none">
        <div className="absolute top-[20%] left-[10%] w-[40vw] h-[40vw] rounded-full bg-primary/20 blur-[120px]" />
        <div className="absolute bottom-[20%] right-[10%] w-[30vw] h-[30vw] rounded-full bg-secondary/20 blur-[100px]" />
      </div>

      <div className="absolute inset-0 z-0 opacity-[0.03] pointer-events-none font-mono text-[10px] leading-tight text-primary whitespace-pre overflow-hidden flex flex-col justify-between py-10 select-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="whitespace-nowrap"
            style={{
              transform: `translateX(${Math.sin(i) * 10}vw)`,
            }}
          >
            {`import { NeuralNet } from '@neurolink/core'; const model = new NeuralNet({ layers: ${Math.floor(Math.random() * 100)}, activation: 'gelu' }); model.train(dataset).then(() => { console.log('OPTIMIZED'); });`.repeat(5)}
          </div>
        ))}
      </div>

      <div className="container mx-auto px-4 md:px-6 relative z-10 flex flex-col lg:flex-row items-center justify-between gap-12">
        <div className="flex-1 text-center lg:text-left pt-12 lg:pt-0">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-primary/30 bg-primary/10 text-primary font-mono text-xs uppercase tracking-widest mb-6 shadow-[0_0_10px_rgba(0,245,255,0.1)]">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            System Online v4.2.0
          </div>
          
          <h1 
            ref={headlineRef}
            className="font-orbitron text-5xl md:text-7xl lg:text-8xl font-bold leading-[1.1] tracking-tight text-foreground mb-6"
          >
            Automate Everything with AI
          </h1>
          
          <p 
            ref={subheadRef}
            className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto lg:mx-0 mb-10 font-sans opacity-0 font-light"
          >
            NeuroLink Labs engineers bespoke machine intelligence that feels like the future. We replace manual friction with electric precision.
          </p>
          
          <div 
            ref={ctaRef}
            className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 opacity-0"
          >
            <Button size="lg" className="w-full sm:w-auto h-14 px-8 bg-primary hover:bg-primary/90 text-primary-foreground font-display font-semibold tracking-widest uppercase shadow-[0_0_20px_rgba(0,245,255,0.4)] hover:shadow-[0_0_30px_rgba(0,245,255,0.6)] transition-all">
              Start Automating
            </Button>
            <Button size="lg" variant="outline" className="w-full sm:w-auto h-14 px-8 border-border hover:border-primary/50 text-foreground hover:bg-primary/10 font-mono tracking-widest uppercase transition-all relative overflow-hidden group">
              <span className="relative z-10">See Live Demo</span>
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
            </Button>
          </div>
        </div>

        <div className="flex-1 w-full max-w-[600px] aspect-square relative lg:h-[800px] lg:max-w-none flex items-center justify-center pointer-events-none">
          <HologramCanvas />
        </div>
      </div>
    </section>
  );
}
