import React from "react";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import SolutionsSection from "@/components/SolutionsSection";
import ChatbotDemo from "@/components/ChatbotDemo";
import WorkflowSection from "@/components/WorkflowSection";
import CaseStudies from "@/components/CaseStudies";
import ContactCTA from "@/components/ContactCTA";

export default function Home() {
  return (
    <div className="min-h-[100dvh] w-full bg-background flex flex-col relative overflow-x-hidden">
      <Navbar />
      <main className="flex-1 w-full relative z-10">
        <HeroSection />
        <SolutionsSection />
        <ChatbotDemo />
        <WorkflowSection />
        <CaseStudies />
        <ContactCTA />
      </main>
    </div>
  );
}
