import { motion } from "framer-motion";

export function Architecture() {
  return (
    <section className="py-24 bg-slate-900 text-white overflow-hidden">
      <div className="container px-4 md:px-6 mx-auto max-w-6xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-6">
              Resilient by Design.
            </h2>
            <p className="text-lg text-slate-400 mb-8 leading-relaxed">
              We don't just lift and shift. We re-architect for scale. Our topology patterns ensure high availability, fault tolerance, and sub-millisecond latency.
            </p>
            <ul className="space-y-4">
              {['Multi-region active-active deployments', 'Event-driven serverless architectures', 'Kubernetes cluster orchestration'].map((item, i) => (
                <li key={i} className="flex items-center text-slate-300">
                  <div className="h-2 w-2 bg-blue-500 rounded-full mr-3" />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <div className="relative h-[400px] w-full rounded-xl border border-slate-800 bg-slate-950 p-6 flex flex-col items-center justify-between">
             {/* Simplified animated diagram */}
             <div className="absolute inset-0 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)] bg-[size:14px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]"></div>
             
             <motion.div 
               initial={{ opacity: 0, scale: 0.9 }}
               whileInView={{ opacity: 1, scale: 1 }}
               viewport={{ once: true }}
               className="z-10 w-48 py-3 bg-slate-800 border border-slate-700 rounded-lg text-center text-sm font-mono shadow-lg"
             >
               Load Balancer
             </motion.div>

             <div className="flex w-full justify-center gap-12 z-10 my-4 relative">
                <motion.div 
                  initial={{ height: 0 }}
                  whileInView={{ height: 40 }}
                  viewport={{ once: true }}
                  className="w-px bg-blue-500 absolute top-[-20px] left-1/2 -translate-x-1/2"
                />
             </div>

             <motion.div 
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true, margin: "-100px" }}
               transition={{ delay: 0.2 }}
               className="z-10 w-56 py-3 bg-slate-800 border border-slate-700 rounded-lg text-center text-sm font-mono shadow-lg"
             >
               API Gateway
             </motion.div>

             <div className="flex w-full justify-around z-10 mt-8 relative">
               {[1, 2, 3].map((i) => (
                 <motion.div
                   key={i}
                   initial={{ opacity: 0, y: 20 }}
                   whileInView={{ opacity: 1, y: 0 }}
                   viewport={{ once: true }}
                   transition={{ delay: 0.4 + (i * 0.1) }}
                   className="w-24 py-4 bg-slate-800 border border-blue-500/30 rounded-lg text-center text-xs font-mono shadow-lg relative"
                 >
                    <div className="absolute -top-8 left-1/2 w-px h-8 bg-slate-700 -translate-x-1/2" />
                    Microservice
                 </motion.div>
               ))}
             </div>
          </div>
        </div>
      </div>
    </section>
  );
}
