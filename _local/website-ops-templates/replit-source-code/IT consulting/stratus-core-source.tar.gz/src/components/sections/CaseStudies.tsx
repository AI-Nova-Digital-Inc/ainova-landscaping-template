import { motion } from "framer-motion";

const studies = [
  {
    client: "Global FinTech",
    metric: "68%",
    metricLabel: "Cost Reduction",
    description: "Migrated 200+ legacy applications to AWS, optimizing resource utilization and implementing spot instance orchestration."
  },
  {
    client: "Healthcare Provider",
    metric: "99.99%",
    metricLabel: "Uptime SLA",
    description: "Re-architected monolithic patient portal into fault-tolerant microservices across multi-region Kubernetes clusters."
  },
  {
    client: "E-Commerce Enterprise",
    metric: "3x",
    metricLabel: "Deployment Velocity",
    description: "Implemented rigorous GitOps and automated CI/CD pipelines, reducing deployment times from days to minutes."
  }
];

export function CaseStudies() {
  return (
    <section className="py-24 bg-slate-50 text-slate-900">
      <div className="container px-4 md:px-6 mx-auto max-w-6xl">
        <div className="mb-16">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Proven Impact</h2>
          <p className="text-lg text-slate-600 max-w-2xl">
            We measure success in tangible business outcomes.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {studies.map((study, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white p-8 rounded-2xl border border-slate-200 flex flex-col"
            >
              <div className="mb-6">
                <span className="text-sm font-semibold text-blue-600 uppercase tracking-wider">{study.client}</span>
              </div>
              <div className="mb-6">
                <div className="text-5xl font-bold tracking-tighter text-slate-900 mb-1">{study.metric}</div>
                <div className="text-sm font-medium text-slate-500 uppercase tracking-wide">{study.metricLabel}</div>
              </div>
              <p className="text-slate-600 leading-relaxed mt-auto">{study.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
