import { motion } from "framer-motion";
import { Link } from "wouter";

export function Hero() {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-slate-900 text-slate-50">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,_rgba(15,98,254,0.15),_transparent_70%)]" />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{ y: [0, -20, 0] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/4 left-1/4 w-32 h-32 border border-slate-700/50 rounded-2xl bg-slate-800/20 backdrop-blur-sm"
        />
        <motion.div
          animate={{ y: [0, 30, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="absolute top-1/3 right-1/4 w-48 h-48 border border-slate-700/50 rounded-full bg-blue-600/5 backdrop-blur-md"
        />
        <motion.div
          animate={{ x: [0, 20, 0], y: [0, -10, 0] }}
          transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 2 }}
          className="absolute bottom-1/4 left-1/3 w-24 h-24 border border-violet-500/20 rounded-xl bg-violet-500/5 backdrop-blur-sm"
        />
      </div>

      <div className="container px-4 md:px-6 relative z-10 mx-auto max-w-5xl text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <div className="inline-flex items-center rounded-full border border-slate-700 bg-slate-800/50 px-3 py-1 text-sm font-medium text-slate-300 backdrop-blur-sm mb-8">
            <span className="flex h-2 w-2 rounded-full bg-blue-500 mr-2"></span>
            Enterprise Cloud Architecture
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-b from-white to-slate-400">
            Simplifying Cloud.<br />Accelerating Growth.
          </h1>
          <p className="mt-4 text-xl md:text-2xl text-slate-400 max-w-2xl mx-auto mb-10 font-medium">
            We engineer resilient, high-velocity infrastructure for organizations that cannot afford to fail.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="#contact" className="inline-flex h-12 items-center justify-center rounded-md bg-blue-600 px-8 text-sm font-medium text-white shadow transition-colors hover:bg-blue-700 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-blue-700 disabled:pointer-events-none disabled:opacity-50" data-testid="button-hero-cta">
              Schedule an Advisory Session
            </Link>
            <Link href="#services" className="inline-flex h-12 items-center justify-center rounded-md border border-slate-700 bg-transparent px-8 text-sm font-medium text-slate-300 shadow-sm transition-colors hover:bg-slate-800 hover:text-white focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-slate-700 disabled:pointer-events-none disabled:opacity-50" data-testid="button-hero-secondary">
              Explore Our Capabilities
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
