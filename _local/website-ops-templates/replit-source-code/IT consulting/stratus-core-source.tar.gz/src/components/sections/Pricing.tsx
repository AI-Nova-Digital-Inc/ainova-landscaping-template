import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";

const tiers = [
  {
    name: "Advisory",
    price: "Custom",
    description: "Strategic planning and architecture design.",
    features: ["Cloud Readiness Assessment", "Architecture Blueprinting", "Security Posture Review", "Cost Optimization Strategy"],
    highlighted: false
  },
  {
    name: "Implementation",
    price: "Project-based",
    description: "End-to-end execution of complex migrations.",
    features: ["Zero-downtime Migration", "Infrastructure as Code", "CI/CD Pipeline Setup", "Kubernetes Orchestration", "Post-migration Support"],
    highlighted: true
  },
  {
    name: "Enterprise Partnership",
    price: "Retainer",
    description: "Ongoing platform engineering and DevOps.",
    features: ["Dedicated Engineering Pod", "24/7 SLA Guarantees", "Continuous Optimization", "Custom Platform Development"],
    highlighted: false
  }
];

export function Pricing() {
  return (
    <section className="py-24 bg-white text-slate-900 border-t border-slate-100">
      <div className="container px-4 md:px-6 mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Engagement Models</h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Flexible partnerships designed to match your specific maturity phase.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {tiers.map((tier, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`relative flex flex-col p-8 rounded-2xl border ${tier.highlighted ? 'border-blue-600 shadow-xl shadow-blue-900/5' : 'border-slate-200 shadow-sm'}`}
            >
              {tier.highlighted && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-3 py-1 bg-blue-600 text-white text-xs font-semibold rounded-full tracking-wide">
                  MOST COMMON
                </div>
              )}
              <h3 className="text-xl font-semibold mb-2">{tier.name}</h3>
              <div className="text-sm text-slate-500 mb-6">{tier.description}</div>
              <div className="text-3xl font-bold mb-8">{tier.price}</div>
              
              <ul className="space-y-4 mb-8 flex-1">
                {tier.features.map((feature, i) => (
                  <li key={i} className="flex items-start">
                    <Check className="h-5 w-5 text-blue-600 mr-3 shrink-0" />
                    <span className="text-slate-600 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Button 
                variant={tier.highlighted ? "default" : "outline"} 
                className="w-full"
                data-testid={`button-pricing-${tier.name.toLowerCase()}`}
              >
                Inquire
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
