import { motion } from "framer-motion";
import { CloudCog, Network, ShieldCheck, Zap } from "lucide-react";

const services = [
  {
    title: "Cloud Migration",
    description: "Seamlessly transition monolithic workloads to scalable, modern cloud-native architectures with zero downtime.",
    icon: CloudCog,
  },
  {
    title: "DevOps Automation",
    description: "Implement rigorous CI/CD pipelines, infrastructure as code (IaC), and automated testing to ship faster.",
    icon: Zap,
  },
  {
    title: "Platform Engineering",
    description: "Build robust internal developer platforms (IDPs) that abstract infrastructure complexity and empower teams.",
    icon: Network,
  },
  {
    title: "Cloud Security",
    description: "Embed zero-trust security principles, compliance automation, and continuous threat monitoring.",
    icon: ShieldCheck,
  },
];

export function Services() {
  return (
    <section id="services" className="py-24 bg-slate-50 text-slate-900">
      <div className="container px-4 md:px-6 mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Core Capabilities</h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Strategic consulting and precise execution across the entire cloud lifecycle.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group p-8 rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow-md transition-all duration-300"
            >
              <div className="h-12 w-12 rounded-lg bg-blue-50 flex items-center justify-center mb-6 group-hover:bg-blue-600 transition-colors duration-300">
                <service.icon className="h-6 w-6 text-blue-600 group-hover:text-white transition-colors duration-300" />
              </div>
              <h3 className="text-xl font-semibold mb-3">{service.title}</h3>
              <p className="text-slate-600 leading-relaxed">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
