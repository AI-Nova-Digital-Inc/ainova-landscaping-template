import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export function Contact() {
  return (
    <section id="contact" className="py-24 bg-slate-900 text-white">
      <div className="container px-4 md:px-6 mx-auto max-w-4xl text-center">
        <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Start the Conversation</h2>
        <p className="text-lg text-slate-400 mb-10 max-w-xl mx-auto">
          Ready to re-architect your infrastructure? Leave us your details and a senior engineer will be in touch.
        </p>

        <form className="max-w-md mx-auto space-y-4 text-left" onSubmit={(e) => e.preventDefault()}>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-2">Work Email</label>
            <Input 
              id="email" 
              type="email" 
              placeholder="cio@company.com" 
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 focus-visible:ring-blue-500"
              data-testid="input-contact-email"
            />
          </div>
          <div>
            <label htmlFor="message" className="block text-sm font-medium text-slate-300 mb-2">Project Details</label>
            <Textarea 
              id="message" 
              placeholder="Tell us about your current infrastructure..." 
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 min-h-[120px] focus-visible:ring-blue-500"
              data-testid="input-contact-message"
            />
          </div>
          <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white" data-testid="button-contact-submit">
            Request Consultation
          </Button>
        </form>
      </div>
    </section>
  );
}
