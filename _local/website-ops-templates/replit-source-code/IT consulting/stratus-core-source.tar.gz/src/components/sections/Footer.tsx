export function Footer() {
  return (
    <footer className="bg-slate-950 py-12 text-slate-400 border-t border-slate-800">
      <div className="container px-4 md:px-6 mx-auto max-w-6xl flex flex-col md:flex-row justify-between items-center">
        <div className="mb-4 md:mb-0">
          <span className="text-xl font-bold tracking-tight text-white">StratusCore Cloud.</span>
        </div>
        <div className="text-sm">
          &copy; {new Date().getFullYear()} StratusCore Cloud Consulting. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
