import { Hero } from "@/components/sections/Hero";
import { Services } from "@/components/sections/Services";
import { Architecture } from "@/components/sections/Architecture";
import { CaseStudies } from "@/components/sections/CaseStudies";
import { Pricing } from "@/components/sections/Pricing";
import { Contact } from "@/components/sections/Contact";
import { Footer } from "@/components/sections/Footer";

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-slate-50 font-sans">
      <Hero />
      <Services />
      <Architecture />
      <CaseStudies />
      <Pricing />
      <Contact />
      <Footer />
    </main>
  );
}
