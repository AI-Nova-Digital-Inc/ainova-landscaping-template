import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  opacity: number;
  pulseSpeed: number;
  pulseOffset: number;
}

export function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let mouseX = 0;
    let mouseY = 0;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const onMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    };
    window.addEventListener('mousemove', onMouseMove);

    const COUNT = 120;
    const particles: Particle[] = Array.from({ length: COUNT }, () => ({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      vx: (Math.random() - 0.5) * 0.4,
      vy: (Math.random() - 0.5) * 0.4,
      radius: Math.random() * 2.5 + 0.8,
      opacity: Math.random() * 0.5 + 0.2,
      pulseSpeed: Math.random() * 0.015 + 0.005,
      pulseOffset: Math.random() * Math.PI * 2,
    }));

    let time = 0;

    const draw = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      time += 0.008;

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        const dx = mouseX - p.x;
        const dy = mouseY - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const maxDist = 200;

        if (dist < maxDist) {
          const force = (1 - dist / maxDist) * 0.012;
          p.vx -= (dx / dist) * force;
          p.vy -= (dy / dist) * force;
        }

        p.x += p.vx + Math.sin(time * 0.5 + p.pulseOffset) * 0.18;
        p.y += p.vy + Math.cos(time * 0.4 + p.pulseOffset * 1.3) * 0.12;

        p.vx *= 0.994;
        p.vy *= 0.994;

        if (p.x < 0) p.x = w;
        if (p.x > w) p.x = 0;
        if (p.y < 0) p.y = h;
        if (p.y > h) p.y = 0;

        const pulse = Math.sin(time * p.pulseSpeed * 60 + p.pulseOffset);
        const alpha = p.opacity * (0.6 + pulse * 0.4);
        const r = p.radius * (0.85 + pulse * 0.15);

        const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r * 4);
        grad.addColorStop(0, `hsla(210, 85%, 62%, ${alpha})`);
        grad.addColorStop(0.4, `hsla(215, 75%, 55%, ${alpha * 0.5})`);
        grad.addColorStop(1, `hsla(220, 70%, 50%, 0)`);

        ctx.beginPath();
        ctx.arc(p.x, p.y, r * 4, 0, Math.PI * 2);
        ctx.fillStyle = grad;
        ctx.fill();
      }

      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const a = particles[i];
          const b = particles[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          const maxLink = 90;
          if (dist < maxLink) {
            const alpha = (1 - dist / maxLink) * 0.12;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.strokeStyle = `hsla(210, 80%, 65%, ${alpha})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }

      animationId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', onMouseMove);
    };
  }, []);

  return (
    <section id="hero" className="relative w-full h-[100dvh] flex items-center justify-center overflow-hidden" style={{ background: 'linear-gradient(160deg, #f8faff 0%, #eef4ff 50%, #f4f8ff 100%)' }}>
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none z-0"
        style={{ width: '100%', height: '100%' }}
      />

      <div className="relative z-10 text-center max-w-4xl px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.1, ease: [0.25, 0.46, 0.45, 0.94] }}
        >
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-sm font-medium tracking-widest uppercase mb-6"
            style={{ color: 'hsl(210, 80%, 50%)' }}
          >
            Premium Plumbing Services
          </motion.p>

          <h1 className="font-serif text-5xl md:text-7xl font-semibold tracking-tight leading-tight mb-6" style={{ color: 'hsl(220, 25%, 12%)' }}>
            Precision Plumbing.<br />
            <span style={{ color: 'hsl(210, 80%, 50%)' }}>Built to Last.</span>
          </h1>

          <p className="text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed" style={{ color: 'hsl(215, 16%, 47%)' }}>
            Expert solutions for modern homes. We deliver master craftsmanship
            with engineering precision — every time.
          </p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <a
              href="#contact"
              data-testid="hero-cta-button"
              className="inline-flex items-center justify-center px-9 py-4 rounded-full text-white font-medium text-base transition-all duration-300 hover:scale-105 active:scale-95"
              style={{
                background: 'linear-gradient(135deg, hsl(210, 80%, 50%) 0%, hsl(215, 75%, 45%) 100%)',
                boxShadow: '0 8px 32px hsla(210, 80%, 50%, 0.28)',
              }}
            >
              Request Consultation
            </a>
            <a
              href="#services"
              data-testid="hero-services-link"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-full font-medium text-base transition-all duration-300 hover:scale-105"
              style={{ color: 'hsl(215, 16%, 47%)', border: '1px solid hsl(214, 32%, 85%)' }}
            >
              Explore Services
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </a>
          </motion.div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.5, delay: 1.2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        style={{ color: 'hsl(215, 16%, 65%)' }}
      >
        <span className="text-xs tracking-widest uppercase font-medium">Scroll</span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ repeat: Infinity, duration: 1.6, ease: 'easeInOut' }}
        >
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M10 4v12M5 11l5 5 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </motion.div>
      </motion.div>
    </section>
  );
}
