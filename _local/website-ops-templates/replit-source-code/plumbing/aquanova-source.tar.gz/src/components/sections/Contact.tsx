import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Phone, Mail, MapPin, Clock } from "lucide-react";

const contactInfo = [
  {
    icon: Phone,
    label: "Phone",
    value: "+44 20 7946 0958",
    sub: "Available 24/7 for emergencies",
  },
  {
    icon: Mail,
    label: "Email",
    value: "hello@aquanovaplumbing.com",
    sub: "Response within 2 hours",
  },
  {
    icon: MapPin,
    label: "Coverage",
    value: "Greater London & Home Counties",
    sub: "All boroughs covered",
  },
  {
    icon: Clock,
    label: "Office Hours",
    value: "Mon–Fri: 7:30am – 7pm",
    sub: "Emergency line: 24/7",
  },
];

export function Contact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="contact" className="py-24 px-6" style={{ background: "hsl(214, 60%, 97%)" }}>
      <div className="max-w-6xl mx-auto" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="mb-16"
        >
          <p className="text-sm font-semibold tracking-widest uppercase mb-3" style={{ color: "hsl(210, 80%, 50%)" }}>
            Get In Touch
          </p>
          <h2 className="font-serif text-4xl md:text-5xl" style={{ color: "hsl(220, 25%, 12%)" }}>
            Request a<br />Consultation
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Left column */}
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="lg:col-span-2 flex flex-col gap-5"
          >
            <div
              className="p-7 rounded-2xl border"
              style={{
                background: "linear-gradient(135deg, hsl(210, 80%, 50%) 0%, hsl(220, 75%, 45%) 100%)",
                borderColor: "transparent",
              }}
            >
              <h3 className="font-serif text-2xl font-semibold text-white mb-2">Speak to an Expert</h3>
              <p className="text-white/80 text-sm leading-relaxed mb-6">
                Our senior engineers are available to discuss your project directly — no call centres, no scripts. Just expert advice.
              </p>
              <a
                href="tel:+442079460958"
                data-testid="contact-phone-cta"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-full text-sm font-semibold transition-all duration-200 hover:scale-105"
                style={{ background: "rgba(255,255,255,0.15)", color: "white", border: "1px solid rgba(255,255,255,0.3)" }}
              >
                <Phone className="w-4 h-4" />
                Call Now: +44 20 7946 0958
              </a>
            </div>

            <div
              className="p-6 rounded-2xl border flex flex-col gap-5"
              style={{
                background: "rgba(255,255,255,0.9)",
                backdropFilter: "blur(12px)",
                borderColor: "hsl(214, 32%, 91%)",
              }}
            >
              {contactInfo.map((info) => {
                const Icon = info.icon;
                return (
                  <div key={info.label} className="flex items-start gap-3">
                    <div
                      className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                      style={{ background: "hsl(210, 80%, 96%)" }}
                    >
                      <Icon className="w-4 h-4" style={{ color: "hsl(210, 80%, 50%)" }} />
                    </div>
                    <div>
                      <p className="text-xs font-semibold mb-0.5" style={{ color: "hsl(215, 16%, 55%)" }}>{info.label}</p>
                      <p className="text-sm font-medium" style={{ color: "hsl(220, 25%, 15%)" }}>{info.value}</p>
                      <p className="text-xs mt-0.5" style={{ color: "hsl(215, 16%, 60%)" }}>{info.sub}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>

          {/* Right column — Form */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="lg:col-span-3"
          >
            <form
              onSubmit={(e) => e.preventDefault()}
              className="p-8 rounded-2xl border h-full"
              style={{
                background: "rgba(255,255,255,0.95)",
                backdropFilter: "blur(12px)",
                borderColor: "hsl(214, 32%, 91%)",
                boxShadow: "0 4px 32px rgba(59, 130, 246, 0.06)",
              }}
            >
              <h3 className="font-serif text-xl font-semibold mb-6" style={{ color: "hsl(220, 25%, 12%)" }}>
                Send Us a Message
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold tracking-wide uppercase" style={{ color: "hsl(215, 16%, 45%)" }}>Full Name</label>
                  <input
                    type="text"
                    placeholder="Jane Doe"
                    data-testid="contact-name"
                    className="w-full px-4 py-3 rounded-xl text-sm outline-none transition-all duration-200"
                    style={{
                      background: "hsl(214, 60%, 98%)",
                      border: "1.5px solid hsl(214, 32%, 91%)",
                      color: "hsl(220, 25%, 12%)",
                    }}
                    onFocus={(e) => (e.target.style.borderColor = "hsl(210, 80%, 60%)")}
                    onBlur={(e) => (e.target.style.borderColor = "hsl(214, 32%, 91%)")}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold tracking-wide uppercase" style={{ color: "hsl(215, 16%, 45%)" }}>Email Address</label>
                  <input
                    type="email"
                    placeholder="jane@example.com"
                    data-testid="contact-email"
                    className="w-full px-4 py-3 rounded-xl text-sm outline-none transition-all duration-200"
                    style={{
                      background: "hsl(214, 60%, 98%)",
                      border: "1.5px solid hsl(214, 32%, 91%)",
                      color: "hsl(220, 25%, 12%)",
                    }}
                    onFocus={(e) => (e.target.style.borderColor = "hsl(210, 80%, 60%)")}
                    onBlur={(e) => (e.target.style.borderColor = "hsl(214, 32%, 91%)")}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold tracking-wide uppercase" style={{ color: "hsl(215, 16%, 45%)" }}>Phone Number</label>
                  <input
                    type="tel"
                    placeholder="+44 20 7946 0958"
                    data-testid="contact-phone"
                    className="w-full px-4 py-3 rounded-xl text-sm outline-none transition-all duration-200"
                    style={{
                      background: "hsl(214, 60%, 98%)",
                      border: "1.5px solid hsl(214, 32%, 91%)",
                      color: "hsl(220, 25%, 12%)",
                    }}
                    onFocus={(e) => (e.target.style.borderColor = "hsl(210, 80%, 60%)")}
                    onBlur={(e) => (e.target.style.borderColor = "hsl(214, 32%, 91%)")}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold tracking-wide uppercase" style={{ color: "hsl(215, 16%, 45%)" }}>Service Required</label>
                  <select
                    data-testid="contact-service"
                    className="w-full px-4 py-3 rounded-xl text-sm outline-none transition-all duration-200 appearance-none"
                    style={{
                      background: "hsl(214, 60%, 98%)",
                      border: "1.5px solid hsl(214, 32%, 91%)",
                      color: "hsl(220, 25%, 25%)",
                    }}
                  >
                    <option value="">Select a service...</option>
                    <option value="leak">Leak Detection & Repair</option>
                    <option value="installation">Fixture Installation</option>
                    <option value="maintenance">Annual Maintenance</option>
                    <option value="heating">Heating & Hot Water</option>
                    <option value="filtration">Water Filtration</option>
                    <option value="emergency">Emergency Response</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1.5 mb-6">
                <label className="text-xs font-semibold tracking-wide uppercase" style={{ color: "hsl(215, 16%, 45%)" }}>Message</label>
                <textarea
                  rows={4}
                  placeholder="Briefly describe your project or issue. The more detail you provide, the better we can prepare for your consultation."
                  data-testid="contact-message"
                  className="w-full px-4 py-3 rounded-xl text-sm outline-none transition-all duration-200 resize-none"
                  style={{
                    background: "hsl(214, 60%, 98%)",
                    border: "1.5px solid hsl(214, 32%, 91%)",
                    color: "hsl(220, 25%, 12%)",
                  }}
                  onFocus={(e) => (e.target.style.borderColor = "hsl(210, 80%, 60%)")}
                  onBlur={(e) => (e.target.style.borderColor = "hsl(214, 32%, 91%)")}
                />
              </div>

              <button
                type="submit"
                data-testid="contact-submit"
                className="w-full py-4 rounded-xl text-white font-semibold text-sm transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
                style={{
                  background: "linear-gradient(135deg, hsl(210, 80%, 50%) 0%, hsl(220, 75%, 45%) 100%)",
                  boxShadow: "0 8px 24px hsla(210, 80%, 50%, 0.25)",
                }}
              >
                Send Request — We'll Respond Within 2 Hours
              </button>

              <p className="text-center text-xs mt-3" style={{ color: "hsl(215, 16%, 60%)" }}>
                Your information is kept strictly confidential and never shared.
              </p>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
