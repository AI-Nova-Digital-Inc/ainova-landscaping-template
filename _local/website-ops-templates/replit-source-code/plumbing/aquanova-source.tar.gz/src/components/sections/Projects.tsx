import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { ArrowUpRight } from "lucide-react";

const projects = [
  {
    id: 1,
    title: "Kensington Residence",
    category: "Full System Upgrade",
    description: "Complete re-pipe of a 5-bedroom period home. New copper supply lines, updated waste system, and luxury fixture installation throughout.",
    year: "2024",
    gradient: "linear-gradient(135deg, hsl(210, 60%, 88%) 0%, hsl(220, 50%, 80%) 100%)",
    accent: "hsl(210, 80%, 50%)",
    tag: "Residential",
    size: "large",
  },
  {
    id: 2,
    title: "Hyde Park Renovation",
    category: "Luxury Fixtures",
    description: "Full bathroom suite upgrades across 4 bathrooms with bespoke Grohe and Duravit fittings.",
    year: "2024",
    gradient: "linear-gradient(135deg, hsl(195, 60%, 88%) 0%, hsl(210, 50%, 82%) 100%)",
    accent: "hsl(195, 70%, 45%)",
    tag: "Renovation",
    size: "small",
  },
  {
    id: 3,
    title: "Chelsea Townhouse",
    category: "Radiant Heating",
    description: "Underfloor heating installation across 3 floors, integrated with a new high-efficiency boiler system.",
    year: "2023",
    gradient: "linear-gradient(135deg, hsl(220, 55%, 90%) 0%, hsl(230, 50%, 82%) 100%)",
    accent: "hsl(220, 70%, 50%)",
    tag: "Heating",
    size: "small",
  },
  {
    id: 4,
    title: "Notting Hill Estate",
    category: "Water Filtration",
    description: "Whole-house water filtration and softening system. Zero limescale, pristine drinking water on every floor.",
    year: "2023",
    gradient: "linear-gradient(135deg, hsl(200, 60%, 88%) 0%, hsl(215, 55%, 80%) 100%)",
    accent: "hsl(200, 75%, 45%)",
    tag: "Filtration",
    size: "small",
  },
  {
    id: 5,
    title: "Mayfair Penthouse",
    category: "Full Modernisation",
    description: "New-build plumbing fit-out for a 4,000 sq ft penthouse. Bespoke solutions, smart water monitoring, and concierge maintenance plan.",
    year: "2024",
    gradient: "linear-gradient(135deg, hsl(215, 65%, 86%) 0%, hsl(225, 55%, 78%) 100%)",
    accent: "hsl(215, 75%, 48%)",
    tag: "New Build",
    size: "large",
  },
];

export function Projects() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="work" className="py-24 px-6" style={{ background: "#ffffff" }}>
      <div className="max-w-6xl mx-auto" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="mb-16"
        >
          <p className="text-sm font-semibold tracking-widest uppercase mb-3" style={{ color: "hsl(210, 80%, 50%)" }}>
            Selected Work
          </p>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <h2 className="font-serif text-4xl md:text-5xl" style={{ color: "hsl(220, 25%, 12%)" }}>
              Projects We're<br />Proud Of
            </h2>
            <p className="text-base max-w-sm leading-relaxed" style={{ color: "hsl(215, 16%, 47%)" }}>
              Every project listed here represents a homeowner who trusted us with their most important asset.
            </p>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {projects.map((project, index) => (
            <motion.div
              key={project.id}
              data-testid={`project-card-${project.id}`}
              initial={{ opacity: 0, y: 28 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.65, delay: index * 0.1 }}
              className={`group relative rounded-2xl overflow-hidden border cursor-default ${project.size === "large" ? "md:col-span-1 row-span-2" : ""}`}
              style={{
                borderColor: "hsl(214, 32%, 91%)",
                boxShadow: "0 2px 16px rgba(59, 130, 246, 0.04)",
              }}
              whileHover={{ y: -3, boxShadow: "0 12px 40px rgba(59, 130, 246, 0.12)" }}
            >
              <div
                className="w-full flex items-center justify-center"
                style={{
                  background: project.gradient,
                  height: project.size === "large" ? "220px" : "160px",
                }}
              >
                <div className="relative w-full h-full flex items-center justify-center">
                  <div
                    className="absolute w-32 h-32 rounded-full opacity-30"
                    style={{ background: project.accent, filter: "blur(32px)" }}
                  />
                  <div
                    className="absolute w-16 h-16 rounded-full opacity-40"
                    style={{ background: "white", filter: "blur(12px)", top: "30%", left: "30%" }}
                  />
                  <div
                    className="relative z-10 w-14 h-14 rounded-xl border-2 border-white/60 flex items-center justify-center shadow-lg"
                    style={{ background: "rgba(255,255,255,0.5)", backdropFilter: "blur(8px)" }}
                  >
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" style={{ color: project.accent }}>
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z" fill="currentColor" opacity="0.3"/>
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" fill="currentColor"/>
                    </svg>
                  </div>
                </div>
              </div>

              <div className="p-6" style={{ background: "#fff" }}>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span
                        className="text-xs font-semibold px-2 py-0.5 rounded-full"
                        style={{ background: "hsl(210, 80%, 96%)", color: "hsl(210, 80%, 45%)" }}
                      >
                        {project.tag}
                      </span>
                      <span className="text-xs" style={{ color: "hsl(215, 16%, 60%)" }}>{project.year}</span>
                    </div>
                    <h3 className="font-serif text-xl font-semibold" style={{ color: "hsl(220, 25%, 12%)" }}>
                      {project.title}
                    </h3>
                  </div>
                  <div
                    className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300"
                    style={{ background: "hsl(210, 80%, 96%)" }}
                  >
                    <ArrowUpRight className="w-4 h-4" style={{ color: "hsl(210, 80%, 50%)" }} />
                  </div>
                </div>
                <p className="text-sm leading-relaxed mt-1" style={{ color: "hsl(215, 16%, 50%)" }}>
                  {project.description}
                </p>
                <div className="mt-4 pt-4 flex items-center justify-between border-t" style={{ borderColor: "hsl(214, 32%, 94%)" }}>
                  <span className="text-xs font-medium" style={{ color: "hsl(215, 16%, 55%)" }}>{project.category}</span>
                  <span
                    className="text-xs font-semibold"
                    style={{ color: "hsl(210, 80%, 50%)" }}
                  >
                    View Case Study →
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
