export function Footer() {
  return (
    <footer className="bg-foreground text-background py-16 px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="col-span-1 md:col-span-2">
          <div className="font-serif text-2xl font-semibold mb-4">AquaNova</div>
          <p className="text-muted/60 max-w-sm">
            Precision plumbing and master craftsmanship for discerning homeowners. Engineered for longevity.
          </p>
        </div>
        
        <div>
          <h4 className="font-medium mb-4 text-background/90">Company</h4>
          <ul className="space-y-2 text-sm text-muted/60">
            <li><a href="#hero" className="hover:text-primary transition-colors">Home</a></li>
            <li><a href="#services" className="hover:text-primary transition-colors">Services</a></li>
            <li><a href="#work" className="hover:text-primary transition-colors">Selected Work</a></li>
            <li><a href="#contact" className="hover:text-primary transition-colors">Contact</a></li>
          </ul>
        </div>
        
        <div>
          <h4 className="font-medium mb-4 text-background/90">Contact</h4>
          <ul className="space-y-2 text-sm text-muted/60">
            <li>London, UK</li>
            <li>+44 20 7946 0958</li>
            <li>hello@aquanovaplumbing.com</li>
          </ul>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-muted/20 flex flex-col md:flex-row items-center justify-between text-sm text-muted/40">
        <p>&copy; {new Date().getFullYear()} AquaNova Plumbing. All rights reserved.</p>
        <div className="flex gap-4 mt-4 md:mt-0">
          <a href="#" className="hover:text-background transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-background transition-colors">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
}
