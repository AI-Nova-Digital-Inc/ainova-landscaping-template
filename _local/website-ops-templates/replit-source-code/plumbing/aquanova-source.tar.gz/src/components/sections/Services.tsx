import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Droplet, Wrench, ShieldCheck, Thermometer, Filter, AlertTriangle } from "lucide-react";

const services = [
  {
    icon: Droplet,
    title: "Leak Detection & Repair",
    description: "Precision non-invasive detection of hidden leaks using acoustic diagnostics. We fix the root cause — not just the symptom.",
    tag: "Most Requested",
  },
  {
    icon: Wrench,
    title: "Luxury Fixture Installation",
    description: "Expert fitting of premium fixtures from Grohe, Hansgrohe, and Kohler. Every installation is calibrated to manufacturer spec.",
    tag: null,
  },
  {
    icon: ShieldCheck,
    title: "Annual Maintenance Plans",
    description: "Year-round protection with scheduled inspections, pressure checks, and pre-emptive repairs before issues escalate.",
    tag: "Popular",
  },
  {
    icon: Thermometer,
    title: "Heating & Hot Water",
    description: "Boiler servicing, underfloor heating, and hot water system upgrades. Efficiency-optimised for modern homes.",
    tag: null,
  },
  {
    icon: Filter,
    title: "Water Filtration Systems",
    description: "Whole-house filtration and water softening solutions. Clean, mineral-balanced water from every tap.",
    tag: null,
  },
  {
    icon: AlertTriangle,
    title: "24/7 Emergency Response",
    description: "Round-the-clock emergency callouts for burst pipes, flooding, and critical failures. Average response time: 45 minutes.",
    tag: "Emergency",
  },
];

export function Services() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="services" className="py-24 px-6" style={{ background: "linear-gradient(180deg, #ffffff 0%, #f4f8ff 100%)" }}>
      <div className="max-w-6xl mx-auto" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="mb-16"
        >
          <p className="text-sm font-semibold tracking-widest uppercase mb-3" style={{ color: "hsl(210, 80%, 50%)" }}>
            What We Do
          </p>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <h2 className="font-serif text-4xl md:text-5xl" style={{ color: "hsl(220, 25%, 12%)" }}>
              Services Built<br />Around Your Home
            </h2>
            <p className="text-base max-w-sm leading-relaxed" style={{ color: "hsl(215, 16%, 47%)" }}>
              Every service is delivered by certified master plumbers with over 15 years of residential experience.
            </p>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.title}
                data-testid={`service-card-${index}`}
                initial={{ opacity: 0, y: 32 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.65, delay: index * 0.1 }}
                className="group relative p-7 rounded-2xl border transition-all duration-500 cursor-default"
                style={{
                  background: "rgba(255,255,255,0.85)",
                  backdropFilter: "blur(12px)",
                  borderColor: "hsl(214, 32%, 91%)",
                  boxShadow: "0 2px 16px rgba(59, 130, 246, 0.04)",
                }}
                whileHover={{
                  y: -4,
                  boxShadow: "0 12px 40px rgba(59, 130, 246, 0.12)",
                  borderColor: "hsl(210, 80%, 70%)",
                }}
              >
                {service.tag && (
                  <span
                    className="absolute top-5 right-5 text-xs font-semibold px-3 py-1 rounded-full"
                    style={{
                      background: service.tag === "Emergency" ? "hsl(0, 84%, 97%)" : "hsl(210, 80%, 96%)",
                      color: service.tag === "Emergency" ? "hsl(0, 84%, 50%)" : "hsl(210, 80%, 45%)",
                    }}
                  >
                    {service.tag}
                  </span>
                )}

                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-5 transition-transform duration-500 group-hover:scale-110"
                  style={{ background: "hsl(210, 80%, 96%)" }}
                >
                  <Icon className="w-5 h-5" style={{ color: "hsl(210, 80%, 50%)" }} />
                </div>

                <h3 className="font-serif text-lg font-semibold mb-2" style={{ color: "hsl(220, 25%, 12%)" }}>
                  {service.title}
                </h3>
                <p className="text-sm leading-relaxed" style={{ color: "hsl(215, 16%, 50%)" }}>
                  {service.description}
                </p>

                <div
                  className="mt-5 flex items-center gap-1.5 text-xs font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  style={{ color: "hsl(210, 80%, 50%)" }}
                >
                  Learn more
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                    <path d="M2 6h8M6.5 2.5L10 6l-3.5 3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
