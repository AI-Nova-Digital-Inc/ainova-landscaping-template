import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Star } from "lucide-react";

const testimonials = [
  {
    quote: "The level of professionalism and cleanliness was unprecedented. They re-piped our entire historic home and you would never know they had been there. Exceptional.",
    author: "Eleanor V.",
    area: "Kensington",
    role: "Homeowner",
    rating: 5,
    initials: "EV",
    color: "hsl(210, 80%, 50%)",
  },
  {
    quote: "AquaNova doesn't just fix problems; they engineer solutions. We finally have a heating system that works flawlessly and silently — even in winter. Worth every penny.",
    author: "James T.",
    area: "Chelsea",
    role: "Property Developer",
    rating: 5,
    initials: "JT",
    color: "hsl(195, 70%, 45%)",
  },
  {
    quote: "Punctual, articulate, and absolute masters of their craft. It is rare to find tradespeople who treat your home with this much respect. I recommend them without hesitation.",
    author: "Sarah M.",
    area: "Mayfair",
    role: "Homeowner",
    rating: 5,
    initials: "SM",
    color: "hsl(220, 70%, 50%)",
  },
  {
    quote: "Called at 11pm for an emergency burst pipe. They arrived within 40 minutes, were incredibly calm and professional, and had everything resolved by 2am. Remarkable service.",
    author: "Richard B.",
    area: "Notting Hill",
    role: "Homeowner",
    rating: 5,
    initials: "RB",
    color: "hsl(205, 75%, 48%)",
  },
];

function StarRating({ count }: { count: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: count }).map((_, i) => (
        <Star key={i} className="w-3.5 h-3.5 fill-current" style={{ color: "hsl(38, 92%, 55%)" }} />
      ))}
    </div>
  );
}

export function Testimonials() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section className="py-24 px-6" style={{ background: "linear-gradient(180deg, #f4f8ff 0%, #ffffff 100%)" }}>
      <div className="max-w-6xl mx-auto" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="mb-16"
        >
          <p className="text-sm font-semibold tracking-widest uppercase mb-3" style={{ color: "hsl(210, 80%, 50%)" }}>
            Client Stories
          </p>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <h2 className="font-serif text-4xl md:text-5xl" style={{ color: "hsl(220, 25%, 12%)" }}>
              What Our Clients<br />Say About Us
            </h2>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="font-serif text-3xl font-semibold" style={{ color: "hsl(210, 80%, 50%)" }}>4.98</p>
                <p className="text-xs" style={{ color: "hsl(215, 16%, 55%)" }}>Average rating · 200+ reviews</p>
              </div>
              <StarRating count={5} />
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {testimonials.map((item, index) => (
            <motion.div
              key={index}
              data-testid={`testimonial-card-${index}`}
              initial={{ opacity: 0, y: 28 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.65, delay: index * 0.1 }}
              className="flex flex-col p-7 rounded-2xl border"
              style={{
                background: "rgba(255,255,255,0.9)",
                backdropFilter: "blur(12px)",
                borderColor: "hsl(214, 32%, 91%)",
                boxShadow: "0 2px 16px rgba(59, 130, 246, 0.04)",
              }}
            >
              <div className="flex items-center justify-between mb-5">
                <StarRating count={item.rating} />
                <span
                  className="text-4xl font-serif leading-none select-none"
                  style={{ color: "hsl(210, 80%, 88%)" }}
                >
                  "
                </span>
              </div>

              <p className="text-base leading-relaxed flex-grow mb-6" style={{ color: "hsl(220, 20%, 25%)" }}>
                {item.quote}
              </p>

              <div className="flex items-center gap-3 pt-5 border-t" style={{ borderColor: "hsl(214, 32%, 94%)" }}>
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-semibold flex-shrink-0"
                  style={{ background: item.color }}
                >
                  {item.initials}
                </div>
                <div>
                  <p className="font-semibold text-sm" style={{ color: "hsl(220, 25%, 12%)" }}>{item.author}</p>
                  <p className="text-xs" style={{ color: "hsl(215, 16%, 55%)" }}>{item.role} · {item.area}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
