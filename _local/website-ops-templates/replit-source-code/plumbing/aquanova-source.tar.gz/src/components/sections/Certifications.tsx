import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Award, Clock, Shield, Star, Users, CheckCircle } from "lucide-react";

const stats = [
  { value: "15+", label: "Years in Business", icon: Clock },
  { value: "2,400+", label: "Projects Completed", icon: CheckCircle },
  { value: "200+", label: "Five-Star Reviews", icon: Star },
  { value: "98%", label: "Client Retention", icon: Users },
];

const badges = [
  { icon: Shield, label: "Fully Licensed & Insured", sub: "Gas Safe Register #543210" },
  { icon: Award, label: "10-Year Workmanship Guarantee", sub: "On all major works" },
  { icon: Clock, label: "24/7 Emergency Response", sub: "Avg. 45-min arrival" },
  { icon: Star, label: "Master Plumber Certified", sub: "WaterSafe accredited" },
];

export function Certifications() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-60px" });

  return (
    <section className="py-24 px-6" style={{ background: "hsl(220, 25%, 12%)" }}>
      <div className="max-w-6xl mx-auto" ref={ref}>
        {/* Stats row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                data-testid={`stat-${index}`}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center mx-auto mb-3"
                  style={{ background: "hsl(210, 80%, 18%)" }}
                >
                  <Icon className="w-5 h-5" style={{ color: "hsl(210, 80%, 60%)" }} />
                </div>
                <p className="font-serif text-4xl font-semibold mb-1" style={{ color: "#ffffff" }}>
                  {stat.value}
                </p>
                <p className="text-xs font-medium" style={{ color: "hsl(215, 16%, 60%)" }}>
                  {stat.label}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Divider */}
        <div className="border-t mb-12" style={{ borderColor: "hsl(215, 20%, 22%)" }} />

        {/* Badges row */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-5"
        >
          {badges.map((badge, index) => {
            const Icon = badge.icon;
            return (
              <div
                key={badge.label}
                data-testid={`badge-${index}`}
                className="flex items-start gap-3 p-5 rounded-xl"
                style={{ background: "hsl(215, 20%, 17%)" }}
              >
                <div
                  className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ background: "hsl(210, 80%, 18%)" }}
                >
                  <Icon className="w-4 h-4" style={{ color: "hsl(210, 80%, 60%)" }} />
                </div>
                <div>
                  <p className="text-sm font-semibold leading-tight mb-0.5" style={{ color: "#ffffff" }}>
                    {badge.label}
                  </p>
                  <p className="text-xs" style={{ color: "hsl(215, 16%, 55%)" }}>
                    {badge.sub}
                  </p>
                </div>
              </div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
