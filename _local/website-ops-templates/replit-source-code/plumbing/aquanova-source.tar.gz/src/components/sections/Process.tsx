import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Search, Lightbulb, Zap, CheckCircle2 } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: Search,
    title: "Thorough Inspection",
    description: "We start with a comprehensive survey of your plumbing infrastructure using acoustic leak detection, thermal imaging, and pressure diagnostics — no guesswork.",
    detail: "Same-day availability",
  },
  {
    number: "02",
    icon: Lightbulb,
    title: "Diagnosis & Design",
    description: "Our engineers architect a precise solution tailored to your home's layout. You receive a detailed written plan with transparent pricing before any work begins.",
    detail: "Fixed-price quote provided",
  },
  {
    number: "03",
    icon: Zap,
    title: "Precision Execution",
    description: "Master plumbers complete the work to the highest standard — on schedule, with minimal disruption. All surfaces protected, all areas left spotless.",
    detail: "Guaranteed completion time",
  },
  {
    number: "04",
    icon: CheckCircle2,
    title: "Quality Sign-Off",
    description: "Every job is signed off with a full pressure test, photographic report, and a 10-year workmanship guarantee. You keep the documentation.",
    detail: "10-year guarantee issued",
  },
];

export function Process() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="process" className="py-24 px-6" style={{ background: "hsl(214, 60%, 97%)" }}>
      <div className="max-w-6xl mx-auto" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="mb-16"
        >
          <p className="text-sm font-semibold tracking-widest uppercase mb-3" style={{ color: "hsl(210, 80%, 50%)" }}>
            How It Works
          </p>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <h2 className="font-serif text-4xl md:text-5xl" style={{ color: "hsl(220, 25%, 12%)" }}>
              The AquaNova<br />Method
            </h2>
            <p className="text-base max-w-sm leading-relaxed" style={{ color: "hsl(215, 16%, 47%)" }}>
              A structured, four-stage process engineered around transparency, precision, and respect for your home.
            </p>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.number}
                data-testid={`process-step-${index}`}
                initial={{ opacity: 0, y: 28 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.65, delay: index * 0.12 }}
                className="flex gap-6 p-7 rounded-2xl border"
                style={{
                  background: "rgba(255,255,255,0.9)",
                  backdropFilter: "blur(8px)",
                  borderColor: "hsl(214, 32%, 91%)",
                  boxShadow: "0 2px 16px rgba(59, 130, 246, 0.04)",
                }}
              >
                <div className="flex-shrink-0">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center"
                    style={{ background: "hsl(210, 80%, 50%)" }}
                  >
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-xs font-bold tracking-widest" style={{ color: "hsl(210, 80%, 65%)" }}>
                      STEP {step.number}
                    </span>
                    <span
                      className="text-xs font-medium px-2 py-0.5 rounded-full"
                      style={{ background: "hsl(210, 80%, 96%)", color: "hsl(210, 80%, 45%)" }}
                    >
                      {step.detail}
                    </span>
                  </div>
                  <h3 className="font-serif text-xl font-semibold mb-2" style={{ color: "hsl(220, 25%, 12%)" }}>
                    {step.title}
                  </h3>
                  <p className="text-sm leading-relaxed" style={{ color: "hsl(215, 16%, 50%)" }}>
                    {step.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
