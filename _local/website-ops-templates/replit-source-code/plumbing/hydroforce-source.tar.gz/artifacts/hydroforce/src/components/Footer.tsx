import { Droplets, Phone, MapPin, Clock, Mail, Shield } from "lucide-react";

const PHONE = "(555) 247-3911";

const quickLinks = [
  { label: "Emergency Services", href: "#services" },
  { label: "Before & After Results", href: "#results" },
  { label: "Why Choose Us", href: "#why-us" },
  { label: "Customer Reviews", href: "#reviews" },
  { label: "Get a Free Quote", href: "#contact" },
];

const serviceAreas = [
  "Downtown", "Midtown", "Westside", "Northpark",
  "Eastview", "Riverside", "Oakwood", "Lakewood",
];

const services = [
  "Emergency Leak Repair",
  "Drain & Clog Clearing",
  "Burst Pipe Repair",
  "Water Heater Service",
  "Sewer Line Replacement",
  "Bathroom & Kitchen",
];

export default function Footer() {
  return (
    <footer
      style={{
        backgroundColor: "#040c18",
        borderTop: "1px solid rgba(255,255,255,0.07)",
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div
                className="w-9 h-9 rounded-full flex items-center justify-center"
                style={{ background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))" }}
              >
                <Droplets size={18} color="white" />
              </div>
              <div>
                <span
                  className="text-xl font-black text-white"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
                >
                  HYDRO<span style={{ color: "var(--hf-orange)" }}>FORCE</span>
                </span>
                <div className="text-[9px] text-gray-500 tracking-widest uppercase leading-none">Plumbing</div>
              </div>
            </div>

            <p className="text-sm leading-relaxed mb-5" style={{ color: "#6b7fa0" }}>
              Fast. Reliable. Every Time.
            </p>

            <div className="flex flex-col gap-3">
              <a
                href={`tel:${PHONE.replace(/\D/g, "")}`}
                className="flex items-center gap-2 text-sm font-semibold text-white hover:opacity-80 transition-opacity"
              >
                <Phone size={15} style={{ color: "var(--hf-orange)" }} />
                {PHONE}
              </a>
              <div className="flex items-center gap-2 text-sm" style={{ color: "#6b7fa0" }}>
                <Mail size={15} style={{ color: "var(--hf-orange)" }} />
                info@hydroforce.com
              </div>
              <div className="flex items-center gap-2 text-sm" style={{ color: "#6b7fa0" }}>
                <Clock size={15} style={{ color: "var(--hf-orange)" }} />
                Available 24/7 — All Holidays
              </div>
              <div className="flex items-center gap-2 text-sm" style={{ color: "#6b7fa0" }}>
                <MapPin size={15} style={{ color: "var(--hf-orange)" }} />
                Serving the Metro Area
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4
              className="text-xs font-bold uppercase tracking-widest mb-5"
              style={{ color: "#8fa3c0" }}
            >
              Quick Links
            </h4>
            <ul className="flex flex-col gap-2.5">
              {quickLinks.map((l) => (
                <li key={l.label}>
                  <a
                    href={l.href}
                    className="text-sm transition-colors duration-200 hover:text-white"
                    style={{ color: "#6b7fa0" }}
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4
              className="text-xs font-bold uppercase tracking-widest mb-5"
              style={{ color: "#8fa3c0" }}
            >
              Services
            </h4>
            <ul className="flex flex-col gap-2.5">
              {services.map((s) => (
                <li key={s}>
                  <a
                    href="#services"
                    className="text-sm transition-colors duration-200 hover:text-white"
                    style={{ color: "#6b7fa0" }}
                  >
                    {s}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Service Areas */}
          <div>
            <h4
              className="text-xs font-bold uppercase tracking-widest mb-5"
              style={{ color: "#8fa3c0" }}
            >
              Service Areas
            </h4>
            <div className="flex flex-wrap gap-2">
              {serviceAreas.map((area) => (
                <span
                  key={area}
                  className="text-xs px-2.5 py-1 rounded-lg"
                  style={{
                    backgroundColor: "rgba(255,255,255,0.04)",
                    border: "1px solid rgba(255,255,255,0.08)",
                    color: "#6b7fa0",
                  }}
                >
                  {area}
                </span>
              ))}
            </div>

            {/* CTA */}
            <a
              href="tel:5552473911"
              className="mt-6 flex items-center justify-center gap-2 py-3 px-5 rounded-xl font-bold text-white text-sm transition-all duration-200 hover:scale-105"
              style={{
                background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))",
                boxShadow: "0 6px 20px rgba(230,57,70,0.35)",
              }}
            >
              <Phone size={15} />
              Emergency? Call Now
            </a>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div
        className="border-t"
        style={{ borderColor: "rgba(255,255,255,0.06)" }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs" style={{ color: "#3d506a" }}>
            © {new Date().getFullYear()} HydroForce Plumbing. All rights reserved.
          </p>
          <div className="flex items-center gap-2 text-xs" style={{ color: "#3d506a" }}>
            <Shield size={12} style={{ color: "#4a6a8a" }} />
            Licensed & Insured | Lic #PLB-447821 | State Contractor #HF-2024
          </div>
        </div>
      </div>
    </footer>
  );
}
