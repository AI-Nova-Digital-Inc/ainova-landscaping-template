import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Phone, ChevronDown, Shield, Star, Clock, Tag } from "lucide-react";

const PHONE = "(555) 247-3911";

const trustBadges = [
  { icon: Shield, label: "Licensed & Insured" },
  { icon: Star, label: "5-Star Rated" },
  { icon: Clock, label: "Same-Day Service" },
  { icon: Tag, label: "Free Estimates" },
];

function WaterBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let width = canvas.offsetWidth;
    let height = canvas.offsetHeight;
    canvas.width = width;
    canvas.height = height;

    const drops: { x: number; y: number; speed: number; size: number; opacity: number }[] = [];
    for (let i = 0; i < 40; i++) {
      drops.push({
        x: Math.random() * width,
        y: Math.random() * height,
        speed: 0.5 + Math.random() * 1.5,
        size: 1 + Math.random() * 2.5,
        opacity: 0.08 + Math.random() * 0.18,
      });
    }

    function draw() {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, width, height);

      for (const drop of drops) {
        ctx.beginPath();
        ctx.arc(drop.x, drop.y, drop.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(100, 180, 255, ${drop.opacity})`;
        ctx.fill();

        drop.y += drop.speed;
        if (drop.y > height + 10) {
          drop.y = -10;
          drop.x = Math.random() * width;
        }
      }

      // Pipe lines
      ctx.strokeStyle = "rgba(26, 58, 107, 0.3)";
      ctx.lineWidth = 1.5;
      for (let i = 0; i < 4; i++) {
        const y = (height / 4) * i + height / 8;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      animationId = requestAnimationFrame(draw);
    }

    draw();

    const handleResize = () => {
      width = canvas.offsetWidth;
      height = canvas.offsetHeight;
      canvas.width = width;
      canvas.height = height;
    };
    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none"
      style={{ opacity: 0.6 }}
    />
  );
}

export default function HeroSection() {
  return (
    <section
      className="relative min-h-screen flex flex-col items-center justify-center text-center overflow-hidden pt-16"
      style={{
        background: "linear-gradient(160deg, #0a1628 0%, #0f1f3d 50%, #0a1628 100%)",
      }}
    >
      {/* Animated background */}
      <WaterBackground />

      {/* Gradient overlays */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 80% 60% at 50% 40%, rgba(26,58,107,0.35) 0%, transparent 70%)",
        }}
      />
      <div
        className="absolute bottom-0 left-0 right-0 h-32 pointer-events-none"
        style={{ background: "linear-gradient(to top, #0a1628, transparent)" }}
      />

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        {/* Urgency badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-semibold mb-8"
          style={{
            background: "rgba(230,57,70,0.15)",
            border: "1px solid rgba(230,57,70,0.4)",
            color: "#ff7a85",
          }}
        >
          <span
            className="w-2 h-2 rounded-full"
            style={{ backgroundColor: "var(--hf-red)", animation: "pulse-ring 2s infinite" }}
          />
          Available 24/7 — Emergency Response in 45 Minutes
        </motion.div>

        {/* Main headline */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="font-display text-white leading-none mb-6"
          style={{
            fontFamily: "'Barlow Condensed', sans-serif",
            fontSize: "clamp(2.8rem, 8vw, 6rem)",
            fontWeight: 800,
            letterSpacing: "0.01em",
            textShadow: "0 4px 24px rgba(0,0,0,0.5)",
          }}
        >
          24/7 Emergency Plumbing{" "}
          <br className="hidden sm:block" />
          <span style={{ color: "var(--hf-orange)" }}>— We Fix It Fast</span>
        </motion.h1>

        {/* Subtext */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-lg sm:text-xl mb-10 max-w-2xl mx-auto"
          style={{ color: "#8fa3c0", lineHeight: 1.6 }}
        >
          Leaks, clogs, burst pipes — call now for immediate service.
          <br />
          <span className="text-white font-medium">No job too big. No hour too late.</span>
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4 justify-center mb-12"
        >
          <motion.a
            href="#contact"
            className="inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl font-bold text-lg text-white transition-all duration-200 pulse-cta"
            style={{
              background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))",
              boxShadow: "0 8px 32px rgba(230,57,70,0.45)",
              fontSize: "1.1rem",
            }}
            whileHover={{ scale: 1.04, boxShadow: "0 12px 40px rgba(230,57,70,0.6)" }}
            whileTap={{ scale: 0.97 }}
          >
            <Phone size={20} />
            Get Immediate Help
          </motion.a>

          <motion.a
            href="#contact"
            className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl font-bold text-lg text-white border transition-all duration-200"
            style={{
              borderColor: "rgba(255,255,255,0.2)",
              backgroundColor: "rgba(255,255,255,0.07)",
              backdropFilter: "blur(8px)",
            }}
            whileHover={{
              backgroundColor: "rgba(255,255,255,0.14)",
              borderColor: "rgba(255,255,255,0.35)",
              scale: 1.02,
            }}
            whileTap={{ scale: 0.97 }}
          >
            Request a Quote
          </motion.a>
        </motion.div>

        {/* Trust badges */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.45 }}
          className="flex flex-wrap justify-center gap-3 sm:gap-5"
        >
          {trustBadges.map(({ icon: Icon, label }, i) => (
            <motion.div
              key={label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 + i * 0.08 }}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium"
              style={{
                backgroundColor: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.1)",
                color: "#c8d8f0",
              }}
            >
              <Icon size={15} style={{ color: "var(--hf-green)" }} />
              {label}
            </motion.div>
          ))}
        </motion.div>

        {/* Phone display */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-10"
        >
          <a
            href={`tel:${PHONE.replace(/\D/g, "")}`}
            className="text-2xl sm:text-3xl font-bold text-white hover:opacity-80 transition-opacity"
            style={{ fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.05em" }}
          >
            <span style={{ color: "var(--hf-muted)" }} className="text-lg font-normal">Call:</span>{" "}
            {PHONE}
          </a>
        </motion.div>
      </div>

      {/* Scroll cue */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 8, 0] }}
        transition={{ repeat: Infinity, duration: 1.8 }}
      >
        <ChevronDown size={28} style={{ color: "rgba(255,255,255,0.3)" }} />
      </motion.div>
    </section>
  );
}
