import { Phone } from "lucide-react";
import { motion } from "framer-motion";

const PHONE = "(555) 247-3911";

export default function FloatingCallButton() {
  return (
    <motion.a
      href={`tel:${PHONE.replace(/\D/g, "")}`}
      className="fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-3 rounded-full font-bold text-white shadow-2xl pulse-cta"
      style={{
        background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))",
        boxShadow: "0 8px 32px rgba(230,57,70,0.5)",
      }}
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: 1.2, type: "spring", stiffness: 300 }}
      whileHover={{ scale: 1.07 }}
      whileTap={{ scale: 0.95 }}
    >
      <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
        <Phone size={16} color="white" />
      </div>
      <span className="text-sm font-bold hidden sm:block">{PHONE}</span>
      <span className="text-sm font-bold sm:hidden">Call Now</span>
    </motion.a>
  );
}
