import { useState, useRef, useCallback, useEffect } from "react";
import { motion, useInView } from "framer-motion";
import { Phone } from "lucide-react";

const slides = [
  {
    title: "Burst Pipe Repair",
    subtitle: "Emergency repair completed in 2 hours",
    before: {
      label: "BEFORE",
      bg: "linear-gradient(135deg, #1a0a0a 0%, #2d0f0f 50%, #1a0a0a 100%)",
      description: "Corroded, burst pipe flooding basement",
    },
    after: {
      label: "AFTER",
      bg: "linear-gradient(135deg, #0a1a10 0%, #0f2d1a 50%, #0a1a10 100%)",
      description: "New copper pipe, sealed and pressure-tested",
    },
  },
  {
    title: "Drain Clearing",
    subtitle: "Complete blockage cleared with hydro-jetting",
    before: {
      label: "BEFORE",
      bg: "linear-gradient(135deg, #1a120a 0%, #2d1e0f 50%, #1a120a 100%)",
      description: "Severely clogged drain pipe, years of buildup",
    },
    after: {
      label: "AFTER",
      bg: "linear-gradient(135deg, #0a1520 0%, #0f2030 50%, #0a1520 100%)",
      description: "Pristine, clear pipe — full flow restored",
    },
  },
  {
    title: "Sewer Line Replacement",
    subtitle: "Full sewer line replaced in one day",
    before: {
      label: "BEFORE",
      bg: "linear-gradient(135deg, #160a1a 0%, #260f2d 50%, #160a1a 100%)",
      description: "Collapsed clay sewer line, sewage backup",
    },
    after: {
      label: "AFTER",
      bg: "linear-gradient(135deg, #0a1220 0%, #0f1e30 50%, #0a1220 100%)",
      description: "Modern PVC sewer line, camera-inspected",
    },
  },
];

function BeforeAfterSlider({ slide }: { slide: (typeof slides)[0] }) {
  const [pos, setPos] = useState(50);
  const [dragging, setDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const getPos = useCallback((clientX: number) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return 50;
    const x = clientX - rect.left;
    return Math.max(2, Math.min(98, (x / rect.width) * 100));
  }, []);

  const onMouseDown = () => setDragging(true);
  const onMouseUp = () => setDragging(false);
  const onMouseMove = (e: React.MouseEvent) => {
    if (!dragging) return;
    setPos(getPos(e.clientX));
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setPos(getPos(e.touches[0].clientX));
  };

  useEffect(() => {
    const up = () => setDragging(false);
    window.addEventListener("mouseup", up);
    return () => window.removeEventListener("mouseup", up);
  }, []);

  return (
    <div
      ref={containerRef}
      className="relative w-full rounded-2xl overflow-hidden select-none"
      style={{ height: 320, cursor: dragging ? "ew-resize" : "col-resize" }}
      onMouseMove={onMouseMove}
      onTouchMove={onTouchMove}
    >
      {/* AFTER (full width, bottom layer) */}
      <div
        className="absolute inset-0 flex flex-col items-end justify-end p-6"
        style={{ background: slide.after.bg }}
      >
        {/* After visual */}
        <AfterVisual />
        <div
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold"
          style={{ backgroundColor: "rgba(34,197,94,0.2)", border: "1px solid rgba(34,197,94,0.4)", color: "#4ade80" }}
        >
          {slide.after.label}
        </div>
        <p className="text-xs mt-1 text-right" style={{ color: "#8fa3c0" }}>
          {slide.after.description}
        </p>
      </div>

      {/* BEFORE (clipped, top layer) */}
      <div
        className="absolute inset-0 flex flex-col items-start justify-end p-6"
        style={{
          background: slide.before.bg,
          clipPath: `inset(0 ${100 - pos}% 0 0)`,
        }}
      >
        <BeforeVisual />
        <div
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold"
          style={{ backgroundColor: "rgba(230,57,70,0.2)", border: "1px solid rgba(230,57,70,0.4)", color: "#f87171" }}
        >
          {slide.before.label}
        </div>
        <p className="text-xs mt-1" style={{ color: "#8fa3c0" }}>
          {slide.before.description}
        </p>
      </div>

      {/* Divider + handle */}
      <div
        className="absolute top-0 bottom-0 flex items-center justify-center before-after-handle z-10"
        style={{ left: `${pos}%`, transform: "translateX(-50%)" }}
        onMouseDown={onMouseDown}
        onTouchStart={() => setDragging(true)}
        onTouchEnd={() => setDragging(false)}
      >
        <div
          className="absolute top-0 bottom-0 w-0.5"
          style={{ backgroundColor: "white", left: "50%", transform: "translateX(-50%)" }}
        />
        <div
          className="relative z-20 w-10 h-10 rounded-full flex items-center justify-center shadow-xl"
          style={{ background: "white" }}
        >
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <path d="M6 9L2 9M2 9L4 7M2 9L4 11" stroke="#0a1628" strokeWidth="1.5" strokeLinecap="round" />
            <path d="M12 9L16 9M16 9L14 7M16 9L14 11" stroke="#0a1628" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        </div>
      </div>

      {/* Drag hint */}
      <div
        className="absolute top-4 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-xs font-medium"
        style={{ backgroundColor: "rgba(0,0,0,0.5)", color: "rgba(255,255,255,0.7)" }}
      >
        Drag to compare
      </div>
    </div>
  );
}

function BeforeVisual() {
  return (
    <div className="absolute inset-0 flex items-center justify-center opacity-30">
      <div className="space-y-3 w-3/4">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="h-3 rounded-full"
            style={{
              backgroundColor: "#8b1a1a",
              width: `${70 + i * 10}%`,
              opacity: 0.6 + i * 0.1,
            }}
          />
        ))}
        <div className="flex gap-2">
          <div className="w-16 h-16 rounded-lg" style={{ backgroundColor: "#6b1010", opacity: 0.7 }} />
          <div className="flex-1 space-y-2 pt-2">
            <div className="h-2 rounded" style={{ backgroundColor: "#8b1a1a", opacity: 0.5 }} />
            <div className="h-2 rounded w-2/3" style={{ backgroundColor: "#8b1a1a", opacity: 0.4 }} />
          </div>
        </div>
      </div>
    </div>
  );
}

function AfterVisual() {
  return (
    <div className="absolute inset-0 flex items-center justify-center opacity-25">
      <div className="space-y-3 w-3/4">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="h-3 rounded-full"
            style={{
              backgroundColor: "#1a7a3a",
              width: `${70 + i * 10}%`,
              opacity: 0.6 + i * 0.1,
            }}
          />
        ))}
        <div className="flex gap-2">
          <div className="w-16 h-16 rounded-lg" style={{ backgroundColor: "#0f4a2a", opacity: 0.7 }} />
          <div className="flex-1 space-y-2 pt-2">
            <div className="h-2 rounded" style={{ backgroundColor: "#1a7a3a", opacity: 0.5 }} />
            <div className="h-2 rounded w-2/3" style={{ backgroundColor: "#1a7a3a", opacity: 0.4 }} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default function BeforeAfterSection() {
  const [active, setActive] = useState(0);
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="results" className="py-20 sm:py-28" style={{ backgroundColor: "var(--hf-navy)" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={ref} className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-4"
            style={{
              backgroundColor: "rgba(230,57,70,0.12)",
              border: "1px solid rgba(230,57,70,0.3)",
              color: "var(--hf-red)",
            }}
          >
            Real Results
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.08 }}
            className="text-white mb-4"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: "clamp(2rem, 5vw, 3.5rem)",
              fontWeight: 800,
            }}
          >
            Before & After{" "}
            <span style={{ color: "var(--hf-red)" }}>Transformations</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.15 }}
            className="text-base sm:text-lg max-w-xl mx-auto"
            style={{ color: "#8fa3c0" }}
          >
            We don't just patch problems — we fix them right. Drag the slider to see the difference.
          </motion.p>
        </div>

        {/* Tab switcher */}
        <div className="flex justify-center gap-2 mb-8 flex-wrap">
          {slides.map((s, i) => (
            <button
              key={s.title}
              onClick={() => setActive(i)}
              className="px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200"
              style={
                active === i
                  ? {
                      background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))",
                      color: "white",
                    }
                  : {
                      backgroundColor: "rgba(255,255,255,0.06)",
                      border: "1px solid rgba(255,255,255,0.1)",
                      color: "#8fa3c0",
                    }
              }
            >
              {s.title}
            </button>
          ))}
        </div>

        {/* Slider */}
        <motion.div
          key={active}
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.35 }}
          className="max-w-3xl mx-auto"
        >
          <BeforeAfterSlider slide={slides[active]} />
          <p className="text-center text-sm mt-3" style={{ color: "#6b7fa0" }}>
            {slides[active].subtitle}
          </p>
        </motion.div>

        {/* CTA */}
        <div className="text-center mt-12">
          <a
            href="#contact"
            className="inline-flex items-center gap-3 px-8 py-4 rounded-xl font-bold text-white text-lg transition-all duration-200 hover:scale-105"
            style={{
              background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))",
              boxShadow: "0 8px 32px rgba(230,57,70,0.35)",
            }}
          >
            <Phone size={20} />
            Get the Same Results — Call Now
          </a>
        </div>
      </div>
    </section>
  );
}
