import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Star, Phone } from "lucide-react";

const reviews = [
  {
    name: "Marcus T.",
    initials: "MT",
    time: "2 weeks ago",
    rating: 5,
    text: "Pipe burst at 2am on a Sunday. HydroForce had someone at my door in 38 minutes. The tech was professional, explained everything clearly, and fixed it in under an hour. My basement was saved. Cannot recommend enough.",
    color: "#e63946",
  },
  {
    name: "Diane Keller",
    initials: "DK",
    time: "1 month ago",
    rating: 5,
    text: "I called 4 plumbers before HydroForce — all said they couldn't come until the next day. These guys showed up within the hour. Cleared a major clog and re-ran our drain line. Flawless. Worth every penny.",
    color: "#f4801a",
  },
  {
    name: "Robert & Jan M.",
    initials: "RJ",
    time: "3 weeks ago",
    rating: 5,
    text: "Water heater died on Thanksgiving. I thought we'd be without hot water for days. HydroForce installed a new one the same day. The price was fair and upfront — no surprises. Real pros.",
    color: "#1a3a6b",
  },
  {
    name: "Priya S.",
    initials: "PS",
    time: "5 days ago",
    rating: 5,
    text: "Had a sewer smell coming from our basement. HydroForce came out, ran a camera through the line, found the break, and gave me a clear written quote. Work was done cleanly and fast. Five stars.",
    color: "#22c55e",
  },
  {
    name: "Chris Alvarez",
    initials: "CA",
    time: "2 months ago",
    rating: 5,
    text: "Third time using HydroForce — they're my go-to plumber for life. Always on time, always honest about pricing, and the quality holds up. Sent them to my mom's house too. Trust these guys completely.",
    color: "#e63946",
  },
];

function StarRow({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          size={14}
          fill={i < rating ? "#fbbf24" : "none"}
          color={i < rating ? "#fbbf24" : "#4a5568"}
        />
      ))}
    </div>
  );
}

export default function TestimonialsSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="reviews" className="py-20 sm:py-28" style={{ backgroundColor: "var(--hf-navy)" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={ref} className="text-center mb-14">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-4"
            style={{
              backgroundColor: "rgba(251,191,36,0.1)",
              border: "1px solid rgba(251,191,36,0.3)",
              color: "#fbbf24",
            }}
          >
            Customer Reviews
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.08 }}
            className="text-white mb-3"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: "clamp(2rem, 5vw, 3.5rem)",
              fontWeight: 800,
            }}
          >
            4.9 Stars Across{" "}
            <span style={{ color: "#fbbf24" }}>200+ Reviews</span>
          </motion.h2>

          {/* Aggregate stars */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={inView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2 }}
            className="flex items-center justify-center gap-2 mb-4"
          >
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} size={28} fill="#fbbf24" color="#fbbf24" />
            ))}
            <span className="text-xl font-bold text-white ml-2">4.9</span>
            <span className="text-sm" style={{ color: "#8fa3c0" }}>(214 reviews)</span>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2 }}
            className="max-w-xl mx-auto text-base sm:text-lg"
            style={{ color: "#8fa3c0" }}
          >
            Real customers. Real emergencies. Real results.
          </motion.p>
        </div>

        {/* Reviews grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {reviews.map((review, i) => (
            <motion.div
              key={review.name}
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="flex flex-col gap-4 p-6 rounded-2xl"
              style={{
                backgroundColor: "var(--hf-card)",
                border: "1px solid rgba(255,255,255,0.07)",
              }}
              whileHover={{
                scale: 1.02,
                borderColor: "rgba(251,191,36,0.2)",
                boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
              }}
            >
              {/* Header */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold text-white flex-shrink-0"
                    style={{ backgroundColor: review.color }}
                  >
                    {review.initials}
                  </div>
                  <div>
                    <div className="font-semibold text-white text-sm">{review.name}</div>
                    <div className="text-xs" style={{ color: "#6b7fa0" }}>
                      {review.time}
                    </div>
                  </div>
                </div>
                {/* Google G */}
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="flex-shrink-0 mt-0.5">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                </svg>
              </div>

              <StarRow rating={review.rating} />

              <p className="text-sm leading-relaxed flex-1" style={{ color: "#c0cfe0" }}>
                "{review.text}"
              </p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.5 }}
          className="text-center mt-12"
        >
          <a
            href="tel:5552473911"
            className="inline-flex items-center gap-3 px-8 py-4 rounded-xl font-bold text-white text-lg transition-all duration-200 hover:scale-105"
            style={{
              background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))",
              boxShadow: "0 8px 32px rgba(230,57,70,0.35)",
            }}
          >
            <Phone size={20} />
            Join 200+ Happy Customers
          </a>
        </motion.div>
      </div>
    </section>
  );
}
