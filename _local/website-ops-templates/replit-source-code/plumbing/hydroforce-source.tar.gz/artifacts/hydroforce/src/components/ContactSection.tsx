import { useState, useRef } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Phone, CheckCircle, ChevronRight, ChevronLeft } from "lucide-react";

const step1Schema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  phone: z.string().min(10, "Enter a valid phone number"),
  address: z.string().min(5, "Enter your address"),
});

const step2Schema = z.object({
  serviceType: z.string().min(1, "Please select a service"),
  urgency: z.string().min(1, "Please select urgency"),
  description: z.string().min(10, "Please describe the issue"),
});

const step3Schema = z.object({
  preferredTime: z.string().min(1, "Select a preferred time"),
  howHeard: z.string().optional(),
});

type Step1 = z.infer<typeof step1Schema>;
type Step2 = z.infer<typeof step2Schema>;
type Step3 = z.infer<typeof step3Schema>;

const PHONE = "(555) 247-3911";

const inputStyle = {
  width: "100%",
  padding: "12px 16px",
  borderRadius: "10px",
  border: "1px solid rgba(255,255,255,0.12)",
  backgroundColor: "rgba(255,255,255,0.06)",
  color: "white",
  fontSize: "15px",
  outline: "none",
  transition: "border-color 0.2s",
};

const labelStyle = {
  display: "block",
  marginBottom: "6px",
  fontSize: "13px",
  fontWeight: 600,
  color: "#8fa3c0",
  textTransform: "uppercase" as const,
  letterSpacing: "0.05em",
};

const errorStyle = {
  color: "#f87171",
  fontSize: "12px",
  marginTop: "4px",
};

export default function ContactSection() {
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState<Partial<Step1 & Step2 & Step3>>({});

  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  const form1 = useForm<Step1>({ resolver: zodResolver(step1Schema) });
  const form2 = useForm<Step2>({ resolver: zodResolver(step2Schema) });
  const form3 = useForm<Step3>({ resolver: zodResolver(step3Schema) });

  const onStep1 = (data: Step1) => {
    setFormData((prev) => ({ ...prev, ...data }));
    setStep(2);
  };

  const onStep2 = (data: Step2) => {
    setFormData((prev) => ({ ...prev, ...data }));
    setStep(3);
  };

  const onStep3 = (data: Step3) => {
    setFormData((prev) => ({ ...prev, ...data }));
    setSubmitted(true);
  };

  const stepLabels = ["Your Info", "Service Details", "Schedule"];

  return (
    <section
      id="contact"
      className="py-20 sm:py-28"
      style={{ backgroundColor: "var(--hf-navy)" }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={ref} className="text-center mb-14">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-4"
            style={{
              backgroundColor: "rgba(244,128,26,0.12)",
              border: "1px solid rgba(244,128,26,0.3)",
              color: "var(--hf-orange)",
            }}
          >
            Get Help Now
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.08 }}
            className="text-white mb-4"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: "clamp(2rem, 5vw, 3.5rem)",
              fontWeight: 800,
            }}
          >
            Get a Free Quote{" "}
            <span style={{ color: "var(--hf-orange)" }}>in 60 Seconds</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.15 }}
            className="max-w-xl mx-auto text-base sm:text-lg"
            style={{ color: "#8fa3c0" }}
          >
            Fill out the short form below or call us directly. We respond to all requests within minutes.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start max-w-5xl mx-auto">
          {/* Left: form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="rounded-2xl p-6 sm:p-8"
            style={{
              backgroundColor: "var(--hf-card)",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            {submitted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center justify-center text-center py-12 gap-6"
              >
                <div
                  className="w-20 h-20 rounded-full flex items-center justify-center"
                  style={{ backgroundColor: "rgba(34,197,94,0.15)", border: "2px solid var(--hf-green)" }}
                >
                  <CheckCircle size={40} style={{ color: "var(--hf-green)" }} />
                </div>
                <div>
                  <h3
                    className="text-2xl font-bold text-white mb-2"
                    style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
                  >
                    Request Received!
                  </h3>
                  <p style={{ color: "#8fa3c0" }}>
                    We'll call you back within 10 minutes. For immediate help:
                  </p>
                </div>
                <a
                  href={`tel:${PHONE.replace(/\D/g, "")}`}
                  className="flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white"
                  style={{
                    background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))",
                    boxShadow: "0 6px 24px rgba(230,57,70,0.4)",
                  }}
                >
                  <Phone size={18} />
                  Call {PHONE}
                </a>
              </motion.div>
            ) : (
              <>
                {/* Step indicator */}
                <div className="flex items-center gap-0 mb-8">
                  {stepLabels.map((label, i) => {
                    const num = i + 1;
                    const isActive = step === num;
                    const isDone = step > num;
                    return (
                      <div key={label} className="flex items-center flex-1">
                        <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
                          <div
                            className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all duration-300"
                            style={
                              isDone
                                ? { backgroundColor: "var(--hf-green)", color: "white" }
                                : isActive
                                ? { background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))", color: "white" }
                                : { backgroundColor: "rgba(255,255,255,0.08)", color: "#6b7fa0" }
                            }
                          >
                            {isDone ? <CheckCircle size={14} /> : num}
                          </div>
                          <span
                            className="text-[10px] font-medium uppercase tracking-wide whitespace-nowrap"
                            style={{ color: isActive ? "white" : "#6b7fa0" }}
                          >
                            {label}
                          </span>
                        </div>
                        {i < stepLabels.length - 1 && (
                          <div
                            className="flex-1 h-0.5 mx-2 mt-[-10px]"
                            style={{
                              backgroundColor: isDone ? "var(--hf-green)" : "rgba(255,255,255,0.1)",
                              transition: "background-color 0.3s",
                            }}
                          />
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Step forms */}
                <AnimatePresence mode="wait">
                  {step === 1 && (
                    <motion.form
                      key="step1"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.25 }}
                      onSubmit={form1.handleSubmit(onStep1)}
                      className="flex flex-col gap-5"
                    >
                      <div>
                        <label style={labelStyle}>Your Name</label>
                        <input
                          {...form1.register("name")}
                          placeholder="John Smith"
                          style={inputStyle}
                          onFocus={(e) => (e.target.style.borderColor = "var(--hf-orange)")}
                          onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.12)")}
                        />
                        {form1.formState.errors.name && (
                          <p style={errorStyle}>{form1.formState.errors.name.message}</p>
                        )}
                      </div>
                      <div>
                        <label style={labelStyle}>Phone Number</label>
                        <input
                          {...form1.register("phone")}
                          placeholder="(555) 000-0000"
                          type="tel"
                          style={inputStyle}
                          onFocus={(e) => (e.target.style.borderColor = "var(--hf-orange)")}
                          onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.12)")}
                        />
                        {form1.formState.errors.phone && (
                          <p style={errorStyle}>{form1.formState.errors.phone.message}</p>
                        )}
                      </div>
                      <div>
                        <label style={labelStyle}>Service Address</label>
                        <input
                          {...form1.register("address")}
                          placeholder="123 Main St, Your City"
                          style={inputStyle}
                          onFocus={(e) => (e.target.style.borderColor = "var(--hf-orange)")}
                          onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.12)")}
                        />
                        {form1.formState.errors.address && (
                          <p style={errorStyle}>{form1.formState.errors.address.message}</p>
                        )}
                      </div>
                      <button
                        type="submit"
                        className="flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-white text-base transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] mt-2"
                        style={{
                          background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))",
                          boxShadow: "0 6px 24px rgba(230,57,70,0.4)",
                        }}
                      >
                        Next: Service Details <ChevronRight size={18} />
                      </button>
                    </motion.form>
                  )}

                  {step === 2 && (
                    <motion.form
                      key="step2"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.25 }}
                      onSubmit={form2.handleSubmit(onStep2)}
                      className="flex flex-col gap-5"
                    >
                      <div>
                        <label style={labelStyle}>Service Type</label>
                        <select
                          {...form2.register("serviceType")}
                          style={{ ...inputStyle, cursor: "pointer" }}
                          onFocus={(e) => (e.target.style.borderColor = "var(--hf-orange)")}
                          onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.12)")}
                        >
                          <option value="" style={{ backgroundColor: "#0f1f3d" }}>Select service...</option>
                          <option value="emergency-leak" style={{ backgroundColor: "#0f1f3d" }}>Emergency Leak Repair</option>
                          <option value="drain-clog" style={{ backgroundColor: "#0f1f3d" }}>Drain & Clog Clearing</option>
                          <option value="burst-pipe" style={{ backgroundColor: "#0f1f3d" }}>Burst Pipe Repair</option>
                          <option value="water-heater" style={{ backgroundColor: "#0f1f3d" }}>Water Heater Service</option>
                          <option value="sewer" style={{ backgroundColor: "#0f1f3d" }}>Sewer Line Issues</option>
                          <option value="bathroom-kitchen" style={{ backgroundColor: "#0f1f3d" }}>Bathroom / Kitchen</option>
                          <option value="other" style={{ backgroundColor: "#0f1f3d" }}>Other</option>
                        </select>
                        {form2.formState.errors.serviceType && (
                          <p style={errorStyle}>{form2.formState.errors.serviceType.message}</p>
                        )}
                      </div>
                      <div>
                        <label style={labelStyle}>Urgency Level</label>
                        <select
                          {...form2.register("urgency")}
                          style={{ ...inputStyle, cursor: "pointer" }}
                          onFocus={(e) => (e.target.style.borderColor = "var(--hf-orange)")}
                          onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.12)")}
                        >
                          <option value="" style={{ backgroundColor: "#0f1f3d" }}>Select urgency...</option>
                          <option value="emergency" style={{ backgroundColor: "#0f1f3d" }}>Emergency — Active leak/damage now</option>
                          <option value="today" style={{ backgroundColor: "#0f1f3d" }}>Urgent — Needs fixing today</option>
                          <option value="this-week" style={{ backgroundColor: "#0f1f3d" }}>This week works</option>
                          <option value="planning" style={{ backgroundColor: "#0f1f3d" }}>Just getting a quote</option>
                        </select>
                        {form2.formState.errors.urgency && (
                          <p style={errorStyle}>{form2.formState.errors.urgency.message}</p>
                        )}
                      </div>
                      <div>
                        <label style={labelStyle}>Describe the Problem</label>
                        <textarea
                          {...form2.register("description")}
                          placeholder="Tell us what's happening — the more detail, the better we can prepare..."
                          rows={3}
                          style={{ ...inputStyle, resize: "none" }}
                          onFocus={(e) => (e.target.style.borderColor = "var(--hf-orange)")}
                          onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.12)")}
                        />
                        {form2.formState.errors.description && (
                          <p style={errorStyle}>{form2.formState.errors.description.message}</p>
                        )}
                      </div>
                      <div className="flex gap-3 mt-2">
                        <button
                          type="button"
                          onClick={() => setStep(1)}
                          className="flex items-center justify-center gap-1 py-3 px-5 rounded-xl font-semibold text-sm transition-all duration-200 hover:opacity-80"
                          style={{
                            border: "1px solid rgba(255,255,255,0.15)",
                            backgroundColor: "rgba(255,255,255,0.06)",
                            color: "#c0cfe0",
                          }}
                        >
                          <ChevronLeft size={16} /> Back
                        </button>
                        <button
                          type="submit"
                          className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-white text-base transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
                          style={{
                            background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))",
                            boxShadow: "0 6px 24px rgba(230,57,70,0.4)",
                          }}
                        >
                          Next: Schedule <ChevronRight size={18} />
                        </button>
                      </div>
                    </motion.form>
                  )}

                  {step === 3 && (
                    <motion.form
                      key="step3"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.25 }}
                      onSubmit={form3.handleSubmit(onStep3)}
                      className="flex flex-col gap-5"
                    >
                      <div>
                        <label style={labelStyle}>Preferred Time</label>
                        <select
                          {...form3.register("preferredTime")}
                          style={{ ...inputStyle, cursor: "pointer" }}
                          onFocus={(e) => (e.target.style.borderColor = "var(--hf-orange)")}
                          onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.12)")}
                        >
                          <option value="" style={{ backgroundColor: "#0f1f3d" }}>Select time...</option>
                          <option value="asap" style={{ backgroundColor: "#0f1f3d" }}>As soon as possible</option>
                          <option value="morning" style={{ backgroundColor: "#0f1f3d" }}>Morning (8am–12pm)</option>
                          <option value="afternoon" style={{ backgroundColor: "#0f1f3d" }}>Afternoon (12pm–5pm)</option>
                          <option value="evening" style={{ backgroundColor: "#0f1f3d" }}>Evening (5pm–9pm)</option>
                          <option value="weekend" style={{ backgroundColor: "#0f1f3d" }}>Weekend</option>
                        </select>
                        {form3.formState.errors.preferredTime && (
                          <p style={errorStyle}>{form3.formState.errors.preferredTime.message}</p>
                        )}
                      </div>
                      <div>
                        <label style={labelStyle}>How Did You Hear About Us? (optional)</label>
                        <input
                          {...form3.register("howHeard")}
                          placeholder="Google, neighbor referral, etc."
                          style={inputStyle}
                          onFocus={(e) => (e.target.style.borderColor = "var(--hf-orange)")}
                          onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.12)")}
                        />
                      </div>

                      {/* Summary */}
                      <div
                        className="rounded-xl p-4 text-sm"
                        style={{
                          backgroundColor: "rgba(255,255,255,0.04)",
                          border: "1px solid rgba(255,255,255,0.07)",
                          color: "#8fa3c0",
                        }}
                      >
                        <div className="font-semibold text-white mb-2">Summary</div>
                        <div>Name: <span className="text-white">{formData.name}</span></div>
                        <div>Phone: <span className="text-white">{formData.phone}</span></div>
                        <div>Service: <span className="text-white">{formData.serviceType || "—"}</span></div>
                        <div>Urgency: <span className="text-white">{formData.urgency || "—"}</span></div>
                      </div>

                      <div className="flex gap-3 mt-2">
                        <button
                          type="button"
                          onClick={() => setStep(2)}
                          className="flex items-center justify-center gap-1 py-3 px-5 rounded-xl font-semibold text-sm transition-all duration-200 hover:opacity-80"
                          style={{
                            border: "1px solid rgba(255,255,255,0.15)",
                            backgroundColor: "rgba(255,255,255,0.06)",
                            color: "#c0cfe0",
                          }}
                        >
                          <ChevronLeft size={16} /> Back
                        </button>
                        <button
                          type="submit"
                          className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-white text-base transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
                          style={{
                            background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))",
                            boxShadow: "0 6px 24px rgba(230,57,70,0.4)",
                          }}
                        >
                          <CheckCircle size={18} />
                          Submit Request
                        </button>
                      </div>
                    </motion.form>
                  )}
                </AnimatePresence>
              </>
            )}
          </motion.div>

          {/* Right: phone CTA */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-col gap-6"
          >
            {/* Big phone CTA */}
            <div
              className="rounded-2xl p-8 flex flex-col items-center text-center gap-5"
              style={{
                background: "linear-gradient(135deg, var(--hf-red) 0%, var(--hf-orange) 100%)",
                boxShadow: "0 16px 48px rgba(230,57,70,0.4)",
              }}
            >
              <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
                <Phone size={32} color="white" />
              </div>
              <div>
                <div className="text-sm font-bold uppercase tracking-widest text-white/80 mb-1">
                  Or Call Us Now
                </div>
                <a
                  href={`tel:${PHONE.replace(/\D/g, "")}`}
                  className="block text-3xl sm:text-4xl font-black text-white hover:opacity-90 transition-opacity"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.03em" }}
                >
                  {PHONE}
                </a>
              </div>
              <div className="text-sm text-white/80">
                Available 24 hours a day, 7 days a week.
                <br />
                Emergency response in 45 minutes.
              </div>
            </div>

            {/* Response promise */}
            {[
              { icon: "⚡", text: "We call back within 10 minutes" },
              { icon: "🔒", text: "Free, no-obligation quotes" },
              { icon: "📋", text: "Flat-rate pricing — no surprises" },
              { icon: "✅", text: "Licensed & insured technicians" },
            ].map((item) => (
              <div
                key={item.text}
                className="flex items-center gap-4 px-5 py-4 rounded-xl"
                style={{
                  backgroundColor: "var(--hf-card)",
                  border: "1px solid rgba(255,255,255,0.07)",
                }}
              >
                <span className="text-xl">{item.icon}</span>
                <span className="text-sm font-medium" style={{ color: "#c0cfe0" }}>
                  {item.text}
                </span>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
