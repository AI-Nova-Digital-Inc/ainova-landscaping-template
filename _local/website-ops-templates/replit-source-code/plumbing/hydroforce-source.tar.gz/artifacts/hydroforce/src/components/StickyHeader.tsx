import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Phone, Menu, X, Droplets } from "lucide-react";

const PHONE = "(555) 247-3911";

const navLinks = [
  { label: "Services", href: "#services" },
  { label: "Results", href: "#results" },
  { label: "Why Us", href: "#why-us" },
  { label: "Reviews", href: "#reviews" },
  { label: "Contact", href: "#contact" },
];

export default function StickyHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        backgroundColor: scrolled ? "rgba(10,22,40,0.97)" : "rgba(10,22,40,0.85)",
        backdropFilter: "blur(12px)",
        borderBottom: scrolled ? "1px solid rgba(255,255,255,0.08)" : "none",
        boxShadow: scrolled ? "0 4px 24px rgba(0,0,0,0.5)" : "none",
      }}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 group">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))" }}
          >
            <Droplets size={16} color="white" />
          </div>
          <div>
            <span
              className="font-display text-xl font-bold tracking-tight text-white"
              style={{ fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.02em" }}
            >
              HYDRO<span style={{ color: "var(--hf-orange)" }}>FORCE</span>
            </span>
            <div className="text-[9px] text-gray-400 tracking-widest uppercase leading-none">Plumbing</div>
          </div>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-gray-300 hover:text-white transition-colors duration-200"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* CTA Phone */}
        <a
          href={`tel:${PHONE.replace(/\D/g, "")}`}
          className="hidden md:flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-white text-sm transition-all duration-200 hover:scale-105 active:scale-95"
          style={{
            background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))",
            boxShadow: "0 4px 14px rgba(230,57,70,0.4)",
          }}
        >
          <Phone size={15} />
          {PHONE}
        </a>

        {/* Mobile: phone + hamburger */}
        <div className="flex items-center gap-3 md:hidden">
          <a
            href={`tel:${PHONE.replace(/\D/g, "")}`}
            className="flex items-center justify-center w-9 h-9 rounded-full"
            style={{ background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))" }}
          >
            <Phone size={16} color="white" />
          </a>
          <button
            className="text-white p-1"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label="Toggle menu"
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25 }}
            className="md:hidden overflow-hidden"
            style={{ backgroundColor: "rgba(10,22,40,0.99)", borderTop: "1px solid rgba(255,255,255,0.07)" }}
          >
            <div className="px-4 py-4 flex flex-col gap-3">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="text-base font-medium text-gray-200 hover:text-white py-1"
                  onClick={() => setMenuOpen(false)}
                >
                  {link.label}
                </a>
              ))}
              <a
                href={`tel:${PHONE.replace(/\D/g, "")}`}
                className="mt-2 flex items-center justify-center gap-2 py-3 rounded-lg font-bold text-white"
                style={{ background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))" }}
              >
                <Phone size={16} />
                Call Now: {PHONE}
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
