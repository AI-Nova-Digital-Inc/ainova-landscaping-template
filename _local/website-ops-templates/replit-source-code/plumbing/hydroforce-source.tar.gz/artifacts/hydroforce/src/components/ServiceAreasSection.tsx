import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { MapPin, Phone } from "lucide-react";

const areas = [
  "Downtown",
  "Midtown",
  "Westside",
  "Northpark",
  "Eastview",
  "Riverside",
  "Oakwood",
  "Lakewood",
  "Hillcrest",
  "Fairview",
  "Cedar Ridge",
  "Sunnyvale",
  "Maplewood",
  "Pinehurst",
  "Brookfield",
  "Harborview",
];

export default function ServiceAreasSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section className="py-20 sm:py-28" style={{ backgroundColor: "#080f1e" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={ref} className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-4"
            style={{
              backgroundColor: "rgba(26,58,107,0.4)",
              border: "1px solid rgba(100,160,255,0.25)",
              color: "#64a0ff",
            }}
          >
            <MapPin size={12} />
            Service Areas
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.08 }}
            className="text-white mb-4"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: "clamp(2rem, 5vw, 3.5rem)",
              fontWeight: 800,
            }}
          >
            We Serve Your{" "}
            <span style={{ color: "var(--hf-orange)" }}>Neighborhood</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.15 }}
            className="max-w-xl mx-auto text-base sm:text-lg"
            style={{ color: "#8fa3c0" }}
          >
            Fast response throughout the metro area. Not sure if we serve your area? Call us — we'll get there.
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="flex flex-wrap justify-center gap-3 max-w-4xl mx-auto"
        >
          {areas.map((area, i) => (
            <motion.div
              key={area}
              initial={{ opacity: 0, scale: 0.85 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.35, delay: 0.2 + i * 0.04 }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm transition-all duration-200"
              style={{
                backgroundColor: "var(--hf-card)",
                border: "1px solid rgba(255,255,255,0.08)",
                color: "#c0cfe0",
              }}
              whileHover={{
                backgroundColor: "rgba(26,58,107,0.6)",
                borderColor: "rgba(100,160,255,0.3)",
                color: "white",
                scale: 1.05,
              }}
            >
              <MapPin size={13} style={{ color: "var(--hf-orange)" }} />
              {area}
            </motion.div>
          ))}
        </motion.div>

        {/* Radius note */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 0.9 }}
          className="text-center text-sm mt-8"
          style={{ color: "#6b7fa0" }}
        >
          Serving a 40-mile radius. Call to confirm availability in your area.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.7 }}
          className="text-center mt-10"
        >
          <a
            href="tel:5552473911"
            className="inline-flex items-center gap-3 px-8 py-4 rounded-xl font-bold text-white text-lg transition-all duration-200 hover:scale-105"
            style={{
              background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))",
              boxShadow: "0 8px 32px rgba(230,57,70,0.35)",
            }}
          >
            <Phone size={20} />
            Check Your Area — Call Now
          </a>
        </motion.div>
      </div>
    </section>
  );
}
