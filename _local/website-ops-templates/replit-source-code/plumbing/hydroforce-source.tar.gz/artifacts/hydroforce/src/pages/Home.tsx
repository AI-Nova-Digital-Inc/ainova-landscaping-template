import StickyHeader from "@/components/StickyHeader";
import HeroSection from "@/components/HeroSection";
import ServicesSection from "@/components/ServicesSection";
import BeforeAfterSection from "@/components/BeforeAfterSection";
import WhyUsSection from "@/components/WhyUsSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import ServiceAreasSection from "@/components/ServiceAreasSection";
import ContactSection from "@/components/ContactSection";
import FloatingCallButton from "@/components/FloatingCallButton";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen" style={{ backgroundColor: "var(--hf-navy)", color: "var(--hf-text)" }}>
      <StickyHeader />
      <HeroSection />
      <ServicesSection />
      <BeforeAfterSection />
      <WhyUsSection />
      <TestimonialsSection />
      <ServiceAreasSection />
      <ContactSection />
      <Footer />
      <FloatingCallButton />
    </div>
  );
}
