import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Droplets, Zap, Wrench, Flame, AlertTriangle, Bath, ChevronRight, Phone } from "lucide-react";

const services = [
  {
    icon: AlertTriangle,
    title: "Emergency Leak Repair",
    description:
      "Burst pipe or hidden leak? Our team responds in under 45 minutes, any time, day or night.",
    color: "var(--hf-red)",
  },
  {
    icon: Droplets,
    title: "Drain & Clog Clearing",
    description:
      "Slow drains or complete blockages cleared fast with hydro-jetting and professional snake tools.",
    color: "var(--hf-orange)",
  },
  {
    icon: Wrench,
    title: "Burst Pipe Repair",
    description:
      "Frozen or burst pipes can destroy your home. We stop damage immediately and restore flow.",
    color: "var(--hf-red)",
  },
  {
    icon: Flame,
    title: "Water Heater Service",
    description:
      "No hot water? We repair and replace all brands of water heaters — same-day installation available.",
    color: "var(--hf-orange)",
  },
  {
    icon: Zap,
    title: "Sewer Line Issues",
    description:
      "Sewer back-ups and line replacements handled with minimal disruption to your property.",
    color: "var(--hf-red)",
  },
  {
    icon: Bath,
    title: "Bathroom & Kitchen",
    description:
      "Faucets, toilets, garbage disposals, dishwasher hookups — all handled by certified plumbers.",
    color: "var(--hf-orange)",
  },
];

function ServiceCard({
  service,
  index,
}: {
  service: (typeof services)[0];
  index: number;
}) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  const Icon = service.icon;

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5, delay: index * 0.08 }}
      className="group relative flex flex-col gap-4 p-6 rounded-2xl cursor-pointer transition-all duration-300"
      style={{
        backgroundColor: "var(--hf-card)",
        border: "1px solid rgba(255,255,255,0.07)",
      }}
      whileHover={{
        scale: 1.02,
        backgroundColor: "#152540",
        borderColor: "rgba(230,57,70,0.3)",
        boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
      }}
    >
      {/* Accent bar */}
      <div
        className="absolute top-0 left-0 right-0 h-0.5 rounded-t-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        style={{ background: `linear-gradient(90deg, ${service.color}, transparent)` }}
      />

      <div
        className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{ backgroundColor: `${service.color}20`, border: `1px solid ${service.color}30` }}
      >
        <Icon size={22} style={{ color: service.color }} />
      </div>

      <div>
        <h3
          className="text-lg font-bold text-white mb-2"
          style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: "1.15rem", letterSpacing: "0.02em" }}
        >
          {service.title}
        </h3>
        <p className="text-sm leading-relaxed" style={{ color: "#8fa3c0" }}>
          {service.description}
        </p>
      </div>

      <a
        href="#contact"
        className="mt-auto flex items-center gap-1 text-sm font-semibold transition-colors duration-200"
        style={{ color: service.color }}
      >
        Get Help Now <ChevronRight size={14} />
      </a>
    </motion.div>
  );
}

export default function ServicesSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section
      id="services"
      className="py-20 sm:py-28"
      style={{ backgroundColor: "#080f1e" }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div ref={ref} className="text-center mb-14">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-4"
            style={{
              backgroundColor: "rgba(244,128,26,0.12)",
              border: "1px solid rgba(244,128,26,0.3)",
              color: "var(--hf-orange)",
            }}
          >
            Our Services
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.08 }}
            className="text-white mb-4"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: "clamp(2rem, 5vw, 3.5rem)",
              fontWeight: 800,
              letterSpacing: "0.01em",
            }}
          >
            Every Plumbing Problem.{" "}
            <span style={{ color: "var(--hf-orange)" }}>Solved Fast.</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.15 }}
            className="max-w-xl mx-auto text-base sm:text-lg"
            style={{ color: "#8fa3c0" }}
          >
            From minor drips to full pipe replacements — licensed plumbers ready to respond the moment you call.
          </motion.p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((service, i) => (
            <ServiceCard key={service.title} service={service} index={i} />
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mt-12 text-center"
        >
          <a
            href="tel:5552473911"
            className="inline-flex items-center gap-3 px-8 py-4 rounded-xl font-bold text-white text-lg transition-all duration-200 hover:scale-105 active:scale-95"
            style={{
              background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))",
              boxShadow: "0 8px 32px rgba(230,57,70,0.35)",
            }}
          >
            <Phone size={20} />
            Call for Emergency Service
          </a>
        </motion.div>
      </div>
    </section>
  );
}
