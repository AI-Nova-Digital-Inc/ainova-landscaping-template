import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Clock, Award, DollarSign, ThumbsUp, Phone } from "lucide-react";

const reasons = [
  {
    icon: Clock,
    stat: "45 Min",
    label: "Response Time",
    description:
      "Our nearest technician dispatches the moment you call. We guarantee on-site in 45 minutes for emergency jobs.",
    color: "var(--hf-red)",
  },
  {
    icon: Award,
    stat: "100%",
    label: "Certified Techs",
    description:
      "Every technician is state-licensed, background-checked, and carries $2M in liability insurance.",
    color: "var(--hf-orange)",
  },
  {
    icon: DollarSign,
    stat: "$0",
    label: "Hidden Fees",
    description:
      "Flat-rate transparent pricing — you approve the price before we lift a wrench. No surprise charges.",
    color: "var(--hf-green)",
  },
  {
    icon: ThumbsUp,
    stat: "100%",
    label: "Satisfaction Guaranteed",
    description:
      "If the job isn't right, we come back and fix it free of charge. No questions asked.",
    color: "var(--hf-red)",
  },
];

export default function WhyUsSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="why-us" className="py-20 sm:py-28" style={{ backgroundColor: "#080f1e" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={ref} className="text-center mb-14">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-4"
            style={{
              backgroundColor: "rgba(34,197,94,0.1)",
              border: "1px solid rgba(34,197,94,0.3)",
              color: "var(--hf-green)",
            }}
          >
            Why HydroForce
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.08 }}
            className="text-white mb-4"
            style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: "clamp(2rem, 5vw, 3.5rem)",
              fontWeight: 800,
            }}
          >
            The Plumber You Can Actually{" "}
            <span style={{ color: "var(--hf-orange)" }}>Trust</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.15 }}
            className="max-w-xl mx-auto text-base sm:text-lg"
            style={{ color: "#8fa3c0" }}
          >
            We built HydroForce on one principle: treat every home like our own. Here's what that means in practice.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {reasons.map((r, i) => {
            const Icon = r.icon;
            return (
              <motion.div
                key={r.label}
                initial={{ opacity: 0, y: 40 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="relative flex flex-col items-center text-center p-8 rounded-2xl"
                style={{
                  backgroundColor: "var(--hf-card)",
                  border: "1px solid rgba(255,255,255,0.07)",
                }}
                whileHover={{
                  scale: 1.03,
                  borderColor: `${r.color}40`,
                  boxShadow: `0 12px 40px rgba(0,0,0,0.4)`,
                }}
              >
                {/* Top accent */}
                <div
                  className="absolute top-0 left-0 right-0 h-1 rounded-t-2xl"
                  style={{ background: `linear-gradient(90deg, ${r.color}, transparent)` }}
                />

                {/* Icon */}
                <div
                  className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
                  style={{
                    backgroundColor: `${r.color}15`,
                    border: `1px solid ${r.color}30`,
                  }}
                >
                  <Icon size={28} style={{ color: r.color }} />
                </div>

                {/* Stat */}
                <div
                  className="text-5xl font-black mb-1"
                  style={{
                    fontFamily: "'Barlow Condensed', sans-serif",
                    color: r.color,
                    lineHeight: 1,
                  }}
                >
                  {r.stat}
                </div>

                <div className="text-sm font-bold uppercase tracking-wider text-white mb-3">
                  {r.label}
                </div>

                <p className="text-sm leading-relaxed" style={{ color: "#8fa3c0" }}>
                  {r.description}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.5 }}
          className="text-center mt-12"
        >
          <a
            href="tel:5552473911"
            className="inline-flex items-center gap-3 px-8 py-4 rounded-xl font-bold text-white text-lg transition-all duration-200 hover:scale-105"
            style={{
              background: "linear-gradient(135deg, var(--hf-red), var(--hf-orange))",
              boxShadow: "0 8px 32px rgba(230,57,70,0.35)",
            }}
          >
            <Phone size={20} />
            Experience the HydroForce Difference
          </a>
        </motion.div>
      </div>
    </section>
  );
}
