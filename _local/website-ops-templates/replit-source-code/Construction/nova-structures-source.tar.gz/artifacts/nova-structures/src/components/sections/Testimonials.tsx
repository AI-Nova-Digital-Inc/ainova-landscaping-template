import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

const testimonials = [
  {
    id: 1,
    quote: "Nova Structures didn't just build a house; they crafted a masterpiece that feels simultaneously monumental and intimately personal. Their attention to detail borders on the obsessive.",
    author: "Elena R.",
    project: "The Glass Pavilion"
  },
  {
    id: 2,
    quote: "Working with Nova was unlike any construction experience. The silence on site, the precision of the trades, the feeling that every millimeter was considered. The result is pure architectural poetry.",
    author: "Jonathan M.",
    project: "Villa Ascend"
  },
  {
    id: 3,
    quote: "They understand that true luxury lies in the unseen infrastructure just as much as the exquisite finishes. Our home is a fortress wrapped in cashmere.",
    author: "Sarah & David L.",
    project: "Horizon House"
  }
];

export function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="py-32 md:py-48 px-8 bg-[#0c0d10] text-white relative overflow-hidden flex items-center justify-center min-h-[70vh]">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[#c2a77d]/10 font-serif text-[20rem] md:text-[30rem] leading-none select-none pointer-events-none">
        "
      </div>
      
      <div className="max-w-4xl mx-auto w-full relative z-10 text-center">
        <span className="font-sans text-xs tracking-[0.2em] text-[#c2a77d] uppercase mb-16 block">04 — Perspectives</span>
        
        <div className="min-h-[250px] relative flex flex-col items-center justify-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className="absolute w-full"
            >
              <blockquote className="font-serif text-2xl md:text-4xl font-light italic leading-snug tracking-wide mb-12">
                "{testimonials[currentIndex].quote}"
              </blockquote>
              <div className="font-sans">
                <div className="text-sm font-medium tracking-widest uppercase mb-1">{testimonials[currentIndex].author}</div>
                <div className="text-xs text-white/50 tracking-widest uppercase">{testimonials[currentIndex].project}</div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="flex justify-center gap-3 mt-16">
          {testimonials.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`w-2 h-2 rounded-full transition-all duration-500 ${
                idx === currentIndex ? 'bg-[#c2a77d] w-6' : 'bg-white/20 hover:bg-white/50'
              }`}
              aria-label={`Go to testimonial ${idx + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
