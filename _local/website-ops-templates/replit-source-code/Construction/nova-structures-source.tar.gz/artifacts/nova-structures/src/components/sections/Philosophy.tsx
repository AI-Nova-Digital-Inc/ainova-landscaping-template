import { motion } from "framer-motion";

export function Philosophy() {
  return (
    <section id="philosophy" className="py-32 md:py-48 px-8 bg-background text-foreground relative overflow-hidden">
      <div className="max-w-4xl mx-auto relative">
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          className="absolute -top-20 -left-10 md:-left-20 text-foreground/5 font-serif text-[12rem] md:text-[20rem] leading-none pointer-events-none select-none"
        >
          01
        </motion.div>

        <div className="relative z-10 grid grid-cols-1 md:grid-cols-12 gap-12">
          <div className="md:col-span-5 flex flex-col justify-center">
            <motion.h2 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
              className="font-serif text-4xl md:text-6xl tracking-wide font-light leading-tight"
            >
              Built for <br/>
              <span className="italic text-accent">Permanence.</span>
            </motion.h2>
          </div>
          
          <div className="md:col-span-7 flex flex-col justify-center">
            <motion.div 
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
              className="w-full h-[1px] bg-border mb-8 origin-left"
            />
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1], delay: 0.4 }}
              className="font-sans font-light text-foreground/80 leading-relaxed text-lg"
            >
              We believe a home is a lifetime masterpiece, an intersection of architectural precision and sculptural artistry. Nova Structures builds for those who recognize that true luxury is unhurried, tactile, and uncompromising.
            </motion.p>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1], delay: 0.5 }}
              className="font-sans font-light text-foreground/80 leading-relaxed text-lg mt-6"
            >
              Every material sourced, every line drawn, and every finish applied is a testament to our dedication to legacy. We don't just construct residences; we craft the physical manifestation of our clients' most profound aspirations.
            </motion.p>
          </div>
        </div>
      </div>
    </section>
  );
}
