import { useState, useEffect } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Link } from "wouter";

export function Navbar() {
  const { scrollY } = useScroll();
  const backgroundColor = useTransform(
    scrollY,
    [0, 100],
    ["rgba(245, 243, 238, 0)", "rgba(245, 243, 238, 0.85)"]
  );
  const backdropFilter = useTransform(
    scrollY,
    [0, 100],
    ["blur(0px)", "blur(12px)"]
  );
  const textColor = useTransform(
    scrollY,
    [0, 100],
    ["rgba(245, 243, 238, 1)", "rgba(26, 28, 33, 1)"]
  );

  return (
    <motion.nav
      style={{ backgroundColor, backdropFilter }}
      className="fixed top-0 left-0 right-0 z-50 px-8 py-6 flex justify-between items-center transition-colors duration-500"
    >
      <motion.a
        href="#"
        onClick={(e) => {
          e.preventDefault();
          window.scrollTo({ top: 0, behavior: "smooth" });
        }}
        style={{ color: textColor }}
        className="font-serif text-xl tracking-[0.3em] font-medium"
      >
        NOVA STRUCTURES
      </motion.a>

      <motion.div style={{ color: textColor }} className="hidden md:flex gap-12 text-sm font-sans tracking-wide font-light">
        <a href="#philosophy" className="hover:opacity-60 transition-opacity">Philosophy</a>
        <a href="#portfolio" className="hover:opacity-60 transition-opacity">Portfolio</a>
        <a href="#materials" className="hover:opacity-60 transition-opacity">Materials</a>
        <a href="#contact" className="hover:opacity-60 transition-opacity">Contact</a>
      </motion.div>
    </motion.nav>
  );
}
