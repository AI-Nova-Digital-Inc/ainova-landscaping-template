export function Footer() {
  return (
    <footer className="bg-[#08090a] text-white/40 py-12 px-8 font-sans text-xs tracking-widest uppercase">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
        <div>
          &copy; {new Date().getFullYear()} NOVA STRUCTURES
        </div>
        <div className="flex gap-8">
          <a href="#" className="hover:text-white transition-colors">Instagram</a>
          <a href="#" className="hover:text-white transition-colors">LinkedIn</a>
          <a href="#" className="hover:text-white transition-colors">Privacy</a>
        </div>
      </div>
    </footer>
  );
}
