import { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const formSchema = z.object({
  name: z.string().min(2, "Name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().optional(),
  project: z.string().min(10, "Please provide some details about your project"),
});

export function Contact() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      project: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      toast({
        title: "Inquiry Received",
        description: "We will be in touch shortly to schedule a consultation.",
      });
      form.reset();
    }, 1500);
  }

  return (
    <section id="contact" className="py-32 md:py-48 px-8 bg-background text-foreground">
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-24">
        
        <div className="lg:col-span-5 flex flex-col">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          >
            <span className="font-sans text-xs tracking-[0.2em] text-accent uppercase mb-6 block">05 — Contact</span>
            <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl tracking-wide font-light leading-tight mb-6">
              Begin Your <br/> Project
            </h2>
            <p className="font-sans font-light text-foreground/80 leading-relaxed text-lg mb-16">
              Private consultations by appointment only. We accept a limited number of commissions per year to ensure uncompromising quality.
            </p>

            <div className="space-y-8 font-sans text-sm tracking-widest font-light text-foreground/70 uppercase">
              <div>
                <p className="mb-1 text-foreground/50">Office</p>
                <p>1440 Architectural Way</p>
                <p>Los Angeles, CA 90210</p>
              </div>
              <div>
                <p className="mb-1 text-foreground/50">Inquiries</p>
                <a href="mailto:hello@novastructures.com" className="hover:text-accent transition-colors">
                  hello@novastructures.com
                </a>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="lg:col-span-7">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
            className="bg-[rgba(255,255,255,0.08)] backdrop-blur-xl border border-white/20 p-8 md:p-12 shadow-sm"
          >
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input 
                            placeholder="FULL NAME" 
                            {...field} 
                            className="bg-transparent border-0 border-b border-border/50 rounded-none px-0 focus-visible:ring-0 focus-visible:border-foreground transition-colors placeholder:text-foreground/30 font-sans tracking-widest text-xs h-12"
                            data-testid="input-name"
                          />
                        </FormControl>
                        <FormMessage className="text-xs font-sans" />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input 
                            placeholder="EMAIL ADDRESS" 
                            type="email"
                            {...field} 
                            className="bg-transparent border-0 border-b border-border/50 rounded-none px-0 focus-visible:ring-0 focus-visible:border-foreground transition-colors placeholder:text-foreground/30 font-sans tracking-widest text-xs h-12"
                            data-testid="input-email"
                          />
                        </FormControl>
                        <FormMessage className="text-xs font-sans" />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Input 
                          placeholder="PHONE (OPTIONAL)" 
                          {...field} 
                          className="bg-transparent border-0 border-b border-border/50 rounded-none px-0 focus-visible:ring-0 focus-visible:border-foreground transition-colors placeholder:text-foreground/30 font-sans tracking-widest text-xs h-12"
                          data-testid="input-phone"
                        />
                      </FormControl>
                      <FormMessage className="text-xs font-sans" />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="project"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Textarea 
                          placeholder="PROJECT DESCRIPTION & LOCATION" 
                          {...field} 
                          className="bg-transparent border-0 border-b border-border/50 rounded-none px-0 focus-visible:ring-0 focus-visible:border-foreground transition-colors placeholder:text-foreground/30 font-sans tracking-widest text-xs min-h-[120px] resize-none"
                          data-testid="input-project"
                        />
                      </FormControl>
                      <FormMessage className="text-xs font-sans" />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full bg-foreground text-background hover:bg-foreground/90 rounded-none h-14 font-sans tracking-[0.2em] text-xs uppercase transition-colors"
                  data-testid="button-submit"
                >
                  {isSubmitting ? "Sending..." : "Submit Inquiry"}
                </Button>
              </form>
            </Form>
          </motion.div>
        </div>

      </div>
    </section>
  );
}
