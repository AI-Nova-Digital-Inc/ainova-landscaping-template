import { motion } from "framer-motion";

const projects = [
  {
    id: 1,
    title: "The Glass Pavilion",
    location: "Montecito, CA",
    year: "2023",
    image: "/images/portfolio-1.png",
  },
  {
    id: 2,
    title: "Villa Ascend",
    location: "Aspen, CO",
    year: "2024",
    image: "/images/portfolio-2.png",
  },
  {
    id: 3,
    title: "Horizon House",
    location: "Malibu, CA",
    year: "2022",
    image: "/images/portfolio-3.png",
  },
];

export function Portfolio() {
  return (
    <section id="portfolio" className="py-32 md:py-48 px-8 bg-[#121418] text-white">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          className="mb-24 flex flex-col items-center text-center"
        >
          <span className="font-sans text-xs tracking-[0.2em] text-[#c2a77d] uppercase mb-4">02 — Portfolio</span>
          <h2 className="font-serif text-4xl md:text-6xl tracking-wider font-light">Selected Works</h2>
        </motion.div>

        <div className="grid grid-cols-1 gap-16 md:gap-32">
          {projects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1], delay: index * 0.2 }}
              className={`relative group cursor-pointer ${index % 2 === 1 ? 'md:ml-auto md:w-3/4' : 'md:mr-auto md:w-3/4'}`}
            >
              <div className="overflow-hidden aspect-[16/9] relative bg-neutral-900">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-[2s] ease-[0.22,1,0.36,1] group-hover:scale-105 opacity-80 group-hover:opacity-100"
                />
                
                {/* Overlay that fades out on hover */}
                <div className="absolute inset-0 bg-black/40 transition-opacity duration-700 group-hover:opacity-0" />
              </div>
              
              <div className="absolute bottom-0 left-0 w-full p-8 translate-y-4 opacity-0 transition-all duration-700 ease-out group-hover:translate-y-0 group-hover:opacity-100 bg-gradient-to-t from-black/80 via-black/40 to-transparent">
                <h3 className="font-serif text-3xl font-light tracking-wide mb-2">{project.title}</h3>
                <div className="flex gap-4 font-sans text-xs tracking-widest text-white/70 uppercase">
                  <span>{project.location}</span>
                  <span>—</span>
                  <span>{project.year}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
