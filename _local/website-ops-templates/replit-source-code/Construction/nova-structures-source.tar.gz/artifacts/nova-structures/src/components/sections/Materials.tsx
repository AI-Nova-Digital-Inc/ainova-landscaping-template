import { motion } from "framer-motion";

export function Materials() {
  return (
    <section id="materials" className="py-32 md:py-48 px-8 bg-card text-foreground">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
        
        {/* Left Column - Text */}
        <div className="flex flex-col justify-center lg:sticky lg:top-48 h-fit">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          >
            <span className="font-sans text-xs tracking-[0.2em] text-accent uppercase mb-6 block">03 — Craftsmanship</span>
            <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl tracking-wide font-light leading-tight mb-8">
              Uncompromising <br/> Materials
            </h2>
            <p className="font-sans font-light text-foreground/80 leading-relaxed text-lg mb-6">
              The weight of a solid travertine door handle. The cool, unyielding touch of hand-finished architectural concrete. The subtle veining of deeply sourced marble.
            </p>
            <p className="font-sans font-light text-foreground/80 leading-relaxed text-lg">
              We source materials not merely for their aesthetic appeal, but for their structural integrity and their ability to age with grace. Our craft is tactile; every surface is designed to be felt as much as it is seen.
            </p>
          </motion.div>
        </div>

        {/* Right Column - Images */}
        <div className="flex flex-col gap-12 md:gap-24">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
            className="aspect-[4/3] overflow-hidden"
          >
            <img 
              src="/images/material-1.png" 
              alt="Premium marble veining" 
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-[2s] ease-out"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
            className="aspect-[4/3] overflow-hidden md:ml-12"
          >
            <img 
              src="/images/material-2.png" 
              alt="Warm lit travertine stone" 
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-[2s] ease-out"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
            className="aspect-[4/3] overflow-hidden"
          >
            <img 
              src="/images/material-3.png" 
              alt="Polished concrete texture" 
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-[2s] ease-out"
            />
          </motion.div>
        </div>

      </div>
    </section>
  );
}
