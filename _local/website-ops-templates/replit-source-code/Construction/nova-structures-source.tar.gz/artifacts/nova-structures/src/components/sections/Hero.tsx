import { motion } from "framer-motion";

export function Hero() {
  return (
    <section className="relative w-full h-screen overflow-hidden bg-[#0c0d10]">
      <div className="absolute inset-0 z-0">
        <div className="hero-architectural-bg" />
        <div className="hero-grid-overlay" />
        <div className="hero-vignette" />
      </div>

      <div className="absolute inset-0 z-0 overflow-hidden">
        <motion.div
          className="absolute bottom-0 left-[8%] w-[2px] bg-gradient-to-t from-[#c2a77d]/60 via-[#c2a77d]/20 to-transparent"
          initial={{ height: 0 }}
          animate={{ height: "70%" }}
          transition={{ duration: 2.5, ease: [0.22, 1, 0.36, 1], delay: 0.5 }}
        />
        <motion.div
          className="absolute bottom-0 left-[20%] w-[1px] bg-gradient-to-t from-white/20 via-white/05 to-transparent"
          initial={{ height: 0 }}
          animate={{ height: "45%" }}
          transition={{ duration: 2.2, ease: [0.22, 1, 0.36, 1], delay: 0.8 }}
        />
        <motion.div
          className="absolute bottom-0 right-[15%] w-[2px] bg-gradient-to-t from-[#8a7d66]/50 via-[#8a7d66]/15 to-transparent"
          initial={{ height: 0 }}
          animate={{ height: "60%" }}
          transition={{ duration: 2.8, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
        />
        <motion.div
          className="absolute bottom-0 right-[30%] w-[1px] bg-gradient-to-t from-white/10 to-transparent"
          initial={{ height: 0 }}
          animate={{ height: "35%" }}
          transition={{ duration: 2.0, ease: [0.22, 1, 0.36, 1], delay: 1.0 }}
        />

        <motion.div
          className="absolute bottom-[45%] left-[6%] h-[1px] bg-gradient-to-r from-transparent via-[#c2a77d]/30 to-transparent"
          initial={{ width: 0, opacity: 0 }}
          animate={{ width: "25%", opacity: 1 }}
          transition={{ duration: 2.0, ease: [0.22, 1, 0.36, 1], delay: 1.5 }}
        />
        <motion.div
          className="absolute bottom-[40%] right-[10%] h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent"
          initial={{ width: 0, opacity: 0 }}
          animate={{ width: "20%", opacity: 1 }}
          transition={{ duration: 2.0, ease: [0.22, 1, 0.36, 1], delay: 1.8 }}
        />

        <motion.div
          className="absolute bottom-0 left-[8%] w-[180px] h-[180px] border border-[#c2a77d]/15"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 2.0, ease: [0.22, 1, 0.36, 1], delay: 1.0 }}
        />
        <motion.div
          className="absolute bottom-[180px] left-[8%] w-[180px] h-[120px] border-t border-l border-[#c2a77d]/10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 2.0, ease: [0.22, 1, 0.36, 1], delay: 1.3 }}
        />

        <motion.div
          className="absolute bottom-0 right-[13%] w-[240px] h-[280px] border border-white/08"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 2.0, ease: [0.22, 1, 0.36, 1], delay: 0.8 }}
        />
        <motion.div
          className="absolute bottom-[280px] right-[13%] w-[240px] h-[100px] border-t border-r border-white/05"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 2.0, ease: [0.22, 1, 0.36, 1], delay: 1.1 }}
        />

        <motion.div
          className="absolute top-[20%] left-[55%] w-[60px] h-[60px] border border-[#c2a77d]/10 rotate-45"
          initial={{ opacity: 0, rotate: 0 }}
          animate={{ opacity: 1, rotate: 45 }}
          transition={{ duration: 2.0, ease: [0.22, 1, 0.36, 1], delay: 2.0 }}
        />

        <motion.div
          className="absolute inset-0 hero-glow-orb"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 3.0, delay: 0.5 }}
        />
      </div>

      <div className="absolute inset-0 z-10 flex flex-col items-center justify-center pointer-events-none text-white">
        <div className="text-center px-4">
          <motion.p
            initial={{ opacity: 0, letterSpacing: "0.5em" }}
            animate={{ opacity: 0.4, letterSpacing: "0.35em" }}
            transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1], delay: 0.1 }}
            className="font-sans text-[10px] uppercase text-white/40 mb-6 tracking-[0.35em]"
          >
            Est. 2008 — Los Angeles
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
            className="font-serif text-6xl md:text-9xl xl:text-[11rem] tracking-[0.35em] font-light mb-0 ml-[0.35em]"
            style={{ textShadow: "0 0 80px rgba(194,167,125,0.15)" }}
          >
            NOVA
          </motion.h1>

          <motion.h2
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1], delay: 0.55 }}
            className="font-serif text-3xl md:text-5xl xl:text-6xl tracking-[0.25em] font-light text-white/70 ml-[0.25em]"
          >
            STRUCTURES
          </motion.h2>

          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 1.8, ease: [0.22, 1, 0.36, 1], delay: 1.0 }}
            className="w-24 h-[1px] bg-[#c2a77d] mx-auto my-8 origin-center"
          />

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1], delay: 1.2 }}
            className="font-sans text-xs md:text-sm tracking-[0.25em] font-light text-white/50 uppercase"
          >
            Bespoke Luxury Residences
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1], delay: 1.6 }}
            className="mt-16 pointer-events-auto"
          >
            <a
              href="#portfolio"
              data-testid="link-view-work"
              className="inline-block border border-white/25 px-10 py-4 font-sans text-[10px] tracking-[0.2em] uppercase hover:bg-white hover:text-[#0c0d10] transition-colors duration-700"
            >
              View Our Work
            </a>
          </motion.div>
        </div>
      </div>

      <motion.div
        className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.4, delay: 2.2 }}
      >
        <span className="font-sans text-[9px] tracking-[0.25em] text-white/30 uppercase">Scroll</span>
        <motion.div
          className="w-[1px] h-10 bg-gradient-to-b from-white/30 to-transparent"
          animate={{ scaleY: [1, 0.3, 1], opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2.0, repeat: Infinity, ease: "easeInOut" }}
        />
      </motion.div>
    </section>
  );
}
