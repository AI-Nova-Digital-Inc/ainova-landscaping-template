import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Home, ChefHat, Bath, Square, Building2, Wrench, ArrowRight } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const SERVICES = [
  {
    icon: Home,
    title: "New Home Construction",
    desc: "Ground-up builds designed for your life. Fast, precise, built to code and beyond.",
    detail: "From foundation to finish — we own the entire process.",
  },
  {
    icon: ChefHat,
    title: "Kitchen Remodels",
    desc: "Transform the heart of your home in record time without sacrificing quality.",
    detail: "Cabinetry, plumbing, electrical — all under one crew.",
  },
  {
    icon: Bath,
    title: "Bathroom Renovations",
    desc: "Luxury finishes, smart layouts, waterproofing that lasts decades.",
    detail: "Most projects completed in under 2 weeks.",
  },
  {
    icon: Square,
    title: "Room Additions",
    desc: "More space, more value. We expand your home without expanding your headaches.",
    detail: "Permitted, engineered, and built to sell.",
  },
  {
    icon: Building2,
    title: "Commercial Buildouts",
    desc: "Retail, office, warehouse — we deliver tenant-ready spaces on deadline.",
    detail: "We work nights and weekends to hit your opening date.",
  },
  {
    icon: Wrench,
    title: "Emergency Repairs",
    desc: "24-hour response for structural, water, and storm damage emergencies.",
    detail: "Licensed, insured, and on-site fast.",
  },
];

export function Services() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (titleRef.current) {
        gsap.fromTo(titleRef.current,
          { x: -80, opacity: 0 },
          {
            x: 0, opacity: 1, duration: 0.8, ease: "power3.out",
            scrollTrigger: { trigger: titleRef.current, start: "top 85%" }
          }
        );
      }

      if (cardsRef.current) {
        const cards = cardsRef.current.querySelectorAll(".service-card");
        gsap.fromTo(cards,
          { y: 60, opacity: 0 },
          {
            y: 0, opacity: 1, stagger: 0.1, duration: 0.7, ease: "power3.out",
            scrollTrigger: { trigger: cardsRef.current, start: "top 80%" }
          }
        );
      }
    });

    return () => ctx.revert();
  }, []);

  return (
    <section id="services" ref={sectionRef} className="py-24 bg-background relative" data-testid="section-services">
      <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary/30" />

      <div className="container mx-auto max-w-7xl px-6 md:px-12">
        <div ref={titleRef} className="mb-16">
          <div className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-3" style={{ fontFamily: "'Oswald', sans-serif" }}>
            What We Build
          </div>
          <h2 className="text-5xl md:text-7xl font-black uppercase leading-none tracking-tighter mb-6" style={{ fontFamily: "'Oswald', sans-serif" }}>
            Our Services
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl">
            Full-spectrum residential and commercial construction. One call. One crew. No subcontracting headaches.
          </p>
        </div>

        <div ref={cardsRef} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border" data-testid="services-grid">
          {SERVICES.map((svc, i) => (
            <div
              key={i}
              className="service-card group bg-card p-8 flex flex-col gap-4 cursor-pointer hover:bg-primary transition-colors duration-200 relative overflow-hidden"
              data-testid={`card-service-${i}`}
            >
              <div className="absolute inset-0 bg-primary translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out" />
              <div className="relative z-10">
                <svc.icon
                  size={36}
                  className="text-primary group-hover:text-black transition-colors duration-200 mb-4"
                />
                <h3
                  className="text-2xl font-black uppercase tracking-tight group-hover:text-black transition-colors"
                  style={{ fontFamily: "'Oswald', sans-serif" }}
                >
                  {svc.title}
                </h3>
                <p className="text-muted-foreground group-hover:text-black/70 transition-colors text-sm mt-2 leading-relaxed">
                  {svc.desc}
                </p>
                <div className="mt-4 pt-4 border-t border-border group-hover:border-black/20 transition-colors flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground group-hover:text-black/60 transition-colors">
                    {svc.detail}
                  </span>
                  <ArrowRight
                    size={18}
                    className="text-primary group-hover:text-black transition-colors opacity-0 group-hover:opacity-100 translate-x-0 group-hover:translate-x-1 transition-all duration-200"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Mid-page CTA */}
        <div className="mt-16 flex flex-col sm:flex-row items-center justify-between gap-6 bg-primary p-8" data-testid="services-cta">
          <div>
            <div
              className="text-3xl font-black uppercase text-black leading-tight"
              style={{ fontFamily: "'Oswald', sans-serif" }}
            >
              Don't see your project? We handle it.
            </div>
            <p className="text-black/70 text-sm mt-1">Call us — we take on projects competitors won't touch.</p>
          </div>
          <button
            onClick={() => document.getElementById("quote")?.scrollIntoView({ behavior: "smooth" })}
            className="bg-black text-white font-black uppercase tracking-widest text-base px-8 py-4 flex items-center gap-2 hover:bg-white hover:text-black transition-colors duration-150 whitespace-nowrap"
            style={{ fontFamily: "'Oswald', sans-serif" }}
            data-testid="button-services-quote"
          >
            Claim Your Spot <ArrowRight size={18} />
          </button>
        </div>
      </div>
    </section>
  );
}
