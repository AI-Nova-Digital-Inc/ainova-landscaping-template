import { Hero } from "@/components/sections/Hero";
import { Services } from "@/components/sections/Services";
import { BeforeAfter } from "@/components/sections/BeforeAfter";
import { Testimonials } from "@/components/sections/Testimonials";
import { Pricing } from "@/components/sections/Pricing";
import { QuoteForm } from "@/components/sections/QuoteForm";

export default function Home() {
  return (
    <div className="flex flex-col w-full overflow-hidden">
      <Hero />
      <Services />
      <BeforeAfter />
      <Testimonials />
      <Pricing />
      <QuoteForm />
    </div>
  );
}
