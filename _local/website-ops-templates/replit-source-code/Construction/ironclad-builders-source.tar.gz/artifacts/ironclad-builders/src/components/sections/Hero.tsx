import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ArrowRight, Shield, Star, Clock } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

export function Hero() {
  const headlineRef = useRef<HTMLDivElement>(null);
  const subRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const counterRefs = useRef<(HTMLSpanElement | null)[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: "power4.out" } });

      if (headlineRef.current) {
        const words = headlineRef.current.querySelectorAll(".word");
        tl.fromTo(words,
          { y: 120, opacity: 0, skewY: 5 },
          { y: 0, opacity: 1, skewY: 0, stagger: 0.08, duration: 0.9 }
        );
      }

      if (subRef.current) {
        tl.fromTo(subRef.current,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7 },
          "-=0.4"
        );
      }

      if (ctaRef.current) {
        tl.fromTo(ctaRef.current,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6 },
          "-=0.3"
        );
      }

      if (statsRef.current) {
        const statCards = statsRef.current.querySelectorAll(".stat-card");
        tl.fromTo(statCards,
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.12, duration: 0.6 },
          "-=0.2"
        );

        ScrollTrigger.create({
          trigger: statsRef.current,
          start: "top 90%",
          once: true,
          onEnter: () => {
            counterRefs.current.forEach((el, i) => {
              if (!el) return;
              const targets = [500, 15, 5];
              const suffixes = ["+", "-Day", "-Star"];
              const obj = { val: 0 };
              gsap.to(obj, {
                val: targets[i],
                duration: 2,
                ease: "power2.out",
                onUpdate: () => {
                  el.textContent = Math.round(obj.val) + suffixes[i];
                }
              });
            });
          }
        });
      }

      if (bgRef.current) {
        gsap.to(bgRef.current.querySelectorAll(".grid-line-h"), {
          x: 30,
          duration: 4,
          repeat: -1,
          yoyo: true,
          ease: "none",
          stagger: 0.3
        });
        gsap.to(bgRef.current.querySelectorAll(".grid-line-v"), {
          y: 30,
          duration: 5,
          repeat: -1,
          yoyo: true,
          ease: "none",
          stagger: 0.4
        });
      }
    });

    return () => ctx.revert();
  }, []);

  const words = ["WE BUILD FAST.", "WE BUILD RIGHT.", "WE BUILD IRONCLAD."];

  return (
    <section
      className="relative min-h-screen flex flex-col justify-center overflow-hidden bg-background pt-24"
      data-testid="section-hero"
    >
      {/* Animated Grid Background */}
      <div ref={bgRef} className="absolute inset-0 overflow-hidden pointer-events-none opacity-10">
        {[...Array(10)].map((_, i) => (
          <div
            key={`h${i}`}
            className="grid-line-h absolute left-0 right-0 border-t border-primary"
            style={{ top: `${i * 11}%` }}
          />
        ))}
        {[...Array(10)].map((_, i) => (
          <div
            key={`v${i}`}
            className="grid-line-v absolute top-0 bottom-0 border-l border-primary"
            style={{ left: `${i * 11}%` }}
          />
        ))}
      </div>

      {/* Yellow accent bar */}
      <div className="absolute left-0 top-24 bottom-0 w-1 bg-primary" />

      <div className="relative z-10 container mx-auto max-w-7xl px-6 md:px-12 py-16">
        <div
          ref={headlineRef}
          className="overflow-hidden mb-6"
          data-testid="hero-headline"
        >
          {words.map((word, i) => (
            <div
              key={i}
              className="word block text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-black uppercase leading-[0.9] tracking-tighter"
              style={{ fontFamily: "'Oswald', sans-serif" }}
            >
              {i === 2 ? (
                <span className="text-primary">{word}</span>
              ) : (
                word
              )}
            </div>
          ))}
        </div>

        <p
          ref={subRef}
          className="text-lg md:text-2xl text-muted-foreground max-w-xl mb-10 font-medium leading-relaxed"
          data-testid="hero-subheadline"
        >
          Residential construction that delivers on time, on budget, and built to outlast everything else. No excuses. No delays.
        </p>

        <div ref={ctaRef} className="flex flex-col sm:flex-row gap-4 mb-16" data-testid="hero-cta">
          <button
            onClick={() => document.getElementById("quote")?.scrollIntoView({ behavior: "smooth" })}
            className="group relative bg-primary text-primary-foreground font-black uppercase tracking-widest text-lg px-10 py-5 flex items-center gap-3 shadow-[6px_6px_0_0_rgba(255,255,255,0.2)] hover:shadow-none hover:translate-x-1.5 hover:translate-y-1.5 transition-all duration-150"
            style={{ fontFamily: "'Oswald', sans-serif" }}
            data-testid="button-hero-quote"
          >
            Get Your Free Quote in 60 Seconds
            <ArrowRight size={22} className="group-hover:translate-x-1 transition-transform" />
          </button>
          <a
            href="tel:5554476625"
            className="border-2 border-white/30 text-white font-bold uppercase tracking-widest text-lg px-10 py-5 flex items-center gap-3 hover:border-primary hover:text-primary transition-colors duration-150"
            style={{ fontFamily: "'Oswald', sans-serif" }}
            data-testid="link-hero-phone"
          >
            Call Now: (555) 447-6625
          </a>
        </div>

        {/* Stats */}
        <div ref={statsRef} className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl" data-testid="hero-stats">
          {[
            { icon: Shield, label: "Projects Completed", color: "text-primary" },
            { icon: Clock, label: "Avg Turnaround", color: "text-primary" },
            { icon: Star, label: "Rated", color: "text-primary" },
          ].map((stat, i) => (
            <div
              key={i}
              className="stat-card bg-card border border-border p-6 flex flex-col gap-2"
              data-testid={`stat-card-${i}`}
            >
              <stat.icon size={24} className={stat.color} />
              <div
                className="text-4xl font-black text-white"
                style={{ fontFamily: "'Oswald', sans-serif" }}
              >
                <span ref={(el) => { counterRefs.current[i] = el; }}>0</span>
              </div>
              <div className="text-sm text-muted-foreground uppercase tracking-wide font-bold">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-muted-foreground animate-bounce">
        <div className="w-px h-12 bg-gradient-to-b from-primary to-transparent" />
        <span className="text-xs uppercase tracking-widest font-bold">Scroll</span>
      </div>
    </section>
  );
}
