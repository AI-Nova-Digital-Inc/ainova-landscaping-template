export function Footer() {
  return (
    <footer className="bg-black border-t border-white/10 py-12 px-6 text-center md:text-left">
      <div className="container mx-auto max-w-6xl grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <div className="text-3xl font-black font-display tracking-tight uppercase mb-4">
            IRONCLAD<span className="text-primary">.</span>BUILDERS
          </div>
          <p className="text-muted-foreground max-w-sm mx-auto md:mx-0">
            We build fast. We build right. No excuses. Professional residential and commercial construction services.
          </p>
        </div>
        
        <div>
          <h4 className="font-display font-bold uppercase text-lg mb-4 text-primary">Contact</h4>
          <p className="text-muted-foreground mb-2">📞 (555) 447-6625</p>
          <p className="text-muted-foreground mb-2">✉️ quotes@ironcladbuilders.com</p>
          <p className="text-muted-foreground">📍 100 Steel Way, Industrial District</p>
        </div>
        
        <div>
          <h4 className="font-display font-bold uppercase text-lg mb-4 text-primary">Licensing</h4>
          <p className="text-muted-foreground mb-2">Fully Licensed & Insured</p>
          <p className="text-muted-foreground mb-2">License #CGC1529983</p>
          <p className="text-muted-foreground">BBB A+ Rated</p>
        </div>
      </div>
      
      <div className="mt-12 pt-8 border-t border-white/10 text-center text-muted-foreground text-sm">
        &copy; {new Date().getFullYear()} IronClad Builders. All rights reserved.
      </div>
    </footer>
  );
}
