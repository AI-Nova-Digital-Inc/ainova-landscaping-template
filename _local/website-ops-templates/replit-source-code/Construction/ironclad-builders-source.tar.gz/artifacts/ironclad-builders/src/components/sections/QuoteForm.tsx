import { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Check, ArrowRight, Phone, Mail, User, Home, DollarSign, Calendar } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const STEP_1_SCHEMA = z.object({
  projectType: z.string().min(1, "Please select a project type"),
  projectSize: z.string().min(1, "Please select a project size"),
});

const STEP_2_SCHEMA = z.object({
  timeline: z.string().min(1, "Please select a timeline"),
  budget: z.string().min(1, "Please select a budget range"),
});

const STEP_3_SCHEMA = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  phone: z.string().min(10, "Enter a valid phone number"),
  email: z.string().email("Enter a valid email address"),
  address: z.string().min(5, "Enter your project address"),
});

type Step1Data = z.infer<typeof STEP_1_SCHEMA>;
type Step2Data = z.infer<typeof STEP_2_SCHEMA>;
type Step3Data = z.infer<typeof STEP_3_SCHEMA>;

const PROJECT_TYPES = [
  "New Home Construction", "Kitchen Remodel", "Bathroom Renovation",
  "Room Addition", "Commercial Buildout", "Emergency Repair", "Other"
];
const PROJECT_SIZES = ["Under 200 sqft", "200–500 sqft", "500–1,000 sqft", "1,000–2,500 sqft", "2,500+ sqft"];
const TIMELINES = ["ASAP (Emergency)", "Within 2 weeks", "Within a month", "1–3 months", "Flexible"];
const BUDGETS = ["Under $5,000", "$5,000–$15,000", "$15,000–$50,000", "$50,000–$150,000", "$150,000+"];

const STEPS = [
  { label: "Project Details", icon: Home },
  { label: "Timeline & Budget", icon: Calendar },
  { label: "Your Info", icon: User },
];

export function QuoteForm() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLDivElement>(null);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<Partial<Step1Data & Step2Data & Step3Data>>({});
  const [submitted, setSubmitted] = useState(false);

  const form1 = useForm<Step1Data>({ resolver: zodResolver(STEP_1_SCHEMA), defaultValues: { projectType: "", projectSize: "" } });
  const form2 = useForm<Step2Data>({ resolver: zodResolver(STEP_2_SCHEMA), defaultValues: { timeline: "", budget: "" } });
  const form3 = useForm<Step3Data>({ resolver: zodResolver(STEP_3_SCHEMA), defaultValues: { name: "", phone: "", email: "", address: "" } });

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (titleRef.current) {
        gsap.fromTo(titleRef.current,
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.8, ease: "power3.out", scrollTrigger: { trigger: titleRef.current, start: "top 85%" } }
        );
      }
      if (formRef.current) {
        gsap.fromTo(formRef.current,
          { y: 50, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.9, ease: "power3.out", scrollTrigger: { trigger: formRef.current, start: "top 80%" } }
        );
      }
    });
    return () => ctx.revert();
  }, []);

  const animateStep = () => {
    if (!formRef.current) return;
    gsap.fromTo(formRef.current.querySelector(".step-content"),
      { x: 40, opacity: 0 },
      { x: 0, opacity: 1, duration: 0.4, ease: "power3.out" }
    );
  };

  const onStep1Submit = (data: Step1Data) => {
    setFormData(prev => ({ ...prev, ...data }));
    setStep(2);
    setTimeout(animateStep, 10);
  };

  const onStep2Submit = (data: Step2Data) => {
    setFormData(prev => ({ ...prev, ...data }));
    setStep(3);
    setTimeout(animateStep, 10);
  };

  const onStep3Submit = (data: Step3Data) => {
    setFormData(prev => ({ ...prev, ...data }));
    setSubmitted(true);
  };

  const OptionButton = ({ value, selected, onClick, label }: { value: string; selected: boolean; onClick: () => void; label: string }) => (
    <button
      type="button"
      onClick={onClick}
      className={`text-left px-4 py-3 border text-sm font-bold uppercase tracking-wide transition-all duration-150 ${
        selected
          ? "bg-primary border-primary text-black"
          : "bg-card border-border text-muted-foreground hover:border-primary hover:text-white"
      }`}
      style={{ fontFamily: "'Oswald', sans-serif" }}
      data-testid={`option-${value.replace(/\s+/g, "-").toLowerCase()}`}
    >
      {selected && <Check size={12} className="inline mr-2" />}
      {label}
    </button>
  );

  return (
    <section id="quote" ref={sectionRef} className="py-24 bg-background relative" data-testid="section-quote-form">
      <div className="absolute right-0 top-0 bottom-0 w-1 bg-primary" />

      <div className="container mx-auto max-w-5xl px-6 md:px-12">
        <div ref={titleRef} className="mb-12 text-center">
          <div className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-3" style={{ fontFamily: "'Oswald', sans-serif" }}>
            No Obligation. No Pressure.
          </div>
          <h2 className="text-5xl md:text-7xl font-black uppercase leading-none tracking-tighter mb-4" style={{ fontFamily: "'Oswald', sans-serif" }}>
            Get Your Free Quote
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            60 seconds. No spam. Our project manager will call you within the hour.
          </p>
        </div>

        <div ref={formRef} className="bg-card border border-border p-8 md:p-12" data-testid="quote-form-container">
          {submitted ? (
            <div className="text-center py-12" data-testid="form-success">
              <div className="w-20 h-20 bg-primary mx-auto flex items-center justify-center mb-6">
                <Check size={40} className="text-black" />
              </div>
              <h3 className="text-4xl font-black uppercase text-white mb-3" style={{ fontFamily: "'Oswald', sans-serif" }}>
                You're In The Queue
              </h3>
              <p className="text-muted-foreground text-lg mb-2">
                We'll call you within <span className="text-primary font-bold">60 minutes</span>.
              </p>
              <p className="text-muted-foreground text-sm">
                Business hours: Mon–Sat 7am–7pm. Emergencies: 24/7.
              </p>
              <div className="mt-8 flex items-center justify-center gap-6">
                <a href="tel:5554476625" className="flex items-center gap-2 text-primary font-bold hover:text-white transition-colors" data-testid="link-success-phone">
                  <Phone size={18} /> (555) 447-6625
                </a>
                <a href="mailto:quotes@ironcladbuilders.com" className="flex items-center gap-2 text-primary font-bold hover:text-white transition-colors" data-testid="link-success-email">
                  <Mail size={18} /> Email Us
                </a>
              </div>
            </div>
          ) : (
            <>
              {/* Progress Bar */}
              <div className="mb-10" data-testid="form-progress">
                <div className="flex items-center justify-between mb-4">
                  {STEPS.map((s, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <div className={`w-8 h-8 flex items-center justify-center font-black text-sm transition-colors ${
                        i + 1 < step ? "bg-primary text-black" : i + 1 === step ? "bg-primary text-black" : "bg-card border border-border text-muted-foreground"
                      }`} style={{ fontFamily: "'Oswald', sans-serif" }}>
                        {i + 1 < step ? <Check size={14} /> : i + 1}
                      </div>
                      <span className={`text-xs font-bold uppercase tracking-wide hidden sm:block ${i + 1 <= step ? "text-primary" : "text-muted-foreground"}`} style={{ fontFamily: "'Oswald', sans-serif" }}>
                        {s.label}
                      </span>
                      {i < STEPS.length - 1 && (
                        <div className={`flex-1 h-px mx-4 min-w-[40px] transition-colors ${i + 1 < step ? "bg-primary" : "bg-border"}`} />
                      )}
                    </div>
                  ))}
                </div>
                <div className="h-1 bg-border relative overflow-hidden">
                  <div
                    className="absolute left-0 top-0 bottom-0 bg-primary transition-all duration-500"
                    style={{ width: `${((step - 1) / (STEPS.length - 1)) * 100}%` }}
                  />
                </div>
                <div className="text-right text-xs text-muted-foreground mt-2 font-bold uppercase tracking-widest">
                  Step {step} of {STEPS.length}
                </div>
              </div>

              {/* Step 1 */}
              {step === 1 && (
                <form onSubmit={form1.handleSubmit(onStep1Submit)} className="step-content">
                  <h3 className="text-2xl font-black uppercase mb-6 text-white" style={{ fontFamily: "'Oswald', sans-serif" }}>
                    What are we building?
                  </h3>
                  <div className="mb-6">
                    <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-3" style={{ fontFamily: "'Oswald', sans-serif" }}>
                      Project Type
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {PROJECT_TYPES.map(t => (
                        <OptionButton
                          key={t}
                          value={t}
                          label={t}
                          selected={form1.watch("projectType") === t}
                          onClick={() => form1.setValue("projectType", t, { shouldValidate: true })}
                        />
                      ))}
                    </div>
                    {form1.formState.errors.projectType && (
                      <p className="text-destructive text-sm mt-2">{form1.formState.errors.projectType.message}</p>
                    )}
                  </div>

                  <div className="mb-8">
                    <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-3" style={{ fontFamily: "'Oswald', sans-serif" }}>
                      Project Size
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {PROJECT_SIZES.map(s => (
                        <OptionButton
                          key={s}
                          value={s}
                          label={s}
                          selected={form1.watch("projectSize") === s}
                          onClick={() => form1.setValue("projectSize", s, { shouldValidate: true })}
                        />
                      ))}
                    </div>
                    {form1.formState.errors.projectSize && (
                      <p className="text-destructive text-sm mt-2">{form1.formState.errors.projectSize.message}</p>
                    )}
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-primary text-black font-black uppercase tracking-widest text-lg py-5 flex items-center justify-center gap-2 hover:bg-white transition-colors duration-150"
                    style={{ fontFamily: "'Oswald', sans-serif" }}
                    data-testid="button-step1-next"
                  >
                    Continue <ArrowRight size={20} />
                  </button>
                </form>
              )}

              {/* Step 2 */}
              {step === 2 && (
                <form onSubmit={form2.handleSubmit(onStep2Submit)} className="step-content">
                  <h3 className="text-2xl font-black uppercase mb-6 text-white" style={{ fontFamily: "'Oswald', sans-serif" }}>
                    Timeline & Budget
                  </h3>

                  <div className="mb-6">
                    <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-3" style={{ fontFamily: "'Oswald', sans-serif" }}>
                      <Calendar size={14} className="inline mr-1" /> When do you need this done?
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {TIMELINES.map(t => (
                        <OptionButton
                          key={t}
                          value={t}
                          label={t}
                          selected={form2.watch("timeline") === t}
                          onClick={() => form2.setValue("timeline", t, { shouldValidate: true })}
                        />
                      ))}
                    </div>
                    {form2.formState.errors.timeline && (
                      <p className="text-destructive text-sm mt-2">{form2.formState.errors.timeline.message}</p>
                    )}
                  </div>

                  <div className="mb-8">
                    <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-3" style={{ fontFamily: "'Oswald', sans-serif" }}>
                      <DollarSign size={14} className="inline mr-1" /> Budget Range
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {BUDGETS.map(b => (
                        <OptionButton
                          key={b}
                          value={b}
                          label={b}
                          selected={form2.watch("budget") === b}
                          onClick={() => form2.setValue("budget", b, { shouldValidate: true })}
                        />
                      ))}
                    </div>
                    {form2.formState.errors.budget && (
                      <p className="text-destructive text-sm mt-2">{form2.formState.errors.budget.message}</p>
                    )}
                  </div>

                  <div className="flex gap-4">
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="flex-1 border border-border text-muted-foreground font-black uppercase tracking-widest text-base py-4 hover:border-white hover:text-white transition-colors"
                      style={{ fontFamily: "'Oswald', sans-serif" }}
                      data-testid="button-step2-back"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      className="flex-1 bg-primary text-black font-black uppercase tracking-widest text-base py-4 flex items-center justify-center gap-2 hover:bg-white transition-colors duration-150"
                      style={{ fontFamily: "'Oswald', sans-serif" }}
                      data-testid="button-step2-next"
                    >
                      Continue <ArrowRight size={18} />
                    </button>
                  </div>
                </form>
              )}

              {/* Step 3 */}
              {step === 3 && (
                <form onSubmit={form3.handleSubmit(onStep3Submit)} className="step-content">
                  <h3 className="text-2xl font-black uppercase mb-6 text-white" style={{ fontFamily: "'Oswald', sans-serif" }}>
                    Where do we reach you?
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2" style={{ fontFamily: "'Oswald', sans-serif" }}>
                        <User size={12} className="inline mr-1" /> Full Name
                      </label>
                      <input
                        {...form3.register("name")}
                        placeholder="John Smith"
                        className="w-full bg-background border border-border text-white px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
                        data-testid="input-name"
                      />
                      {form3.formState.errors.name && (
                        <p className="text-destructive text-xs mt-1">{form3.formState.errors.name.message}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2" style={{ fontFamily: "'Oswald', sans-serif" }}>
                        <Phone size={12} className="inline mr-1" /> Phone Number
                      </label>
                      <input
                        {...form3.register("phone")}
                        placeholder="(555) 000-0000"
                        className="w-full bg-background border border-border text-white px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
                        data-testid="input-phone"
                      />
                      {form3.formState.errors.phone && (
                        <p className="text-destructive text-xs mt-1">{form3.formState.errors.phone.message}</p>
                      )}
                    </div>
                  </div>

                  <div className="mb-4">
                    <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2" style={{ fontFamily: "'Oswald', sans-serif" }}>
                      <Mail size={12} className="inline mr-1" /> Email Address
                    </label>
                    <input
                      {...form3.register("email")}
                      type="email"
                      placeholder="john@example.com"
                      className="w-full bg-background border border-border text-white px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
                      data-testid="input-email"
                    />
                    {form3.formState.errors.email && (
                      <p className="text-destructive text-xs mt-1">{form3.formState.errors.email.message}</p>
                    )}
                  </div>

                  <div className="mb-8">
                    <label className="block text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2" style={{ fontFamily: "'Oswald', sans-serif" }}>
                      <Home size={12} className="inline mr-1" /> Project Address
                    </label>
                    <input
                      {...form3.register("address")}
                      placeholder="123 Main St, Tampa, FL 33601"
                      className="w-full bg-background border border-border text-white px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
                      data-testid="input-address"
                    />
                    {form3.formState.errors.address && (
                      <p className="text-destructive text-xs mt-1">{form3.formState.errors.address.message}</p>
                    )}
                  </div>

                  <p className="text-muted-foreground text-xs mb-6">
                    By submitting, you agree to be contacted about your project. We never sell your information.
                  </p>

                  <div className="flex gap-4">
                    <button
                      type="button"
                      onClick={() => setStep(2)}
                      className="flex-1 border border-border text-muted-foreground font-black uppercase tracking-widest text-base py-4 hover:border-white hover:text-white transition-colors"
                      style={{ fontFamily: "'Oswald', sans-serif" }}
                      data-testid="button-step3-back"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      className="flex-1 bg-primary text-black font-black uppercase tracking-widest text-base py-4 flex items-center justify-center gap-2 hover:bg-white transition-colors duration-150"
                      style={{ fontFamily: "'Oswald', sans-serif" }}
                      data-testid="button-step3-submit"
                    >
                      Get My Free Quote <ArrowRight size={18} />
                    </button>
                  </div>
                </form>
              )}
            </>
          )}
        </div>

        {/* Trust line below form */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-6 text-xs text-muted-foreground" data-testid="form-trust-line">
          {["Licensed & Insured", "No Spam. Ever.", "We Call Within 60 Min", "Free — No Obligation"].map((t, i) => (
            <span key={i} className="flex items-center gap-1.5 font-bold uppercase tracking-wide">
              <Check size={12} className="text-primary" /> {t}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
