import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Check, ArrowRight, Shield, Award, Star, ThumbsUp } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const TIERS = [
  {
    name: "Essential",
    tagline: "Get it done, no frills",
    starting: "$4,500",
    features: [
      "Single-room scope",
      "Licensed & insured crew",
      "10-day average completion",
      "2-year labor warranty",
      "Progress photos daily",
    ],
    cta: "Lock In This Rate",
    highlight: false,
  },
  {
    name: "Pro Build",
    tagline: "Most popular — best value",
    starting: "$12,000",
    features: [
      "Multi-room or complex scope",
      "Dedicated project manager",
      "7-day average completion",
      "5-year labor warranty",
      "Real-time project dashboard",
      "Free design consultation included",
    ],
    cta: "Claim Your Pro Slot",
    highlight: true,
  },
  {
    name: "IronClad Elite",
    tagline: "Total hands-off experience",
    starting: "$28,000",
    features: [
      "Full home or commercial scope",
      "Senior foreman + dedicated PM",
      "Priority scheduling (next slot)",
      "Lifetime craftsmanship guarantee",
      "White-glove material sourcing",
      "Weekly executive reports",
      "Priority 24/7 support line",
    ],
    cta: "Reserve Elite Access",
    highlight: false,
  },
];

const TRUST_BADGES = [
  { icon: Shield, label: "Licensed & Insured" },
  { icon: Award, label: "BBB A+ Rated" },
  { icon: Star, label: "5-Star Google Rating" },
  { icon: ThumbsUp, label: "100% Satisfaction Guarantee" },
];

export function Pricing() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const badgesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (titleRef.current) {
        gsap.fromTo(titleRef.current,
          { y: 40, opacity: 0 },
          {
            y: 0, opacity: 1, duration: 0.8, ease: "power3.out",
            scrollTrigger: { trigger: titleRef.current, start: "top 85%" }
          }
        );
      }

      if (cardsRef.current) {
        const cards = cardsRef.current.querySelectorAll(".pricing-card");
        gsap.fromTo(cards,
          { y: 70, opacity: 0 },
          {
            y: 0, opacity: 1, stagger: 0.15, duration: 0.8, ease: "back.out(1.2)",
            scrollTrigger: { trigger: cardsRef.current, start: "top 80%" }
          }
        );

        cards.forEach((card) => {
          (card as HTMLElement).addEventListener("mouseenter", () => {
            gsap.to(card, { scale: 1.03, duration: 0.25, ease: "back.out(2)" });
          });
          (card as HTMLElement).addEventListener("mouseleave", () => {
            gsap.to(card, { scale: 1, duration: 0.25, ease: "power2.out" });
          });
        });
      }

      if (badgesRef.current) {
        const badges = badgesRef.current.querySelectorAll(".trust-badge");
        gsap.fromTo(badges,
          { y: 30, opacity: 0 },
          {
            y: 0, opacity: 1, stagger: 0.1, duration: 0.6, ease: "power3.out",
            scrollTrigger: { trigger: badgesRef.current, start: "top 90%" }
          }
        );
      }
    });

    return () => ctx.revert();
  }, []);

  return (
    <section id="pricing" ref={sectionRef} className="py-24 bg-background relative" data-testid="section-pricing">
      <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary/30" />

      <div className="container mx-auto max-w-7xl px-6 md:px-12">
        <div ref={titleRef} className="mb-16 text-center">
          <div className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-3" style={{ fontFamily: "'Oswald', sans-serif" }}>
            Transparent Pricing
          </div>
          <h2 className="text-5xl md:text-7xl font-black uppercase leading-none tracking-tighter mb-4" style={{ fontFamily: "'Oswald', sans-serif" }}>
            Choose Your Build
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            No hidden fees. No bait-and-switch. Final price agreed before a single nail is driven.
          </p>
          <div className="mt-6 inline-block bg-primary/10 border border-primary text-primary font-bold uppercase text-sm tracking-widest px-6 py-3" style={{ fontFamily: "'Oswald', sans-serif" }}>
            ⚡ Only 3 Build Slots Remaining This Month
          </div>
        </div>

        <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-3 gap-6" data-testid="pricing-grid">
          {TIERS.map((tier, i) => (
            <div
              key={i}
              className={`pricing-card relative flex flex-col p-8 border transition-all duration-200 ${
                tier.highlight
                  ? "bg-primary border-primary text-black"
                  : "bg-card border-border hover:border-primary"
              }`}
              data-testid={`card-pricing-${i}`}
            >
              {tier.highlight && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-black text-primary text-xs font-black uppercase tracking-widest px-4 py-1.5" style={{ fontFamily: "'Oswald', sans-serif" }}>
                  Most Popular
                </div>
              )}

              <div className="mb-6">
                <h3
                  className={`text-3xl font-black uppercase tracking-tight mb-1 ${tier.highlight ? "text-black" : "text-white"}`}
                  style={{ fontFamily: "'Oswald', sans-serif" }}
                >
                  {tier.name}
                </h3>
                <p className={`text-sm font-bold uppercase tracking-wide ${tier.highlight ? "text-black/60" : "text-muted-foreground"}`}>
                  {tier.tagline}
                </p>
              </div>

              <div className="mb-8">
                <span className={`text-sm font-bold uppercase ${tier.highlight ? "text-black/60" : "text-muted-foreground"}`}>Starting from</span>
                <div
                  className={`text-5xl font-black mt-1 ${tier.highlight ? "text-black" : "text-primary"}`}
                  style={{ fontFamily: "'Oswald', sans-serif" }}
                >
                  {tier.starting}
                </div>
              </div>

              <ul className="flex flex-col gap-3 mb-8 flex-1">
                {tier.features.map((f, j) => (
                  <li key={j} className="flex items-start gap-3">
                    <Check
                      size={16}
                      className={`mt-0.5 flex-shrink-0 ${tier.highlight ? "text-black" : "text-primary"}`}
                    />
                    <span className={`text-sm ${tier.highlight ? "text-black/80" : "text-muted-foreground"}`}>{f}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => document.getElementById("quote")?.scrollIntoView({ behavior: "smooth" })}
                className={`w-full font-black uppercase tracking-widest text-base py-4 flex items-center justify-center gap-2 transition-colors duration-150 ${
                  tier.highlight
                    ? "bg-black text-white hover:bg-white hover:text-black"
                    : "bg-primary text-black hover:bg-white hover:text-black"
                }`}
                style={{ fontFamily: "'Oswald', sans-serif" }}
                data-testid={`button-pricing-${i}`}
              >
                {tier.cta} <ArrowRight size={18} />
              </button>
            </div>
          ))}
        </div>

        {/* Urgency CTA */}
        <div className="mt-16 bg-primary p-10 text-center" data-testid="pricing-urgency">
          <h3
            className="text-4xl md:text-5xl font-black uppercase text-black mb-3"
            style={{ fontFamily: "'Oswald', sans-serif" }}
          >
            Book Your Free Consultation
          </h3>
          <p className="text-black/70 text-lg font-bold mb-2 uppercase tracking-wide">
            Only 3 Slots Left This Month
          </p>
          <p className="text-black/60 text-sm mb-8 max-w-lg mx-auto">
            We cap our monthly intake to guarantee quality. Once slots fill, you wait. Don't wait.
          </p>
          <button
            onClick={() => document.getElementById("quote")?.scrollIntoView({ behavior: "smooth" })}
            className="bg-black text-white font-black uppercase tracking-widest text-lg px-12 py-5 hover:bg-white hover:text-black transition-colors duration-150"
            style={{ fontFamily: "'Oswald', sans-serif" }}
            data-testid="button-pricing-main-cta"
          >
            Lock In Your Rate Now
          </button>
        </div>

        {/* Trust Badges */}
        <div ref={badgesRef} className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4" data-testid="trust-badges">
          {TRUST_BADGES.map((badge, i) => (
            <div key={i} className="trust-badge flex flex-col items-center gap-3 bg-card border border-border p-6 text-center" data-testid={`badge-trust-${i}`}>
              <badge.icon size={28} className="text-primary" />
              <span className="text-sm font-black uppercase tracking-wide text-white" style={{ fontFamily: "'Oswald', sans-serif" }}>
                {badge.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
