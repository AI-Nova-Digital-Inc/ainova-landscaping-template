import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ArrowRight } from "lucide-react";

export function FloatingCTA() {
  const btnRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!btnRef.current) return;
    
    gsap.to(btnRef.current, {
      scale: 1.05,
      boxShadow: "0 0 20px rgba(250, 204, 21, 0.6)",
      duration: 1.5,
      repeat: -1,
      yoyo: true,
      ease: "power1.inOut"
    });
  }, []);

  return (
    <button
      ref={btnRef}
      onClick={() => document.getElementById('quote')?.scrollIntoView({ behavior: 'smooth' })}
      className="fixed bottom-6 right-6 z-50 bg-primary text-primary-foreground font-display font-bold uppercase tracking-wider px-6 py-4 flex items-center gap-2 shadow-lg hover:bg-white transition-colors"
    >
      Get Free Quote <ArrowRight size={20} />
    </button>
  );
}
