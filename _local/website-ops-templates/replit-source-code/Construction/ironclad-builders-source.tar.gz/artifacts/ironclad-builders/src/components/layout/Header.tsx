import { Button } from "@/components/ui/button";
import { Phone } from "lucide-react";

export function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 w-full flex flex-col">
      {/* Urgency Banner */}
      <div className="bg-primary text-primary-foreground font-bold py-2 px-4 text-center text-sm md:text-base flex items-center justify-center gap-2 font-display uppercase tracking-wide">
        <span>⚡ LIMITED TIME: Free Design Consultation — Only 5 Spots Remaining This Month</span>
      </div>
      
      {/* Main Header */}
      <div className="bg-background/95 backdrop-blur-md border-b border-white/10 py-4 px-6 md:px-12 flex justify-between items-center transition-all duration-300">
        <div className="text-2xl md:text-3xl font-black font-display tracking-tight uppercase">
          IRONCLAD<span className="text-primary">.</span>BUILDERS
        </div>
        
        <div className="hidden md:flex items-center gap-8 font-bold font-display uppercase tracking-wider text-sm">
          <a href="#services" className="hover:text-primary transition-colors">Services</a>
          <a href="#projects" className="hover:text-primary transition-colors">Projects</a>
          <a href="#testimonials" className="hover:text-primary transition-colors">Reviews</a>
          <a href="#pricing" className="hover:text-primary transition-colors">Pricing</a>
        </div>
        
        <div className="flex items-center gap-4">
          <a href="tel:5554476625" className="hidden lg:flex items-center gap-2 font-bold hover:text-primary transition-colors">
            <Phone size={18} className="text-primary" />
            (555) 447-6625
          </a>
          <Button 
            className="font-display uppercase tracking-wide font-bold text-base h-12 px-6 shadow-[4px_4px_0_0_#fff] hover:shadow-none hover:translate-y-1 hover:translate-x-1 transition-all"
            onClick={() => document.getElementById('quote')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Get Quote
          </Button>
        </div>
      </div>
    </header>
  );
}
