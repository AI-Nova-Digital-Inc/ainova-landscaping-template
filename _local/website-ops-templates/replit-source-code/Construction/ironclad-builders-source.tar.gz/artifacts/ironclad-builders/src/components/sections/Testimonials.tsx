import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Star, Play, Quote } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const TESTIMONIALS = [
  {
    name: "Marcus D.",
    location: "Tampa, FL",
    quote: "IronClad finished our kitchen remodel in 11 days. ELEVEN. I had three other contractors tell me it would take 6 weeks minimum. The work is flawless. These guys are machines.",
    project: "Kitchen Remodel",
    rating: 5,
    initials: "MD",
  },
  {
    name: "Sandra & Tom K.",
    location: "Orlando, FL",
    quote: "We've used three builders over the years. IronClad is in a different league. On-site every day, zero mess left behind, and they actually finished two days early.",
    project: "Home Addition",
    rating: 5,
    initials: "SK",
  },
  {
    name: "Javier R.",
    location: "Miami, FL",
    quote: "Called them on a Tuesday after storm damage. They were on-site Wednesday morning, fully permitted and repaired by Friday. I literally cannot believe how fast they operate.",
    project: "Emergency Repair",
    rating: 5,
    initials: "JR",
  },
  {
    name: "Priya M.",
    location: "Fort Lauderdale, FL",
    quote: "The master bath renovation exceeded every expectation. The tile work alone looks like it came from a five-star hotel. IronClad doesn't build average — they refuse to.",
    project: "Bathroom Renovation",
    rating: 5,
    initials: "PM",
  },
];

export function Testimonials() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (titleRef.current) {
        gsap.fromTo(titleRef.current,
          { y: 40, opacity: 0 },
          {
            y: 0, opacity: 1, duration: 0.8, ease: "power3.out",
            scrollTrigger: { trigger: titleRef.current, start: "top 85%" }
          }
        );
      }

      if (cardsRef.current) {
        const cards = cardsRef.current.querySelectorAll(".testimonial-card");
        gsap.fromTo(cards,
          { y: 60, opacity: 0, scale: 0.96 },
          {
            y: 0, opacity: 1, scale: 1, stagger: 0.15, duration: 0.7, ease: "power3.out",
            scrollTrigger: { trigger: cardsRef.current, start: "top 80%" }
          }
        );
      }
    });

    return () => ctx.revert();
  }, []);

  return (
    <section id="testimonials" ref={sectionRef} className="py-24 bg-card relative" data-testid="section-testimonials">
      <div className="absolute right-0 top-0 bottom-0 w-1 bg-primary/30" />

      <div className="container mx-auto max-w-7xl px-6 md:px-12">
        <div ref={titleRef} className="mb-16 text-center">
          <div className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-3" style={{ fontFamily: "'Oswald', sans-serif" }}>
            Real Clients. Real Results.
          </div>
          <h2 className="text-5xl md:text-7xl font-black uppercase leading-none tracking-tighter mb-6" style={{ fontFamily: "'Oswald', sans-serif" }}>
            What They're Saying
          </h2>
          <div className="flex items-center justify-center gap-1 mt-4">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={24} className="fill-primary text-primary" />
            ))}
            <span className="ml-3 text-muted-foreground font-bold">4.9 / 5 across 200+ reviews</span>
          </div>
        </div>

        <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-2 gap-6" data-testid="testimonials-grid">
          {TESTIMONIALS.map((t, i) => (
            <div
              key={i}
              className="testimonial-card group bg-background border border-border p-0 overflow-hidden hover:border-primary transition-colors duration-200"
              data-testid={`card-testimonial-${i}`}
            >
              {/* Video thumbnail treatment */}
              <div className="relative bg-gradient-to-br from-zinc-900 to-zinc-800 h-40 flex items-center justify-center overflow-hidden">
                {/* Abstract construction background */}
                <div
                  className="absolute inset-0 opacity-20"
                  style={{
                    backgroundImage: `repeating-linear-gradient(
                      45deg,
                      transparent,
                      transparent 20px,
                      rgba(250,204,21,0.3) 20px,
                      rgba(250,204,21,0.3) 21px
                    )`
                  }}
                />
                {/* Avatar */}
                <div className="relative z-10 flex flex-col items-center gap-3">
                  <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center text-black font-black text-xl" style={{ fontFamily: "'Oswald', sans-serif" }}>
                    {t.initials}
                  </div>
                  <div className="w-10 h-10 rounded-full bg-white/10 border-2 border-white/40 flex items-center justify-center group-hover:bg-primary group-hover:border-primary transition-colors duration-200">
                    <Play size={14} className="fill-white text-white ml-0.5 group-hover:fill-black group-hover:text-black transition-colors" />
                  </div>
                </div>
                {/* Project badge */}
                <div className="absolute top-3 right-3 bg-primary text-black text-xs font-black uppercase tracking-widest px-2 py-1" style={{ fontFamily: "'Oswald', sans-serif" }}>
                  {t.project}
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="flex items-center gap-1 mb-3">
                  {[...Array(t.rating)].map((_, j) => (
                    <Star key={j} size={14} className="fill-primary text-primary" />
                  ))}
                </div>
                <Quote size={20} className="text-primary mb-2" />
                <p className="text-white leading-relaxed text-sm mb-4 italic">
                  "{t.quote}"
                </p>
                <div className="flex items-center justify-between border-t border-border pt-4">
                  <div>
                    <div className="font-black text-white uppercase tracking-wide" style={{ fontFamily: "'Oswald', sans-serif" }}>
                      {t.name}
                    </div>
                    <div className="text-muted-foreground text-xs mt-0.5">{t.location}</div>
                  </div>
                  <div className="text-primary text-xs font-bold uppercase tracking-widest">Verified Client</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Mid-page CTA */}
        <div className="mt-16 text-center" data-testid="testimonials-cta">
          <p className="text-muted-foreground mb-6 text-lg">Join 500+ homeowners who chose IronClad — and never looked back.</p>
          <button
            onClick={() => document.getElementById("quote")?.scrollIntoView({ behavior: "smooth" })}
            className="bg-primary text-black font-black uppercase tracking-widest text-lg px-10 py-5 hover:bg-white transition-colors duration-150"
            style={{ fontFamily: "'Oswald', sans-serif" }}
            data-testid="button-testimonials-quote"
          >
            Start Your Project Today
          </button>
        </div>
      </div>
    </section>
  );
}
