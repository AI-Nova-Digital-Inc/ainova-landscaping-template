import { useEffect, useRef, useState, useCallback } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ArrowRight } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const PROJECTS = [
  {
    label: "Kitchen Overhaul — Tampa, FL",
    beforeLabel: "BEFORE",
    afterLabel: "AFTER",
    beforeGradient: "linear-gradient(135deg, #1a1a1a 0%, #2a2a2a 50%, #1c1c1c 100%)",
    afterGradient: "linear-gradient(135deg, #78350f 0%, #d97706 40%, #f59e0b 70%, #fbbf24 100%)",
    beforeText: "Outdated 1990s layout, damaged cabinets",
    afterText: "Modern open kitchen, custom cabinetry — 9 days",
  },
  {
    label: "Master Bath — Orlando, FL",
    beforeLabel: "BEFORE",
    afterLabel: "AFTER",
    beforeGradient: "linear-gradient(135deg, #111111 0%, #222222 50%, #1a1a1a 100%)",
    afterGradient: "linear-gradient(135deg, #1e3a5f 0%, #2563eb 40%, #3b82f6 70%, #60a5fa 100%)",
    beforeText: "Builder-grade finishes, water damage",
    afterText: "Spa-level renovation, zero callbacks — 11 days",
  },
  {
    label: "Garage Conversion — Miami, FL",
    beforeLabel: "BEFORE",
    afterLabel: "AFTER",
    beforeGradient: "linear-gradient(135deg, #0f0f0f 0%, #1f1f1f 50%, #151515 100%)",
    afterGradient: "linear-gradient(135deg, #14532d 0%, #16a34a 40%, #22c55e 70%, #4ade80 100%)",
    beforeText: "Unused garage, concrete floor",
    afterText: "Fully permitted 400sqft guest suite — 14 days",
  },
];

function BeforeAfterSlider({ project }: { project: typeof PROJECTS[0] }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sliderRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState(50);
  const isDragging = useRef(false);

  const updatePosition = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
    setPosition((x / rect.width) * 100);
  }, []);

  const onMouseDown = useCallback(() => { isDragging.current = true; }, []);
  const onMouseMove = useCallback((e: MouseEvent) => {
    if (isDragging.current) updatePosition(e.clientX);
  }, [updatePosition]);
  const onMouseUp = useCallback(() => { isDragging.current = false; }, []);

  const onTouchMove = useCallback((e: TouchEvent) => {
    updatePosition(e.touches[0].clientX);
  }, [updatePosition]);

  useEffect(() => {
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
    };
  }, [onMouseMove, onMouseUp]);

  return (
    <div className="flex flex-col gap-0">
      <div
        ref={containerRef}
        className="relative h-72 md:h-96 overflow-hidden cursor-col-resize select-none"
        data-testid="before-after-slider"
      >
        {/* BEFORE (full width, underneath) */}
        <div
          className="absolute inset-0 flex items-end p-4"
          style={{ background: project.beforeGradient }}
        >
          <div className="text-white/60 text-xs font-bold uppercase tracking-widest">{project.beforeText}</div>
          <div
            className="absolute top-4 left-4 text-white font-black text-xs uppercase tracking-[0.25em] bg-black/60 px-2 py-1"
            style={{ fontFamily: "'Oswald', sans-serif" }}
          >
            {project.beforeLabel}
          </div>
        </div>

        {/* AFTER (clipped) */}
        <div
          className="absolute inset-0 flex items-end p-4"
          style={{
            background: project.afterGradient,
            clipPath: `inset(0 ${100 - position}% 0 0)`,
          }}
        >
          <div className="text-white/80 text-xs font-bold uppercase tracking-widest">{project.afterText}</div>
          <div
            className="absolute top-4 right-4 text-black font-black text-xs uppercase tracking-[0.25em] bg-primary px-2 py-1"
            style={{ fontFamily: "'Oswald', sans-serif" }}
          >
            {project.afterLabel}
          </div>
        </div>

        {/* Divider handle */}
        <div
          ref={sliderRef}
          className="absolute top-0 bottom-0 w-1 bg-primary z-10 cursor-col-resize"
          style={{ left: `calc(${position}% - 2px)` }}
          onMouseDown={onMouseDown}
          onTouchMove={(e) => onTouchMove(e.nativeEvent)}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 bg-primary flex items-center justify-center shadow-lg">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M6 10H14M6 10L3 7M6 10L3 13M14 10L17 7M14 10L17 13" stroke="black" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
        </div>
      </div>

      <div className="bg-card border border-border border-t-0 px-6 py-4">
        <div
          className="font-black uppercase tracking-wide text-white text-sm"
          style={{ fontFamily: "'Oswald', sans-serif" }}
        >
          {project.label}
        </div>
      </div>
    </div>
  );
}

export function BeforeAfter() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (titleRef.current) {
        gsap.fromTo(titleRef.current,
          { x: -80, opacity: 0 },
          {
            x: 0, opacity: 1, duration: 0.8, ease: "power3.out",
            scrollTrigger: { trigger: titleRef.current, start: "top 85%" }
          }
        );
      }

      const sliders = sectionRef.current?.querySelectorAll(".slider-wrapper");
      if (sliders) {
        gsap.fromTo(sliders,
          { y: 60, opacity: 0 },
          {
            y: 0, opacity: 1, stagger: 0.15, duration: 0.8, ease: "power3.out",
            scrollTrigger: { trigger: sectionRef.current, start: "top 75%" }
          }
        );
      }
    });

    return () => ctx.revert();
  }, []);

  return (
    <section id="projects" ref={sectionRef} className="py-24 bg-card relative" data-testid="section-before-after">
      <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary/30" />

      <div className="container mx-auto max-w-7xl px-6 md:px-12">
        <div ref={titleRef} className="mb-16">
          <div className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-3" style={{ fontFamily: "'Oswald', sans-serif" }}>
            The Proof Is In The Project
          </div>
          <h2 className="text-5xl md:text-7xl font-black uppercase leading-none tracking-tighter mb-6" style={{ fontFamily: "'Oswald', sans-serif" }}>
            Drag to See
            <span className="text-primary"> The Difference</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl">
            Drag the slider left and right to see the transformation. Every project. Same crew. Every time.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" data-testid="before-after-grid">
          {PROJECTS.map((project, i) => (
            <div key={i} className="slider-wrapper" data-testid={`slider-project-${i}`}>
              <BeforeAfterSlider project={project} />
            </div>
          ))}
        </div>

        <div className="mt-16 flex flex-col sm:flex-row items-center justify-between gap-6 border border-primary p-8" data-testid="before-after-cta">
          <div>
            <div className="text-3xl font-black uppercase text-white leading-tight" style={{ fontFamily: "'Oswald', sans-serif" }}>
              Your home could be next.
            </div>
            <p className="text-muted-foreground text-sm mt-1">Priority booking available for this month only.</p>
          </div>
          <button
            onClick={() => document.getElementById("quote")?.scrollIntoView({ behavior: "smooth" })}
            className="bg-primary text-black font-black uppercase tracking-widest text-base px-8 py-4 flex items-center gap-2 hover:bg-white transition-colors duration-150 whitespace-nowrap"
            style={{ fontFamily: "'Oswald', sans-serif" }}
            data-testid="button-beforeafter-quote"
          >
            Get My Free Quote <ArrowRight size={18} />
          </button>
        </div>
      </div>
    </section>
  );
}
