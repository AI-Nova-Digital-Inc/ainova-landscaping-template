import { ArrowDown } from "lucide-react";
import { motion } from "framer-motion";
import SmartCityScene from "./SmartCityScene";

export default function HeroSection() {
  return (
    <section className="relative h-screen w-full overflow-hidden bg-[#040a15] flex items-center justify-center">
      <div className="absolute inset-0 z-0">
        <SmartCityScene />
      </div>

      <div className="relative z-10 container mx-auto px-4 md:px-6 flex flex-col items-center text-center pointer-events-none">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="mb-6 inline-flex items-center rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary backdrop-blur-md"
        >
          <span className="flex h-2 w-2 rounded-full bg-primary mr-2 animate-pulse" />
          SMART CITY SOLUTIONS
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
          className="max-w-4xl font-display text-5xl md:text-7xl font-bold tracking-tight text-white mb-6 leading-tight"
        >
          Building Tomorrow's <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent neon-text">Cities, Today.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut", delay: 0.4 }}
          className="max-w-2xl text-lg md:text-xl text-muted-foreground mb-10"
        >
          UrbanEdge Developments creates intelligent urban ecosystems that harmonize human experience with cutting-edge technology.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut", delay: 0.6 }}
          className="flex flex-col sm:flex-row gap-4 pointer-events-auto"
        >
          <button
            onClick={() => document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" })}
            className="px-8 py-3.5 rounded-sm bg-primary text-primary-foreground font-semibold hover:bg-primary/90 neon-border transition-all duration-300"
            data-testid="hero-cta-projects"
          >
            Explore Projects
          </button>
          <button
            onClick={() => document.getElementById("vision")?.scrollIntoView({ behavior: "smooth" })}
            className="px-8 py-3.5 rounded-sm bg-transparent text-white border border-white/20 font-semibold hover:bg-white/5 transition-all duration-300"
            data-testid="hero-cta-vision"
          >
            Our Vision
          </button>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/50 animate-bounce pointer-events-auto cursor-pointer"
        onClick={() => document.getElementById("vision")?.scrollIntoView({ behavior: "smooth" })}
      >
        <ArrowDown size={24} />
      </motion.div>
      
      {/* Gradient overlay at bottom to blend into next section */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent z-0" />
    </section>
  );
}
