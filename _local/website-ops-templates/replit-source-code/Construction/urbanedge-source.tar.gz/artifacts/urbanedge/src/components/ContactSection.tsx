import { motion } from "framer-motion";
import { Mail, MapPin, Phone } from "lucide-react";
import { useForm } from "react-hook-form";
import { useToast } from "@/hooks/use-toast";

export default function ContactSection() {
  const { toast } = useToast();
  const { register, handleSubmit, reset } = useForm();

  const onSubmit = (data: any) => {
    console.log(data);
    toast({
      title: "Transmission Received",
      description: "Our intelligence network has logged your request. We will initiate contact shortly.",
    });
    reset();
  };

  return (
    <section className="py-24 md:py-32 bg-background relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-10 pointer-events-none"></div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          
          {/* Left Column */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
              Start Your <span className="text-primary">Smart City</span> Project
            </h2>
            <p className="text-lg text-muted-foreground mb-12 max-w-md leading-relaxed">
              Connect with our engineering teams to discuss digital twin implementation, intelligent infrastructure, and next-generation urban developments.
            </p>

            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-sm bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                  <Mail className="text-primary" size={20} />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-1">Global Communications</h4>
                  <a href="mailto:hello@urbanedge.dev" className="text-muted-foreground hover:text-primary transition-colors text-lg">hello@urbanedge.dev</a>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-sm bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                  <Phone className="text-primary" size={20} />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-1">Direct Line</h4>
                  <a href="tel:+442079460958" className="text-muted-foreground hover:text-primary transition-colors text-lg">+44 20 7946 0958</a>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-sm bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                  <MapPin className="text-primary" size={20} />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-1">Command Center</h4>
                  <p className="text-muted-foreground text-lg">100 Cyber Core Avenue<br/>London, E1 4NX<br/>United Kingdom</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="glass-card p-8 md:p-10 rounded-xl relative"
          >
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-accent rounded-t-xl opacity-50"></div>
            
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-mono text-muted-foreground uppercase">Name</label>
                  <input 
                    {...register("name", { required: true })}
                    className="w-full bg-black/50 border border-border rounded-sm px-4 py-3 text-white focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/50 transition-all placeholder:text-gray-600"
                    placeholder="Enter your name"
                    data-testid="input-name"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-mono text-muted-foreground uppercase">Company</label>
                  <input 
                    {...register("company", { required: true })}
                    className="w-full bg-black/50 border border-border rounded-sm px-4 py-3 text-white focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/50 transition-all placeholder:text-gray-600"
                    placeholder="Organization name"
                    data-testid="input-company"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-mono text-muted-foreground uppercase">Location</label>
                  <input 
                    {...register("location", { required: true })}
                    className="w-full bg-black/50 border border-border rounded-sm px-4 py-3 text-white focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/50 transition-all placeholder:text-gray-600"
                    placeholder="City, Country"
                    data-testid="input-location"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-mono text-muted-foreground uppercase">Project Type</label>
                  <select 
                    {...register("projectType")}
                    className="w-full bg-black/50 border border-border rounded-sm px-4 py-3 text-white focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/50 transition-all appearance-none"
                    data-testid="select-project-type"
                  >
                    <option value="smart-district">Smart District</option>
                    <option value="transit-hub">Transit Hub</option>
                    <option value="energy-network">Energy Network</option>
                    <option value="green-zone">Green Urban Zone</option>
                    <option value="cultural">Cultural District</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-mono text-muted-foreground uppercase">Message Parameters</label>
                <textarea 
                  {...register("message", { required: true })}
                  rows={4}
                  className="w-full bg-black/50 border border-border rounded-sm px-4 py-3 text-white focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/50 transition-all placeholder:text-gray-600 resize-none"
                  placeholder="Outline your project requirements..."
                  data-testid="textarea-message"
                ></textarea>
              </div>

              <button 
                type="submit"
                className="w-full bg-primary text-primary-foreground font-bold py-4 rounded-sm neon-border hover:bg-primary/90 transition-all duration-300 mt-4"
                data-testid="button-submit-contact"
              >
                Send Message
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
