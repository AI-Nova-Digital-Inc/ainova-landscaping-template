import { motion } from "framer-motion";
import { ArrowRight, Clock } from "lucide-react";

const articles = [
  {
    category: "TECHNOLOGY",
    readTime: "5 MIN READ",
    title: "The Rise of Digital Twin Cities",
    excerpt: "How virtual replicas of urban environments are transforming city planning and management, allowing for consequence-free simulation.",
  },
  {
    category: "AI & ALGORITHMS",
    readTime: "8 MIN READ",
    title: "AI-Driven Infrastructure Planning",
    excerpt: "Machine learning models predict infrastructure needs 10 years ahead, ensuring cities scale efficiently without massive overhauls.",
  },
  {
    category: "SUSTAINABILITY",
    readTime: "6 MIN READ",
    title: "Net Zero Urban Development in 2025",
    excerpt: "Pathways to carbon neutrality in large-scale urban development projects, blending advanced materials with smart grids.",
  }
];

export default function InsightsSection() {
  return (
    <section className="py-24 md:py-32 bg-[#060c18] relative">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-sm font-semibold tracking-widest text-primary uppercase mb-4 block">INSIGHTS</span>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-white max-w-2xl">Thinking at the Edge of Urban Innovation</h2>
          </motion.div>
          
          <motion.button
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="hidden md:flex items-center gap-2 text-primary font-medium hover:text-white transition-colors"
            data-testid="link-all-insights"
          >
            View All Insights <ArrowRight size={16} />
          </motion.button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {articles.map((article, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="group cursor-pointer flex flex-col h-full"
              data-testid={`insight-card-${i}`}
            >
              <div className="relative w-full h-48 bg-muted/50 rounded-lg mb-6 overflow-hidden border border-border group-hover:border-primary/50 transition-colors">
                <div className="absolute inset-0 grid-bg opacity-20 group-hover:scale-110 transition-transform duration-700"></div>
                <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent opacity-60"></div>
              </div>
              
              <div className="flex items-center gap-4 mb-4">
                <span className="inline-flex px-2 py-1 bg-primary/10 border border-primary/30 text-primary text-[10px] font-bold tracking-wider rounded-sm">
                  {article.category}
                </span>
                <span className="flex items-center gap-1.5 text-xs text-muted-foreground font-mono">
                  <Clock size={12} /> {article.readTime}
                </span>
              </div>
              
              <h3 className="font-display text-2xl font-bold text-white mb-3 group-hover:text-primary transition-colors line-clamp-2">
                {article.title}
              </h3>
              
              <p className="text-muted-foreground text-sm leading-relaxed mb-6 flex-grow">
                {article.excerpt}
              </p>
              
              <div className="flex items-center gap-2 text-white text-sm font-medium mt-auto group-hover:text-primary transition-colors">
                Read Article <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </div>
            </motion.div>
          ))}
        </div>
        
        <button className="mt-10 md:hidden w-full py-4 border border-border rounded-lg text-white font-medium hover:bg-primary/5 hover:border-primary/30 transition-all">
          View All Insights
        </button>
      </div>
    </section>
  );
}
