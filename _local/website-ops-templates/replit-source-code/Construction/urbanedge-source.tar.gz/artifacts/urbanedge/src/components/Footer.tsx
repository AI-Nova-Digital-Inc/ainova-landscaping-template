import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-[#02050a] border-t border-primary/20 pt-16 pb-8 relative">
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-primary to-transparent opacity-50"></div>
      
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 mb-12">
          
          <Link href="/" className="flex items-center gap-2 group">
            <span className="font-display font-bold text-2xl tracking-wider text-white">
              URBAN<span className="text-primary">EDGE</span>
            </span>
          </Link>

          <nav className="flex flex-wrap justify-center gap-6 md:gap-10">
            {["Vision", "Projects", "Technology", "Insights", "Contact"].map((item) => (
              <button
                key={item}
                onClick={() => document.getElementById(item.toLowerCase())?.scrollIntoView({ behavior: "smooth" })}
                className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors uppercase tracking-wider"
              >
                {item}
              </button>
            ))}
          </nav>

          <div className="flex gap-4">
            {['Twitter', 'LinkedIn', 'GitHub'].map((social) => (
              <a 
                key={social} 
                href={`#${social.toLowerCase()}`} 
                className="text-muted-foreground hover:text-white transition-colors text-sm font-mono"
              >
                {social}
              </a>
            ))}
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-muted-foreground text-sm">
            &copy; {new Date().getFullYear()} UrbanEdge Developments. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm text-muted-foreground">
            <a href="#privacy" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#terms" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
