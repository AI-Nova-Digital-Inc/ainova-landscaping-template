import { motion } from "framer-motion";
import { Cpu, Wifi, Activity, Settings, CheckCircle2 } from "lucide-react";

export default function SustainabilitySection() {
  return (
    <section className="py-24 md:py-32 bg-background relative overflow-hidden">
      <div className="absolute top-0 right-0 w-1/2 h-full bg-primary/5 blur-[150px] rounded-full pointer-events-none"></div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
          
          {/* Left: Sustainability */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-sm font-semibold tracking-widest text-primary uppercase mb-4 block">SUSTAINABILITY</span>
            <h2 className="font-display text-4xl font-bold text-white mb-8">Engineering a Greener Tomorrow</h2>
            
            <div className="flex items-center gap-8 mb-12">
              <div className="relative w-32 h-32 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90">
                  <circle cx="64" cy="64" r="60" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-border" />
                  <motion.circle 
                    cx="64" cy="64" r="60" stroke="currentColor" strokeWidth="8" fill="transparent" 
                    strokeDasharray="377" 
                    initial={{ strokeDashoffset: 377 }}
                    whileInView={{ strokeDashoffset: 377 - (377 * 0.78) }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.5, ease: "easeOut" }}
                    className="text-primary drop-shadow-[0_0_10px_rgba(0,212,255,0.5)]" 
                  />
                </svg>
                <div className="absolute flex flex-col items-center">
                  <span className="text-2xl font-bold text-white">78%</span>
                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Progress</span>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white mb-2">Carbon Neutral by 2035</h3>
                <p className="text-muted-foreground text-sm">Aggressive timeline tracking ahead of schedule across all active development zones.</p>
              </div>
            </div>

            <div className="space-y-6">
              {[
                { label: "40% Energy Reduction", width: "40%" },
                { label: "Zero Waste Construction", width: "85%" },
                { label: "100% Renewable by 2030", width: "65%" }
              ].map((item, i) => (
                <div key={i}>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium text-white">{item.label}</span>
                  </div>
                  <div className="h-2 w-full bg-border rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      whileInView={{ width: item.width }}
                      viewport={{ once: true }}
                      transition={{ duration: 1, delay: 0.2 + i * 0.2 }}
                      className="h-full bg-primary relative"
                    >
                      <div className="absolute inset-0 bg-white/30 animate-pulse"></div>
                    </motion.div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Right: Technology */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-sm font-semibold tracking-widest text-primary uppercase mb-4 block">TECHNOLOGY CORE</span>
            <h2 className="font-display text-4xl font-bold text-white mb-8">The Algorithmic City</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { icon: <Cpu className="text-primary" size={24} />, title: "AI Urban Planning", desc: "Machine learning models optimize traffic and resource flow." },
                { icon: <Activity className="text-primary" size={24} />, title: "Digital Twin Infrastructure", desc: "Real-time virtual replicas of physical assets." },
                { icon: <Wifi className="text-primary" size={24} />, title: "IoT Sensor Networks", desc: "Millions of data points driving autonomous decisions." },
                { icon: <Settings className="text-primary" size={24} />, title: "Predictive Maintenance", desc: "Anticipating structural needs before failures occur." }
              ].map((tile, i) => (
                <div key={i} className="p-6 rounded-lg bg-card border border-border hover:border-primary/50 hover:shadow-[0_0_15px_rgba(0,212,255,0.15)] transition-all duration-300">
                  <div className="mb-4 bg-primary/10 w-12 h-12 rounded-md flex items-center justify-center border border-primary/20">
                    {tile.icon}
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">{tile.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{tile.desc}</p>
                </div>
              ))}
            </div>
          </motion.div>

        </div>

        {/* Bottom Callouts */}
        <div className="mt-20 pt-10 border-t border-border grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            "99.8% Grid Uptime",
            "Real-time AI Monitoring",
            "ISO 14001 Certified"
          ].map((metric, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="flex items-center gap-3 justify-center md:justify-start"
            >
              <CheckCircle2 className="text-primary" size={20} />
              <span className="font-mono text-lg text-white">{metric}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
