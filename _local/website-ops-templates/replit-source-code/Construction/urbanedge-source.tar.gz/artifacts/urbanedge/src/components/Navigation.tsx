import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Menu, X } from "lucide-react";

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b border-transparent ${
        isScrolled ? "bg-background/80 backdrop-blur-md border-border/50 shadow-sm" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4 md:px-6 h-20 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group" data-testid="link-home">
          <span className="font-display font-bold text-xl tracking-wider text-white">
            URBAN<span className="text-primary group-hover:neon-text transition-all duration-300">EDGE</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {[
            { label: "Vision", id: "vision" },
            { label: "Projects", id: "projects" },
            { label: "Technology", id: "technology" },
            { label: "Insights", id: "insights" },
            { label: "Contact", id: "contact" },
          ].map((item) => (
            <button
              key={item.label}
              onClick={() => scrollTo(item.id)}
              className="text-sm font-medium text-muted-foreground hover:text-white transition-colors duration-200"
              data-testid={`link-${item.id}`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="hidden md:block">
          <button
            onClick={() => scrollTo("contact")}
            className="px-6 py-2.5 rounded-sm bg-primary/10 text-primary border border-primary/30 font-medium hover:bg-primary hover:text-primary-foreground hover:neon-border transition-all duration-300"
            data-testid="button-get-started"
          >
            Get Started
          </button>
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-white p-2"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          data-testid="button-mobile-menu"
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Nav */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-20 left-0 right-0 bg-background/95 backdrop-blur-xl border-b border-border p-4 flex flex-col gap-4">
          {[
            { label: "Vision", id: "vision" },
            { label: "Projects", id: "projects" },
            { label: "Technology", id: "technology" },
            { label: "Insights", id: "insights" },
            { label: "Contact", id: "contact" },
          ].map((item) => (
            <button
              key={item.label}
              onClick={() => scrollTo(item.id)}
              className="text-left px-4 py-3 text-lg font-medium text-white hover:text-primary transition-colors"
              data-testid={`mobile-link-${item.id}`}
            >
              {item.label}
            </button>
          ))}
          <button
            onClick={() => scrollTo("contact")}
            className="mt-4 mx-4 px-6 py-3 rounded-sm bg-primary text-primary-foreground font-medium neon-border"
            data-testid="mobile-button-get-started"
          >
            Get Started
          </button>
        </div>
      )}
    </header>
  );
}
