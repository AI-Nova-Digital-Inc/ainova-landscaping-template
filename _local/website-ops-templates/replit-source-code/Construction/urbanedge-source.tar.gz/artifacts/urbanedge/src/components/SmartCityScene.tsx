import { useRef, useEffect } from "react";

export default function SmartCityScene() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    let t = 0;

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    // City horizon line sits at 70% of canvas height
    const HORIZON = 0.68;

    type Building = {
      x: number;
      w: number;
      h: number; // normalized height above horizon (0..1 maps to 0..HORIZON*H)
      windows: { wx: number; wy: number; phase: number; speed: number; isBlue: boolean }[];
      glowPhase: number;
    };

    const buildingCount = 40;
    const buildings: Building[] = [];

    for (let i = 0; i < buildingCount; i++) {
      const bx = i / buildingCount + (Math.random() - 0.5) * 0.015;
      const bw = 0.016 + Math.random() * 0.026;
      const bh = 0.06 + Math.random() * 0.36; // 0 = flat, 1 = tall

      const windows: Building["windows"] = [];
      const wCols = Math.max(1, Math.round(bw * 120));
      const wRows = Math.max(1, Math.round(bh * 16));
      for (let wc = 0; wc < wCols; wc++) {
        for (let wr = 0; wr < wRows; wr++) {
          windows.push({
            wx: (wc + 0.15) / wCols,
            wy: (wr + 0.1) / wRows,
            phase: Math.random() * Math.PI * 2,
            speed: 0.2 + Math.random() * 0.9,
            isBlue: Math.random() > 0.25,
          });
        }
      }
      buildings.push({ x: bx, w: bw, h: bh, windows, glowPhase: Math.random() * Math.PI * 2 });
    }

    // Floating particles
    const particles: { x: number; y: number; vy: number; size: number; alpha: number; isBlue: boolean }[] = [];
    for (let i = 0; i < 80; i++) {
      particles.push({
        x: Math.random(),
        y: Math.random() * HORIZON,
        vy: 0.00015 + Math.random() * 0.0003,
        size: 0.6 + Math.random() * 1.2,
        alpha: 0.2 + Math.random() * 0.5,
        isBlue: Math.random() > 0.35,
      });
    }

    // Horizontal scan lines
    const scanLines = Array.from({ length: 3 }, () => ({
      y: Math.random(),
      speed: 0.00025 + Math.random() * 0.0003,
      alpha: 0.06 + Math.random() * 0.08,
    }));

    const draw = () => {
      const W = canvas.width;
      const H = canvas.height;
      t += 0.016;

      // Background gradient
      const bg = ctx.createLinearGradient(0, 0, 0, H);
      bg.addColorStop(0, "#020810");
      bg.addColorStop(0.55, "#030d1a");
      bg.addColorStop(1, "#040f1f");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);

      // Stars
      ctx.save();
      ctx.globalAlpha = 0.5;
      for (let s = 0; s < 90; s++) {
        // stable via deterministic seed trick
        const sx = ((s * 137.5) % 1) * W;
        const sy = ((s * 71.3) % 1) * H * 0.6;
        const brightness = 0.3 + ((s * 53.1) % 0.7);
        ctx.fillStyle = `rgba(180,220,255,${brightness * (0.4 + 0.3 * Math.sin(t * 0.8 + s))})`;
        ctx.fillRect(sx, sy, 1, 1);
      }
      ctx.restore();

      // Horizon ambient glow
      const horizonGlow = ctx.createRadialGradient(W / 2, H * HORIZON, 0, W / 2, H * HORIZON, W * 0.7);
      horizonGlow.addColorStop(0, "rgba(0,100,200,0.12)");
      horizonGlow.addColorStop(0.5, "rgba(0,50,120,0.06)");
      horizonGlow.addColorStop(1, "transparent");
      ctx.fillStyle = horizonGlow;
      ctx.fillRect(0, 0, W, H);

      // Ground (below horizon) — perspective grid
      const groundY = H * HORIZON;
      ctx.save();
      ctx.globalAlpha = 0.18;
      ctx.strokeStyle = "#00d4ff";
      ctx.lineWidth = 0.5;
      const vp = { x: W / 2, y: groundY };
      // Converging vertical lines
      const gridV = 18;
      for (let i = 0; i <= gridV; i++) {
        const gx = (i / gridV) * W;
        ctx.beginPath();
        ctx.moveTo(vp.x, vp.y);
        ctx.lineTo(gx, H);
        ctx.stroke();
      }
      // Horizontal lines with perspective spacing
      const gridH = 10;
      for (let i = 0; i <= gridH; i++) {
        const frac = Math.pow(i / gridH, 1.8);
        const gy = groundY + frac * (H - groundY);
        const spreadFrac = frac;
        const lx = vp.x - spreadFrac * W * 0.5;
        const rx = vp.x + spreadFrac * W * 0.5;
        ctx.beginPath();
        ctx.moveTo(lx, gy);
        ctx.lineTo(rx, gy);
        ctx.stroke();
      }
      ctx.restore();

      // Draw buildings (back to front using height as proxy)
      const sortedBuildings = [...buildings].sort((a, b) => a.h - b.h);

      for (const b of sortedBuildings) {
        const bx = b.x * W - (b.w * W) / 2;
        const bw = b.w * W;
        const bTop = groundY - b.h * groundY * 0.85;
        const bH = groundY - bTop;

        // Building silhouette
        const buildGrad = ctx.createLinearGradient(bx, bTop, bx + bw, groundY);
        buildGrad.addColorStop(0, "#0b1828");
        buildGrad.addColorStop(1, "#060e1c");
        ctx.fillStyle = buildGrad;
        ctx.fillRect(bx, bTop, bw, bH);

        // Subtle edge outline
        ctx.save();
        ctx.globalAlpha = 0.15 + 0.08 * Math.sin(t * 0.4 + b.glowPhase);
        ctx.strokeStyle = "#00d4ff";
        ctx.lineWidth = 0.5;
        ctx.strokeRect(bx, bTop, bw, bH);
        ctx.restore();

        // Windows
        const wSlotW = bw / Math.max(1, Math.round(bw / 6));
        const wSlotH = 8;
        for (const w of b.windows) {
          const lit = Math.sin(t * w.speed + w.phase) > 0.3;
          if (!lit) continue;
          const wx = bx + w.wx * bw;
          const wy = bTop + w.wy * bH;
          const bright = 0.35 + 0.65 * Math.abs(Math.sin(t * w.speed * 0.5 + w.phase));
          ctx.save();
          ctx.globalAlpha = bright * 0.7;
          if (w.isBlue) {
            ctx.fillStyle = `rgba(0,200,255,${bright * 0.9})`;
            ctx.shadowColor = "#00d4ff";
          } else {
            ctx.fillStyle = `rgba(140,80,255,${bright * 0.75})`;
            ctx.shadowColor = "#8b5cf6";
          }
          ctx.shadowBlur = 3;
          ctx.fillRect(wx, wy, wSlotW * 0.5, wSlotH * 0.5);
          ctx.restore();
        }

        // Rooftop pulse
        const pulseAlpha = 0.5 + 0.5 * Math.sin(t * 1.5 + b.glowPhase);
        ctx.save();
        ctx.globalAlpha = pulseAlpha * 0.7;
        ctx.fillStyle = Math.random() > 0.5 ? "#00d4ff" : "#8b5cf6";
        ctx.shadowColor = "#00d4ff";
        ctx.shadowBlur = 5;
        ctx.beginPath();
        ctx.arc(bx + bw / 2, bTop, 1.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Scan lines over sky
      for (const sl of scanLines) {
        sl.y += sl.speed;
        if (sl.y > 1) sl.y = 0;
        const sy = sl.y * H;
        if (sy > groundY) continue;
        const sg = ctx.createLinearGradient(0, sy - 1, 0, sy + 1);
        sg.addColorStop(0, "transparent");
        sg.addColorStop(0.5, `rgba(0,212,255,${sl.alpha})`);
        sg.addColorStop(1, "transparent");
        ctx.fillStyle = sg;
        ctx.fillRect(0, sy - 1, W, 2);
      }

      // Floating particles
      for (const p of particles) {
        p.y -= p.vy;
        if (p.y < 0) p.y = HORIZON;
        const pulse = 0.5 + 0.5 * Math.sin(t * 2 + p.x * 12);
        ctx.save();
        ctx.globalAlpha = p.alpha * pulse;
        ctx.fillStyle = p.isBlue ? "#00d4ff" : "#9d6fff";
        ctx.shadowColor = p.isBlue ? "#00d4ff" : "#7b2fff";
        ctx.shadowBlur = 4;
        ctx.beginPath();
        ctx.arc(p.x * W, p.y * H, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Dark gradient overlay — keeps center dark for text legibility
      const heroOverlay = ctx.createRadialGradient(W / 2, H * 0.42, 0, W / 2, H * 0.42, W * 0.55);
      heroOverlay.addColorStop(0, "rgba(2,8,16,0.55)");
      heroOverlay.addColorStop(1, "rgba(2,8,16,0.0)");
      ctx.fillStyle = heroOverlay;
      ctx.fillRect(0, 0, W, H);

      // HUD corner brackets
      ctx.save();
      ctx.globalAlpha = 0.2;
      ctx.strokeStyle = "#00d4ff";
      ctx.lineWidth = 1;
      const bsize = 28;
      const pad = 16;
      [[pad, pad, 1, 1], [W - pad, pad, -1, 1], [pad, H - pad, 1, -1], [W - pad, H - pad, -1, -1]].forEach(([cx, cy, dx, dy]) => {
        ctx.beginPath();
        ctx.moveTo(cx, cy + dy * bsize);
        ctx.lineTo(cx, cy);
        ctx.lineTo(cx + dx * bsize, cy);
        ctx.stroke();
      });
      ctx.restore();

      animId = requestAnimationFrame(draw);
    };

    animId = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full"
      style={{ display: "block" }}
    />
  );
}
