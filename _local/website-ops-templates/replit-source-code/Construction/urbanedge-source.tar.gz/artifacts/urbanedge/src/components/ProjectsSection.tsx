import { motion } from "framer-motion";
import { ArrowRight, MapPin, Calendar, Activity, Zap, Building2, Leaf } from "lucide-react";

const projects = [
  {
    title: "NexusCore",
    location: "Dubai, UAE",
    type: "Smart District",
    year: "2024",
    icon: <Building2 size={16} />,
    metrics: ["847 smart buildings", "2.1M sq ft"],
    colSpan: "col-span-1 lg:col-span-2",
  },
  {
    title: "MetroSync",
    location: "Singapore",
    type: "Transit Hub",
    year: "2023",
    icon: <Activity size={16} />,
    metrics: ["99.97% uptime", "4.2M daily riders"],
    colSpan: "col-span-1",
  },
  {
    title: "VerdaCity",
    location: "Toronto, Canada",
    type: "Green Urban Zone",
    year: "2024",
    icon: <Leaf size={16} />,
    metrics: ["94% carbon reduction", "180 green acres"],
    colSpan: "col-span-1",
  },
  {
    title: "PulseGrid",
    location: "Seoul, South Korea",
    type: "Energy Network",
    year: "2025",
    icon: <Zap size={16} />,
    metrics: ["AI-optimized", "40% energy savings"],
    colSpan: "col-span-1",
  },
  {
    title: "ArcaLight",
    location: "London, UK",
    type: "Cultural District",
    year: "2026",
    icon: <Building2 size={16} />,
    metrics: ["28 heritage sites", "Zero-emission grid"],
    colSpan: "col-span-1 lg:col-span-2",
  }
];

export default function ProjectsSection() {
  return (
    <section className="py-24 md:py-32 bg-[#060c18] relative">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="flex flex-col items-center text-center mb-16"
        >
          <span className="text-sm font-semibold tracking-widest text-primary uppercase mb-4 block">FLAGSHIP PROJECTS</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-6">Cities of the Future, Built Today</h2>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className={`group relative overflow-hidden rounded-lg glass-card transition-all duration-500 hover:neon-border ${project.colSpan}`}
              data-testid={`project-card-${i}`}
            >
              {/* Abstract background gradient that shows on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-0"></div>
              
              <div className="relative z-10 p-8 h-full flex flex-col justify-between min-h-[320px]">
                <div>
                  <div className="flex justify-between items-start mb-6">
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-medium">
                      {project.icon}
                      <span>{project.type}</span>
                    </div>
                    <span className="text-sm font-mono text-muted-foreground flex items-center gap-1.5">
                      <Calendar size={14} />
                      {project.year}
                    </span>
                  </div>
                  
                  <h3 className="font-display text-2xl font-bold text-white mb-2 group-hover:text-primary transition-colors">{project.title}</h3>
                  <div className="flex items-center gap-2 text-muted-foreground text-sm mb-6">
                    <MapPin size={14} />
                    <span>{project.location}</span>
                  </div>
                </div>

                <div className="mt-auto">
                  <div className="space-y-3 mb-6">
                    {project.metrics.map((metric, j) => (
                      <div key={j} className="flex items-center gap-3">
                        <div className="h-1.5 w-1.5 rounded-full bg-primary"></div>
                        <span className="text-sm font-medium text-gray-300">{metric}</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex items-center gap-2 text-primary font-medium text-sm opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300">
                    <span>View Data Topology</span>
                    <ArrowRight size={16} />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
