import { useRef, useEffect } from "react";
import { motion, useInView } from "framer-motion";
import gsap from "gsap";

function Counter({ value, prefix = "", suffix = "", duration = 2 }: { value: number, prefix?: string, suffix?: string, duration?: number }) {
  const nodeRef = useRef<HTMLSpanElement>(null);
  const inView = useInView(nodeRef, { once: true, margin: "-100px" });

  useEffect(() => {
    if (inView && nodeRef.current) {
      const obj = { val: 0 };
      gsap.to(obj, {
        val: value,
        duration: duration,
        ease: "power2.out",
        onUpdate: () => {
          if (nodeRef.current) {
            // format with 1 decimal if less than 10 but has decimal (e.g. 2.4, 8.2), else integer
            let formatted = Math.floor(obj.val).toString();
            if (value % 1 !== 0) {
              formatted = obj.val.toFixed(1);
            }
            nodeRef.current.textContent = `${prefix}${formatted}${suffix}`;
          }
        }
      });
    }
  }, [inView, value, prefix, suffix, duration]);

  return <span ref={nodeRef} className="font-mono text-5xl md:text-6xl font-bold neon-text">{prefix}0{suffix}</span>;
}

export default function VisionSection() {
  return (
    <section className="relative py-24 md:py-32 overflow-hidden bg-background">
      <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />
      
      <div className="container relative z-10 mx-auto px-4 md:px-6">
        <div className="max-w-3xl mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="flex items-center gap-4 mb-6"
          >
            <span className="h-[1px] w-12 bg-primary"></span>
            <span className="text-sm font-semibold tracking-widest text-primary uppercase">OUR VISION</span>
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-display text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-8"
          >
            The Future of Urban Living Is Already Here
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg md:text-xl text-muted-foreground leading-relaxed"
          >
            We don't just build structures; we architect intelligence. By seamlessly integrating digital twins, AI-driven infrastructure, and sustainable energy grids, we are redefining what a city can be—a living, breathing organism that adapts to human needs in real-time.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12">
          {[
            { value: 50, suffix: "+", label: "Projects Delivered" },
            { value: 12, suffix: "", label: "Cities Transformed" },
            { value: 2.4, suffix: "M", label: "Residents Served" },
            { value: 8.2, prefix: "$", suffix: "B", label: "Capital Deployed" },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 + i * 0.1 }}
              className="flex flex-col"
            >
              <Counter value={stat.value} prefix={stat.prefix} suffix={stat.suffix} />
              <div className="mt-4 mb-4 h-[1px] w-full bg-gradient-to-r from-primary/50 to-transparent"></div>
              <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider">{stat.label}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
