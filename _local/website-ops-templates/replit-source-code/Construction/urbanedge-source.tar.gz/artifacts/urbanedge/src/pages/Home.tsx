import { useEffect } from "react";
import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import VisionSection from "@/components/VisionSection";
import ProjectsSection from "@/components/ProjectsSection";
import SustainabilitySection from "@/components/SustainabilitySection";
import InsightsSection from "@/components/InsightsSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";

export default function Home() {
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-primary/30">
      <Navigation />
      <main>
        <div id="hero">
          <HeroSection />
        </div>
        <div id="vision">
          <VisionSection />
        </div>
        <div id="projects">
          <ProjectsSection />
        </div>
        <div id="technology">
          <SustainabilitySection />
        </div>
        <div id="insights">
          <InsightsSection />
        </div>
        <div id="contact">
          <ContactSection />
        </div>
      </main>
      <Footer />
    </div>
  );
}
