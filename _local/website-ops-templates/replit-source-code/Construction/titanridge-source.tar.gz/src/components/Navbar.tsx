import { useEffect, useState } from "react";
import { Link } from "wouter";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-[#0d1117]/90 backdrop-blur-md border-b border-[#c9a84c]/20" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-6 h-24 flex items-center justify-between">
        <Link href="/">
          <div className="font-display text-3xl tracking-[0.2em] text-white cursor-pointer select-none">
            TITAN<span className="text-[#c9a84c]">RIDGE</span>
          </div>
        </Link>
        <div className="hidden md:flex items-center gap-8 text-sm font-sans tracking-wide text-[#e6edf3]">
          {["capabilities", "projects", "process", "leadership", "contact"].map((item) => (
            <button
              key={item}
              onClick={() => scrollTo(item)}
              className="uppercase hover:text-[#c9a84c] transition-colors"
              data-testid={`nav-${item}`}
            >
              {item}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}
