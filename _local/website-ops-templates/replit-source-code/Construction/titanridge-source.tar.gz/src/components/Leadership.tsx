import { motion } from "framer-motion";

const leaders = [
  {
    name: "Marcus Holt",
    title: "Chairman & CEO",
    bio: "30 years reshaping America's skyline",
    initials: "MH"
  },
  {
    name: "Dr. Elena Vasquez",
    title: "Chief Engineer",
    bio: "MIT-trained structural innovator",
    initials: "EV"
  },
  {
    name: "James Okafor",
    title: "VP of Operations",
    bio: "Delivered $900M in infrastructure on zero budget overruns",
    initials: "JO"
  }
];

const certs = ["ISO 9001:2015", "LEED Platinum Partner", "AGC Member", "OSHA VPP Star"];

export default function Leadership() {
  return (
    <section id="leadership" className="py-32 bg-[#0d1117]">
      <div className="container mx-auto px-6">
        <div className="mb-20 text-center">
          <h2 className="font-display text-6xl md:text-8xl text-white mb-4">LEADERSHIP</h2>
          <div className="h-1 w-24 bg-[#c9a84c] mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-32 max-w-6xl mx-auto">
          {leaders.map((leader, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: i * 0.2 }}
              viewport={{ once: true }}
              className="text-center group"
            >
              <div className="w-48 h-48 mx-auto mb-8 bg-[#161b22] border border-[#30363d] group-hover:border-[#c9a84c] transition-colors duration-500 rounded-full flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-[#c9a84c]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <span className="font-display text-5xl text-[#c9a84c] tracking-widest">{leader.initials}</span>
              </div>
              <h3 className="font-display text-3xl text-white mb-1">{leader.name}</h3>
              <p className="font-sans text-[#c9a84c] text-sm tracking-widest uppercase mb-4">{leader.title}</p>
              <p className="font-serif italic text-[#8b949e]">{leader.bio}</p>
            </motion.div>
          ))}
        </div>

        {/* Certifications Strip */}
        <div className="border-t border-b border-[#30363d] py-10 overflow-hidden">
          <div className="flex flex-wrap justify-center items-center gap-12 md:gap-24 opacity-60">
            {certs.map((cert, i) => (
              <div key={i} className="font-sans text-[#e6edf3] text-sm tracking-widest uppercase whitespace-nowrap">
                {cert}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
