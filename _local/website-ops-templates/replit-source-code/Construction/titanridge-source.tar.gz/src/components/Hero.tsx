import HeroCanvas from "./HeroCanvas";
import { Button } from "@/components/ui/button";

export default function Hero() {
  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
  };

  const scrollToProjects = () => {
    document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative w-full h-screen overflow-hidden flex items-center justify-center">
      <HeroCanvas />
      
      <div className="relative z-10 container mx-auto px-6 flex flex-col items-start justify-center pt-20">
        <span className="font-sans text-[#c9a84c] tracking-[0.3em] text-sm uppercase mb-4 block">
          Commercial & Infrastructure
        </span>
        <h1 className="font-display text-[clamp(80px,12vw,180px)] leading-[0.85] text-white m-0">
          WE BUILD<br />THE FUTURE
        </h1>
        <p className="font-serif italic text-xl md:text-2xl text-[#8b949e] mt-6 max-w-2xl">
          Precision-engineered for the demands of tomorrow's skylines.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 mt-12">
          <Button 
            variant="outline" 
            size="lg"
            onClick={scrollToProjects}
            className="border-[#c9a84c] text-[#c9a84c] hover:bg-[#c9a84c] hover:text-[#0d1117] h-14 px-8 text-sm tracking-widest uppercase rounded-none"
            data-testid="hero-btn-projects"
          >
            View Projects
          </Button>
          <Button 
            size="lg"
            onClick={scrollToContact}
            className="bg-[#c9a84c] text-[#0d1117] hover:bg-white h-14 px-8 text-sm tracking-widest uppercase rounded-none"
            data-testid="hero-btn-contact"
          >
            Start a Project
          </Button>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10 animate-bounce">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 5v14M19 12l-7 7-7-7"/>
        </svg>
      </div>
    </section>
  );
}
