import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { motion } from "framer-motion";

const formSchema = z.object({
  name: z.string().min(2, "Name is required"),
  company: z.string().min(2, "Company is required"),
  type: z.string().min(1, "Project type is required"),
  scale: z.string().min(1, "Project scale is required"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

export default function Contact() {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      company: "",
      type: "",
      scale: "",
      message: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    console.log(values);
    setIsSubmitted(true);
  }

  return (
    <section id="contact" className="py-32 bg-[#161b22]">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 max-w-6xl mx-auto">
          
          {/* Left Side */}
          <div>
            <h2 className="font-display text-6xl md:text-8xl text-white mb-4">START A PROJECT</h2>
            <div className="h-1 w-24 bg-[#c9a84c] mb-12"></div>
            
            <p className="font-serif italic text-2xl text-[#8b949e] mb-12 max-w-md">
              "For projects requiring precision at scale."
            </p>

            <div className="space-y-6 font-sans text-lg text-white">
              <div>
                <p className="text-[#8b949e] text-sm tracking-widest uppercase mb-1">Email</p>
                <a href="mailto:projects@titanridge.com" className="hover:text-[#c9a84c] transition-colors">
                  projects@titanridge.com
                </a>
              </div>
              <div>
                <p className="text-[#8b949e] text-sm tracking-widest uppercase mb-1">Phone</p>
                <a href="tel:+13129007700" className="hover:text-[#c9a84c] transition-colors">
                  +1 (312) 900-7700
                </a>
              </div>
              <div>
                <p className="text-[#8b949e] text-sm tracking-widest uppercase mb-1">Headquarters</p>
                <p>150 N Riverside Plaza<br/>Chicago, IL 60606</p>
              </div>
            </div>
          </div>

          {/* Right Side / Form */}
          <div className="bg-[#0d1117] p-8 md:p-12 border border-[#30363d]">
            {isSubmitted ? (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full flex flex-col items-center justify-center text-center py-20"
              >
                <div className="w-16 h-16 rounded-full bg-[#c9a84c]/20 border border-[#c9a84c] flex items-center justify-center mb-6">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                </div>
                <h3 className="font-display text-4xl text-white mb-2">INQUIRY RECEIVED</h3>
                <p className="font-sans text-[#8b949e]">Our executive team will contact you within 24 hours.</p>
                <Button 
                  onClick={() => {
                    setIsSubmitted(false);
                    form.reset();
                  }}
                  variant="outline"
                  className="mt-8 border-[#30363d] text-white hover:bg-[#30363d]"
                >
                  Submit Another
                </Button>
              </motion.div>
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-[#8b949e] uppercase tracking-widest text-xs">Name</FormLabel>
                          <FormControl>
                            <Input className="bg-[#161b22] border-[#30363d] focus-visible:ring-[#c9a84c] rounded-none h-12 text-white" {...field} />
                          </FormControl>
                          <FormMessage className="text-[#c9a84c]" />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="company"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-[#8b949e] uppercase tracking-widest text-xs">Company</FormLabel>
                          <FormControl>
                            <Input className="bg-[#161b22] border-[#30363d] focus-visible:ring-[#c9a84c] rounded-none h-12 text-white" {...field} />
                          </FormControl>
                          <FormMessage className="text-[#c9a84c]" />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-[#8b949e] uppercase tracking-widest text-xs">Project Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-[#161b22] border-[#30363d] focus-visible:ring-[#c9a84c] rounded-none h-12 text-white">
                              <SelectValue placeholder="Select a category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-[#161b22] border-[#30363d] text-white rounded-none">
                            <SelectItem value="commercial">Commercial Tower</SelectItem>
                            <SelectItem value="infrastructure">Bridge & Infrastructure</SelectItem>
                            <SelectItem value="industrial">Industrial</SelectItem>
                            <SelectItem value="healthcare">Healthcare</SelectItem>
                            <SelectItem value="datacenter">Data Center</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage className="text-[#c9a84c]" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="scale"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-[#8b949e] uppercase tracking-widest text-xs">Project Scale</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-[#161b22] border-[#30363d] focus-visible:ring-[#c9a84c] rounded-none h-12 text-white">
                              <SelectValue placeholder="Select project value" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-[#161b22] border-[#30363d] text-white rounded-none">
                            <SelectItem value="50-100">$50M–$100M</SelectItem>
                            <SelectItem value="100-500">$100M–$500M</SelectItem>
                            <SelectItem value="500+">$500M+</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage className="text-[#c9a84c]" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-[#8b949e] uppercase tracking-widest text-xs">Message</FormLabel>
                        <FormControl>
                          <Textarea 
                            className="bg-[#161b22] border-[#30363d] focus-visible:ring-[#c9a84c] rounded-none min-h-[120px] text-white resize-none" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage className="text-[#c9a84c]" />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    size="lg"
                    className="w-full bg-[#c9a84c] text-[#0d1117] hover:bg-white h-14 text-sm tracking-widest uppercase rounded-none mt-4 transition-colors"
                  >
                    Submit Inquiry
                  </Button>
                </form>
              </Form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
