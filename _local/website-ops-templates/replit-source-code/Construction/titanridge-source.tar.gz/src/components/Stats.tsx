import { useEffect, useRef, useState } from "react";

function Counter({ end, label, prefix = "", suffix = "", decimals = 0 }: { end: number, label: string, prefix?: string, suffix?: string, decimals?: number }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          let start = 0;
          const duration = 2000;
          const increment = end / (duration / 16);
          const timer = setInterval(() => {
            start += increment;
            if (start >= end) {
              setCount(end);
              clearInterval(timer);
            } else {
              setCount(start);
            }
          }, 16);
          observer.disconnect();
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [end]);

  return (
    <div ref={ref} className="flex flex-col items-center justify-center p-6 text-center">
      <div className="font-display text-5xl md:text-7xl text-[#c9a84c] mb-2">
        {prefix}{count.toFixed(decimals)}{suffix}
      </div>
      <div className="font-sans text-sm tracking-widest text-[#8b949e] uppercase">
        {label}
      </div>
    </div>
  );
}

export default function Stats() {
  return (
    <section className="bg-[#161b22] py-20 border-y border-[#30363d]">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 divide-x divide-[#c9a84c]/20">
          <Counter end={2.4} decimals={1} prefix="$" suffix="B+" label="Total Project Value" />
          <Counter end={120} suffix="+" label="Signature Builds" />
          <Counter end={38} label="Years of Excellence" />
          <Counter end={99.2} decimals={1} suffix="%" label="On-Time Delivery" />
        </div>
      </div>
    </section>
  );
}
