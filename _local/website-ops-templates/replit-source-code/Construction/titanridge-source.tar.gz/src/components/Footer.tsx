import { Linkedin, Twitter } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[#0d1117] border-t border-[#30363d] pt-16 pb-8">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center md:items-end gap-8 mb-12">
          <div>
            <div className="font-display text-4xl tracking-[0.2em] text-white mb-4 text-center md:text-left">
              TITAN<span className="text-[#c9a84c]">RIDGE</span>
            </div>
            <p className="font-serif italic text-[#8b949e] text-lg">
              "Building civilization, one project at a time."
            </p>
          </div>
          
          <div className="flex items-center gap-6">
            <a href="#" className="text-[#8b949e] hover:text-[#c9a84c] transition-colors" aria-label="LinkedIn">
              <Linkedin size={24} />
            </a>
            <a href="#" className="text-[#8b949e] hover:text-[#c9a84c] transition-colors" aria-label="Twitter">
              <Twitter size={24} />
            </a>
          </div>
        </div>
        
        <div className="border-t border-[#30363d]/50 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm font-sans text-[#8b949e]">
          <p>© {new Date().getFullYear()} TitanRidge Construction Group. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
