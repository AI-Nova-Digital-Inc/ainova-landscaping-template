import { useEffect, useRef } from "react";
import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";

const phases = [
  {
    num: "01",
    title: "SITE ASSESSMENT & PLANNING",
    desc: "Exhaustive due diligence before the first blueprint is drawn. We analyze soil composition, structural constraints, and micro-climate impacts."
  },
  {
    num: "02",
    title: "ENGINEERING & DESIGN",
    desc: "Our engineers don't follow standards — they set them. Leveraging advanced BIM and structural simulations to push architectural boundaries."
  },
  {
    num: "03",
    title: "PRECISION EXECUTION",
    desc: "Every trade, every crew, every deadline managed with zero tolerance for drift. Our proprietary logistics matrix ensures materials arrive exactly when needed."
  },
  {
    num: "04",
    title: "HANDOVER & LEGACY",
    desc: "We don't just hand over keys. We hand over buildings that last centuries. Complete operational transfer with enterprise-grade facility documentation."
  }
];

export default function Process() {
  const containerRef = useRef<HTMLDivElement>(null);
  const lineRef = useRef<SVGPathElement>(null);
  const phasesRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);

    const ctx = gsap.context(() => {
      // Animate the line drawing
      if (lineRef.current) {
        const length = lineRef.current.getTotalLength();
        gsap.set(lineRef.current, { strokeDasharray: length, strokeDashoffset: length });

        gsap.to(lineRef.current, {
          strokeDashoffset: 0,
          ease: "none",
          scrollTrigger: {
            trigger: containerRef.current,
            start: "top center",
            end: "bottom center",
            scrub: true,
          }
        });
      }

      // Animate phases coming in
      phasesRef.current.forEach((phase, i) => {
        if (!phase) return;
        gsap.fromTo(phase, 
          { x: 50, opacity: 0 },
          {
            x: 0, opacity: 1, duration: 0.8, ease: "power3.out",
            scrollTrigger: {
              trigger: phase,
              start: "top 80%",
            }
          }
        );
      });
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <section id="process" className="py-32 bg-[#161b22]" ref={containerRef}>
      <div className="container mx-auto px-6">
        <div className="mb-24 text-center md:text-left">
          <h2 className="font-display text-6xl md:text-8xl text-white mb-4">HOW WE BUILD</h2>
          <div className="h-1 w-24 bg-[#c9a84c] mx-auto md:mx-0"></div>
        </div>

        <div className="relative max-w-4xl mx-auto md:ml-12 lg:ml-24">
          {/* SVG Line */}
          <div className="absolute left-4 top-0 bottom-0 w-8 -ml-[1px]">
            <svg className="w-full h-full" preserveAspectRatio="none" viewBox="0 0 10 1000">
              <line x1="5" y1="0" x2="5" y2="1000" stroke="#30363d" strokeWidth="2" />
              <path 
                ref={lineRef}
                d="M5,0 L5,1000" 
                stroke="#c9a84c" 
                strokeWidth="2" 
                fill="none" 
              />
            </svg>
          </div>

          <div className="space-y-24 py-12">
            {phases.map((phase, i) => (
              <div 
                key={i} 
                ref={el => phasesRef.current[i] = el}
                className="relative pl-16 md:pl-24"
              >
                {/* Node dot */}
                <div className="absolute left-[13px] top-4 w-3 h-3 rounded-full bg-[#0d1117] border-2 border-[#c9a84c] shadow-[0_0_10px_rgba(201,168,76,0.5)] transform -translate-x-1/2" />
                
                <div className="flex flex-col md:flex-row md:items-start gap-4 md:gap-8">
                  <div className="font-display text-6xl text-[#c9a84c]/20 leading-none select-none">
                    {phase.num}
                  </div>
                  <div>
                    <h3 className="font-display text-3xl md:text-4xl text-white mb-3">
                      {phase.title}
                    </h3>
                    <p className="font-sans text-lg text-[#8b949e] max-w-2xl leading-relaxed">
                      {phase.desc}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
