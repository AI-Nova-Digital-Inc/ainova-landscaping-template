import { useEffect, useRef } from "react";

interface Particle {
  x: number;
  y: number;
  speed: number;
  size: number;
  opacity: number;
}

interface Floor {
  y: number;
  width: number;
  depth: number;
  revealed: number;
  isActive: boolean;
}

export default function HeroCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    let t = 0;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    // Isometric projection helpers
    const isoX = (x: number, z: number) => (x - z) * 0.866;
    const isoY = (x: number, y: number, z: number) => (x + z) * 0.5 - y;

    // Building config
    const floors = 24;
    const floorH = 18;
    const bw = 90;
    const bd = 90;
    const baseX = 0;
    const baseZ = 0;
    const originX = canvas.width / 2;
    const originY = canvas.height * 0.72;

    // Particles
    const particles: Particle[] = Array.from({ length: 120 }, () => ({
      x: (Math.random() - 0.5) * canvas.width * 1.4,
      y: Math.random() * canvas.height,
      speed: 0.2 + Math.random() * 0.5,
      size: 0.5 + Math.random() * 1.5,
      opacity: 0.1 + Math.random() * 0.4,
    }));

    // Crane arm state
    let craneAngle = 0;

    const drawBuilding = (progress: number) => {
      const floorsVisible = Math.floor(progress * floors);
      const partialFraction = (progress * floors) % 1;

      for (let i = 0; i < floorsVisible + 1; i++) {
        if (i >= floors) break;
        const frac = i < floorsVisible ? 1 : partialFraction;
        if (frac <= 0) continue;

        const fy = (floors - i) * floorH;
        const isTop = i === floorsVisible || i === floorsVisible - 1;
        const alpha = isTop ? Math.min(1, frac * 2) : 1;
        const goldAlpha = isTop ? alpha : (i === floorsVisible - 2 ? 0.4 : 0.15);

        const corners = [
          [baseX - bw / 2, fy, baseZ - bd / 2],
          [baseX + bw / 2, fy, baseZ - bd / 2],
          [baseX + bw / 2, fy, baseZ + bd / 2],
          [baseX - bw / 2, fy, baseZ + bd / 2],
        ];
        const cornersBelow = corners.map(([x, y, z]) => [x, y + floorH, z]);

        const project = ([x, y, z]: number[]) => ({
          sx: originX + isoX(x, z) * frac,
          sy: originY + isoY(x, y, z),
        });

        const pts = corners.map(project);
        const ptsB = cornersBelow.map(project);

        // Top face
        ctx.beginPath();
        ctx.moveTo(pts[0].sx, pts[0].sy);
        pts.forEach((p) => ctx.lineTo(p.sx, p.sy));
        ctx.closePath();
        ctx.strokeStyle = `rgba(201, 168, 76, ${goldAlpha * alpha})`;
        ctx.lineWidth = isTop ? 1.5 : 0.8;
        ctx.stroke();

        // Vertical edges (left/right visible sides)
        [[0, 0], [1, 1], [2, 2], [3, 3]].forEach(([a, b]) => {
          ctx.beginPath();
          ctx.moveTo(pts[a].sx, pts[a].sy);
          ctx.lineTo(ptsB[b].sx, ptsB[b].sy);
          ctx.strokeStyle = `rgba(48, 54, 61, ${0.6 * alpha})`;
          ctx.lineWidth = 0.6;
          ctx.stroke();
        });

        // Window grid on visible faces
        if (frac > 0.5 && i < floorsVisible) {
          const cols = 4;
          for (let c = 1; c < cols; c++) {
            const wx = baseX - bw / 2 + (bw / cols) * c;
            const wTop = project([wx, fy, baseZ - bd / 2]);
            const wBot = project([wx, fy + floorH, baseZ - bd / 2]);
            ctx.beginPath();
            ctx.moveTo(wTop.sx, wTop.sy);
            ctx.lineTo(wBot.sx, wBot.sy);
            ctx.strokeStyle = `rgba(48, 54, 61, ${0.35 * alpha})`;
            ctx.lineWidth = 0.4;
            ctx.stroke();
          }
        }
      }

      // Crane at top of revealed building
      if (progress > 0.2) {
        const topY = (floors - floorsVisible) * floorH;
        const craneBase = project2d(baseX, topY, baseZ);
        craneAngle += 0.003;
        const craneLen = 80;
        const cx2 = craneBase.sx + Math.cos(craneAngle) * craneLen;
        const cy2 = craneBase.sy + Math.sin(craneAngle) * 20 - 50;

        ctx.beginPath();
        ctx.moveTo(craneBase.sx, craneBase.sy);
        ctx.lineTo(craneBase.sx, craneBase.sy - 60);
        ctx.lineTo(cx2, cy2);
        ctx.strokeStyle = `rgba(201, 168, 76, 0.5)`;
        ctx.lineWidth = 1;
        ctx.stroke();

        // Cable
        ctx.beginPath();
        ctx.moveTo(cx2, cy2);
        ctx.lineTo(cx2, cy2 + 25);
        ctx.strokeStyle = `rgba(201, 168, 76, 0.3)`;
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }
    };

    const project2d = (x: number, y: number, z: number) => ({
      sx: originX + isoX(x, z),
      sy: originY + isoY(x, y, z),
    });

    const drawGrid = () => {
      const gridSize = 12;
      const gridStep = 30;
      ctx.strokeStyle = "rgba(48, 54, 61, 0.25)";
      ctx.lineWidth = 0.5;

      for (let i = -gridSize; i <= gridSize; i++) {
        const x1 = baseX - gridSize * gridStep;
        const x2 = baseX + gridSize * gridStep;
        const groundY = floors * floorH;
        const p1 = project2d(x1, groundY, i * gridStep);
        const p2 = project2d(x2, groundY, i * gridStep);
        ctx.beginPath();
        ctx.moveTo(p1.sx, p1.sy);
        ctx.lineTo(p2.sx, p2.sy);
        ctx.stroke();

        const p3 = project2d(i * gridStep, groundY, -gridSize * gridStep);
        const p4 = project2d(i * gridStep, groundY, gridSize * gridStep);
        ctx.beginPath();
        ctx.moveTo(p3.sx, p3.sy);
        ctx.lineTo(p4.sx, p4.sy);
        ctx.stroke();
      }
    };

    const drawParticles = () => {
      particles.forEach((p) => {
        p.y -= p.speed;
        if (p.y < -10) {
          p.y = canvas.height + 10;
          p.x = (Math.random() - 0.5) * canvas.width * 1.4;
        }
        ctx.beginPath();
        ctx.arc(originX + p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(201, 168, 76, ${p.opacity})`;
        ctx.fill();
      });
    };

    const drawAtmosphere = () => {
      // Radial gradient glow at base
      const grd = ctx.createRadialGradient(
        originX, originY - 40, 0,
        originX, originY - 40, 280
      );
      grd.addColorStop(0, "rgba(201, 168, 76, 0.06)");
      grd.addColorStop(1, "rgba(13, 17, 23, 0)");
      ctx.fillStyle = grd;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    };

    const draw = () => {
      t += 0.004;
      const progress = Math.min(1, t * 0.6);

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Background
      ctx.fillStyle = "#0d1117";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      drawAtmosphere();
      drawGrid();
      drawBuilding(progress);
      drawParticles();

      animId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(animId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 z-0 pointer-events-none"
      style={{ width: "100%", height: "100%" }}
    />
  );
}
