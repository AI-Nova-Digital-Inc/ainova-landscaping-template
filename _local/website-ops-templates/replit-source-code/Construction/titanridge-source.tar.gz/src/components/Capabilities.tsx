import { motion } from "framer-motion";
import { Building2, Train, Factory, Activity, LayoutTemplate, Server } from "lucide-react";

const capabilities = [
  {
    title: "Commercial Towers",
    desc: "Skyline-defining corporate headquarters and multi-tenant skyscrapers.",
    icon: Building2
  },
  {
    title: "Transportation Infrastructure",
    desc: "Bridges, transit hubs, and heavy civil engineering projects.",
    icon: Train
  },
  {
    title: "Industrial Complexes",
    desc: "Large-scale manufacturing and logistics facilities.",
    icon: Factory
  },
  {
    title: "Healthcare Facilities",
    desc: "State-of-the-art hospitals and specialized medical research centers.",
    icon: Activity
  },
  {
    title: "Mixed-Use Developments",
    desc: "Integrated urban environments combining residential, retail, and commercial spaces.",
    icon: LayoutTemplate
  },
  {
    title: "Data Center Construction",
    desc: "Hyperscale mission-critical facilities with extreme power density requirements.",
    icon: Server
  }
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" }
  }
};

export default function Capabilities() {
  return (
    <section id="capabilities" className="py-32 bg-[#0d1117]">
      <div className="container mx-auto px-6">
        <div className="mb-16">
          <h2 className="font-display text-6xl md:text-8xl text-white mb-4">WHAT WE BUILD</h2>
          <div className="h-1 w-24 bg-[#c9a84c]"></div>
        </div>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          {capabilities.map((cap, i) => (
            <motion.div
              key={i}
              variants={itemVariants}
              className="group bg-[#161b22] p-8 border border-[#30363d] hover:border-[#c9a84c] transition-colors duration-300 relative overflow-hidden"
              data-testid={`capability-card-${i}`}
            >
              <div className="mb-6 text-[#8b949e] group-hover:text-[#c9a84c] transition-colors duration-300">
                <cap.icon size={40} strokeWidth={1} />
              </div>
              <h3 className="font-display text-2xl text-white mb-3 tracking-wide">{cap.title}</h3>
              <p className="font-sans text-[#8b949e] leading-relaxed">
                {cap.desc}
              </p>
              
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#c9a84c] opacity-0 group-hover:opacity-5 blur-3xl rounded-full transition-opacity duration-500"></div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
