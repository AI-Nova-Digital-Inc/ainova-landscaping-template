import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

const projects = [
  {
    id: "meridian",
    name: "MERIDIAN TOWER",
    location: "Chicago, IL",
    year: "2023",
    value: "$340M",
    type: "68-story mixed-use skyscraper",
    desc: "A towering achievement in urban density. The Meridian Tower features an innovative exoskeleton structural system allowing for column-free interior floor plates.",
    bg: "linear-gradient(135deg, rgba(22, 27, 34, 0.9) 0%, rgba(13, 17, 23, 0.9) 100%), conic-gradient(from 180deg at 50% 50%, #161b22 0deg, #30363d 180deg, #161b22 360deg)",
    shapes: (
      <>
        <div className="absolute top-0 left-10 w-20 h-[150%] bg-[#30363d]/10 transform -skew-x-[20deg]" />
        <div className="absolute top-10 right-20 w-40 h-[120%] bg-[#c9a84c]/5 transform skew-x-[15deg]" />
        <div className="absolute bottom-0 left-0 w-full h-1/3 bg-gradient-to-t from-[#0d1117] to-transparent" />
      </>
    )
  },
  {
    id: "harbor",
    name: "HARBOR BRIDGE COMPLEX",
    location: "Seattle, WA",
    year: "2022",
    value: "$280M",
    type: "Suspension bridge & transit hub",
    desc: "Spanning 1.2 miles across deep water channels, constructed with zero disruption to active shipping lanes below. Awarded National Engineering Excellence.",
    bg: "linear-gradient(to bottom, rgba(22, 27, 34, 0.8), rgba(13, 17, 23, 1)), radial-gradient(circle at 70% 30%, #21262d 0%, #0d1117 70%)",
    shapes: (
      <>
        <svg className="absolute inset-0 w-full h-full opacity-10" preserveAspectRatio="none">
          <path d="M0,80 Q200,20 400,80 T800,80" fill="none" stroke="#c9a84c" strokeWidth="2" />
          <path d="M0,100 Q200,40 400,100 T800,100" fill="none" stroke="#e6edf3" strokeWidth="1" />
          <line x1="200" y1="0" x2="200" y2="100" stroke="#30363d" strokeWidth="4" />
          <line x1="600" y1="0" x2="600" y2="100" stroke="#30363d" strokeWidth="4" />
        </svg>
      </>
    )
  },
  {
    id: "nexus",
    name: "NEXUS DATA CENTER",
    location: "Austin, TX",
    year: "2024",
    value: "$190M",
    type: "Hyperscale facility, 2.1M sq ft",
    desc: "Built to Tier IV standards with an unprecedented PUE of 1.12. Features proprietary liquid cooling infrastructure and blast-resistant reinforced concrete shells.",
    bg: "linear-gradient(45deg, #0d1117 0%, #161b22 50%, #0d1117 100%)",
    shapes: (
      <>
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "linear-gradient(#c9a84c 1px, transparent 1px), linear-gradient(90deg, #c9a84c 1px, transparent 1px)", backgroundSize: "40px 40px" }} />
        <div className="absolute top-1/4 right-1/4 w-32 h-32 border border-[#c9a84c]/20 rounded-full" />
        <div className="absolute top-1/4 right-1/4 w-48 h-48 border border-[#e6edf3]/10 rounded-full" />
      </>
    )
  }
];

export default function Projects() {
  return (
    <section id="projects" className="py-32 bg-[#0d1117]">
      <div className="container mx-auto px-6 mb-16">
        <h2 className="font-display text-6xl md:text-8xl text-white mb-4">SIGNATURE PROJECTS</h2>
        <div className="h-1 w-24 bg-[#c9a84c]"></div>
      </div>

      <div className="flex flex-col lg:flex-row w-full min-h-[600px]">
        {projects.map((project) => (
          <motion.div
            key={project.id}
            layoutId={project.id}
            className="relative group flex-1 min-h-[400px] border-y border-b-0 lg:border-y-0 lg:border-r border-[#30363d] overflow-hidden cursor-pointer"
            whileHover={{ flex: 1.3 }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            data-testid={`project-${project.id}`}
          >
            {/* Background elements */}
            <div 
              className="absolute inset-0 transition-transform duration-700 group-hover:scale-105"
              style={{ background: project.bg }}
            >
              {project.shapes}
            </div>

            {/* Content */}
            <div className="absolute inset-0 p-8 flex flex-col justify-end bg-gradient-to-t from-[#0d1117] via-[#0d1117]/80 to-transparent">
              <div className="mb-auto mt-4">
                <span className="inline-block px-3 py-1 text-xs font-sans tracking-widest text-[#0d1117] bg-[#c9a84c] mb-6">
                  {project.value}
                </span>
              </div>
              
              <div className="transform transition-transform duration-500 translate-y-8 group-hover:translate-y-0">
                <h3 className="font-display text-4xl md:text-5xl text-white leading-none mb-2">
                  {project.name}
                </h3>
                
                <div className="flex flex-wrap items-center gap-4 text-sm font-sans text-[#8b949e] mb-4">
                  <span>{project.location}</span>
                  <span className="w-1 h-1 rounded-full bg-[#c9a84c]"></span>
                  <span>{project.year}</span>
                </div>
                
                <p className="font-sans text-white/90 mb-4">{project.type}</p>
                
                <div className="opacity-0 h-0 group-hover:opacity-100 group-hover:h-auto transition-all duration-500 delay-100">
                  <p className="font-serif italic text-[#8b949e] text-lg mb-6 leading-relaxed">
                    {project.desc}
                  </p>
                  <button className="flex items-center gap-2 text-[#c9a84c] hover:text-white transition-colors font-sans text-sm tracking-widest uppercase">
                    View Details <ArrowRight size={16} />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
