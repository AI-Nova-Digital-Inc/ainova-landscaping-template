import { useRef, useState } from "react";
import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { MapPin, Phone, Mail, Send } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

export function Contact() {
  const container = useRef<HTMLDivElement>(null);
  const [formStatus, setFormStatus] = useState<"idle" | "submitting" | "success">("idle");

  useGSAP(() => {
    if (!container.current) return;
    
    gsap.from('.contact-panel', {
      y: 50,
      opacity: 0,
      duration: 1,
      stagger: 0.2,
      ease: "power3.out",
      scrollTrigger: {
        trigger: container.current,
        start: "top 70%",
      }
    });
  }, { scope: container });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus("submitting");
    // Simulate network request
    setTimeout(() => {
      setFormStatus("success");
      // Reset after 3s
      setTimeout(() => setFormStatus("idle"), 3000);
    }, 1500);
  };

  return (
    <section id="contact" ref={container} className="py-32 bg-background relative z-30 -mt-[4vw] clip-diagonal texture-grid">
      <div className="absolute inset-0 bg-background/90" />
      
      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="mb-16 text-center">
          <h2 className="text-4xl md:text-6xl font-display text-foreground mb-4">
            <span className="text-primary orange-bracket">Initiate</span> Project
          </h2>
          <div className="w-24 h-2 bg-primary mx-auto mb-6" />
          <p className="text-xl text-muted-foreground font-condensed max-w-2xl mx-auto">
            Submit specs for review. Our engineering and estimation team will respond within 48 hours.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 max-w-6xl mx-auto">
          
          {/* Contact Info */}
          <div className="lg:col-span-2 space-y-8 contact-panel">
            <div className="bg-muted border-2 border-border p-8 bolted-corner">
              <h3 className="text-2xl font-display text-foreground mb-8 uppercase tracking-wider border-b border-border pb-4">
                Headquarters
              </h3>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-background border border-border text-primary">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <h4 className="font-condensed text-lg text-foreground uppercase tracking-widest mb-1">Location</h4>
                    <p className="font-sans text-muted-foreground">4400 Industrial Blvd<br/>Houston, TX 77019</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-3 bg-background border border-border text-primary">
                    <Phone size={24} />
                  </div>
                  <div>
                    <h4 className="font-condensed text-lg text-foreground uppercase tracking-widest mb-1">Direct Line</h4>
                    <p className="font-display text-2xl text-muted-foreground">(713) 555-0182</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-3 bg-background border border-border text-primary">
                    <Mail size={24} />
                  </div>
                  <div>
                    <h4 className="font-condensed text-lg text-foreground uppercase tracking-widest mb-1">Inquiries</h4>
                    <p className="font-sans text-muted-foreground">projects@groundforgeconst.com</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-3 contact-panel">
            <form onSubmit={handleSubmit} className="bg-card border-2 border-border p-8 bolted-corner flex flex-col gap-6">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex flex-col gap-2">
                  <label htmlFor="name" className="font-condensed text-lg text-foreground uppercase tracking-widest">Full Name</label>
                  <input 
                    type="text" 
                    id="name" 
                    required
                    className="bg-background border-2 border-border p-3 text-foreground font-sans focus:border-primary focus:outline-none transition-colors"
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <label htmlFor="company" className="font-condensed text-lg text-foreground uppercase tracking-widest">Company</label>
                  <input 
                    type="text" 
                    id="company" 
                    required
                    className="bg-background border-2 border-border p-3 text-foreground font-sans focus:border-primary focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <label htmlFor="type" className="font-condensed text-lg text-foreground uppercase tracking-widest">Project Type</label>
                <select 
                  id="type"
                  required
                  className="bg-background border-2 border-border p-3 text-foreground font-sans focus:border-primary focus:outline-none transition-colors appearance-none"
                >
                  <option value="">Select scope...</option>
                  <option value="plant">Industrial Plant</option>
                  <option value="infrastructure">Heavy Infrastructure</option>
                  <option value="factory">Factory Build-out</option>
                  <option value="demo">Demolition</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div className="flex flex-col gap-2">
                <label htmlFor="message" className="font-condensed text-lg text-foreground uppercase tracking-widest">Project Specs / Message</label>
                <textarea 
                  id="message" 
                  rows={5}
                  required
                  className="bg-background border-2 border-border p-3 text-foreground font-sans focus:border-primary focus:outline-none transition-colors resize-none"
                ></textarea>
              </div>

              <button 
                type="submit" 
                disabled={formStatus !== "idle"}
                className="group flex items-center justify-center gap-3 p-4 bg-primary text-primary-foreground font-display text-2xl uppercase tracking-widest hover:bg-primary/90 transition-colors disabled:opacity-70 disabled:cursor-not-allowed mt-4 clip-diagonal-top"
              >
                {formStatus === "idle" && (
                  <>Submit Bid Request <Send size={24} className="group-hover:translate-x-1 transition-transform" /></>
                )}
                {formStatus === "submitting" && "Transmitting..."}
                {formStatus === "success" && "Request Received"}
              </button>

            </form>
          </div>

        </div>
      </div>
    </section>
  );
}
