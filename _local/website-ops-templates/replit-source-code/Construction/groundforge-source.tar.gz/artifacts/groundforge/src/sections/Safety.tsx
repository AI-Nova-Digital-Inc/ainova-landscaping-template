import { useRef } from "react";
import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ShieldCheck, CheckCircle2 } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const certs = [
  "OSHA 10 & 30 Certified Workforce",
  "ISO 9001:2015 Quality Management",
  "ISNetworld A-Rated Contractor",
  "PEC Premier Safe Contractor",
  "National Safety Council Member",
  "EMR Rating < 0.80"
];

export function Safety() {
  const container = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!container.current) return;
    
    gsap.from('.safety-badge', {
      scale: 0.8,
      opacity: 0,
      duration: 0.6,
      stagger: 0.1,
      ease: "back.out(1.7)",
      scrollTrigger: {
        trigger: container.current,
        start: "top 70%",
      }
    });

    gsap.from('.safety-text', {
      x: -50,
      opacity: 0,
      duration: 0.8,
      scrollTrigger: {
        trigger: container.current,
        start: "top 70%",
      }
    });
  }, { scope: container });

  return (
    <section id="safety" ref={container} className="py-24 bg-primary text-primary-foreground relative z-30 -mt-[4vw] clip-diagonal texture-noise">
      <div className="container mx-auto px-4 md:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          <div className="safety-text">
            <div className="inline-flex items-center gap-3 px-4 py-2 border-2 border-primary-foreground/20 mb-8">
              <ShieldCheck size={24} />
              <span className="font-condensed text-xl uppercase tracking-widest">Zero Incidents Target</span>
            </div>
            
            <h2 className="text-4xl md:text-6xl font-display mb-6">
              Ironclad Compliance
            </h2>
            <p className="text-xl font-sans mb-8 max-w-xl text-primary-foreground/90">
              In heavy industrial construction, safety isn't a manual—it's a culture. Our site protocols exceed federal requirements, ensuring every operator goes home and every project advances without delay.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {certs.map((cert, idx) => (
              <div 
                key={idx} 
                className="safety-badge flex items-start gap-4 p-6 bg-background/10 border-2 border-primary-foreground/20 backdrop-blur-sm bolted-corner"
              >
                <CheckCircle2 className="shrink-0 mt-1" size={24} />
                <span className="font-condensed text-xl tracking-wider uppercase">{cert}</span>
              </div>
            ))}
          </div>

        </div>

      </div>
    </section>
  );
}
