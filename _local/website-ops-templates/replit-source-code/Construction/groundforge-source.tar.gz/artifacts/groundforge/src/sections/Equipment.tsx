import { useRef } from "react";
import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const equipment = [
  { name: "Tower Cranes", spec: "Up to 40-Ton Lift Capacity", desc: "For high-rise structural steel and equipment placement." },
  { name: "Heavy Excavators", spec: "90+ Ton Operating Weight", desc: "Massive earthmoving and trenching for deep foundations." },
  { name: "Concrete Batching", spec: "200 cubic yards/hour", desc: "On-site continuous pour capability for massive pads." },
  { name: "Heavy Haul Rigs", spec: "Multi-axle, 150+ Ton Load", desc: "Transport of turbines, generators, and pre-fab modules." },
  { name: "Boring Machines", spec: "Large Diameter Capability", desc: "Underground utility routing and foundational piling." },
  { name: "Aerial Platforms", spec: "Up to 150ft Reach", desc: "High-elevation welding, bolting, and inspection." },
];

export function Equipment() {
  const container = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!container.current) return;
    
    gsap.from('.equip-row', {
      x: 100,
      opacity: 0,
      duration: 0.8,
      stagger: 0.1,
      ease: "power3.out",
      scrollTrigger: {
        trigger: container.current,
        start: "top 60%",
      }
    });
  }, { scope: container });

  return (
    <section id="equipment" ref={container} className="py-32 bg-card relative z-20 -mt-[4vw] clip-diagonal texture-noise">
      <div className="container mx-auto px-4 md:px-8">
        
        <div className="mb-16">
          <h2 className="text-4xl md:text-6xl font-display text-foreground mb-4">
            <span className="text-primary orange-bracket">Heavy</span> Artillery
          </h2>
          <div className="w-24 h-2 bg-primary mb-6" />
          <p className="text-xl text-muted-foreground font-condensed max-w-2xl">
            We don't rent when we can own. A massive fleet of meticulously maintained heavy machinery ready for immediate deployment.
          </p>
        </div>

        <div className="border-t-4 border-border">
          {equipment.map((item, idx) => (
            <div 
              key={idx} 
              className="equip-row grid grid-cols-1 md:grid-cols-12 gap-4 py-8 border-b border-border items-center hover:bg-muted transition-colors px-4"
            >
              <div className="md:col-span-4">
                <h3 className="text-2xl md:text-3xl font-display text-foreground uppercase tracking-wider">
                  {item.name}
                </h3>
              </div>
              <div className="md:col-span-4">
                <span className="inline-block px-3 py-1 bg-primary/10 text-primary border border-primary font-condensed text-lg uppercase tracking-wider">
                  {item.spec}
                </span>
              </div>
              <div className="md:col-span-4">
                <p className="text-muted-foreground font-sans">
                  {item.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
