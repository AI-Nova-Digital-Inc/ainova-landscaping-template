import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-background pt-24 pb-12 border-t-4 border-primary texture-noise">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8 mb-16">
          <div className="col-span-1 md:col-span-2 lg:col-span-1">
            <Link href="/" className="group flex items-center gap-3 mb-6 inline-flex">
              <div className="w-12 h-12 bg-primary flex items-center justify-center font-display text-primary-foreground text-3xl font-bold">
                GF
              </div>
              <div className="flex flex-col">
                <span className="font-display text-3xl tracking-widest text-foreground leading-none">GROUNDFORGE</span>
                <span className="font-condensed text-sm text-primary uppercase tracking-widest leading-none">Construction</span>
              </div>
            </Link>
            <p className="text-muted-foreground font-sans text-sm mb-6 max-w-xs">
              Specializing in heavy industrial facilities, factory build-outs, and massive civil infrastructure. We don't build. We forge.
            </p>
          </div>

          <div>
            <h4 className="font-display text-2xl mb-6 text-foreground tracking-widest">Services</h4>
            <ul className="space-y-3 font-condensed text-lg text-muted-foreground">
              <li><a href="#" className="hover:text-primary transition-colors">Industrial Plant Construction</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Heavy Infrastructure</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Factory Build-out</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Civil Engineering</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Site Clearing</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display text-2xl mb-6 text-foreground tracking-widest">Headquarters</h4>
            <ul className="space-y-3 font-sans text-sm text-muted-foreground">
              <li>4400 Industrial Blvd</li>
              <li>Houston, TX 77019</li>
              <li className="pt-4">
                <span className="block font-condensed text-primary uppercase tracking-wider mb-1">Direct Line</span>
                <span className="font-display text-xl text-foreground">(713) 555-0182</span>
              </li>
              <li>
                <span className="block font-condensed text-primary uppercase tracking-wider mb-1">Project Inquiries</span>
                <a href="mailto:projects@groundforgeconst.com" className="text-foreground hover:text-primary transition-colors">projects@groundforgeconst.com</a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-display text-2xl mb-6 text-foreground tracking-widest">Certifications</h4>
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1 bg-muted border border-border font-condensed text-sm text-foreground">OSHA 30</span>
              <span className="px-3 py-1 bg-muted border border-border font-condensed text-sm text-foreground">ISO 9001</span>
              <span className="px-3 py-1 bg-muted border border-border font-condensed text-sm text-foreground">ISNetworld</span>
              <span className="px-3 py-1 bg-muted border border-border font-condensed text-sm text-foreground">PEC Premier</span>
            </div>
          </div>
        </div>

        <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="font-sans text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} GroundForge Construction. All rights reserved.
          </p>
          <div className="flex gap-6 font-condensed text-muted-foreground">
            <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-primary transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
