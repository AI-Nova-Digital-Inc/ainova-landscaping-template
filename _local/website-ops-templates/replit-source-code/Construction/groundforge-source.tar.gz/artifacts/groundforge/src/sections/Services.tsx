import { useRef } from "react";
import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Factory, Construction, Hammer, Compass, Pickaxe, Settings } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const services = [
  {
    title: "Industrial Plant Construction",
    desc: "End-to-end build-out of chemical, manufacturing, and processing facilities. Handling everything from foundational concrete to final equipment placement.",
    icon: Factory
  },
  {
    title: "Heavy Infrastructure",
    desc: "Bridges, dams, and large-scale civil projects demanding extreme engineering precision and massive material handling.",
    icon: Construction
  },
  {
    title: "Factory & Facility Build-out",
    desc: "Rapid scaling of production floors. We construct robust shells and coordinate complex internal mechanical and electrical routing.",
    icon: Hammer
  },
  {
    title: "Civil & Structural Engineering",
    desc: "In-house structural design ensuring every I-beam and footing meets extreme stress tolerances and local safety codes.",
    icon: Compass
  },
  {
    title: "Demolition & Site Clearing",
    desc: "Controlled teardown of massive structures. We safely clear massive concrete and steel impediments to prepare raw sites.",
    icon: Pickaxe
  },
  {
    title: "Specialized Equipment Installation",
    desc: "Precision placement of multi-ton turbines, generators, and manufacturing lines using heavy-lift rigging and custom transport.",
    icon: Settings
  }
];

export function Services() {
  const container = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!container.current) return;
    
    const cards = container.current.querySelectorAll('.service-card');
    
    gsap.from(cards, {
      y: 50,
      opacity: 0,
      duration: 0.8,
      stagger: 0.1,
      ease: "power3.out",
      scrollTrigger: {
        trigger: container.current,
        start: "top 75%",
      }
    });
  }, { scope: container });

  return (
    <section id="services" ref={container} className="py-32 bg-card relative z-10 -mt-[4vw] clip-diagonal texture-noise">
      <div className="container mx-auto px-4 md:px-8">
        
        <div className="mb-16">
          <h2 className="text-4xl md:text-6xl font-display text-foreground mb-4">
            <span className="text-primary orange-bracket">Core</span> Capabilities
          </h2>
          <div className="w-24 h-2 bg-primary mb-6" />
          <p className="text-xl text-muted-foreground font-condensed max-w-2xl">
            We operate in environments where failure is not an option. Our specialized divisions handle every phase of heavy industrial development.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, idx) => (
            <div 
              key={idx} 
              className="service-card bolted-corner bg-muted border-2 border-border p-8 hover:border-primary/50 transition-colors group"
            >
              <div className="mb-6 inline-block p-4 bg-background border border-border text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors clip-diagonal-top">
                <service.icon size={32} strokeWidth={1.5} />
              </div>
              <h3 className="text-2xl font-display text-foreground mb-4 uppercase tracking-wider">{service.title}</h3>
              <p className="text-muted-foreground font-sans leading-relaxed">
                {service.desc}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
