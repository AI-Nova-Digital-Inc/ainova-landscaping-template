import { useRef } from "react";
import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ArrowRight } from "lucide-react";

export function Hero() {
  const container = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const gearRef = useRef<SVGSVGElement>(null);

  useGSAP(() => {
    const tl = gsap.timeline();

    // Headline stagger
    if (headlineRef.current) {
      const chars = headlineRef.current.querySelectorAll('.char');
      tl.from(chars, {
        y: 100,
        opacity: 0,
        rotationX: -90,
        stagger: 0.05,
        duration: 1,
        ease: "power4.out",
        delay: 0.2
      });
    }

    // Subtitle & CTA fade up
    tl.from('.hero-fade-up', {
      y: 30,
      opacity: 0,
      duration: 0.8,
      stagger: 0.2,
      ease: "power2.out"
    }, "-=0.5");

    // Gear continuous rotation
    if (gearRef.current) {
      gsap.to(gearRef.current, {
        rotation: 360,
        duration: 20,
        repeat: -1,
        ease: "none"
      });
    }
  }, { scope: container });

  return (
    <section 
      ref={container} 
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background pt-20 clip-diagonal"
    >
      {/* Background Texture & Overlay */}
      <div className="absolute inset-0 texture-grid opacity-20 pointer-events-none" />
      <div className="absolute inset-0 texture-noise pointer-events-none" />
      <div className="absolute inset-0 bg-gradient-to-b from-background/50 to-background pointer-events-none" />
      
      {/* Animated Graphic */}
      <div className="absolute right-[-10%] top-1/2 -translate-y-1/2 opacity-10 pointer-events-none text-primary">
        <svg 
          ref={gearRef}
          width="800" 
          height="800" 
          viewBox="0 0 100 100" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="2"
        >
          <path d="M50 15 L50 5 M50 95 L50 85 M15 50 L5 50 M95 50 L85 50 M25.25 25.25 L18.18 18.18 M74.75 74.75 L81.82 81.82 M25.25 74.75 L18.18 81.82 M74.75 25.25 L81.82 18.18" strokeWidth="4" />
          <circle cx="50" cy="50" r="30" />
          <circle cx="50" cy="50" r="20" strokeDasharray="4 4" />
          <circle cx="50" cy="50" r="10" />
        </svg>
      </div>

      <div className="container mx-auto px-4 md:px-8 relative z-10 flex flex-col md:flex-row items-center">
        <div className="max-w-4xl">
          <div className="inline-block px-4 py-1 border border-primary text-primary font-condensed text-xl uppercase tracking-widest mb-6 hero-fade-up bg-primary/10">
            Industrial Contractors
          </div>
          
          <h1 
            ref={headlineRef}
            className="text-6xl md:text-8xl lg:text-9xl font-display text-foreground leading-[0.85] tracking-tight mb-8"
          >
            <span className="block overflow-hidden"><span className="char inline-block">W</span><span className="char inline-block">E</span> <span className="char inline-block">D</span><span className="char inline-block">O</span><span className="char inline-block">N</span><span className="char inline-block">'</span><span className="char inline-block">T</span></span>
            <span className="block overflow-hidden"><span className="char inline-block">B</span><span className="char inline-block">U</span><span className="char inline-block">I</span><span className="char inline-block">L</span><span className="char inline-block">D</span><span className="char inline-block">.</span></span>
            <span className="block text-primary overflow-hidden"><span className="char inline-block">W</span><span className="char inline-block">E</span> <span className="char inline-block">F</span><span className="char inline-block">O</span><span className="char inline-block">R</span><span className="char inline-block">G</span><span className="char inline-block">E</span><span className="char inline-block">.</span></span>
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground font-condensed max-w-2xl mb-12 hero-fade-up">
            Massive scale. Tight tolerances. Total stakes. We engineer and construct the heavy infrastructure that powers the modern world.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 hero-fade-up">
            <a 
              href="#projects" 
              className="group flex items-center justify-center gap-3 px-8 py-4 bg-primary text-primary-foreground font-display text-2xl uppercase tracking-widest hover:bg-primary/90 transition-all clip-diagonal-top"
            >
              View Projects
              <ArrowRight className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a 
              href="#contact" 
              className="flex items-center justify-center px-8 py-4 border-2 border-border text-foreground font-display text-2xl uppercase tracking-widest hover:bg-muted transition-colors clip-diagonal-top"
            >
              Request Bid
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
