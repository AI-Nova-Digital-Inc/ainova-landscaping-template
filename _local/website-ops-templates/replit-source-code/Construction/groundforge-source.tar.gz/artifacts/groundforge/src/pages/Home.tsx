import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Hero } from "@/sections/Hero";
import { Services } from "@/sections/Services";
import { Projects } from "@/sections/Projects";
import { Safety } from "@/sections/Safety";
import { Equipment } from "@/sections/Equipment";
import { Contact } from "@/sections/Contact";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <Services />
        <Projects />
        <Safety />
        <Equipment />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
