import { useRef } from "react";
import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

import proj1 from "@/assets/images/project-1.png";
import proj2 from "@/assets/images/project-2.png";
import proj3 from "@/assets/images/project-3.png";
import proj4 from "@/assets/images/project-4.png";
import proj5 from "@/assets/images/project-5.png";
import proj6 from "@/assets/images/project-6.png";

gsap.registerPlugin(ScrollTrigger);

const projects = [
  {
    name: "Apex Steel Mill Expansion",
    location: "Gary, IN",
    scope: "Structural Steel, Concrete Foundations",
    image: proj1,
  },
  {
    name: "Titan Hydro Facility",
    location: "Boulder City, CO",
    scope: "Heavy Infrastructure, Concrete Pour",
    image: proj2,
  },
  {
    name: "Ironclad Logistics Hub",
    location: "Dallas, TX",
    scope: "Site Clearing, Warehouse Build-out",
    image: proj3,
  },
  {
    name: "Vulcan Chemical Plant",
    location: "Baton Rouge, LA",
    scope: "Specialized Equipment, Piping",
    image: proj4,
  },
  {
    name: "Goliath Demolition Project",
    location: "Detroit, MI",
    scope: "Controlled Demolition, Salvage",
    image: proj5,
  },
  {
    name: "Aegis Power Station",
    location: "Phoenix, AZ",
    scope: "Turbine Installation, Electrical",
    image: proj6,
  }
];

export function Projects() {
  const container = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    if (!container.current) return;
    
    const items = container.current.querySelectorAll('.project-item');
    
    gsap.from(items, {
      y: 60,
      opacity: 0,
      duration: 1,
      stagger: 0.15,
      ease: "power3.out",
      scrollTrigger: {
        trigger: container.current,
        start: "top 60%",
      }
    });
  }, { scope: container });

  return (
    <section id="projects" ref={container} className="py-32 bg-background relative z-20 -mt-[4vw] clip-diagonal texture-grid">
      <div className="absolute inset-0 bg-background/80" />
      
      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="mb-16 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h2 className="text-4xl md:text-6xl font-display text-foreground mb-4">
              <span className="text-primary orange-bracket">Proven</span> Ground
            </h2>
            <div className="w-24 h-2 bg-primary mb-6" />
            <p className="text-xl text-muted-foreground font-condensed max-w-xl">
              Our portfolio speaks in tons of steel erected and cubic yards of concrete poured. Recent heavy industrial completions.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {projects.map((proj, idx) => (
            <div 
              key={idx} 
              className="project-item relative group overflow-hidden border-4 border-border hover:border-primary transition-colors duration-500 bg-muted aspect-[4/3] bolted-corner"
            >
              <img 
                src={proj.image} 
                alt={proj.name} 
                className="w-full h-full object-cover opacity-60 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700"
              />
              
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-300" />
              
              <div className="absolute inset-0 p-6 flex flex-col justify-end translate-y-8 group-hover:translate-y-0 transition-transform duration-300">
                <p className="text-primary font-condensed text-lg uppercase tracking-widest mb-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100">
                  {proj.location}
                </p>
                <h3 className="text-3xl font-display text-foreground uppercase tracking-wider mb-2">
                  {proj.name}
                </h3>
                <div className="w-12 h-1 bg-primary mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-200" />
                <p className="text-muted-foreground font-sans text-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-300">
                  <strong className="text-foreground">Scope:</strong> {proj.scope}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
