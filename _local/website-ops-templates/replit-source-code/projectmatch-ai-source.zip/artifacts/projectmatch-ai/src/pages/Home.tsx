import React, { useState, useEffect } from 'react';
import { Hero } from '@/components/Hero';
import { InputPanel } from '@/components/InputPanel';
import { AnalysisPanel } from '@/components/AnalysisPanel';
import { ProjectCard } from '@/components/ProjectCard';
import { TechStackPanel } from '@/components/TechStackPanel';
import { RoadmapPanel } from '@/components/RoadmapPanel';
import { PortfolioPositioning } from '@/components/PortfolioPositioning';
import { SavedProjectsSidebar } from '@/components/SavedProjectsSidebar';
import { ExportControls } from '@/components/ExportControls';
import { AnimatedGrid } from '@/components/AnimatedGrid';
import { analyzeJobPosting } from '@/lib/analyzer';
import { AnalysisResult, ProjectRecommendation } from '@/types';
import { motion } from 'framer-motion';

export default function Home() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [savedProjects, setSavedProjects] = useState<ProjectRecommendation[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('projectmatch_saved');
    if (saved) {
      try {
        setSavedProjects(JSON.parse(saved));
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  const handleAnalyze = async (text: string, platform: string) => {
    setIsAnalyzing(true);
    setResult(null);
    try {
      const res = await analyzeJobPosting(text, platform);
      setResult(res);
      // Scroll slightly to reveal results after a short delay
      setTimeout(() => {
        document.getElementById('results-area')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    } catch (error) {
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSaveProject = (project: ProjectRecommendation) => {
    if (savedProjects.some(p => p.id === project.id)) return;
    const newSaved = [...savedProjects, project];
    setSavedProjects(newSaved);
    localStorage.setItem('projectmatch_saved', JSON.stringify(newSaved));
  };

  const handleRemoveSaved = (id: string) => {
    const newSaved = savedProjects.filter(p => p.id !== id);
    setSavedProjects(newSaved);
    localStorage.setItem('projectmatch_saved', JSON.stringify(newSaved));
  };

  return (
    <div className="min-h-[100dvh] bg-background text-foreground relative pb-32">
      <AnimatedGrid />
      
      <main className="relative z-10 flex flex-col gap-12 md:gap-24">
        <Hero />
        
        <InputPanel onAnalyze={handleAnalyze} isAnalyzing={isAnalyzing} />

        <div id="results-area" className="w-full flex flex-col gap-12 md:gap-16 pb-12">
          {result && (
            <>
              <AnalysisPanel analysis={result.analysis} />
              
              <section className="max-w-4xl mx-auto px-4 w-full">
                <div className="mb-8">
                  <h2 className="text-2xl md:text-3xl font-bold font-display text-foreground mb-2">Project Blueprints</h2>
                  <p className="text-muted-foreground">Tailored ideas based on detected skills and tools.</p>
                </div>
                <div className="grid grid-cols-1 gap-6">
                  {result.recommendations.map((rec, i) => (
                    <ProjectCard 
                      key={rec.id} 
                      project={rec} 
                      index={i}
                      onSave={handleSaveProject}
                      isSaved={savedProjects.some(p => p.id === rec.id)}
                    />
                  ))}
                </div>
              </section>

              <section className="max-w-4xl mx-auto px-4 w-full">
                <TechStackPanel techStack={result.techStack} />
              </section>

              <section className="max-w-4xl mx-auto px-4 w-full">
                <RoadmapPanel roadmap={result.roadmap} />
              </section>

              <section className="max-w-4xl mx-auto px-4 w-full">
                <PortfolioPositioning positioning={result.positioning} />
              </section>
            </>
          )}

          {!result && !isAnalyzing && (
            <div className="max-w-4xl mx-auto px-4 w-full text-center py-20 opacity-50">
              <div className="w-24 h-24 border border-dashed border-muted rounded-full mx-auto mb-6 flex items-center justify-center">
                <div className="w-2 h-2 bg-muted rounded-full" />
              </div>
              <p className="text-muted-foreground max-w-sm mx-auto">
                Waiting for input. Paste a job description above to generate your portfolio blueprint.
              </p>
            </div>
          )}
        </div>
      </main>

      <SavedProjectsSidebar savedProjects={savedProjects} onRemove={handleRemoveSaved} />
      <ExportControls result={result} />

      <footer className="absolute bottom-0 w-full py-6 text-center text-sm text-muted-foreground border-t border-white/5">
        ProjectMatch AI — Built for serious freelancers
      </footer>
    </div>
  );
}
