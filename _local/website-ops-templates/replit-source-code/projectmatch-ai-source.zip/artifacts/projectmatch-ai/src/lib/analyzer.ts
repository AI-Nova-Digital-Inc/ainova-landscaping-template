import type { AnalysisResult, JobAnalysis, ProjectRecommendation, TechStackBreakdown, RoadmapPhase, PortfolioPositioning } from '../types';

const t = (text: string) => text.toLowerCase();

function detect(text: string, keywords: string[]): boolean {
  return keywords.some(k => t(text).includes(t(k)));
}

function extractMentionedTools(text: string, allTools: string[]): string[] {
  return allTools.filter(tool => t(text).includes(t(tool)));
}

function scoreOpportunity(matchCount: number, baseScore: number): number {
  return Math.min(100, baseScore + matchCount * 2);
}

// ─── Role detection ───────────────────────────────────────────────────────────

function detectRole(text: string): string {
  const tl = t(text);

  if (detect(text, ['llmops', 'llm ops', 'llm pipeline', 'llm deployment', 'prompt engineering', 'langchain', 'llamaindex', 'llama index', 'vector database', 'vector db', 'rag pipeline', 'retrieval augmented', 'fine-tuning', 'finetuning', 'fine tuning']))
    return 'LLMOps / AI Engineer';

  if (detect(text, ['mlops', 'ml ops', 'ml pipeline', 'model serving', 'model deployment', 'feature store', 'mlflow', 'kubeflow', 'feast', 'model registry', 'model monitoring', 'data drift', 'model drift']))
    return 'MLOps Engineer';

  if (detect(text, ['generative ai', 'gen ai', 'genai', 'stable diffusion', 'image generation', 'text generation', 'gpt', 'openai', 'anthropic', 'gemini', 'multimodal', 'diffusion model']))
    return 'Generative AI Engineer';

  if (detect(text, ['machine learning', 'deep learning', 'neural network', 'tensorflow', 'pytorch', 'keras', 'scikit-learn', 'sklearn', 'xgboost', 'lightgbm', 'model training', 'classification', 'regression', 'nlp', 'computer vision', 'object detection', 'time series']))
    return 'Machine Learning Engineer';

  if (detect(text, ['data scientist', 'data science', 'statistical analysis', 'hypothesis testing', 'a/b testing', 'predictive modeling', 'feature engineering', 'eda', 'exploratory data']))
    return 'Data Scientist';

  if (detect(text, ['data analyst', 'data analysis', 'sql', 'tableau', 'power bi', 'looker', 'business intelligence', 'bi developer', 'reporting', 'dashboard', 'kpi', 'data visualization', 'excel', 'google analytics', 'dbt', 'data modeling']))
    return 'Data Analyst';

  if (detect(text, ['data engineer', 'data pipeline', 'etl', 'elt', 'apache spark', 'airflow', 'kafka', 'flink', 'databricks', 'snowflake', 'bigquery', 'redshift', 'data warehouse', 'data lake', 'delta lake', 'iceberg']))
    return 'Data Engineer';

  if (detect(text, ['sre', 'site reliability', 'platform engineer', 'infrastructure engineer', 'observability', 'slo', 'sli', 'error budget', 'chaos engineering', 'incident response', 'on-call', 'pagerduty', 'runbook']))
    return 'SRE / Platform Engineer';

  if (detect(text, ['devops', 'ci/cd', 'continuous integration', 'continuous delivery', 'continuous deployment', 'docker', 'kubernetes', 'k8s', 'helm', 'terraform', 'ansible', 'jenkins', 'github actions', 'gitlab ci', 'argocd', 'gitops']))
    return 'DevOps Engineer';

  if (detect(text, ['cloud engineer', 'aws', 'azure', 'gcp', 'google cloud', 'cloud architect', 'solutions architect', 'cloud infrastructure', 'iam', 'vpc', 'lambda', 'serverless', 'cloud formation', 'pulumi']))
    return 'Cloud / Infrastructure Engineer';

  return 'Software Engineer';
}

// ─── Skill & tool banks ───────────────────────────────────────────────────────

const ALL_TOOLS = [
  // DevOps / Cloud
  'Docker', 'Kubernetes', 'Helm', 'Terraform', 'Ansible', 'Pulumi', 'CloudFormation',
  'GitHub Actions', 'GitLab CI', 'Jenkins', 'CircleCI', 'ArgoCD', 'Flux', 'Spinnaker',
  'AWS', 'Azure', 'GCP', 'Google Cloud', 'DigitalOcean', 'Cloudflare',
  'Prometheus', 'Grafana', 'Datadog', 'New Relic', 'PagerDuty', 'Splunk', 'ELK', 'Loki',
  'Istio', 'Linkerd', 'Envoy', 'Nginx', 'Traefik',
  'Vault', 'Consul', 'etcd',
  // MLOps
  'MLflow', 'Kubeflow', 'Feast', 'Seldon', 'BentoML', 'Ray', 'Weights & Biases', 'DVC', 'ClearML', 'ZenML',
  'Triton', 'TorchServe', 'TFServing',
  // LLM / GenAI
  'LangChain', 'LlamaIndex', 'OpenAI', 'Anthropic', 'Claude', 'GPT-4', 'Gemini', 'Mistral', 'Llama', 'Ollama',
  'Pinecone', 'Weaviate', 'Chroma', 'Qdrant', 'Milvus', 'FAISS',
  'Hugging Face', 'Transformers', 'PEFT', 'LoRA', 'vLLM', 'TGI',
  // ML / Data Science
  'TensorFlow', 'PyTorch', 'Keras', 'scikit-learn', 'XGBoost', 'LightGBM', 'CatBoost',
  'Pandas', 'NumPy', 'Matplotlib', 'Seaborn', 'Plotly',
  // Data Engineering
  'Apache Spark', 'Airflow', 'Kafka', 'Flink', 'dbt', 'Databricks', 'Snowflake', 'BigQuery',
  'Redshift', 'Delta Lake', 'Iceberg', 'Hudi', 'Fivetran', 'Airbyte', 'Great Expectations',
  // Data Analysis / BI
  'Tableau', 'Power BI', 'Looker', 'Metabase', 'Superset', 'Google Analytics',
  // Backend / General
  'Python', 'FastAPI', 'Flask', 'Node.js', 'Go', 'Rust', 'Java', 'PostgreSQL', 'Redis', 'MongoDB',
  'GraphQL', 'gRPC', 'REST API',
  // Frontend
  'React', 'TypeScript', 'Next.js',
];

const ALL_SKILLS_BY_ROLE: Record<string, string[]> = {
  'LLMOps / AI Engineer': ['Prompt Engineering', 'RAG Pipelines', 'Vector Databases', 'LLM Fine-tuning', 'LangChain', 'LlamaIndex', 'Model Evaluation', 'Context Window Management', 'Embeddings', 'Token Optimization', 'Agent Design', 'Tool Calling'],
  'MLOps Engineer': ['Model Serving', 'CI/CD for ML', 'Feature Stores', 'Model Monitoring', 'Data Drift Detection', 'A/B Testing Models', 'Model Registry', 'Pipeline Orchestration', 'Infrastructure as Code', 'Containerization'],
  'Generative AI Engineer': ['Diffusion Models', 'Transformer Architecture', 'Prompt Engineering', 'Image Generation', 'Text Generation', 'Multimodal AI', 'Fine-tuning', 'RLHF', 'Model Distillation', 'AI Safety'],
  'Machine Learning Engineer': ['Model Training', 'Feature Engineering', 'Hyperparameter Tuning', 'Cross-validation', 'NLP', 'Computer Vision', 'Time Series', 'Ensemble Methods', 'Transfer Learning', 'Model Optimization'],
  'Data Scientist': ['Statistical Modeling', 'A/B Testing', 'Hypothesis Testing', 'EDA', 'Predictive Modeling', 'Clustering', 'Dimensionality Reduction', 'Causal Inference', 'Bayesian Methods'],
  'Data Analyst': ['SQL', 'Data Visualization', 'Dashboard Design', 'KPI Tracking', 'Business Intelligence', 'ETL Basics', 'Excel / Sheets', 'Storytelling with Data', 'Cohort Analysis', 'Funnel Analysis'],
  'Data Engineer': ['ETL / ELT Pipelines', 'Streaming Data', 'Batch Processing', 'Data Modeling', 'Schema Design', 'Data Quality', 'Orchestration', 'Data Lakehouse', 'CDC', 'Partitioning Strategies'],
  'SRE / Platform Engineer': ['Observability', 'SLO/SLI Design', 'Incident Response', 'Chaos Engineering', 'Capacity Planning', 'Distributed Systems', 'Error Budgets', 'Runbook Automation', 'Platform Engineering'],
  'DevOps Engineer': ['CI/CD Pipelines', 'Container Orchestration', 'Infrastructure as Code', 'GitOps', 'Secret Management', 'Blue-Green Deployments', 'Canary Releases', 'Log Aggregation', 'Security Scanning', 'Cost Optimization'],
  'Cloud / Infrastructure Engineer': ['Cloud Architecture', 'IAM & Security', 'Networking / VPC', 'Serverless', 'Cost Optimization', 'Multi-cloud Strategy', 'Disaster Recovery', 'High Availability', 'Load Balancing'],
  'Software Engineer': ['API Design', 'System Design', 'Testing', 'Performance Optimization', 'Database Design', 'Documentation'],
};

// ─── Project template banks ───────────────────────────────────────────────────

const PROJECT_TEMPLATES: Record<string, ProjectRecommendation[]> = {
  'LLMOps / AI Engineer': [
    {
      id: 'llm-1',
      title: 'Production RAG System with Evaluation Framework',
      matchReason: 'Directly demonstrates RAG pipeline design, vector search, and LLM orchestration — the core skills requested.',
      problemSolved: 'Businesses cannot trust LLM answers without a structured retrieval layer and accuracy tracking.',
      targetClient: 'Enterprise teams needing reliable document Q&A or knowledge base assistants.',
      techStack: ['LangChain', 'LlamaIndex', 'Pinecone', 'OpenAI / Claude', 'FastAPI', 'Docker'],
      featuresToBuild: ['Document ingestion pipeline', 'Chunking and embedding strategy', 'Semantic + hybrid search', 'Answer evaluation with RAGAS', 'Hallucination detection layer', 'REST API wrapper'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 96,
      demoHighlights: ['Upload a PDF and ask questions in real-time', 'Show hallucination score per answer', 'Compare retrieval strategies side by side'],
      readmeOutline: ['Architecture Overview', 'Chunking Strategy Explained', 'Embedding Model Choice', 'Evaluation Metrics', 'Deployment Guide'],
      resumeBullet: 'Built a production RAG system with RAGAS evaluation achieving 91% answer faithfulness on internal knowledge base.',
      proposalAngle: "I saw you need LLM pipeline experience. I built a RAG system from scratch with evaluation metrics — I can walk you through it before we start.",
    },
    {
      id: 'llm-2',
      title: 'LLM Fine-tuning Pipeline with LoRA / PEFT',
      matchReason: 'Shows you can adapt foundation models to domain-specific tasks — a high-value differentiator.',
      problemSolved: 'Generic LLMs perform poorly on specialized business tasks like legal drafting, medical notes, or code review.',
      targetClient: 'Companies needing domain-specific AI with controlled costs.',
      techStack: ['Hugging Face', 'PEFT', 'LoRA', 'PyTorch', 'Weights & Biases', 'AWS / GCP'],
      featuresToBuild: ['Dataset preparation and formatting', 'LoRA adapter training', 'Evaluation with perplexity and BLEU', 'Model checkpointing', 'Inference API', 'Cost vs accuracy tradeoff dashboard'],
      difficulty: 'Expert',
      estimatedBuildTime: '3–4 weeks',
      portfolioValueScore: 94,
      demoHighlights: ['Compare base model vs fine-tuned on same prompt', 'Show training loss curves in W&B', 'Benchmark inference latency'],
      readmeOutline: ['Dataset Format', 'Training Config', 'Evaluation Results', 'Inference Examples', 'Cost Analysis'],
      resumeBullet: 'Fine-tuned Llama-3 on domain-specific dataset using LoRA, reducing inference cost by 60% vs GPT-4.',
      proposalAngle: "Fine-tuning is exactly what your use case needs over prompt engineering. I have a complete pipeline I can adapt for your domain.",
    },
    {
      id: 'llm-3',
      title: 'AI Agent with Tool Calling and Memory',
      matchReason: 'Demonstrates multi-step reasoning, tool orchestration, and persistent memory — trending LLMOps requirement.',
      problemSolved: 'Single-turn LLMs cannot complete complex multi-step tasks autonomously.',
      targetClient: 'Ops teams wanting AI automation for repetitive workflows.',
      techStack: ['LangChain', 'OpenAI / Claude', 'Redis', 'FastAPI', 'PostgreSQL', 'Docker'],
      featuresToBuild: ['Tool registry (web search, code exec, API calls)', 'Conversation memory with summarization', 'Agent loop with retry logic', 'Streaming response API', 'Audit log of agent actions', 'Human-in-the-loop approval step'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 92,
      demoHighlights: ['Show agent completing a 5-step research task', 'Demonstrate memory recall across sessions', 'Show tool call trace in UI'],
      readmeOutline: ['Agent Architecture', 'Available Tools', 'Memory Strategy', 'Safety Guardrails', 'API Reference'],
      resumeBullet: 'Built a multi-tool AI agent with persistent memory, handling 15+ tool types and 100+ concurrent sessions.',
      proposalAngle: "Your workflow automation needs an agent, not just a chatbot. I have one built that I can show you immediately.",
    },
    {
      id: 'llm-4',
      title: 'LLM Observability and Prompt Management Platform',
      matchReason: 'Production LLM systems need tracing, cost tracking, and prompt versioning — this shows operational maturity.',
      problemSolved: 'Teams have no visibility into LLM costs, latency, or prompt regressions in production.',
      targetClient: 'AI product teams managing multiple LLM-powered features.',
      techStack: ['FastAPI', 'PostgreSQL', 'React', 'Prometheus', 'OpenTelemetry', 'Docker'],
      featuresToBuild: ['Request tracing with token counts', 'Prompt version control', 'Cost breakdown dashboard', 'Latency percentile tracking', 'Alerting on cost spikes', 'A/B prompt testing'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 90,
      demoHighlights: ['Show real-time cost tracking dashboard', 'Demo prompt A/B test results', 'Show latency heatmap by model'],
      readmeOutline: ['System Architecture', 'Metrics Collected', 'Dashboard Guide', 'Alerting Setup', 'SDK Integration'],
      resumeBullet: 'Built an LLM observability platform tracking 2M+ monthly tokens, reducing prompt-related regressions by 70%.',
      proposalAngle: "Once your LLM is in production, cost and quality visibility are critical. I built exactly that — let me show you.",
    },
  ],

  'MLOps Engineer': [
    {
      id: 'mlops-1',
      title: 'End-to-End ML Pipeline with Automated Retraining',
      matchReason: 'Demonstrates full ML lifecycle automation from data ingestion to model redeployment — the definition of MLOps.',
      problemSolved: 'Models go stale without automated monitoring and retraining triggers.',
      targetClient: 'ML teams managing models in production at scale.',
      techStack: ['MLflow', 'Airflow', 'Scikit-learn / PyTorch', 'FastAPI', 'Docker', 'AWS S3'],
      featuresToBuild: ['Data versioning with DVC', 'Training pipeline in Airflow', 'Experiment tracking in MLflow', 'Model registry with staging/prod environments', 'Data drift detection trigger', 'Automated retraining on drift', 'Canary deployment of new models'],
      difficulty: 'Expert',
      estimatedBuildTime: '3–4 weeks',
      portfolioValueScore: 97,
      demoHighlights: ['Simulate data drift and trigger auto-retrain', 'Show experiment comparison in MLflow UI', 'Demonstrate zero-downtime model swap'],
      readmeOutline: ['Pipeline Architecture', 'Drift Detection Logic', 'Retraining Trigger Config', 'Model Versioning Strategy', 'Rollback Procedure'],
      resumeBullet: 'Designed an automated MLOps pipeline with drift-triggered retraining, cutting manual intervention by 90%.',
      proposalAngle: "Your models will need continuous retraining. I built a full automated pipeline — I can adapt it to your stack in days.",
    },
    {
      id: 'mlops-2',
      title: 'Feature Store with Real-time and Batch Serving',
      matchReason: 'Feature stores are a core MLOps infrastructure component that directly matches the role requirements.',
      problemSolved: 'Training/serving skew and inconsistent feature computation across models.',
      targetClient: 'ML Platform teams supporting multiple data science teams.',
      techStack: ['Feast', 'Redis', 'PostgreSQL', 'Apache Kafka', 'FastAPI', 'Kubernetes'],
      featuresToBuild: ['Feature registry with versioning', 'Batch ingestion from data warehouse', 'Real-time feature computation via Kafka', 'Point-in-time correct retrieval', 'Feature monitoring for drift', 'Python SDK for feature access'],
      difficulty: 'Expert',
      estimatedBuildTime: '3–5 weeks',
      portfolioValueScore: 95,
      demoHighlights: ['Query same feature in batch vs real-time mode', 'Show point-in-time correct retrieval', 'Demonstrate feature reuse across 3 models'],
      readmeOutline: ['Feature Store Architecture', 'Ingestion Pipeline', 'Online vs Offline Stores', 'SDK Usage Guide', 'Monitoring Setup'],
      resumeBullet: 'Implemented a dual-mode feature store serving 50+ features across 8 production models with <10ms P99 latency.',
      proposalAngle: "Training/serving skew is the silent killer of ML systems. I built a feature store that eliminates it — let me walk you through.",
    },
    {
      id: 'mlops-3',
      title: 'Model Monitoring and Alerting System',
      matchReason: 'Production model observability is non-negotiable and directly listed in the job requirements.',
      problemSolved: 'Silent model degradation costs businesses revenue before anyone notices.',
      targetClient: 'Data science teams with models in production.',
      techStack: ['Evidently AI', 'Prometheus', 'Grafana', 'FastAPI', 'PostgreSQL', 'Docker'],
      featuresToBuild: ['Data drift metrics (PSI, KS test)', 'Prediction distribution tracking', 'Performance metric decay alerts', 'Grafana dashboards per model', 'PagerDuty / Slack alerts', 'Drift report generation'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 91,
      demoHighlights: ['Inject drift into dataset and trigger alert', 'Show Grafana model health dashboard', 'Generate automated drift report PDF'],
      readmeOutline: ['Monitoring Architecture', 'Drift Metrics Explained', 'Alert Thresholds', 'Dashboard Setup', 'Report Format'],
      resumeBullet: 'Built an ML model monitoring system detecting data drift across 12 production models with real-time Grafana dashboards.',
      proposalAngle: "Silent model degradation is the biggest untracked cost in ML. I have a monitoring system built that catches it early.",
    },
    {
      id: 'mlops-4',
      title: 'Kubernetes-based Model Serving Platform',
      matchReason: 'Scalable model serving on Kubernetes shows infrastructure-grade MLOps skills.',
      problemSolved: 'Data scientists cannot efficiently serve models at scale without platform engineering support.',
      targetClient: 'ML Platform teams needing self-service model deployment.',
      techStack: ['Kubernetes', 'Seldon Core / BentoML', 'Triton Inference Server', 'Helm', 'Prometheus', 'Istio'],
      featuresToBuild: ['Model packaging with BentoML', 'Kubernetes deployment manifests', 'Auto-scaling by request volume', 'Multi-model serving on GPU', 'Traffic splitting for A/B tests', 'Latency / throughput SLO dashboard'],
      difficulty: 'Expert',
      estimatedBuildTime: '3–4 weeks',
      portfolioValueScore: 93,
      demoHighlights: ['Deploy 3 models with a single CLI command', 'Show auto-scaling under load test', 'Demonstrate A/B traffic split with metrics'],
      readmeOutline: ['Platform Architecture', 'Model Packaging Guide', 'Helm Chart Reference', 'Scaling Policy', 'SLO Configuration'],
      resumeBullet: 'Deployed a Kubernetes model serving platform supporting 20+ models with P99 latency under 50ms at 1000 RPS.',
      proposalAngle: "Serving models reliably at scale is the hardest part of MLOps. I have a Kubernetes platform built for exactly this.",
    },
  ],

  'Generative AI Engineer': [
    {
      id: 'genai-1',
      title: 'Multi-modal AI Application (Text + Image)',
      matchReason: 'Multimodal capability is a core differentiator in GenAI engineering and matches the job requirements.',
      problemSolved: 'Businesses need AI that understands both text and images for real-world workflows.',
      targetClient: 'E-commerce, media, and content creation companies.',
      techStack: ['OpenAI GPT-4V / Claude', 'Stable Diffusion', 'FastAPI', 'React', 'AWS S3', 'Docker'],
      featuresToBuild: ['Image upload and understanding', 'Text-to-image generation', 'Image editing with prompts', 'Multi-turn visual conversations', 'Image metadata extraction', 'Batch processing pipeline'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 93,
      demoHighlights: ['Upload a product photo and generate ad copy', 'Edit image via natural language prompt', 'Show multi-turn image analysis conversation'],
      readmeOutline: ['Supported Models', 'API Reference', 'Multimodal Pipeline', 'Cost Per Request', 'Rate Limiting'],
      resumeBullet: 'Built a multimodal AI app processing 10k+ image+text requests/day for content generation workflows.',
      proposalAngle: "Multimodal AI is where the real product value lives right now. I built a working system I can show you today.",
    },
    {
      id: 'genai-2',
      title: 'AI Content Generation Pipeline with Quality Guardrails',
      matchReason: 'Production GenAI requires quality control, moderation, and consistency — all core GenAI engineering skills.',
      problemSolved: 'Raw LLM output is unpredictable — businesses need consistent, brand-safe, high-quality content at scale.',
      targetClient: 'Marketing, media, and publishing companies.',
      techStack: ['OpenAI / Claude / Mistral', 'LangChain', 'FastAPI', 'PostgreSQL', 'Redis', 'Docker'],
      featuresToBuild: ['Template-based prompt system', 'Output quality scoring', 'Content moderation layer', 'Brand voice enforcement', 'Batch generation with retry', 'Human review queue for flagged content'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 90,
      demoHighlights: ['Generate 50 product descriptions in one batch', 'Show quality score distribution', 'Flag and review low-quality outputs'],
      readmeOutline: ['Prompt Template System', 'Quality Scoring Logic', 'Moderation Pipeline', 'Batch API Reference', 'Review Queue UI'],
      resumeBullet: 'Built a content generation pipeline producing 50k+ weekly assets with 94% quality score and automated moderation.',
      proposalAngle: "Content at scale only works if quality is consistent. I have a guardrail system built that handles this end-to-end.",
    },
    {
      id: 'genai-3',
      title: 'Custom Chatbot with Persona and Memory',
      matchReason: 'Persona-driven, stateful chatbots are the most common GenAI product requirement.',
      problemSolved: 'Generic chatbots lose context and lack the personality needed for brand-specific customer interactions.',
      targetClient: 'SaaS companies, e-commerce, and customer support teams.',
      techStack: ['LangChain', 'OpenAI / Claude', 'Redis', 'PostgreSQL', 'FastAPI', 'React'],
      featuresToBuild: ['System prompt persona builder', 'Short-term + long-term memory', 'Knowledge base injection', 'Conversation handoff to human', 'Analytics on common queries', 'Embeddable widget'],
      difficulty: 'Intermediate',
      estimatedBuildTime: '1–2 weeks',
      portfolioValueScore: 87,
      demoHighlights: ['Show persona persistence across 10-turn conversation', 'Inject a knowledge base and ask domain questions', 'Trigger human handoff on low-confidence response'],
      readmeOutline: ['Persona Configuration', 'Memory Architecture', 'Knowledge Base Setup', 'Widget Embed Guide', 'Analytics Dashboard'],
      resumeBullet: 'Built a persona-driven chatbot with 3-tier memory achieving 88% user satisfaction in pilot deployment.',
      proposalAngle: "I noticed you need a chatbot that actually remembers context and stays on-brand. I have exactly that working right now.",
    },
  ],

  'Machine Learning Engineer': [
    {
      id: 'ml-1',
      title: 'End-to-End NLP Classification System',
      matchReason: 'Text classification is a foundational ML skill directly matching the NLP requirements in the posting.',
      problemSolved: 'Manual text categorization is slow, inconsistent, and unscalable.',
      targetClient: 'Customer support, legal, and compliance teams with high document volumes.',
      techStack: ['PyTorch', 'Hugging Face Transformers', 'FastAPI', 'PostgreSQL', 'Docker', 'Weights & Biases'],
      featuresToBuild: ['Data preprocessing pipeline', 'BERT/RoBERTa fine-tuning', 'Confidence score output', 'Active learning loop', 'Batch and real-time inference API', 'Performance monitoring'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 92,
      demoHighlights: ['Show confusion matrix on test set', 'Compare fine-tuned vs baseline accuracy', 'Process 1000 documents in batch demo'],
      readmeOutline: ['Dataset Preparation', 'Model Architecture', 'Training Config', 'Evaluation Results', 'API Reference'],
      resumeBullet: 'Fine-tuned RoBERTa classifier achieving 94.2% accuracy on 15-class document categorization task.',
      proposalAngle: "Your text classification problem is exactly what transformer fine-tuning solves. I have a working system with 94% accuracy to show you.",
    },
    {
      id: 'ml-2',
      title: 'Computer Vision Pipeline with Real-time Inference',
      matchReason: 'Vision models are directly mentioned in the job and show production-grade ML skills.',
      problemSolved: 'Manual image inspection is slow, expensive, and error-prone at scale.',
      targetClient: 'Manufacturing, retail, and healthcare companies with image analysis needs.',
      techStack: ['PyTorch', 'YOLOv8 / ResNet', 'OpenCV', 'FastAPI', 'Docker', 'ONNX'],
      featuresToBuild: ['Object detection with bounding boxes', 'Image classification endpoint', 'ONNX export for fast inference', 'Real-time video stream processing', 'Confidence threshold controls', 'Result visualization API'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 91,
      demoHighlights: ['Run real-time detection on webcam feed', 'Show model comparison (PyTorch vs ONNX speed)', 'Process 100 images in batch and export CSV'],
      readmeOutline: ['Model Architecture', 'Dataset Format', 'Inference Modes', 'Performance Benchmarks', 'Docker Deployment'],
      resumeBullet: 'Deployed computer vision pipeline with ONNX optimization achieving 3x inference speedup, serving 500 RPS.',
      proposalAngle: "Your image analysis workflow needs a real-time pipeline, not a notebook. I have one built with production inference speeds.",
    },
    {
      id: 'ml-3',
      title: 'Time Series Forecasting Platform',
      matchReason: 'Forecasting is one of the highest-value ML use cases and directly matches the skills requested.',
      problemSolved: 'Businesses make poor inventory, capacity, and financial decisions without reliable forecasts.',
      targetClient: 'Retail, fintech, and operations teams needing demand or metric forecasting.',
      techStack: ['Prophet', 'LightGBM', 'PyTorch (LSTM)', 'FastAPI', 'PostgreSQL', 'Grafana'],
      featuresToBuild: ['Multi-model forecasting (statistical + ML)', 'Anomaly detection in time series', 'Forecast confidence intervals', 'Backtesting framework', 'REST API with horizon parameter', 'Grafana forecast visualization'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 90,
      demoHighlights: ['Show 30/60/90 day forecast with confidence bands', 'Compare Prophet vs LightGBM accuracy', 'Trigger anomaly detection on simulated data'],
      readmeOutline: ['Supported Models', 'Input Data Format', 'Backtesting Results', 'API Reference', 'Grafana Setup'],
      resumeBullet: 'Built a multi-model forecasting platform improving demand prediction accuracy by 23% vs legacy statistical models.',
      proposalAngle: "Time series is tricky to get right. I have a multi-model platform with proper backtesting that I can adapt to your data.",
    },
    {
      id: 'ml-4',
      title: 'Recommendation System with A/B Testing Framework',
      matchReason: 'Recommendation engines are a high-value ML product that shows business impact alongside technical skill.',
      problemSolved: 'Generic content or product ordering reduces engagement and revenue.',
      targetClient: 'E-commerce, streaming, and media platforms.',
      techStack: ['Python', 'Surprise / PyTorch', 'FastAPI', 'Redis', 'PostgreSQL', 'Docker'],
      featuresToBuild: ['Collaborative filtering model', 'Content-based filtering', 'Hybrid ranking', 'Real-time user event ingestion', 'A/B experiment framework', 'Metrics dashboard (CTR, conversion)'],
      difficulty: 'Advanced',
      estimatedBuildTime: '3–4 weeks',
      portfolioValueScore: 93,
      demoHighlights: ['Show personalized recommendations for 3 user types', 'Run live A/B test and show metric difference', 'Demonstrate cold-start handling'],
      readmeOutline: ['Recommendation Algorithms', 'A/B Testing Design', 'Metric Definitions', 'API Reference', 'Cold Start Strategy'],
      resumeBullet: 'Built a hybrid recommendation engine increasing simulated CTR by 34% over baseline in controlled A/B test.',
      proposalAngle: "Recommendations with proper A/B testing infrastructure separate amateur from senior ML engineers. I have both built.",
    },
  ],

  'Data Scientist': [
    {
      id: 'ds-1',
      title: 'Customer Churn Prediction System with Business Dashboard',
      matchReason: 'Churn modeling is a universal high-value data science application that shows end-to-end skills.',
      problemSolved: 'Companies lose revenue to preventable churn because they have no early warning system.',
      targetClient: 'SaaS and subscription businesses.',
      techStack: ['Python', 'XGBoost', 'SHAP', 'FastAPI', 'Tableau / Metabase', 'PostgreSQL'],
      featuresToBuild: ['EDA and feature engineering', 'Model training with cross-validation', 'SHAP explainability layer', 'Risk score API', 'Business dashboard with churn cohorts', 'Intervention recommendation engine'],
      difficulty: 'Intermediate',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 89,
      demoHighlights: ['Show SHAP feature importance for a prediction', 'Compare at-risk vs healthy customer profiles', 'Demonstrate intervention ROI calculator'],
      readmeOutline: ['Problem Framing', 'Feature Engineering', 'Model Performance', 'SHAP Explanation', 'Business Dashboard Guide'],
      resumeBullet: 'Built churn prediction model with 87% recall, enabling proactive retention campaigns with projected $200K annual savings.',
      proposalAngle: "Churn prediction only delivers ROI when it connects to action. My system includes both the model and the intervention workflow.",
    },
    {
      id: 'ds-2',
      title: 'A/B Testing Framework with Statistical Rigor',
      matchReason: 'A/B testing design and analysis is explicitly requested and shows advanced statistical capability.',
      problemSolved: 'Teams run underpowered or misconfigured experiments and make wrong product decisions.',
      targetClient: 'Product, growth, and data teams at tech companies.',
      techStack: ['Python', 'Statsmodels', 'SciPy', 'PostgreSQL', 'Streamlit', 'Docker'],
      featuresToBuild: ['Power analysis and sample size calculator', 'Sequential testing with early stopping', 'Multiple comparison correction', 'Novelty effect detection', 'Segment breakdown analysis', 'Automated experiment report'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 91,
      demoHighlights: ['Design an experiment with power analysis', 'Run sequential test with peek probability', 'Generate automated stakeholder report'],
      readmeOutline: ['Statistical Methods', 'Experiment Design Guide', 'Sequential Testing Config', 'Report Format', 'API Reference'],
      resumeBullet: 'Built an A/B testing framework with proper sequential testing, eliminating 3 major false-positive product decisions.',
      proposalAngle: "Most A/B tests in practice are statistically invalid. I built a framework that handles this correctly — let me show you.",
    },
  ],

  'Data Analyst': [
    {
      id: 'da-1',
      title: 'Business Intelligence Dashboard with dbt + SQL Analytics',
      matchReason: 'End-to-end analytics engineering from raw data to insight is the core data analyst skill.',
      problemSolved: 'Stakeholders make decisions on stale, inconsistent data from disconnected reports.',
      targetClient: 'Operations, finance, and product teams at growth-stage companies.',
      techStack: ['dbt', 'PostgreSQL / BigQuery / Snowflake', 'Metabase / Superset', 'Python', 'Airflow'],
      featuresToBuild: ['dbt data model layer (staging, marts)', 'Automated data quality tests', 'KPI metrics layer', 'Executive dashboard in Metabase', 'Automated daily refresh pipeline', 'Anomaly alerting on key metrics'],
      difficulty: 'Intermediate',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 88,
      demoHighlights: ['Walk through dbt model lineage graph', 'Show automated data quality test results', 'Demonstrate executive dashboard with drill-down'],
      readmeOutline: ['Data Model Architecture', 'dbt Project Structure', 'Metric Definitions', 'Dashboard Setup', 'Refresh Pipeline'],
      resumeBullet: 'Built a dbt analytics layer standardizing 25+ KPIs, reducing analyst query time by 60% and eliminating metric discrepancies.',
      proposalAngle: "Inconsistent metrics are the #1 data trust issue I see. My dbt project solves that — I can adapt it to your data warehouse.",
    },
    {
      id: 'da-2',
      title: 'Product Analytics Funnel with Cohort Analysis',
      matchReason: 'Funnel and cohort analysis are the most requested analytical skills in data analyst roles.',
      problemSolved: 'Product teams cannot identify where users drop off or how retention trends by acquisition cohort.',
      targetClient: 'Product and growth teams at consumer apps and SaaS companies.',
      techStack: ['SQL', 'Python', 'Plotly / Streamlit', 'PostgreSQL', 'dbt'],
      featuresToBuild: ['Multi-step funnel definition', 'Time-to-convert analysis', 'Weekly/monthly cohort retention matrix', 'Segment comparison (device, plan, channel)', 'Export to CSV / PNG', 'Automated weekly report'],
      difficulty: 'Intermediate',
      estimatedBuildTime: '1–2 weeks',
      portfolioValueScore: 85,
      demoHighlights: ['Show funnel drop-off with statistical significance', 'Compare retention curves for 3 cohorts', 'Identify best-performing acquisition channel'],
      readmeOutline: ['Funnel Definition Format', 'Cohort Logic', 'Segment Parameters', 'Visualization Reference', 'Report Template'],
      resumeBullet: 'Built product analytics platform identifying 3 high-impact funnel drop-offs, directly informing features that improved D30 retention by 18%.',
      proposalAngle: "I noticed you need cohort and funnel work. I have a complete analytics system I can plug into your data warehouse this week.",
    },
    {
      id: 'da-3',
      title: 'Automated Reporting System with Anomaly Detection',
      matchReason: 'Automated reporting with alerts shows analytical engineering maturity beyond manual reporting.',
      problemSolved: 'Data teams spend hours on repetitive reporting instead of generating insights.',
      targetClient: 'Business operations and finance teams.',
      techStack: ['Python', 'PostgreSQL', 'Pandas', 'Plotly', 'Airflow', 'Slack API / Email'],
      featuresToBuild: ['Scheduled report generation', 'Statistical anomaly detection (Z-score, IQR)', 'Natural language narrative generation', 'Multi-format output (PDF, Slack, Email)', 'Interactive HTML report', 'Alert threshold configuration UI'],
      difficulty: 'Intermediate',
      estimatedBuildTime: '2 weeks',
      portfolioValueScore: 86,
      demoHighlights: ['Trigger anomaly alert on injected spike', 'Show auto-generated narrative in report', 'Demonstrate Slack notification with chart'],
      readmeOutline: ['Report Templates', 'Anomaly Detection Config', 'Scheduling Setup', 'Delivery Channels', 'Custom Narrative Templates'],
      resumeBullet: 'Built automated reporting system eliminating 15+ hours/week of manual analyst work with real-time anomaly alerting.',
      proposalAngle: "Your team shouldn't be making reports — they should be making decisions. I built automation that handles the reporting entirely.",
    },
  ],

  'Data Engineer': [
    {
      id: 'de-1',
      title: 'Real-time Streaming Data Pipeline',
      matchReason: 'Kafka-based streaming pipelines are the backbone of modern data engineering and match the role requirements.',
      problemSolved: 'Batch-only pipelines create data latency that makes analytics and ML systems unreliable.',
      targetClient: 'Fintech, e-commerce, and IoT companies needing real-time data.',
      techStack: ['Apache Kafka', 'Apache Flink / Spark Streaming', 'PostgreSQL', 'Redis', 'Docker', 'Kubernetes'],
      featuresToBuild: ['Kafka producer and consumer setup', 'Stream processing with windowing', 'Exactly-once delivery guarantees', 'Dead letter queue handling', 'Schema registry with Avro', 'Real-time metrics dashboard'],
      difficulty: 'Expert',
      estimatedBuildTime: '3–4 weeks',
      portfolioValueScore: 96,
      demoHighlights: ['Show real-time event processing at 10k events/sec', 'Demonstrate dead letter queue recovery', 'Show schema evolution without downtime'],
      readmeOutline: ['Architecture Diagram', 'Topic Design', 'Consumer Group Strategy', 'Schema Registry', 'Deployment Guide'],
      resumeBullet: 'Built Kafka streaming pipeline processing 500k events/day with exactly-once semantics and <500ms end-to-end latency.',
      proposalAngle: "Real-time data is the foundation your analytics and ML need. I built a production-grade streaming pipeline I can show you now.",
    },
    {
      id: 'de-2',
      title: 'Modern Data Lakehouse with Delta Lake / Iceberg',
      matchReason: 'Lakehouse architecture is the current gold standard in data engineering and directly matches the job.',
      problemSolved: 'Separate lakes and warehouses create data silos, quality issues, and high costs.',
      targetClient: 'Data-heavy companies modernizing their analytics infrastructure.',
      techStack: ['Apache Spark', 'Delta Lake / Iceberg', 'Airflow', 'dbt', 'AWS S3 / GCS', 'Trino'],
      featuresToBuild: ['Bronze / Silver / Gold medallion layers', 'Schema evolution with ACID guarantees', 'Time travel queries', 'Incremental processing with CDC', 'Data quality checks with Great Expectations', 'Unified SQL query layer'],
      difficulty: 'Expert',
      estimatedBuildTime: '4–5 weeks',
      portfolioValueScore: 95,
      demoHighlights: ['Show time travel query recovering deleted data', 'Demonstrate schema evolution without rewrite', 'Compare query performance vs raw Parquet'],
      readmeOutline: ['Lakehouse Architecture', 'Medallion Layer Design', 'CDC Strategy', 'Data Quality Rules', 'Query Access Patterns'],
      resumeBullet: 'Architected a Delta Lake lakehouse reducing query costs by 40% while enabling time-travel and ACID transactions.',
      proposalAngle: "Lakehouse architecture is what separates modern data platforms from legacy systems. I have one built end-to-end.",
    },
    {
      id: 'de-3',
      title: 'ELT Pipeline Orchestration with Airflow + dbt',
      matchReason: 'Airflow and dbt together are the most common data engineering production stack mentioned in job postings.',
      problemSolved: 'Ad-hoc data scripts are brittle, untested, and impossible to maintain at scale.',
      targetClient: 'Analytics engineering teams at scaling startups and enterprises.',
      techStack: ['Apache Airflow', 'dbt', 'Snowflake / BigQuery', 'Python', 'Docker', 'Great Expectations'],
      featuresToBuild: ['Modular DAG design with task dependencies', 'dbt model versioning and testing', 'Dynamic pipeline generation from config', 'Alerting on pipeline failures', 'Data lineage visualization', 'SLA monitoring and breach alerts'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 91,
      demoHighlights: ['Show DAG with 20+ tasks and dependency graph', 'Trigger a dbt test failure and alert', 'Visualize full data lineage from source to BI'],
      readmeOutline: ['DAG Architecture', 'dbt Project Structure', 'Alert Configuration', 'SLA Definitions', 'Local Development Setup'],
      resumeBullet: 'Designed Airflow + dbt pipeline orchestrating 40+ daily jobs with SLA monitoring and automated failure recovery.',
      proposalAngle: "Reliable pipelines need proper orchestration and testing, not cron jobs. I have a production-grade setup I can walk you through.",
    },
  ],

  'SRE / Platform Engineer': [
    {
      id: 'sre-1',
      title: 'Full Observability Stack with SLO Tracking',
      matchReason: 'SLO-based observability is the core SRE practice and directly matches the role requirements.',
      problemSolved: 'Teams react to outages instead of preventing them due to lack of structured observability.',
      targetClient: 'Engineering teams at scale-ups managing production microservices.',
      techStack: ['Prometheus', 'Grafana', 'Loki', 'OpenTelemetry', 'Kubernetes', 'PagerDuty'],
      featuresToBuild: ['Distributed tracing with OpenTelemetry', 'RED metrics per service (Rate, Error, Duration)', 'SLO definition and error budget dashboards', 'Log aggregation with structured queries', 'Alerting with runbook links', 'Incident timeline view'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 93,
      demoHighlights: ['Inject a service error and trace it end-to-end', 'Show error budget burn rate alert firing', 'Walk through an incident timeline reconstruction'],
      readmeOutline: ['Observability Architecture', 'SLO Definitions', 'Alert Runbooks', 'Dashboard Reference', 'Incident Response Process'],
      resumeBullet: 'Implemented full observability stack with SLO tracking across 15 microservices, reducing MTTR by 65%.',
      proposalAngle: "SRE is about structured reliability, not firefighting. I built an observability system that makes SLOs actionable — let me show you.",
    },
    {
      id: 'sre-2',
      title: 'Chaos Engineering Platform with Automated Game Days',
      matchReason: 'Chaos engineering shows senior-level SRE thinking about failure modes and system resilience.',
      problemSolved: 'Unknown failure modes cause preventable incidents in production.',
      targetClient: 'Engineering teams wanting to proactively test system resilience.',
      techStack: ['Chaos Monkey / Litmus Chaos', 'Kubernetes', 'Prometheus', 'Python', 'Grafana', 'Slack API'],
      featuresToBuild: ['Failure injection scenarios (pod kill, network partition, CPU stress)', 'Automated hypothesis validation', 'Blast radius controls', 'Real-time system health monitoring during experiment', 'Automated game day report', 'Slack notifications'],
      difficulty: 'Expert',
      estimatedBuildTime: '3–4 weeks',
      portfolioValueScore: 94,
      demoHighlights: ['Kill a pod and show system recovery time', 'Demonstrate blast radius limiter in action', 'Generate post-game-day report automatically'],
      readmeOutline: ['Experiment Catalog', 'Safety Controls', 'Hypothesis Template', 'Blast Radius Config', 'Report Format'],
      resumeBullet: 'Designed chaos engineering platform running 20+ automated game days, uncovering 8 critical failure modes before they hit production.',
      proposalAngle: "You can't know your system's limits until you test them deliberately. I built the platform that does this safely and automatically.",
    },
    {
      id: 'sre-3',
      title: 'Internal Developer Platform (IDP) with Self-Service Deployments',
      matchReason: 'Platform engineering / IDP is the evolution of SRE and shows infrastructure product thinking.',
      problemSolved: 'Engineering teams waste time on ops toil instead of shipping features.',
      targetClient: 'Platform engineering teams at companies with 20+ developers.',
      techStack: ['Backstage', 'Kubernetes', 'ArgoCD', 'Terraform', 'GitHub Actions', 'Vault'],
      featuresToBuild: ['Service catalog with ownership metadata', 'Self-service environment provisioning', 'GitOps deployment via ArgoCD', 'Secret injection from Vault', 'Cost attribution per team', 'Deployment history and rollback UI'],
      difficulty: 'Expert',
      estimatedBuildTime: '4–5 weeks',
      portfolioValueScore: 95,
      demoHighlights: ['Self-provision a new service in under 2 minutes', 'Show GitOps deployment and rollback flow', 'Demonstrate cost breakdown by team in dashboard'],
      readmeOutline: ['Platform Architecture', 'Self-Service Workflows', 'GitOps Flow', 'Secret Management', 'Cost Tracking Setup'],
      resumeBullet: 'Built an internal developer platform enabling self-service deployments, reducing engineering toil by 8 hours/developer/week.',
      proposalAngle: "Developer productivity is a force multiplier. I built an IDP that eliminates ops toil — let me show you the impact.",
    },
  ],

  'DevOps Engineer': [
    {
      id: 'devops-1',
      title: 'Production-Grade CI/CD Pipeline with Security Scanning',
      matchReason: 'CI/CD with integrated security is the highest-value DevOps skill and matches the job directly.',
      problemSolved: 'Manual deployments are slow, inconsistent, and ship vulnerabilities to production.',
      targetClient: 'Engineering teams wanting fast, secure, automated releases.',
      techStack: ['GitHub Actions / GitLab CI', 'Docker', 'Kubernetes', 'Trivy / Snyk', 'Terraform', 'AWS'],
      featuresToBuild: ['Multi-stage pipeline (test, build, scan, deploy)', 'Container image vulnerability scanning', 'SAST with CodeQL', 'Blue-green deployment strategy', 'Rollback on health check failure', 'Slack deployment notifications'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 94,
      demoHighlights: ['Push a commit and walk through the full pipeline', 'Inject a vulnerable dependency and show scan failure', 'Demonstrate blue-green cutover with zero downtime'],
      readmeOutline: ['Pipeline Architecture', 'Stage Definitions', 'Security Scan Config', 'Deployment Strategy', 'Rollback Procedure'],
      resumeBullet: 'Built DevSecOps pipeline with SAST and container scanning, blocking 15 critical vulnerabilities from reaching production.',
      proposalAngle: "I saw you need CI/CD experience. I have a full DevSecOps pipeline built — let me show you the security scanning step specifically.",
    },
    {
      id: 'devops-2',
      title: 'Kubernetes Multi-environment Infrastructure with GitOps',
      matchReason: 'Kubernetes and GitOps are explicitly mentioned in the job and represent production-grade DevOps.',
      problemSolved: 'Manual Kubernetes management leads to configuration drift and environment inconsistency.',
      targetClient: 'Engineering teams running microservices on Kubernetes.',
      techStack: ['Kubernetes', 'ArgoCD', 'Helm', 'Terraform', 'AWS EKS / GKE', 'Sealed Secrets'],
      featuresToBuild: ['Multi-environment cluster setup (dev/staging/prod)', 'GitOps with ArgoCD sync and auto-healing', 'Helm chart library for common services', 'RBAC and namespace isolation', 'Sealed Secrets for secret management', 'Cost optimization with Cluster Autoscaler'],
      difficulty: 'Expert',
      estimatedBuildTime: '3–4 weeks',
      portfolioValueScore: 95,
      demoHighlights: ['Manually break a deployment and show ArgoCD auto-heal', 'Promote a release from staging to prod via Git', 'Show cost savings from autoscaling'],
      readmeOutline: ['Cluster Architecture', 'ArgoCD Application Setup', 'Helm Chart Reference', 'RBAC Policy', 'Cost Optimization Guide'],
      resumeBullet: 'Designed GitOps Kubernetes platform across 3 environments, eliminating configuration drift and reducing cluster costs by 35%.',
      proposalAngle: "GitOps is how serious teams manage Kubernetes. I have a full multi-environment setup built that I can walk you through today.",
    },
    {
      id: 'devops-3',
      title: 'Terraform AWS Infrastructure with Modular Design',
      matchReason: 'Infrastructure as Code with Terraform on AWS is the most common DevOps requirement.',
      problemSolved: 'Manually provisioned infrastructure is inconsistent, unauditable, and hard to replicate.',
      targetClient: 'Teams needing reproducible, version-controlled cloud infrastructure.',
      techStack: ['Terraform', 'AWS', 'GitHub Actions', 'Terragrunt', 'tfsec', 'Atlantis'],
      featuresToBuild: ['Modular Terraform structure (VPC, ECS, RDS, S3)', 'Remote state with locking', 'Automated tfsec security scanning', 'Atlantis PR-based plan and apply', 'Multi-account structure', 'Cost estimation with Infracost'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 92,
      demoHighlights: ['Open a PR and show Atlantis plan comment', 'Show security scan catching an open S3 bucket', 'Provision full environment with one command'],
      readmeOutline: ['Module Structure', 'State Management', 'Security Scanning', 'PR Workflow', 'Cost Estimation'],
      resumeBullet: 'Built modular Terraform modules provisioning 50+ AWS resources with automated security scanning and cost estimation.',
      proposalAngle: "Terraform done right is modular, tested, and automated. I have a production-ready module library built for exactly this.",
    },
    {
      id: 'devops-4',
      title: 'DevSecOps Pipeline with Container and SAST Security',
      matchReason: 'Security-integrated DevOps is a growing requirement and differentiates senior DevOps engineers.',
      problemSolved: 'Security is bolted on at the end of development instead of integrated throughout.',
      targetClient: 'Companies with compliance requirements (SOC2, PCI, HIPAA).',
      techStack: ['GitHub Actions', 'Trivy', 'Snyk', 'OWASP ZAP', 'SonarQube', 'Docker', 'Kubernetes'],
      featuresToBuild: ['Dependency vulnerability scanning', 'Container image scanning in CI', 'SAST in pull request gate', 'DAST against staging environment', 'Security report artifact storage', 'Policy-as-code with OPA'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 91,
      demoHighlights: ['Show a PR blocked by critical CVE in dependency', 'Walk through full security report artifact', 'Demonstrate DAST scan against staging'],
      readmeOutline: ['Security Pipeline Stages', 'Tool Configuration', 'Severity Thresholds', 'Report Format', 'Policy-as-Code Rules'],
      resumeBullet: 'Built DevSecOps pipeline enforcing 5-stage security gates, achieving SOC2 compliance readiness in 6 weeks.',
      proposalAngle: "Shifting security left isn't optional anymore. I have a complete DevSecOps pipeline built that your compliance team will love.",
    },
  ],

  'Cloud / Infrastructure Engineer': [
    {
      id: 'cloud-1',
      title: 'Multi-region AWS Architecture with Disaster Recovery',
      matchReason: 'Multi-region design and DR show senior cloud engineering thinking that directly matches the job.',
      problemSolved: 'Single-region deployments are a single point of failure for business-critical systems.',
      targetClient: 'Companies with high availability requirements and global users.',
      techStack: ['AWS', 'Terraform', 'Route 53', 'RDS Multi-AZ', 'CloudFront', 'Lambda'],
      featuresToBuild: ['Active-passive multi-region setup', 'Automated failover with Route 53 health checks', 'RDS cross-region read replica promotion', 'CloudFront CDN with origin failover', 'RTO/RPO monitoring dashboard', 'Chaos test for regional failover'],
      difficulty: 'Expert',
      estimatedBuildTime: '3–4 weeks',
      portfolioValueScore: 96,
      demoHighlights: ['Simulate a region failure and show automatic failover', 'Show RTO measurement in monitoring dashboard', 'Walk through Terraform multi-region config'],
      readmeOutline: ['Architecture Diagram', 'Failover Sequence', 'RTO/RPO Targets', 'Testing Procedure', 'Cost Breakdown'],
      resumeBullet: 'Architected multi-region AWS infrastructure achieving 99.99% availability with <60 second RTO via automated failover.',
      proposalAngle: "Multi-region DR is complex to get right. I have a working architecture with measured RTO I can adapt to your requirements.",
    },
    {
      id: 'cloud-2',
      title: 'Cloud Cost Optimization Platform with FinOps Dashboard',
      matchReason: 'Cloud cost management is a critical skill for cloud engineers and often overlooked in portfolios.',
      problemSolved: 'Cloud bills grow uncontrolled without visibility and automated optimization.',
      targetClient: 'Engineering and finance teams at companies spending $50k+/month on cloud.',
      techStack: ['AWS Cost Explorer API', 'Python', 'Grafana', 'Terraform', 'Lambda', 'PostgreSQL'],
      featuresToBuild: ['Cost breakdown by service, team, and environment', 'Idle resource detection and termination', 'Reserved instance vs on-demand analysis', 'Budget alerts with Slack notifications', 'Rightsizing recommendations', 'Monthly executive report'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 90,
      demoHighlights: ['Show cost dashboard with team-level breakdown', 'Demonstrate idle resource detection finding savings', 'Generate monthly executive cost report'],
      readmeOutline: ['FinOps Architecture', 'Cost Attribution Strategy', 'Alert Configuration', 'Rightsizing Logic', 'Report Format'],
      resumeBullet: 'Built FinOps platform identifying $45K/month in cloud waste through idle resource detection and rightsizing recommendations.',
      proposalAngle: "Cloud cost is a business problem masquerading as a technical one. I built a platform that makes the savings visible and automatic.",
    },
    {
      id: 'cloud-3',
      title: 'Serverless Event-Driven Architecture on AWS',
      matchReason: 'Serverless and Lambda expertise is a core cloud engineering skill explicitly mentioned.',
      problemSolved: 'Traditional servers are over-provisioned and expensive for variable-traffic workloads.',
      targetClient: 'Startups and scale-ups wanting to minimize infrastructure management.',
      techStack: ['AWS Lambda', 'API Gateway', 'EventBridge', 'SQS', 'DynamoDB', 'Terraform', 'CDK'],
      featuresToBuild: ['Event-driven Lambda functions', 'API Gateway with auth layer', 'SQS dead letter queues', 'EventBridge rule routing', 'DynamoDB single-table design', 'X-Ray distributed tracing'],
      difficulty: 'Advanced',
      estimatedBuildTime: '2–3 weeks',
      portfolioValueScore: 89,
      demoHighlights: ['Show end-to-end event flow through EventBridge', 'Demonstrate DLQ recovery for failed events', 'Show X-Ray trace for a request'],
      readmeOutline: ['Architecture Diagram', 'Event Schema', 'Lambda Functions Reference', 'DLQ Strategy', 'Deployment with CDK'],
      resumeBullet: 'Built serverless event-driven architecture handling 1M+ daily events with 99.9% reliability and zero server management.',
      proposalAngle: "Serverless isn't just about cost — it's about operational simplicity. I have a production-grade event-driven architecture to show you.",
    },
  ],
};

// ─── Main analyzer ─────────────────────────────────────────────────────────────

export async function analyzeJobPosting(text: string, _platform: string): Promise<AnalysisResult> {
  await new Promise(resolve => setTimeout(resolve, 2000));

  const role = detectRole(text);
  const mentionedTools = extractMentionedTools(text, ALL_TOOLS);
  const roleSkills = ALL_SKILLS_BY_ROLE[role] || ALL_SKILLS_BY_ROLE['Software Engineer'];

  // Build required skills list from detected tools + role defaults
  const detectedSkills = mentionedTools.slice(0, 6);
  const requiredSkills = detectedSkills.length >= 3
    ? detectedSkills
    : [...detectedSkills, ...roleSkills.slice(0, 5 - detectedSkills.length)];

  // Detect difficulty
  const expertKeywords = ['production', 'scale', 'enterprise', 'architect', 'senior', 'lead', 'principal', 'staff', 'complex', 'large-scale'];
  const hasExpertSignals = detect(text, expertKeywords);
  const difficultyLevel = hasExpertSignals ? 'Expert' : 'High';

  // Detect budget
  const highBudgetKeywords = ['enterprise', 'senior', 'lead', 'architect', 'principal', '$', 'competitive', 'negotiable', 'top of market'];
  const budgetPotential = detect(text, highBudgetKeywords) ? 'High' : 'Medium';

  // Get role-specific project templates
  const templates = PROJECT_TEMPLATES[role] || PROJECT_TEMPLATES['DevOps Engineer'];

  // Score: more keyword matches = higher score
  const opportunityScore = scoreOpportunity(mentionedTools.length, 72);

  const analysis: JobAnalysis = {
    role,
    clientProblem: buildClientProblem(role),
    requiredSkills,
    toolsMentioned: mentionedTools.slice(0, 8),
    businessOutcome: buildBusinessOutcome(role),
    difficultyLevel,
    budgetPotential,
    opportunityScore,
  };

  const recommendations = templates.slice(0, 4);

  const techStack = buildTechStack(role, mentionedTools);
  const roadmap = buildRoadmap(role);
  const positioning = buildPositioning(role, recommendations[0]);

  return { analysis, recommendations, techStack, roadmap, positioning };
}

// ─── Content builders ──────────────────────────────────────────────────────────

function buildClientProblem(role: string): string {
  const map: Record<string, string> = {
    'LLMOps / AI Engineer': 'Needs a reliable, production-ready LLM system that delivers accurate, consistent, and auditable outputs at scale without hallucinations.',
    'MLOps Engineer': 'Struggling to move ML models from notebooks to production reliably — models go stale, pipelines break, and retraining is manual.',
    'Generative AI Engineer': 'Wants to leverage generative AI for content, automation, or UX but lacks the infrastructure for quality, safety, and scale.',
    'Machine Learning Engineer': 'Needs ML models that work reliably in production — not just in notebooks — with proper data pipelines and performance monitoring.',
    'Data Scientist': 'Making critical business decisions without reliable predictive models or statistical rigor, leading to poor outcomes and missed opportunities.',
    'Data Analyst': 'Teams are working with inconsistent data, slow ad-hoc queries, and disconnected dashboards — making aligned decisions is impossible.',
    'Data Engineer': 'Data pipelines are brittle, slow, and untested — analytics and ML teams are blocked because they cannot trust the data.',
    'SRE / Platform Engineer': 'System reliability is reactive — outages are discovered by customers, incidents drag on because there is no structured observability or runbook automation.',
    'DevOps Engineer': 'Deployments are manual, slow, and risky — engineers spend more time on ops than shipping features, and production incidents are frequent.',
    'Cloud / Infrastructure Engineer': 'Cloud infrastructure is expensive, inconsistent, and difficult to replicate — no IaC, no cost controls, and no DR plan.',
  };
  return map[role] || 'Needs scalable, reliable engineering infrastructure to support business growth without technical debt accumulating.';
}

function buildBusinessOutcome(role: string): string {
  const map: Record<string, string> = {
    'LLMOps / AI Engineer': 'Reduce LLM hallucination rates, cut prompt-to-production time, and build measurable trust in AI outputs across the organization.',
    'MLOps Engineer': 'Move from monthly manual model updates to continuous automated retraining with full audit trails and zero-downtime model swaps.',
    'Generative AI Engineer': 'Ship AI-powered features that are consistent, brand-safe, and scalable — turning AI from a demo into a production product.',
    'Machine Learning Engineer': 'ML models that generalize well, retrain automatically, and deliver measurable business KPI improvements.',
    'Data Scientist': 'Replace gut-feel decisions with statistically sound, model-driven insights that stakeholders trust and act on.',
    'Data Analyst': 'Single source of truth for all KPIs, with self-service dashboards and automated alerts replacing manual reporting cycles.',
    'Data Engineer': 'Reliable, tested, low-latency data pipelines that unblock analytics and ML teams and scale without manual intervention.',
    'SRE / Platform Engineer': 'Achieve defined SLOs with error budgets, reduce MTTR, and make reliability engineering proactive rather than reactive.',
    'DevOps Engineer': 'Deploy multiple times per day with zero-downtime releases, full audit trails, and automated rollback on failure.',
    'Cloud / Infrastructure Engineer': 'Fully automated, version-controlled infrastructure with cost visibility, multi-region resilience, and one-command environment provisioning.',
  };
  return map[role] || 'Faster, safer, and more reliable software delivery with full visibility into system health and cost.';
}

function buildTechStack(role: string, detected: string[]): TechStackBreakdown {
  const stacks: Record<string, TechStackBreakdown> = {
    'LLMOps / AI Engineer': {
      frontend: ['React', 'TypeScript', 'Streamlit'],
      backend: ['FastAPI', 'Python', 'LangChain', 'LlamaIndex'],
      database: ['PostgreSQL', 'Redis', 'Pinecone', 'Weaviate'],
      aiAutomation: ['OpenAI / Claude', 'Hugging Face', 'PEFT / LoRA', 'vLLM'],
      devopsCloud: ['Docker', 'Kubernetes', 'AWS / GCP'],
      deployment: ['GitHub Actions', 'ArgoCD', 'Helm'],
    },
    'MLOps Engineer': {
      frontend: ['Streamlit', 'Grafana', 'React'],
      backend: ['FastAPI', 'Python', 'Ray Serve'],
      database: ['PostgreSQL', 'Redis', 'S3 / GCS'],
      aiAutomation: ['MLflow', 'Kubeflow', 'Feast', 'Weights & Biases'],
      devopsCloud: ['Kubernetes', 'Docker', 'Terraform', 'AWS SageMaker'],
      deployment: ['GitHub Actions', 'ArgoCD', 'Seldon / BentoML'],
    },
    'Generative AI Engineer': {
      frontend: ['React', 'TypeScript', 'Next.js'],
      backend: ['FastAPI', 'Python', 'LangChain'],
      database: ['PostgreSQL', 'Pinecone', 'Redis'],
      aiAutomation: ['OpenAI / Claude / Gemini', 'Stable Diffusion', 'Hugging Face'],
      devopsCloud: ['Docker', 'AWS / GCP', 'Kubernetes'],
      deployment: ['Vercel', 'GitHub Actions', 'Modal / Replicate'],
    },
    'Machine Learning Engineer': {
      frontend: ['Streamlit', 'Gradio', 'React'],
      backend: ['FastAPI', 'Python', 'TorchServe'],
      database: ['PostgreSQL', 'Redis', 'S3'],
      aiAutomation: ['PyTorch', 'TensorFlow', 'scikit-learn', 'ONNX'],
      devopsCloud: ['Docker', 'AWS', 'Kubernetes'],
      deployment: ['GitHub Actions', 'MLflow', 'Triton Inference Server'],
    },
    'Data Scientist': {
      frontend: ['Streamlit', 'Plotly Dash', 'Tableau'],
      backend: ['Python', 'FastAPI', 'Jupyter'],
      database: ['PostgreSQL', 'BigQuery', 'Snowflake'],
      aiAutomation: ['scikit-learn', 'XGBoost', 'PyTorch', 'SHAP'],
      devopsCloud: ['Docker', 'AWS', 'Databricks'],
      deployment: ['MLflow', 'GitHub Actions', 'Airflow'],
    },
    'Data Analyst': {
      frontend: ['Metabase', 'Superset', 'Tableau', 'Power BI'],
      backend: ['Python', 'dbt', 'SQL'],
      database: ['PostgreSQL', 'BigQuery', 'Snowflake', 'Redshift'],
      aiAutomation: ['Pandas', 'Plotly', 'Great Expectations'],
      devopsCloud: ['dbt Cloud', 'Airflow', 'AWS'],
      deployment: ['Airbyte', 'Fivetran', 'GitHub Actions'],
    },
    'Data Engineer': {
      frontend: ['Airflow UI', 'Grafana', 'Streamlit'],
      backend: ['Python', 'Scala', 'Apache Spark', 'Kafka'],
      database: ['PostgreSQL', 'Snowflake', 'BigQuery', 'Delta Lake'],
      aiAutomation: ['Great Expectations', 'dbt', 'Soda'],
      devopsCloud: ['Kubernetes', 'Docker', 'AWS / GCP', 'Databricks'],
      deployment: ['Airflow', 'GitHub Actions', 'Terraform'],
    },
    'SRE / Platform Engineer': {
      frontend: ['Grafana', 'Backstage', 'React'],
      backend: ['Go', 'Python', 'Node.js'],
      database: ['PostgreSQL', 'InfluxDB', 'Redis'],
      aiAutomation: ['OpenTelemetry', 'Prometheus', 'AlertManager'],
      devopsCloud: ['Kubernetes', 'Terraform', 'AWS / GCP', 'Istio'],
      deployment: ['ArgoCD', 'GitHub Actions', 'Helm', 'PagerDuty'],
    },
    'DevOps Engineer': {
      frontend: ['Grafana', 'ArgoCD UI', 'Backstage'],
      backend: ['Python', 'Go', 'Bash'],
      database: ['PostgreSQL', 'Redis'],
      aiAutomation: ['Trivy', 'Snyk', 'SonarQube', 'OWASP ZAP'],
      devopsCloud: ['Kubernetes', 'Docker', 'Terraform', 'AWS / GCP / Azure'],
      deployment: ['GitHub Actions / GitLab CI', 'ArgoCD', 'Helm', 'Jenkins'],
    },
    'Cloud / Infrastructure Engineer': {
      frontend: ['Grafana', 'AWS Console', 'Backstage'],
      backend: ['Python', 'Go', 'Terraform CDK'],
      database: ['RDS', 'DynamoDB', 'S3'],
      aiAutomation: ['CloudWatch', 'AWS Config', 'Infracost'],
      devopsCloud: ['AWS / GCP / Azure', 'Terraform', 'Pulumi', 'CDK'],
      deployment: ['GitHub Actions', 'Atlantis', 'ArgoCD'],
    },
  };

  const base = stacks[role] || stacks['DevOps Engineer'];

  // Inject detected tools where appropriate
  if (detected.length > 0) {
    const extra = detected.filter(d => !Object.values(base).flat().some(b => b.toLowerCase().includes(d.toLowerCase())));
    if (extra.length > 0) base.devopsCloud = [...new Set([...extra.slice(0, 3), ...base.devopsCloud])].slice(0, 6);
  }

  return base;
}

function buildRoadmap(role: string): RoadmapPhase[] {
  const maps: Record<string, RoadmapPhase[]> = {
    'LLMOps / AI Engineer': [
      { phase: 1, title: 'MVP — Core Pipeline', tasks: ['Set up project structure and Docker environment', 'Implement document ingestion and chunking', 'Wire vector database and embedding model', 'Build basic RAG query endpoint', 'Add unit tests for retrieval logic'] },
      { phase: 2, title: 'Advanced Features', tasks: ['Add RAGAS evaluation framework', 'Implement hybrid search (semantic + keyword)', 'Add conversation memory and multi-turn support', 'Build prompt versioning system', 'Add streaming response support'] },
      { phase: 3, title: 'Production Polish', tasks: ['Add request tracing with OpenTelemetry', 'Implement rate limiting and auth middleware', 'Add hallucination detection guard', 'Build cost tracking per request', 'Load test and optimize for latency'] },
      { phase: 4, title: 'Deployment', tasks: ['Containerize with Docker Compose / Helm chart', 'Deploy to Kubernetes cluster', 'Set up CI/CD with GitHub Actions', 'Configure autoscaling on GPU/CPU nodes', 'Add monitoring dashboards in Grafana'] },
      { phase: 5, title: 'Portfolio Presentation', tasks: ['Write detailed README with architecture diagram', 'Record Loom demo walkthrough (under 5 minutes)', 'Publish evaluation results with benchmarks', 'Write case study: problem → approach → results', 'Pin to GitHub and add to LinkedIn featured'] },
    ],
    'MLOps Engineer': [
      { phase: 1, title: 'MVP — Pipeline Skeleton', tasks: ['Set up Airflow with Docker Compose', 'Create data ingestion DAG', 'Implement basic model training pipeline', 'Set up MLflow experiment tracking', 'Create model registry with staging/prod stages'] },
      { phase: 2, title: 'Advanced Features', tasks: ['Add drift detection with Evidently AI', 'Implement automated retraining trigger', 'Build feature store integration', 'Add A/B testing for model versions', 'Implement canary model deployment'] },
      { phase: 3, title: 'Production Polish', tasks: ['Add comprehensive pipeline alerting', 'Implement model performance SLOs', 'Add data quality checks with Great Expectations', 'Build cost tracking per training run', 'Stress test pipeline with high data volumes'] },
      { phase: 4, title: 'Deployment', tasks: ['Deploy on Kubernetes with Helm', 'Set up GitOps with ArgoCD', 'Configure Prometheus and Grafana dashboards', 'Implement secret management with Vault', 'Document runbooks for common failures'] },
      { phase: 5, title: 'Portfolio Presentation', tasks: ['Create architecture diagram with all components', 'Record end-to-end pipeline demo', 'Publish drift detection results with sample data', 'Write case study focusing on business impact', 'Create README with quickstart guide'] },
    ],
    'DevOps Engineer': [
      { phase: 1, title: 'MVP — Pipeline Scaffold', tasks: ['Set up GitHub Actions / GitLab CI workflow', 'Add build and unit test stage', 'Containerize application with Docker', 'Push image to container registry', 'Deploy to dev environment automatically'] },
      { phase: 2, title: 'Advanced Features', tasks: ['Add container vulnerability scanning with Trivy', 'Implement SAST with CodeQL', 'Set up Kubernetes deployment with Helm', 'Add blue-green or canary deployment', 'Implement automated rollback on health check failure'] },
      { phase: 3, title: 'Production Polish', tasks: ['Add end-to-end integration tests in pipeline', 'Implement secret management with Vault', 'Add Slack/Teams deployment notifications', 'Build deployment approval gate for production', 'Add pipeline performance monitoring'] },
      { phase: 4, title: 'Deployment', tasks: ['Deploy to cloud Kubernetes cluster (EKS/GKE)', 'Set up Terraform for infrastructure provisioning', 'Configure Prometheus/Grafana for pipeline metrics', 'Set up GitOps with ArgoCD', 'Document disaster recovery procedure'] },
      { phase: 5, title: 'Portfolio Presentation', tasks: ['Record live pipeline demo from push to deployed', 'Document security scan findings and fixes', 'Write case study: before vs after deployment stats', 'Create README with architecture and setup guide', 'Publish pipeline as reusable GitHub Actions template'] },
    ],
    'Data Engineer': [
      { phase: 1, title: 'MVP — Pipeline Basics', tasks: ['Set up Airflow with Docker Compose', 'Create source connection (API or DB)', 'Build basic ETL DAG', 'Load to staging table', 'Add basic data quality assertion'] },
      { phase: 2, title: 'Advanced Features', tasks: ['Add dbt transformation layer', 'Implement incremental processing', 'Add Great Expectations data quality suite', 'Set up data lineage tracking', 'Add streaming layer with Kafka'] },
      { phase: 3, title: 'Production Polish', tasks: ['Add SLA monitoring and breach alerts', 'Implement idempotent pipeline design', 'Add retry and dead letter queue for failures', 'Build data catalog metadata', 'Load test pipeline with large dataset'] },
      { phase: 4, title: 'Deployment', tasks: ['Deploy Airflow to Kubernetes', 'Set up CI/CD for dbt models', 'Configure cloud data warehouse', 'Implement access controls and audit logging', 'Set up Grafana pipeline health dashboard'] },
      { phase: 5, title: 'Portfolio Presentation', tasks: ['Create data architecture diagram', 'Record demo showing pipeline failure recovery', 'Publish dbt documentation site', 'Write case study with data quality metrics', 'Create README with sample dataset quickstart'] },
    ],
    'SRE / Platform Engineer': [
      { phase: 1, title: 'MVP — Observability Foundation', tasks: ['Deploy Prometheus + Grafana stack', 'Add OpenTelemetry instrumentation to sample app', 'Create basic service health dashboards', 'Set up AlertManager with basic rules', 'Define first SLO for a target service'] },
      { phase: 2, title: 'Advanced Features', tasks: ['Implement distributed tracing with Jaeger / Tempo', 'Add SLO error budget dashboards', 'Build log aggregation with Loki', 'Create runbook automation for common alerts', 'Implement chaos engineering experiments'] },
      { phase: 3, title: 'Production Polish', tasks: ['Add PagerDuty / OpsGenie routing', 'Build incident timeline reconstruction tool', 'Create capacity planning dashboards', 'Add cost attribution per service/team', 'Conduct and document a game day'] },
      { phase: 4, title: 'Deployment', tasks: ['Deploy full observability stack on Kubernetes', 'Set up GitOps management with ArgoCD', 'Configure high availability for Prometheus/Grafana', 'Implement Vault for secret management', 'Document on-call runbooks'] },
      { phase: 5, title: 'Portfolio Presentation', tasks: ['Create observability architecture diagram', 'Record MTTR improvement demo', 'Publish SLO dashboard as live demo', 'Write case study: reliability before vs after', 'Open source runbook templates on GitHub'] },
    ],
  };

  return maps[role] || maps['DevOps Engineer'];
}

function buildPositioning(role: string, project?: ProjectRecommendation): PortfolioPositioning {
  const title = project?.title || 'Production-Grade System';

  const headlines: Record<string, string> = {
    'LLMOps / AI Engineer': `Production RAG and LLM Pipeline Engineering for ${title}`,
    'MLOps Engineer': `End-to-End ML Automation: From Model Notebook to Production with ${title}`,
    'Generative AI Engineer': `Generative AI at Scale: Building Reliable, Production-Ready AI Products`,
    'Machine Learning Engineer': `ML Engineering That Ships: From Experimentation to Production with ${title}`,
    'Data Scientist': `Data Science That Moves the Needle: Statistical Modeling Tied to Business KPIs`,
    'Data Analyst': `Analytics Engineering: Turning Raw Data Into Trusted, Actionable Insights`,
    'Data Engineer': `Modern Data Engineering: Reliable Pipelines That Unblock Analytics and ML`,
    'SRE / Platform Engineer': `Platform Engineering for Developer Velocity and System Reliability`,
    'DevOps Engineer': `DevOps Engineering: Automated, Secure, Zero-Downtime Delivery Pipelines`,
    'Cloud / Infrastructure Engineer': `Cloud Architecture That Scales, Survives Failures, and Controls Costs`,
  };

  const caseStudies: Record<string, string> = {
    'LLMOps / AI Engineer': `How I Built a Production RAG System with 91% Answer Faithfulness and Full Observability`,
    'MLOps Engineer': `How I Automated Model Retraining to Eliminate Drift and Remove Manual ML Ops`,
    'Generative AI Engineer': `How I Built a GenAI Content Pipeline Generating 50k+ Weekly Assets with Quality Guardrails`,
    'Machine Learning Engineer': `How I Took a Classification Model from Notebook to Production Serving 500 RPS`,
    'Data Scientist': `How I Built a Churn Prediction Model That Enabled $200K in Prevented Revenue Loss`,
    'Data Analyst': `How I Standardized 25+ Business KPIs Using dbt, Eliminating Metric Discrepancies Across Teams`,
    'Data Engineer': `How I Built a Real-time Streaming Pipeline Processing 500k Events/Day with Zero Data Loss`,
    'SRE / Platform Engineer': `How I Reduced MTTR by 65% by Implementing SLO-Based Observability Across 15 Microservices`,
    'DevOps Engineer': `How I Eliminated Manual Deployments and Blocked 15 Critical Vulnerabilities with a DevSecOps Pipeline`,
    'Cloud / Infrastructure Engineer': `How I Built Multi-region Disaster Recovery Achieving 99.99% Availability with <60 Second RTO`,
  };

  const problems: Record<string, string> = {
    'LLMOps / AI Engineer': 'LLM outputs were inconsistent, hallucination-prone, and had no observability — production was blocked.',
    'MLOps Engineer': 'ML models were trained manually in notebooks and never updated — performance decayed silently in production.',
    'Generative AI Engineer': 'GenAI demos existed but couldn\'t scale — quality was unpredictable and there were no guardrails for production.',
    'Machine Learning Engineer': 'Models achieved great accuracy in evaluation but failed silently in production due to data pipeline issues.',
    'Data Scientist': 'Business decisions were based on gut feeling with no statistical validation or predictive capability.',
    'Data Analyst': 'Each team had different numbers for the same metrics — no one trusted the data, so reports were ignored.',
    'Data Engineer': 'Pipelines were a collection of untested scripts that broke regularly, blocking both analytics and ML teams.',
    'SRE / Platform Engineer': 'Incidents were discovered by users — teams had no visibility, no SLOs, and no structured incident response.',
    'DevOps Engineer': 'Deployments took hours and required manual steps — one wrong command could break production with no rollback.',
    'Cloud / Infrastructure Engineer': 'Infrastructure was click-ops with no version control — impossible to replicate environments or trace changes.',
  };

  const solutions: Record<string, string> = {
    'LLMOps / AI Engineer': 'Built a production RAG system with RAGAS evaluation, vector search, prompt versioning, and OpenTelemetry tracing.',
    'MLOps Engineer': 'Implemented a full MLOps pipeline with automated drift detection, retraining triggers, and zero-downtime model deployment.',
    'Generative AI Engineer': 'Designed a GenAI content pipeline with quality scoring, content moderation, brand voice enforcement, and batch processing.',
    'Machine Learning Engineer': 'Delivered end-to-end ML system from feature engineering through model serving with monitoring and auto-retraining.',
    'Data Scientist': 'Built predictive models with proper cross-validation, SHAP explainability, and stakeholder-facing dashboards.',
    'Data Analyst': 'Created a dbt analytics layer with a single metrics definition, automated testing, and self-service dashboards.',
    'Data Engineer': 'Built modular, tested, idempotent pipelines with SLA monitoring, data quality checks, and automated failure recovery.',
    'SRE / Platform Engineer': 'Deployed full observability stack with SLO tracking, distributed tracing, runbook automation, and PagerDuty integration.',
    'DevOps Engineer': 'Built a DevSecOps pipeline with multi-stage security scanning, blue-green deployments, and automated rollback.',
    'Cloud / Infrastructure Engineer': 'Provisioned multi-region infrastructure with Terraform, automated failover, cost controls, and one-command DR activation.',
  };

  const impacts: Record<string, string> = {
    'LLMOps / AI Engineer': '91% answer faithfulness score, full cost and latency visibility, and production LLM serving at scale with confidence.',
    'MLOps Engineer': '90% reduction in manual ML ops work, continuous model freshness, and auditable model lineage across all production models.',
    'Generative AI Engineer': '50k+ weekly assets generated with 94% quality score, zero brand safety violations, and 3x faster content production.',
    'Machine Learning Engineer': '94%+ model accuracy in production, automated retraining on drift, and sub-50ms inference latency at 500 RPS.',
    'Data Scientist': 'Predictive models enabling measurable business outcomes with stakeholder buy-in from SHAP-based explainability.',
    'Data Analyst': '60% reduction in analyst query time, zero metric discrepancies, and executive dashboard refreshing automatically every morning.',
    'Data Engineer': 'Sub-500ms end-to-end pipeline latency, zero data loss, and analytics team unblocked from days to minutes.',
    'SRE / Platform Engineer': '65% reduction in MTTR, 99.99% SLO achievement, and proactive reliability replacing reactive incident response.',
    'DevOps Engineer': 'Multiple daily deployments with zero-downtime releases, 15 critical vulnerabilities blocked, and MTTR under 5 minutes.',
    'Cloud / Infrastructure Engineer': '99.99% availability with <60 second RTO, 35% cloud cost reduction, and fully reproducible infrastructure.',
  };

  const demoScripts: Record<string, string> = {
    'LLMOps / AI Engineer': `"I am going to walk you through the complete RAG pipeline I built. First, I upload a PDF document — watch how it gets chunked, embedded, and stored in the vector database. Now I ask a question. See how the retrieval pulls the exact relevant chunks before sending to the LLM. Notice the RAGAS hallucination score in the response — that is live evaluation. Finally, here is the cost and latency dashboard tracking every single request."`,
    'MLOps Engineer': `"Here is the full MLOps pipeline. I will simulate a data distribution shift — watch the drift detection trigger an alert within 30 seconds. Now ArgoCD automatically kicks off a retraining job. The new model is evaluated against the current production model — only if it wins does it promote. I just did a zero-downtime model swap. Let me show you the MLflow experiment comparison."`,
    'DevOps Engineer': `"I am going to push a commit right now. Watch the pipeline: first the tests run — green. Now the Docker image builds and Trivy scans for vulnerabilities. All clear. Now it deploys using blue-green — traffic shifts from old to new version with zero downtime. I will simulate a failure — and watch the rollback trigger automatically. The whole process from push to live is under 4 minutes."`,
    'Data Engineer': `"I will walk you through the full data pipeline. A new batch of events arrives from Kafka. The Airflow DAG picks it up, runs transformation through dbt, and validates with Great Expectations. I will inject a bad record — watch the quality check catch it and route it to the quarantine table. The main pipeline continues unaffected. Here is the Grafana dashboard showing SLA compliance for the last 30 days."`,
    'SRE / Platform Engineer': `"I am going to kill a pod in our Kubernetes cluster right now. Watch the Prometheus alert fire within 15 seconds. The runbook link in the alert takes you directly to the documented resolution steps. Here is the distributed trace showing exactly where the latency spike originated. And this is the error budget dashboard — we have consumed 12% this month, so the team gets notified before we breach our SLO."`,
  };

  const linkedInPosts: Record<string, string> = {
    'LLMOps / AI Engineer': `Just shipped a production RAG system with full evaluation infrastructure.\n\nMost LLM demos look impressive. Most production LLM systems fail silently.\n\nHere is what I built to fix that:\n- Hybrid semantic + keyword retrieval\n- RAGAS hallucination scoring on every response\n- Token cost tracking per request\n- Prompt version control with rollback\n- Full OpenTelemetry tracing\n\nThe result: 91% answer faithfulness. Every request auditable.\n\nIf you are building LLM systems that need to actually work, not just demo well — this is the architecture.\n\n[Link to GitHub]`,
    'MLOps Engineer': `Models in notebooks are not MLOps. This is MLOps.\n\nI built an end-to-end ML pipeline that:\n- Detects data drift automatically\n- Triggers retraining without human intervention\n- Evaluates the new model against production\n- Deploys with zero downtime only if it wins\n- Rolls back in 30 seconds if something goes wrong\n\n90% less manual work. Full model lineage. No silent degradation.\n\nThis is what production ML looks like.\n\n[Link to GitHub]`,
    'DevOps Engineer': `Pushed a commit. 4 minutes later it was live in production. Zero downtime.\n\nHere is what happened in between:\n- Unit and integration tests\n- Docker build and image scan (Trivy found 0 critical CVEs)\n- SAST with CodeQL\n- Blue-green deployment with health checks\n- Automatic rollback armed and ready\n\nThis is the pipeline every engineering team deserves.\n\nI open-sourced the GitHub Actions template — link in comments.\n\n[Link to GitHub]`,
    'Data Engineer': `Data pipelines that break silently are not pipelines. They are technical debt with a scheduler.\n\nI built one that doesn not break silently:\n- Idempotent design — safe to rerun any time\n- Great Expectations data quality on every batch\n- Dead letter queue for bad records\n- SLA monitoring with automatic alerts\n- Full lineage from source to BI tool\n\nThe analytics team stopped asking "is the data fresh?" They just know it is.\n\n[Link to GitHub]`,
    'SRE / Platform Engineer': `Your users should not be your monitoring system.\n\nI built an observability platform that changed how a team runs on-call:\n- SLO error budgets replacing vanity uptime metrics\n- Distributed tracing cutting RCA time from hours to minutes\n- Runbook automation resolving 40% of alerts without human action\n- MTTR dropped 65%\n\nReliability engineering is not about responding faster. It is about understanding your system deeply enough to prevent incidents.\n\n[Link to GitHub]`,
  };

  return {
    projectHeadline: headlines[role] || `Production-Grade ${title}`,
    caseStudyTitle: caseStudies[role] || `How I Built ${title} for Real-World Impact`,
    problem: problems[role] || 'Manual, error-prone processes were blocking engineering velocity and causing production incidents.',
    solution: solutions[role] || 'Built a fully automated, production-grade system with monitoring, testing, and CI/CD.',
    impact: impacts[role] || 'Faster delivery, higher reliability, and measurable business outcome improvement.',
    demoScript: demoScripts[role] || `"Let me walk you through ${title} — I will show you the architecture, a live demo, and the key metrics."`,
    linkedInPost: linkedInPosts[role] || `Just shipped ${title}. Here is what I built and why it matters for production engineering teams.\n\n[Link to GitHub]`,
  };
}
