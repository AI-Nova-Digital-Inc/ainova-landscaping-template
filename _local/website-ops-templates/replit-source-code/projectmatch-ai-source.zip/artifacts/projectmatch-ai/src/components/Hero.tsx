import React from 'react';
import { Button } from '@/components/ui/button';
import { ChevronDown } from 'lucide-react';
import { motion } from 'framer-motion';

export function Hero() {
  const scrollToInput = () => {
    document.getElementById('input-panel')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-4 text-center">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-4xl mx-auto space-y-6"
      >
        <div className="inline-flex items-center rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-sm font-medium text-primary mb-6">
          <span className="flex h-2 w-2 rounded-full bg-primary mr-2 animate-pulse"></span>
          AI-Powered Portfolio Blueprint
        </div>
        
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight text-foreground drop-shadow-sm">
          Turn Job Postings Into <br className="hidden md:block" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Projects That Win Clients</span>
        </h1>
        
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
          Paste any freelance or job posting and get real-world project ideas, tech stacks, roadmaps, and proposal angles — engineered for your success.
        </p>
        
        <div className="pt-8">
          <Button 
            size="lg" 
            className="rounded-full h-14 px-8 text-lg bg-primary text-primary-foreground hover:bg-primary/90 glow-border"
            onClick={scrollToInput}
          >
            Analyze a Posting
            <ChevronDown className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </motion.div>
    </section>
  );
}
