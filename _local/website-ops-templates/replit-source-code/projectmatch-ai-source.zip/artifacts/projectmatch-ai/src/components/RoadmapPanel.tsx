import React from 'react';
import { motion } from 'framer-motion';
import { RoadmapPhase } from '../types';
import { GitCommit, Circle } from 'lucide-react';

interface RoadmapPanelProps {
  roadmap: RoadmapPhase[] | null;
}

export function RoadmapPanel({ roadmap }: RoadmapPanelProps) {
  if (!roadmap) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-panel rounded-2xl p-6 md:p-8"
    >
      <div className="flex items-center gap-3 mb-8">
        <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
          <GitCommit className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-foreground">Execution Roadmap</h2>
          <p className="text-sm text-muted-foreground">Step-by-step build plan</p>
        </div>
      </div>

      <div className="relative border-l border-white/10 ml-3 md:ml-4 space-y-8 pb-4">
        {roadmap.map((phase, index) => (
          <div key={phase.phase} className="relative pl-8 md:pl-10">
            {/* Timeline node */}
            <div className="absolute left-[-9px] top-1 h-4 w-4 rounded-full bg-background border-2 border-primary ring-4 ring-background flex items-center justify-center">
              <Circle className="h-1.5 w-1.5 fill-primary text-primary" />
            </div>

            <div className="bg-background/40 border border-white/5 rounded-xl p-5 hover:bg-background/60 transition-colors">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-xs font-bold text-primary tracking-widest uppercase bg-primary/10 px-2 py-1 rounded">
                  Phase {phase.phase}
                </span>
                <h3 className="text-lg font-semibold text-foreground">{phase.title}</h3>
              </div>
              
              <ul className="space-y-2 mt-4">
                {phase.tasks.map((task, i) => (
                  <li key={i} className="text-sm text-muted-foreground flex items-start">
                    <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/50 mt-1.5 mr-2 shrink-0" />
                    {task}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
