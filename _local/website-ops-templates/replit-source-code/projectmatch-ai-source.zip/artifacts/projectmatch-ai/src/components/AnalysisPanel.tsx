import React from 'react';
import { motion } from 'framer-motion';
import { JobAnalysis } from '../types';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Target, AlertCircle, Briefcase, Zap, CircleDollarSign } from 'lucide-react';

interface AnalysisPanelProps {
  analysis: JobAnalysis | null;
}

export function AnalysisPanel({ analysis }: AnalysisPanelProps) {
  if (!analysis) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-4xl mx-auto px-4 mt-12 w-full"
    >
      <div className="glass-panel rounded-2xl p-6 md:p-8 glow-border">
        <div className="flex items-center gap-3 mb-6 pb-6 border-b border-white/10">
          <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
            <Zap className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-foreground">AI Intelligence Report</h2>
            <p className="text-sm text-muted-foreground">Deconstructed job requirements</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-2 flex items-center"><Briefcase className="w-4 h-4 mr-2"/> Detected Role</h3>
              <p className="text-lg font-semibold">{analysis.role}</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-2 flex items-center"><AlertCircle className="w-4 h-4 mr-2"/> Core Client Problem</h3>
              <p className="text-md text-foreground/90">{analysis.clientProblem}</p>
            </div>

            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-2 flex items-center"><Target className="w-4 h-4 mr-2"/> Desired Business Outcome</h3>
              <p className="text-md text-foreground/90">{analysis.businessOutcome}</p>
            </div>
          </div>

          <div className="space-y-6 bg-background/30 rounded-xl p-5 border border-white/5">
            <div>
              <div className="flex justify-between mb-2">
                <h3 className="text-sm font-medium text-muted-foreground">Opportunity Score</h3>
                <span className="text-sm font-bold text-primary">{analysis.opportunityScore}/100</span>
              </div>
              <Progress value={analysis.opportunityScore} className="h-2 bg-white/10" indicatorClassName="bg-primary" />
            </div>

            <div className="grid grid-cols-2 gap-4 pt-2">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-1">Difficulty</h3>
                <Badge variant="outline" className="bg-white/5 border-white/10">{analysis.difficultyLevel}</Badge>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-1 flex items-center"><CircleDollarSign className="w-3 h-3 mr-1"/> Budget Potential</h3>
                <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">{analysis.budgetPotential}</Badge>
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-2">Required Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {analysis.requiredSkills.map(skill => (
                    <Badge key={skill} className="bg-accent/20 text-accent-foreground hover:bg-accent/30">{skill}</Badge>
                  ))}
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-2">Tools Mentioned</h3>
                <div className="flex flex-wrap gap-2">
                  {analysis.toolsMentioned.map(tool => (
                    <Badge key={tool} variant="secondary" className="bg-secondary text-secondary-foreground">{tool}</Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
