import React from 'react';
import { ProjectRecommendation } from '../types';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Bookmark, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface SavedProjectsSidebarProps {
  savedProjects: ProjectRecommendation[];
  onRemove: (id: string) => void;
}

export function SavedProjectsSidebar({ savedProjects, onRemove }: SavedProjectsSidebarProps) {
  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button 
          variant="outline" 
          size="icon" 
          className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-2xl bg-card border-white/10 hover:bg-card/80 z-50 glow-border"
        >
          <div className="relative">
            <Bookmark className="h-6 w-6 text-primary" />
            {savedProjects.length > 0 && (
              <span className="absolute -top-2 -right-2 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                {savedProjects.length}
              </span>
            )}
          </div>
        </Button>
      </SheetTrigger>
      
      <SheetContent className="w-full sm:max-w-md border-l border-white/10 bg-background/95 backdrop-blur-xl flex flex-col h-full">
        <SheetHeader className="mb-6">
          <SheetTitle className="text-xl flex items-center">
            <Bookmark className="h-5 w-5 mr-2 text-primary" />
            Saved Projects
          </SheetTitle>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto space-y-4 pr-4">
          {savedProjects.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Bookmark className="h-12 w-12 mx-auto mb-4 opacity-20" />
              <p>No saved projects yet.</p>
              <p className="text-sm mt-2">Analyze a job posting to get started.</p>
            </div>
          ) : (
            savedProjects.map((project) => (
              <div key={project.id} className="p-4 rounded-xl bg-card border border-white/5 relative group">
                <h4 className="font-semibold text-foreground pr-8 mb-2">{project.title}</h4>
                <div className="flex gap-2 mb-3">
                  <Badge variant="outline" className="bg-primary/10 text-primary text-xs">
                    Score: {project.portfolioValueScore}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {project.difficulty}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground line-clamp-2">
                  {project.matchReason}
                </p>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 h-8 w-8 text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => onRemove(project.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
