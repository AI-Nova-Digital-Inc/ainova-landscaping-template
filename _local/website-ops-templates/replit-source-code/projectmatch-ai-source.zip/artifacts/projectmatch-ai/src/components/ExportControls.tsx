import React from 'react';
import { AnalysisResult } from '../types';
import { Button } from '@/components/ui/button';
import { Download, Copy, Share2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ExportControlsProps {
  result: AnalysisResult | null;
}

export function ExportControls({ result }: ExportControlsProps) {
  const { toast } = useToast();

  if (!result) return null;

  const handleExportMarkdown = () => {
    let md = `# ProjectMatch AI Analysis: ${result.analysis.role}\n\n`;
    md += `## Job Intel\n`;
    md += `- **Problem:** ${result.analysis.clientProblem}\n`;
    md += `- **Outcome:** ${result.analysis.businessOutcome}\n`;
    md += `- **Skills:** ${result.analysis.requiredSkills.join(', ')}\n\n`;

    md += `## Recommended Projects\n`;
    result.recommendations.forEach(r => {
      md += `### ${r.title}\n`;
      md += `- ${r.matchReason}\n`;
      md += `- **Stack:** ${r.techStack.join(', ')}\n\n`;
    });

    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'project-blueprint.md';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Export Successful",
      description: "Markdown file downloaded.",
    });
  };

  const handleCopyPlan = () => {
    const text = `Project Plan for: ${result.analysis.role}\nBased on matching skills: ${result.analysis.requiredSkills.join(', ')}`;
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied Plan",
      description: "Copied summary to clipboard.",
    });
  };

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 glass-panel px-4 py-3 rounded-full flex items-center gap-2 z-40 border border-white/10 shadow-2xl">
      <Button variant="ghost" size="sm" onClick={handleExportMarkdown} className="hover:bg-primary/20 hover:text-primary">
        <Download className="w-4 h-4 mr-2" />
        <span className="hidden sm:inline">Export MD</span>
      </Button>
      <div className="w-px h-6 bg-white/10 mx-1"></div>
      <Button variant="ghost" size="sm" onClick={handleCopyPlan} className="hover:bg-primary/20 hover:text-primary">
        <Copy className="w-4 h-4 mr-2" />
        <span className="hidden sm:inline">Copy Plan</span>
      </Button>
      <div className="w-px h-6 bg-white/10 mx-1"></div>
      <Button variant="ghost" size="sm" onClick={() => toast({ title: "Share link generated", description: "Copied to clipboard" })} className="hover:bg-primary/20 hover:text-primary">
        <Share2 className="w-4 h-4 mr-2" />
        <span className="hidden sm:inline">Share</span>
      </Button>
    </div>
  );
}
