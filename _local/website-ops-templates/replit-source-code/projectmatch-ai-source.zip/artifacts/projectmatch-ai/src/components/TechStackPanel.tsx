import React from 'react';
import { motion } from 'framer-motion';
import { TechStackBreakdown } from '../types';
import { Layers } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface TechStackPanelProps {
  techStack: TechStackBreakdown | null;
}

export function TechStackPanel({ techStack }: TechStackPanelProps) {
  if (!techStack) return null;

  const categories = [
    { key: 'frontend', label: 'Frontend', color: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
    { key: 'backend', label: 'Backend', color: 'bg-green-500/10 text-green-400 border-green-500/20' },
    { key: 'database', label: 'Database', color: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20' },
    { key: 'aiAutomation', label: 'AI & Automation', color: 'bg-purple-500/10 text-purple-400 border-purple-500/20' },
    { key: 'devopsCloud', label: 'DevOps & Cloud', color: 'bg-orange-500/10 text-orange-400 border-orange-500/20' },
    { key: 'deployment', label: 'Deployment', color: 'bg-teal-500/10 text-teal-400 border-teal-500/20' },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-panel rounded-2xl p-6 md:p-8"
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="h-10 w-10 rounded-full bg-accent/20 flex items-center justify-center">
          <Layers className="h-5 w-5 text-accent" />
        </div>
        <h2 className="text-xl font-bold text-foreground">Recommended Tech Stack</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((cat) => {
          const items = techStack[cat.key as keyof TechStackBreakdown];
          if (!items || items.length === 0) return null;

          return (
            <div key={cat.key} className="space-y-3 p-4 rounded-xl bg-background/30 border border-white/5">
              <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">{cat.label}</h3>
              <div className="flex flex-wrap gap-2">
                {items.map(item => (
                  <Badge key={item} variant="outline" className={cat.color}>
                    {item}
                  </Badge>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}
