import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sparkles, Loader2 } from 'lucide-react';

interface InputPanelProps {
  onAnalyze: (text: string, platform: string) => void;
  isAnalyzing: boolean;
}

export function InputPanel({ onAnalyze, isAnalyzing }: InputPanelProps) {
  const [text, setText] = useState('');
  const [platform, setPlatform] = useState('upwork');

  const handleSubmit = () => {
    if (!text.trim()) return;
    onAnalyze(text, platform);
  };

  return (
    <section id="input-panel" className="max-w-4xl mx-auto px-4 w-full relative z-10">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="glass-panel rounded-2xl p-6 md:p-8"
      >
        <div className="space-y-6">
          <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
            <h2 className="text-2xl font-semibold flex items-center">
              <Sparkles className="mr-2 h-5 w-5 text-primary" />
              Job Description
            </h2>
            <div className="w-full md:w-48">
              <Select value={platform} onValueChange={setPlatform}>
                <SelectTrigger className="bg-background/50 border-white/10">
                  <SelectValue placeholder="Select Platform" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="upwork">Upwork</SelectItem>
                  <SelectItem value="fiverr">Fiverr</SelectItem>
                  <SelectItem value="linkedin">LinkedIn</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Textarea 
            placeholder="Paste the full job description or client request here..."
            className="min-h-[200px] bg-background/50 border-white/10 resize-y text-base focus-visible:ring-primary/50"
            value={text}
            onChange={(e) => setText(e.target.value)}
          />

          <div className="flex justify-end">
            <Button 
              size="lg" 
              className="w-full md:w-auto h-12 px-8 bg-primary hover:bg-primary/90 text-primary-foreground font-medium"
              onClick={handleSubmit}
              disabled={!text.trim() || isAnalyzing}
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Analyzing Job Posting...
                </>
              ) : (
                'Analyze Job Posting'
              )}
            </Button>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
