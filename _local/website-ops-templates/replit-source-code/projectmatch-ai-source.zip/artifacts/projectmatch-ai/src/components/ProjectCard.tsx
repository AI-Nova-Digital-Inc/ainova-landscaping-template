import React from 'react';
import { motion } from 'framer-motion';
import { ProjectRecommendation } from '../types';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { BookmarkPlus, Clock, Target, CheckCircle2, ChevronRight, FileText } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ProjectCardProps {
  project: ProjectRecommendation;
  onSave: (project: ProjectRecommendation) => void;
  isSaved: boolean;
  index: number;
}

export function ProjectCard({ project, onSave, isSaved, index }: ProjectCardProps) {
  const { toast } = useToast();

  const handleSave = () => {
    onSave(project);
    if (!isSaved) {
      toast({
        title: "Project Saved",
        description: "Added to your portfolio ideas.",
      });
    }
  };

  const difficultyColors = {
    Beginner: "bg-green-500/10 text-green-500 border-green-500/20",
    Intermediate: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
    Advanced: "bg-orange-500/10 text-orange-500 border-orange-500/20",
    Expert: "bg-red-500/10 text-red-500 border-red-500/20",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      className="glass-panel rounded-2xl p-6 relative overflow-hidden group"
    >
      {/* Decorative gradient blob */}
      <div className="absolute top-0 right-0 -mt-10 -mr-10 w-32 h-32 bg-primary/10 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

      <div className="flex justify-between items-start mb-4 relative z-10">
        <h3 className="text-xl font-bold text-foreground pr-8">{project.title}</h3>
        <Button 
          variant="ghost" 
          size="icon" 
          className={`shrink-0 transition-colors ${isSaved ? 'text-primary' : 'text-muted-foreground hover:text-primary'}`}
          onClick={handleSave}
        >
          <BookmarkPlus className={`h-5 w-5 ${isSaved ? 'fill-primary' : ''}`} />
        </Button>
      </div>

      <div className="flex flex-wrap gap-2 mb-6 relative z-10">
        <Badge variant="outline" className={difficultyColors[project.difficulty]}>
          {project.difficulty}
        </Badge>
        <Badge variant="outline" className="bg-white/5 border-white/10 text-muted-foreground flex items-center">
          <Clock className="w-3 h-3 mr-1" />
          {project.estimatedBuildTime}
        </Badge>
        <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 flex items-center">
          Score: {project.portfolioValueScore}
        </Badge>
      </div>

      <div className="space-y-4 mb-6 relative z-10 text-sm">
        <div>
          <span className="font-semibold text-foreground/90 block mb-1">Why this matches:</span>
          <p className="text-muted-foreground leading-relaxed">{project.matchReason}</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <span className="font-semibold text-foreground/90 block mb-1">Problem Solved:</span>
            <p className="text-muted-foreground">{project.problemSolved}</p>
          </div>
          <div>
            <span className="font-semibold text-foreground/90 block mb-1">Target Client:</span>
            <p className="text-muted-foreground flex items-center">
              <Target className="w-3 h-3 mr-1 text-primary" />
              {project.targetClient}
            </p>
          </div>
        </div>

        <div>
          <span className="font-semibold text-foreground/90 block mb-2">Features to Build:</span>
          <ul className="space-y-1">
            {project.featuresToBuild.map((feature, i) => (
              <li key={i} className="text-muted-foreground flex items-start">
                <CheckCircle2 className="w-4 h-4 mr-2 text-primary shrink-0 mt-0.5" />
                {feature}
              </li>
            ))}
          </ul>
        </div>

        <div>
          <span className="font-semibold text-foreground/90 block mb-2">Tech Stack:</span>
          <div className="flex flex-wrap gap-1.5">
            {project.techStack.map(tech => (
              <Badge key={tech} variant="secondary" className="bg-secondary/50 text-xs py-0 h-5">
                {tech}
              </Badge>
            ))}
          </div>
        </div>
      </div>

      <Accordion type="single" collapsible className="relative z-10 w-full">
        <AccordionItem value="details" className="border-white/10">
          <AccordionTrigger className="text-sm font-medium hover:no-underline text-primary hover:text-primary/80 py-2">
            View Execution Details
          </AccordionTrigger>
          <AccordionContent className="space-y-4 pt-4">
            <div className="bg-background/30 rounded-lg p-4 border border-white/5">
              <span className="font-semibold text-foreground block mb-2 flex items-center">
                <FileText className="w-4 h-4 mr-2 text-accent" />
                Resume Bullet
              </span>
              <p className="text-sm text-muted-foreground">{project.resumeBullet}</p>
            </div>

            <div>
              <span className="font-semibold text-foreground block mb-2">Demo Highlights:</span>
              <ul className="space-y-1">
                {project.demoHighlights.map((demo, i) => (
                  <li key={i} className="text-sm text-muted-foreground flex items-center">
                    <ChevronRight className="w-3 h-3 mr-1 text-accent" />
                    {demo}
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <span className="font-semibold text-foreground block mb-2">Proposal Angle:</span>
              <p className="text-sm text-muted-foreground italic border-l-2 border-primary/50 pl-3">
                "{project.proposalAngle}"
              </p>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </motion.div>
  );
}
