import React from 'react';
import { motion } from 'framer-motion';
import { PortfolioPositioning as PositioningType } from '../types';
import { Megaphone, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface PortfolioPositioningProps {
  positioning: PositioningType | null;
}

export function PortfolioPositioning({ positioning }: PortfolioPositioningProps) {
  const { toast } = useToast();
  const [copiedScript, setCopiedScript] = React.useState(false);
  const [copiedPost, setCopiedPost] = React.useState(false);

  if (!positioning) return null;

  const copyToClipboard = (text: string, type: 'script' | 'post') => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "Text is ready to paste.",
    });
    
    if (type === 'script') {
      setCopiedScript(true);
      setTimeout(() => setCopiedScript(false), 2000);
    } else {
      setCopiedPost(true);
      setTimeout(() => setCopiedPost(false), 2000);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-panel rounded-2xl p-6 md:p-8"
    >
      <div className="flex items-center gap-3 mb-8">
        <div className="h-10 w-10 rounded-full bg-accent/20 flex items-center justify-center">
          <Megaphone className="h-5 w-5 text-accent" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-foreground">Portfolio Positioning</h2>
          <p className="text-sm text-muted-foreground">How to sell this to clients</p>
        </div>
      </div>

      <div className="space-y-8">
        <div className="text-center space-y-2 p-6 bg-background/50 rounded-xl border border-white/5">
          <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Project Headline</h3>
          <p className="text-2xl md:text-3xl font-bold text-foreground font-display">{positioning.projectHeadline}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-5 rounded-xl bg-background/30 border border-white/5">
            <h4 className="text-primary font-semibold mb-2">1. The Problem</h4>
            <p className="text-sm text-muted-foreground">{positioning.problem}</p>
          </div>
          <div className="p-5 rounded-xl bg-background/30 border border-white/5">
            <h4 className="text-accent font-semibold mb-2">2. The Solution</h4>
            <p className="text-sm text-muted-foreground">{positioning.solution}</p>
          </div>
          <div className="p-5 rounded-xl bg-background/30 border border-white/5">
            <h4 className="text-green-400 font-semibold mb-2">3. The Impact</h4>
            <p className="text-sm text-muted-foreground">{positioning.impact}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <h4 className="font-semibold text-foreground">Loom Demo Script</h4>
              <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={() => copyToClipboard(positioning.demoScript, 'script')}>
                {copiedScript ? <Check className="w-3 h-3 mr-1" /> : <Copy className="w-3 h-3 mr-1" />}
                Copy
              </Button>
            </div>
            <div className="p-4 rounded-xl bg-muted/30 border border-white/5 text-sm text-muted-foreground font-mono leading-relaxed">
              "{positioning.demoScript}"
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <h4 className="font-semibold text-foreground">LinkedIn Post Idea</h4>
              <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={() => copyToClipboard(positioning.linkedInPost, 'post')}>
                {copiedPost ? <Check className="w-3 h-3 mr-1" /> : <Copy className="w-3 h-3 mr-1" />}
                Copy
              </Button>
            </div>
            <div className="p-4 rounded-xl bg-muted/30 border border-white/5 text-sm text-muted-foreground font-mono leading-relaxed whitespace-pre-wrap">
              {positioning.linkedInPost}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
