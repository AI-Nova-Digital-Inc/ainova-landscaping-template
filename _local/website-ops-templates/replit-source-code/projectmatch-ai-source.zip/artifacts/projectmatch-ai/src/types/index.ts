export interface JobAnalysis {
  role: string;
  clientProblem: string;
  requiredSkills: string[];
  toolsMentioned: string[];
  businessOutcome: string;
  difficultyLevel: 'Low' | 'Medium' | 'High' | 'Expert';
  budgetPotential: 'Low' | 'Medium' | 'High';
  opportunityScore: number; // 1-100
}

export interface ProjectRecommendation {
  id: string;
  title: string;
  matchReason: string;
  problemSolved: string;
  targetClient: string;
  techStack: string[];
  featuresToBuild: string[];
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert';
  estimatedBuildTime: string;
  portfolioValueScore: number; // 1-100
  demoHighlights: string[];
  readmeOutline: string[];
  resumeBullet: string;
  proposalAngle: string;
}

export interface TechStackBreakdown {
  frontend: string[];
  backend: string[];
  database: string[];
  aiAutomation: string[];
  devopsCloud: string[];
  deployment: string[];
}

export interface RoadmapPhase {
  phase: number;
  title: string;
  tasks: string[];
}

export interface PortfolioPositioning {
  projectHeadline: string;
  caseStudyTitle: string;
  problem: string;
  solution: string;
  impact: string;
  demoScript: string;
  linkedInPost: string;
}

export interface AnalysisResult {
  analysis: JobAnalysis;
  recommendations: ProjectRecommendation[];
  techStack: TechStackBreakdown;
  roadmap: RoadmapPhase[];
  positioning: PortfolioPositioning;
}
